---
title: "BS - Skyblox Islands"
source: "Game Stuff/Game Ideas/BS - Skyblox Islands"
modified: 2015-12-21
type: notes
area: game-idea
status: "idea"
projects: ["[[Minecraft & Voxel Building]]"]
concepts: ["Minecraft ideas"]
words: 134
summary: "Small note on island regeneration options for a Skyblock-like game; includes a table."
tags: ["area/game-idea", "project/minecraft-voxel-building", "type/notes"]
---

Island Combinations

Current Options

- each island has a one use part which is spawned at the start of the level

- each island has a small area 3x3x3 which is regenerated every 5-10 minutes

- each island can and should include a mob spawner in its regen section

- each island can include some rare resources in its regen section

- first get resources can be included in the initial section of an island

<table>
<colgroup>
<col style="width: 22%" />
<col style="width: 40%" />
<col style="width: 37%" />
</colgroup>
<thead>
<tr class="header">
<th>Regen</th>
<th>Initial</th>
<th>Monster</th>
</tr>
<tr class="odd">
<th>Diamond Ore</th>
<th>Diorite Stone and Stone walls</th>
<th>Creeper</th>
</tr>
<tr class="header">
<th>Wood</th>
<th><p>Sand</p>
<p>Sandstone</p></th>
<th>Skeleton</th>
</tr>
<tr class="odd">
<th>Cobble</th>
<th>Bricks and Mossy Cobblestone</th>
<th>Zombie</th>
</tr>
<tr class="header">
<th>Iron Ore</th>
<th>Granite Stone decoration</th>
<th>Spider</th>
</tr>
<tr class="odd">
<th>Coal Ore</th>
<th></th>
<th>Cave Spider</th>
</tr>
<tr class="header">
<th>Leaves</th>
<th></th>
<th>Ghast</th>
</tr>
<tr class="odd">
<th>Wood</th>
<th></th>
<th>Blaze</th>
</tr>
<tr class="header">
<th>Redstone Ore</th>
<th></th>
<th>Magma Slime</th>
</tr>
<tr class="odd">
<th>Gold Ore</th>
<th></th>
<th>Witch</th>
</tr>
<tr class="header">
<th>Lapis Ore</th>
<th></th>
<th>Enderman</th>
</tr>
<tr class="odd">
<th>Emerald Ore</th>
<th></th>
<th>Wither Skeleton</th>
</tr>
<tr class="header">
<th>Quartz Ore</th>
<th></th>
<th>Zombie Pigman</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th>Guardian</th>
</tr>
<tr class="header">
<th>Obsidian</th>
<th></th>
<th>Endermite</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th>Silverfish</th>
</tr>
<tr class="header">
<th></th>
<th></th>
<th>Zombie</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th>Zombie</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
