---
title: "BS - Minecraft Realm Ideas"
source: "Game Stuff/Game Ideas/BS - Minecraft Realm Ideas"
modified: 2018-03-21
type: design-doc
area: game-idea
status: "idea"
projects: ["[[Minecraft & Voxel Building]]"]
concepts: ["Minecraft ideas", "Design: Geographic Class Selection"]
words: 1330
summary: "Ideas for a Minecraft server/realm: exploration drivers, random structures, geographic classes, player infrastructure, respawn rules, and a modding plan to gamify Minecraft (enemies, hunger, farming, death, crafting)."
tags: ["area/game-idea", "project/minecraft-voxel-building", "type/design-doc"]
---

# 

# Things I want the server to promote

- A gameplay loop involving changing your geographical location regularly

- Give the players a driver to go out and explore from the starting spawnpoint

- Greater difficulty the further you are from spawn

- More variation in “land quality”. Currently every place in Minecraft is basically the same in terms of value.

- Higher cost for death that includes not just a reduction in player power

- Diversity of abilities, to promote teamplay

- Give the players a driver to generate infrastructure

# Ideas that do not require modding

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Mechanic or Feature</strong></th>
<th><strong>Intended Benefit</strong></th>
</tr>
<tr class="odd">
<th>The concept of a <strong>starting zone</strong>: Around the first spawn (0,0) PVP is disabled, and no negative gameplay effects happen. This Area functions completely as normal Survival Multiplayer. Outside this zone (circular or square of n size) new mechanics come into play to create challenge.</th>
<th><p>Give the players a ‘safe’ and ‘easy’ area to start off in.</p>
<p>Creates a central location to return to.</p></th>
</tr>
<tr class="header">
<th>All Food items except Mushroom stew are immediately removed from your inventory, When outside the starting zone.</th>
<th><p>To add difficulty</p>
<p>Mushroom Stew is the most time consuming and inventory ‘heavy’ food item.</p></th>
</tr>
<tr class="odd">
<th>Stone and Wooden Tools are removed from inventory, when outside starting zone.</th>
<th><p>To add difficulty</p>
<p>These tools are very easy to make, and cost almost no resources (or ‘free’ resources)</p></th>
</tr>
<tr class="header">
<th>Iron, Gold and Diamond tools need to be ‘Blessed” before they can be used (Adventure mode tags added)</th>
<th>To regulate and price the work that players do in the world.</th>
</tr>
<tr class="odd">
<th>Specialist villagers in starting area</th>
<th>To add value to unvaluable items through trade</th>
</tr>
<tr class="header">
<th>Beds removed when you sleep in them, either making them one use or impossible to use</th>
<th><p>Gives a reason to live close to spawns</p>
<p>Adds geographical cost for death.</p></th>
</tr>
<tr class="odd">
<th>Saplings instantly destroyed, forests are non-renewable</th>
<th><p>Create visible player impact on the world</p>
<p>Adds more resource scarcity to the game</p></th>
</tr>
<tr class="header">
<th>Random Structures</th>
<th><p>Add/Subtract value from certain real estate</p>
<p>Modify spawning behaviors</p></th>
</tr>
<tr class="odd">
<th>Random Effects at hidden locations</th>
<th><p>Adds an interesting side to exploration</p>
<p>Gives reason to build infrastructure.</p>
<p>Adds element of danger or unknown to exploration</p></th>
</tr>
<tr class="header">
<th>Class System (randomly gifted based on hidden geographical locations)</th>
<th><p>Gives reason to explore</p>
<p>Adds value to staying alive</p>
<p>Gives unique advantages/disadvantages</p>
<p>Adds reason to work together with other players</p></th>
</tr>
<tr class="odd">
<th>World Border based on number of players logged in</th>
<th><p>Promote playing at the same time</p>
<p>Adds value to other players being online</p></th>
</tr>
<tr class="header">
<th>World Border based on number of players in proximity to each other</th>
<th><p>Promote playing in small teams</p>
<p>Adds value to working together closely</p></th>
</tr>
<tr class="odd">
<th>Logging in costs some hunger, to stop people logging out due to danger</th>
<th><p>Adds value to food</p>
<p>Adds cost to logon-logoff loophole</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Random Structures spawned in world based on lvl 1 block

- New Spawnpoints (probably players claim these as new towns)

- Beacon placed on bedrock, Armorstand used to spawn tower of glass

- void holes in bedrock

- Rich veins of a single ore type. These would need to be very long and interconnected to create an interesting mining experience

- Swap all ores in the chunk with one type

- Long distance portals, targetted scatterplayers effect, spawns matching portal at the other end… or not (one way)

- Key and Lock structures. One Structure that gives a reward if you bring a key, another structure that gives one key per day.

- Tower and Moat: anchor for skybridge or city?

- Access to pocket dimension

Random Effects in the area outside the starting zone

- Scatterplayers tripmine

- Negative Potion Effects

- Monster Ambush

- Teleport to random other player

Starting Zone Ideas

- Team selection for PvP (three teams with colors)

- Portal for random Team teleport?

- Wall. No way out except via random team teleport? Why is this good?

- Limitations on blocks used inside the Starting zone?

Different Classes that are randomly selected based on L1B. “Leveling by geographical location” Once a Class is chosen it is fixed for several hours of play. Change class areas are not shown. Good and Bad sides. Permanent Potion effects, fill/replace timers, special abilities, special items

Death could remove these abilities, then you need to revisit the location to re-acquire them.

- Void God - deployable End Portal that times out

- Sneaker - Becomes invisible at night

- Fishguy - Breath underwater forever, gets free fish every minute

- Taint - Changes grass to mycelium every minute, replaces farmland with dirt

- Lander - Always has Feather Falling Diamond Boots. These are removed from other players.

- Beastmaster. Mobs are friendly to this class and it can summon special mobs

- Skipper - Gets ScatterPlayers bomb that only works on himself

Some classes not allowed back into the starting area.

**Infrastructure Buildable by players**

- Teleport Pads: Cardinal Direction Teleports fixed distance

- Teleport Pads: To nearest randomly generated tp point (random placed entity)

- Scatter Pad: Scatterplayers

- 

Spawning

- When you die you always respawn at 0,0

- when respawning you begin with very little hunger bar left. You need to find food immediately. Encourages building infrastructure around Spawn Points

- Spawn points can be found throughout the world, but cannot be built.

Sleeping

- Beds are disabled you cannot sleep to skip nights

- Beds also do not act as spawn points

# Ideas that require Modding

My Plan to rework Minecraft gameplay AKA gamefying Minecraft

Enemies:

1.  Enemies attack your base once a week

2.  This is done by increasing their vision radius by a VERY large amount

3.  during this time will path to any player

4.  creepers will become impatient and explode if they get stuck in one place

5.  Endermen will attempt to steal chests and items then flee

Hunger:

- Everything should use up the hunger bar

- This includes digging and placing blocks

- This is to make it harder to move farther from the spawn

- Hunger can go above 10 with the last item

- Hunger above 10 drops twice as fast

- When dying of hunger any food will restore 2 hunger

Farming

- All plants take x10 as long to grow

- Foliage regrows over time if the tree has at least one foliage per trunk section

- Foliage drops sticks when cut with an axe

- Foiliage drops only apples when smashed with fists

- wheat drops more food in the second last growth stage

- wheat drops more seeds in the final growth stage

- wheat dies if left too long in the last stage. It replants itself 50% of the time

- melons and pumpkins sometimes break their stems when you harvest them

Animals

- animals attack as zombie pigmen when there are 3 or more animals nearby

- animals run away much faster than the player when injured or alone

- the players must use ranged attacks to take down animals without injury

Dieing

- When a player dies a chest is spawned with his items inside

- When a player logs off, he remains standing in the same spot and can die

- Logged off players who are gone longer than 1 hour are considered killed, their items drop in a chest and they respawn at 0,0 when they relog

- If you are carrying gold bars, you respawn with half of them

Crafting

- there is a considerable wait until you can take the crafted item

- furnaces take much longer to smelt items

- crafting tables need iron

- furnaces need stone bricks

- The server will spawn one of each at 0,0

- ingredients stay in the crafting bench when it is closed

Ore distribution

# Server Spawn Shops

- quick material changers

- specialty tools

- staircase generators

- Skyscraper core generator

- sky island generator

- cave clearer for rooms

- Redstone door setups

- Return Home Teleport pad setup

- Safezone expanders

- 

these should cost gold, redstone or lapis
