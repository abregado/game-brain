---
title: "BS - 4x tradable tech bases"
source: "Game Stuff/Game Ideas/BS - 4x tradable tech bases"
modified: 2022-02-08
type: design-doc
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["4X Tradable Tech Bases", "FourEcks / 4X Space Empire"]
words: 461
summary: "Concept where empires research different uses of resources and can trade tech bases, creating dependencies, with the Ziltoid and Garron example."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/design-doc"]
---

**Concept:** When you discover a new resource type, you can begin researching ways to use it to benefit one (or more) areas of your empire. When you research these, you can also give out the technology to utilise your version of the exploitation. You can save a lot of research by trading for these from neighbours. However they can trade you the ability to use the tech base, or produce the resources, creating a dependency on them for the resource.

**Example:**

You, the Ziltoid Empire, discover a new resource Hard Alloys. Hard Alloys exist for all empires. You decide to research using Hard Alloys for military armour and discover the technology Zillian Hard Armor. You can now produce Zillian Hard Armor items from Hard Alloys, and research new ship modules/design/building ect that use them as ingredients.

You meet the Garron Empire. They also have found hard Alloys but chose to use them to increase their projectile power. You can spend a (now larger) amount of research also developing such a bonus (Zillian Hard projectiles) or you can trade for some Garron Hard projectiles and spend a smaller amount of research points to learn how to create guns/buildings/ect out of Garron Hard projectile items. You gain the option to research the production of Garron Hard projectiles, but it is much more expensive to reverse engineer alien tech.

**What happens:**

- You can base your tech on Garron Hard projectiles and trade with them for the resources you need to spend.

- You could research how to make the items in their style and then out-produce them, offering to sell the excess back to them (they can already use it).

- You could research a lot of new buildings/bonuses/weapons using their tech, gaining dependency on them.

- They could refuse to trade with you, making you go cold turkey.

- You could still research their tech base so you can produce the material after this treachery.

- You could save a lot of research by using your neighbours' tech, and hoping they become dependent on you to buy it, then spend the savings on skipping ahead to the next tech level, turning the tables on them.

- Trading empires could buy/sell resources that are hot property.

- Finding a small amount of super high tech materials will be very interesting, since you can choose how to use them, but this also opens up those options for other empires who know of you and also find the same resources.

- Gives the possibility to have tech bases carry over between playthroughs. Finding a tech base from an empire you played last time and basing your new empire on it could be interesting.

- In multiplayer games, teams of players could deliberately create co-dependent empires.
