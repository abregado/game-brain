---
title: "BS - 4x Military Tech and Experience per enemy"
source: "Game Stuff/Game Ideas/BS - 4x Military Tech and Experience per enemy"
modified: 2022-02-08
type: design-doc
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["4X Per-Enemy Experience", "FourEcks / 4X Space Empire"]
words: 575
summary: "Concept where military tech comes from converting per-enemy battle experience into bonuses, with tech bases and crew species making counters obsolete."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/design-doc"]
---

**Concept:** Military technology comes mostly from spending research points to convert battle experience into bonuses. These bonuses are mostly applicable only against the enemy who was fought to generate the experience, and a small amount is a global bonuses against all enemies.

**Expand this idea:**

- When a fleet is in combat, it gains XP against that enemy empire over time (not based on kills or losses)

- When fighting, the power of a fleet is modified directly by your and your opponents relative XP levels against one another.

- Ships store XP individually

- XP against different empires is stored individually

- Over time, the XP of a fleet is homogenised between its ships.

- As fleets earn experience, a small amount (1%?) is also added to a global XP store. The global store does not affect fleet effectiveness.

- Empires can spend global XP to begin a technology project, which will add two passive bonuses to newly built ships:

  - A larger modifier which is effective against ships of the targeted empire

  - A much smaller modifier which is effective against all enemies.

- Relative experience determines your fleets change to have a strategic victory (causing the enemy to flee)

- Targeted experience decreases damage taken. Then means that two empires who have fought many wars will both take reduced damage.

**Benefits**

- Encourages small scale fighting against rivals to build up your war skills.

- Encourages small scale wars against new enemies to build experience before taking on a bigger war.

- Gives a benefit to not being at peace with neutral empires. Reduces the contrast between war and peace.

- Opens up possibilities for mutually beneficial wars, such as between two similarly matched aggressive empires.

- Opens up possibilities for “generational hatred” conflicts.

- Rubber bands empires being completely wiped out by a single enemy. Eventually a stalemate will be reached.

- Tech alone cannot give you military might.

- Active gameplay is more interesting than turtling and out eco-ing your opponent.

- Possible to develop multiple lines of Military tech for dealing with different opponent empires.

**Expand again on the idea:**

Ships are classified by Tech base and Crew species.

XP is built up against both of these simultaneously.

An empire might develop an entire new tech base and begin building ships based on it, or trade for materials from another empire's tech base. Doing this will nullify an opponent's experience against your old tech base. Every research project from the previous system is applied to one of your tech bases.

**Benefits**

- Technology becomes automatically obsolete as the galaxy learns how to counter you.

- Arms races can occur.

- Outside empires who are not involved in the war can affect the power balance.

- War merchants can exist.

- Interesting forbidden weapon situations can unfold where you are given a new tech base which is basically unknown and told only to use it in emergencies since if everyone starts using it, it will become countered.

- Possibilities for you to have “secret weapons” which you only deploy in certain situations where the enemy will not have time to develop much XP.

- Gives warlike empires something to do other than all the “peace” tech. They can develop multiple military tech bases simultaneously.

- Perhaps you can secretly make a deal to crew your ships with another empire’s species, or become a multicultural empire to dilute enemy XP bonuses.
