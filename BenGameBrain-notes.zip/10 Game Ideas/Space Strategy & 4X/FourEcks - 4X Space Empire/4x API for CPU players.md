---
title: "4x API for CPU players"
source: "Game Stuff/Game Ideas/4x API for CPU players"
modified: 2023-05-16
type: idea
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["FourEcks / 4X Space Empire"]
words: 17
summary: "One-line idea to provide an API so others can write CPU player behaviours."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/idea"]
---

Instead of writing behaviours for the CPU players, create an API so that others can do it.
