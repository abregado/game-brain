---
title: "BS - 4x Map is relationship tree is Map"
source: "Game Stuff/Game Ideas/BS - 4x Map is relationship tree is Map"
modified: 2022-02-09
type: idea
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["4X Relationship Graph Map", "FourEcks / 4X Space Empire"]
words: 114
summary: "Short concept for a 4X with no spatial map, played through a relationship graph with wars as tug-of-war along connections."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/idea"]
---

**Concept:** There is no solar system map. Colonies/assets/systems are shown elsewhere and their spacial relationship with one another has no meaning. Instead the game is played via a chart/graph of your relationships. Connections between you and other empires have different types (Diplomatic/Border/ect) and each one can be utilised in a number of different ways. Border connections could be used for War or Trade. Stealth/Espionage comes from having connections with another empire that only you know about.

Wars are represented as a “Tug of War” along a connection. Multifront wars are those that just include multiple borders.

Experiences:

- Relationships have more meaning given to them.

- Allies become geographical shields from other empires

-
