---
title: "BS - 4x citizen empire opinion"
source: "Game Stuff/Game Ideas/BS - 4x citizen empire opinion"
modified: 2022-03-04
type: design-doc
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]", "[[Stellaris mods]]"]
concepts: ["4X Citizen Empire Opinion", "FourEcks / 4X Space Empire", "Stellaris mods"]
words: 325
summary: "Several solutions for making citizen opinion limit how a player treats other empires: expectations, peace timer, asymmetric war/peace rewards, trade dependency, border upgrades."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "project/stellaris-mods", "type/design-doc"]
---

Goal: Your empire (pops, ethics, civics) should influence which empires you can treat badly/well. The player should not have complete control over who they attack or befriend.

Solution 1:

*Citizen expectations.* You have a morality score with each empire. Treating them badly lowers it, treating them well raises it. Your population has an expectation level, and you receive maluses for having a morality score for a given citizen which is either higher or lower than that expectation.

Solution 1.1: Expectations are calculated based on similarity of citizen ethics. Downside is that you cant have asynchronous expectations between any two given empires.

Solution 1.2: Expectations are calculated based on species compatibility (habitability overlap). Same lack of asynchronous levels.

Solution 1.3: Expectations are calculated per pop and aggregated. Pops might have like/dislike for a given other species, empire's government, plus ethical elements. Religious pops might ignore racial differences, but have strong opinions about heathens. Pops involved in a war, or bombardment/purge will gain strong dislikes for members of the instigating empire (pops and government). They could also have an opinion about an empires leader. Downside is that this is very complex to implement, balance and understand.

Solution 2:

Peace timer is the approval cost for declaring war. Over time while at peace with an empire you border, you build up peace synchronisation. Empire type determines how quickly it builds, and what cap it has. It gives no bonus, but if you declare war, then you gain a production debuff for a given time. This debuff is then modified by war exhaustion.

Solution 3:

Reward empires asynchronously for both being at war and being at peace. Some empire types gain bonuses for being at war. Some gain bonuses for being at peace.

Solution 4:

Just make trade necessary and have empires build up dependencies with each other.

Solution 5:

Upgrades can be applied to link between border systems. These can give bonuses or impose penalties to either side.
