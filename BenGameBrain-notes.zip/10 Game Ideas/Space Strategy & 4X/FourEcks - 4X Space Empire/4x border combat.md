---
title: "4x border combat"
source: "Game Stuff/Game Ideas/4x border combat"
modified: 2023-05-02
type: idea
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["FourEcks / 4X Space Empire"]
words: 44
summary: "Short notes on border fleet pool settings (equal, higher, double, half, zero) and staging systems."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/idea"]
---

4x border combat

Set to equal, be higher, double, half or zero

Percent of Strength moves per turn to pool if too much

Entire pool can empty per turn to fill.

Pool is split between staging systems.

Staging system can be set as mothballed
