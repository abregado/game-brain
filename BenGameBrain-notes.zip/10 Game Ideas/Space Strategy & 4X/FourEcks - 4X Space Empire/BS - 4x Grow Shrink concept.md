---
title: "BS - 4x Grow Shrink concept"
source: "Game Stuff/Game Ideas/BS - 4x Grow_Shrink concept"
modified: 2022-02-08
type: design-doc
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["4X Grow and Shrink Empire Tiers", "FourEcks / 4X Space Empire"]
words: 867
summary: "Concept for a 4X where empires pass through expansion, consolidation and elder phases and cannot persist forever, with lists of player experiences per phase and common systems."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/design-doc"]
---

Goal

A 4x in which you start out as a single planet, grow and spread across a large area, consolidate your empire then shrink back down to become an elder race. Systems in the game should support gameplay that moves an empire through these three phases in different ways. It should be impossible to keep an empire forever.

Deconstruction and Questions

- Empires at different stages need to be able to interact in meaningful ways

- Being bigger does not mean being more powerful

- Can empires start at different stages?

- What forces are in play to cause an empire to grow or shrink?

**Elder Phase Player experiences**

- Your people want to be on as few planets as possible so begin migrating to be closer to the capital/centre of your empire.

- Your controllable population shrinking due to:

  - people begin to upload their minds, either loading into ships and leaving, or to a central computer.

  - People flock to a high tech agrarian lifestyle, stagnating technology growth.

  - Citizens migrating to other welcoming empires to experience something new.

  - Groups of your people subliming/transcending.

  - Private arkships leaving the galaxy for a new one.

  - Slow genetic plague causing population growth to stop, but extending lifespans.

  - Genetic change making it impossible to produce new population.

  - Religion dictates that “the golden age” has passed.

  - Citizens want to urbanise, so migrate towards the largest of your planets, depopulating the colonies.

- Controlling the galaxy politically to keep others from becoming the most powerful elder species.

- Enslaving others to have them do your bidding.

- Working on long term, galaxy wide projects such as:

  - A zoo containing all of the species in the galaxy.

  - Building a gateway to a new dimension.

  - Birthing new civilizations/seeding new planets

  - Solar terraforming/ Megastructures

  - Cataloguing every star

  - Redesigning the starlane network

- Controlling less star systems and becoming self-sufficient.

- Being reliant on younger neighbours trade to fight against your empires constant stagnation.

- Sponsoring young races so they distract the Expansionist races from looking your way.

- Eventually raising the ire of your neighbours because your demands are too great.

- Eventually just petering out if you survive your neighbours attacks.

**Consolidation Phase Player Experiences**

- Conquering/Vassalizing/enslaving empires

- Creating coalitions of empires

- Competing to be the most desirable migration target if you are playing peacefully.

- Building dependency on and from trade with your neighbours.

- Researching towards a “Elder singularity” tech event of your choosing

- Space war, as aggressor and defender.

- Managing borders, demilitarised zones and no-mans-land

- Meeting primitives and deciding what to do with them.

- Negotiating open borders to explore solar systems inside a neighbours space.

- Meeting and making Diplomatic demands.

- Solidifying trade routes throughout your empire

- Urbanising colonies and increasing population.

- Attempting to set up situations where you can overcome an Elder race without having to split up the spoils.

- Dealing with the consequences of all the choices you made during the early phase.

- Integrating different species into your empire.

**Expansion Phase Player Experiences**

- Exploration

- “Painting the map”. Claiming ownership of massive areas of space.

- Manipulating internal politics/factions to prepare for the Expansion phase.

- Founding research colonies

- Enjoying lots of technology bonuses.

- Building up tech specialties.

- Enjoying freedom to choose from many solutions.

- Finding an elder race to sponsor you so you don’t get eaten up by Expansion phase empires.

- Being generally ignored because you are so pitiful.

- Protecting your homeworld.

- Reconfiguring your homeworld to prepare for expansion.

- Holding back the change to Expansion phase until you are ready

- Reaching the Expansion phase before you are noticed.

- Finding the closest systems with starlanes.

**What are the common systems?**

Systems and System Ownership: Map painting. The concept of claiming the map.

Resource production density: An elder empire needs to be able to produce more in a smaller space.

Unproducible resources: You need to be able to get (from other empires) resources that you yourself cannot produce.

A mechanic which halts system growth: Some rubber banding mechanic, which as an empire grows, applies empire wide production penalties based on empire size.

Bismarckian mechanics: Empires who spend a lot of time bordering each other should become dependent on one another. Having rivals and enemies on your border should also be useful.

Some pressure to stay in a lower tier for as long as possible: So the choice is real when to move on.

Some minimum threshold before moving to a new tier: So that racing for the next tier will force you to cut your own throat in some areas.

Some pressure to leave a tier as quickly as possible: Eventually you should simply be forced to move to the next tier.

Multiple different types of tier paths: Some tier long bonuses. These should affect your choices in their tier as well as in the next one.

**What does Empire Tier represent?**

- Genetic makeup of your citizens

- Mindset of your citizens

- Vanity/Pride/ect

- Type of economy

- Ethics of your government/ruling class
