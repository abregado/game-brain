---
title: "BS - 4x starlanes but not everywhere"
source: "Game Stuff/Game Ideas/BS - 4x starlanes but not everywhere"
modified: 2022-02-08
type: design-doc
area: game-idea
status: "idea"
projects: ["[[FourEcks - 4X Space Empire|FourEcks / 4X Space Empire]]"]
concepts: ["4X Sparse Starlanes", "FourEcks / 4X Space Empire"]
words: 415
summary: "Concept of a dense galaxy where only some systems have starlanes, with starlane FTL versus folding FTL and a list of resulting experiences."
tags: ["area/game-idea", "project/fourecks-/-4x-space-empire", "type/design-doc"]
---

**Concept:** The galaxy is very dense and has many many solar systems, but not many of them have star lanes set up. Player empire homeworlds start in systems without Starlanes. They begin by exploring their immediate area for systems until they find one. Starlane systems are just better for trade, map control and building high population planets. Different types of stars are interesting for different types of empires, but all starlane systems are interesting for all empires.

Two types of FTL exist.

- Starlane interface. Instant travel. Time to recharge on arrival before activation is possible again.

- Folding. Just fast FTL via dimensional folding or compression. Limited by fuel range from a starlink system or homeworld.

**Experiences:**

- You claim a starlink system and begin exploring solar systems within range of it using Folding. There are many, so you prioritise those that are most likely going to yield something for your empire.

- Your homeworld has access to the Folding resource, so it counts as a Fuel depot. You might find planets with populations of all tech levels who never had access to Folding (and therefore starlanes).

- Each starlane system has a different worth to each empire, since each will want to exploit a different set of local systems.

- There are exploration options throughout an entire playthrough.

- Play several playthroughs in the same galaxy, since empires might grow and die in the space between starlane systems

- Isolated starlane networks become breeding grounds for new galactic empires.

- Building/destroying starlanes and folding infrastructure can be a high tech option.

- Early game you will explore the closest systems to your homeworld looking for the starlane. Later on you will only explore possible colonisation options.

- Gives interesting many system gameplay without sacrificing the simplicity of defensive chokepoints.

- Fight guerilla wars as the invaders take over your starlanes, but struggle to locate your nearby colonies.

- Disappear off the grid as an elder race by researching the longest range Fold drives and living on the outer rim of each cluster.

- Control only starlane systems and then charge a toll fee.

- Find a suitable planet for your species that has a starlane and begin a massive migration. Only enormous trade can support an enormous population!

- Take joint ownership of a Starlane system, or provide passage to other empires and try to utilise every system in a cluster.

- Planets in Starlane systems are going to be terraformed very often..
