---
title: "Concept - Star Ruler Population"
source: "Game Stuff/Game Ideas/Concept - Star Ruler Population"
modified: 2013-06-12
type: design-doc
area: game-idea
status: "designed"
projects: ["[[Star Ruler mods]]"]
concepts: ["Star Ruler mods"]
words: 437
summary: "Star Ruler mod notes making population a crew resource for ships, with galactic mood/war weariness, immigration via the bank and staged implementation."
tags: ["area/game-idea", "project/star-ruler-mods", "type/design-doc"]
---

**The Importance of Home**

A Star Ruler Modification Concept

*By Ben Buckton*

**Table of Contents**

Goal 3

New Structures and Systems 3

> Domed Colony 3
>
> Industrial/Construction/Science District 3
>
> Forge Arcology 3
>
> Construction Arcology 3
>
> Refining Beam 4

Play Flow 5

Stage 1 5

Stage 2 5

Stage 3 6

#  Goal

- Add a core mechanic

- Population becomes important

- Homeworlds become focal to expansion

- Secondary homeworlds/System hubs become vital

This modification is aiming to add a new way that players manage their Star Ruler economies. It adds a number of new ways to use population

# Description

All homeworlds now start with a special Planetary Condition that increases their maximum population by a factor of 100. Population growth will be slowed down substantially, perhaps to 0.1% of its current speed.

When a planet is at maximum population, the excess growth is exported to the galactic bank as Immigration Pool. The value in the Immigration pool must still be fed, and its ratio to your total empire population is also a penalty to every planets Mood. Mood should also effect population growth, so as Mood drops, so does the amount of population being emmigrated to the galactic bank.

Space Ports should have their priority modified so that importing population is second only to Food.

At later stages of development population should be converted into crew, and all ships will require this resource. This should be a bottleneck for building larger craft without Computers, and should revitalise the need of Computer Technology in warfare.

Population dieing should create a empire wide moral loss. Be it from bombing, or from ship loss. This should build up until wars are stopped, similar to War Weariness from other games.

When in system with a friendly planet, ship crews should be replaced from the galactic bank on any ship with a functioning life support system. This means grey ships can be rescued by repairing them, where at the moment once the crew is dead you have to board them with marines, after repairing.

# Stage 1

- Population growth rate reduced and balanced

- Homeworld Condition to increase max population

- excess population exported to bank for free (like Goods/Luxuries)

- population imported from bank for free (like Goods/Luxuries)

# Stage 2

- Population uses trade capacity

- Immigration Pool eats stored food before planets

# Stage 3

- Galactic Mood Modifier

- Galactic Mood loss on population death

- Mood modifies Growth Rate

# Stage 4

- Crew Requirement for ships

- Local Crews replenished automatically when life support functions
