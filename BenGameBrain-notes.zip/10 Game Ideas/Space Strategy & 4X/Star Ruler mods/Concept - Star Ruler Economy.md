---
title: "Concept - Star Ruler Economy"
source: "Game Stuff/Game Ideas/Concept - Star Ruler Economy"
modified: 2013-06-12
type: design-doc
area: game-idea
status: "designed"
projects: ["[[Star Ruler mods]]"]
concepts: ["Star Ruler mods"]
words: 1348
summary: "Star Ruler mod concept 'Minimizing Micromanagement' adding Domed Colonies, districts, Forge/Construction Arcologies and a Refining Beam, with staged implementation plan."
tags: ["area/game-idea", "project/star-ruler-mods", "type/design-doc"]
---

**Minimizing Micromanagement**

A Star Ruler Modification Concept

*By Ben Buckton*

**Table of Contents**

Goal 3

New Structures and Systems 3

> Domed Colony 3
>
> Industrial/Construction/Science District 3
>
> Forge Arcology 3
>
> Construction Arcology 3
>
> Refining Beam 4

Play Flow 5

Stage 1 5

Stage 2 5

Stage 3 6

#  Goal

- Reduce micromanagement of new colonies

- Create and option to have maintenance free, yet useful planets

- Make empire management simpler at high tech levels with many systems

- No changes to core mechanics, addition only

- As minimal changes as possible

This modification is aiming to add a new way that players manage their Star Ruler economies. It can be utilized in addition to or instead of the current system. It could also not be used at all.

# New Structures and Systems

Several new structures are added to the game.

## Domed Colony

This structure is very cheap but supplies enough food, goods and housing to sustain itself while generating small amounts of all other resources (except luxuries). They contain very little population, but require a similarly small amount. The idea here is that new colonies can have these queued up, and the first one is placed free with the colony ship (or more than one). They produce enough to build more of themselves without importing resources and slowing down the players economy. Once the planet is full of them, changing one or two into other structures is possible without importing resources. This structure is available with General Sciences 1, and increase in efficiency with the same research.

## Industrial/Construction/Science District

These are self governed districts that are self sufficient in regards to housing, goods, luxuries and food. Construction districts generate additional trade capacity and labour. Industrial districts generate Metals, Electronics and Adv Parts from local ores. Science Districts generate Research Points. However these do not have a lot of trade capacity, so haulers are still necessary for joint construction projects. These all become available at Sociology 3 and increase in efficiency with sociology research. Each will require one other technology at level 3 (Economics, Metallurgy and General Science)

## Forge Arcology

These monstrosities are full self contained cities generating all resources and exporting them to the galactic bank. They also contain planetary defence weapons, minimal cargo bays, fuel/ammo depots and research labs. They do not generate much free labour or trade capacity. Each requires massive population, but also houses its own requirements. Forge Arcologies are highly resistant to damage and chemical weapons. These are very expensive and only become available with all of the civic technologies at 12, as well as Mass Construction at 12.

## Construction Arcology

Similar to their Forge cousins in respects to self sufficency, Construction Arcs are simply masses of Space Ports, Cargo Bays and Ship Yards. They generate substantial additional trade capacity, labour and can hold a lot of resources. They do not generate research, fuel/ammo or have defence weapons, relying on orbital platforms for defence. Each requires massive population, but also houses its own requirements. Construction Arcologies are highly resistant to damage and chemical weapons. These are very expensive and only become available with all of the civic technologies at 12, as well as Engineering AND Mass Construction at 12.

## Refining Beam

This ship system collects ore from a nearby asteroid, transforms it into Metal, Electronics and Adv Parts. It does not require a cargo bay to work but is very heavy, expensive and takes a lot of power. It becomes available at the same time as Export Dock and Advanced Parts Fabricators.

#  Play Flow

Players will utilize Domed Colonies early on to colonise many systems without overloading their economies. Setting a new planet to no Import OR Export should see them grow with just Domed Colonies. A governor for this is probably not required, but may be helpful.

Once a planet has been filled with Domed Colonies, the player may begin to build districts or follow the regular planetary construction path (Governors will slowly remove the Domed Colonies and replace them with other things). Districts allow the economy to expand without worrying about balancing all the structures. If you need more research, simply build more Science Districts. The same goes for the other districts. Since districts will require much more population, it will take some time for them to reach full potential.

As industrial districts cannot export all the resources they create, you must balance them with Construction districts. Alternativly, you can build many planets full of Industrial Districts, and just one with Construction districts, using Haulers to move the resources to be exported.

Once Arcologies become available haulers are all but pointless. Your empire probably spans hundreds of systems and you just want systems that can look after themselves while you fight the enemies and build ships bigger than suns. Filling every planet with Arcologies solves this problem. Most planets will be filled with Forge Arcologies. These do everything that needs to be done and export all their goods to the galactic bank. Blockades do not matter to them as they are self sufficent, and also protect themselves. As they require MASSIVE population, it will take a while for regular worlds to get accustomed to Arcology life.

Where you wish to construct regular ships place Construction Arcologies on one planet and begin importing the required resources to your drydock.

For massive ships and ringworlds, simply place Construction Arcologies on all the planets in that system, and supply with copious amounts of large haulers.

You can also suppliment your economy with the Refinery Beam. Equip a few ships with these and Construction Bays, and begin your Van Neumon takeover as they self replicate. Then build a few hundred versions with export docks and viola! Instant economy!

# Stage 1

- Domed Colonies coded and balanced. They must be self sufficient at all levels of technology.

- Colony Ships must build Domed Colonies when they land.

- Seed Colony Governor

Reducing micromanagement during the early game is more important as players always use this content more. Automated colony ships will colonize planets and automatically begin producing more Domed Colonies. The player may disable imports to be sure that their economy does not crash. Once a Seed Colony is finished, it may be possible to have the Automatic Governor Selection function trigger, changing it to something else.

# Stage 2

- Districts coded and balanced. They must not generate more than a similar all round planet with vanilla structures. Their population requirements should be similar to regular structures

- Possibly rename Construction Districts to Economic Districts

Midgame micromanagment can be optionally culled using these three new structures. Districts, in combination with Dry Docks and haulers can replace the entire current build order. Only Fuel, Ammo and Planetary Weapons are still required. Districts will generate slightly more food and housing than are nessesary to support a few of these structures, but realistically orbital platforms could be used instead much more easily.

# Stage 3

- Arcologies coded and balanced. They should generate roughly double a similar all round planet and require one hundred times the population. Planets should be pushed into the billions with this structure.

- Refinery Beam coded and balanced. It should be suitable for use as a local boost, with a construction bay or with an export dock. Very small versions should still be suitable for van neumon shenanigans.

- Allowing the AI to build Arcologies.

Endgame micromanagement is to do with having too may systems to physically control. With the advent of Arcologies, the player can fill unimportant support systems with a single structure that will keep his economy in the black, while focusing his attention on a few system wide construction projects. The AI already does not perform well at such high technology levels, so it needs to be directed to build Arcologies as well.

Once a player has ringworlds filled with arcologies I feel the gameplay becomes unimportant. Ships start to become larger than solar systems and can destroy suns with a single shot.
