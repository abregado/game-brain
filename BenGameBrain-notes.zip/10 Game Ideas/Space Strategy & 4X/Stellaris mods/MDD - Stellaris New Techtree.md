---
title: "MDD - Stellaris New Techtree"
source: "Game Stuff/Game Ideas/MDD - Stellaris New Techtree"
modified: 2021-05-03
type: planning
area: other
status: "designed"
projects: ["[[Stellaris mods]]"]
concepts: ["Stellaris mods"]
words: 128
summary: "Todo list and CSV column spec for a Stellaris tech tree scraper/builder tool for a mod."
tags: ["area/other", "project/stellaris-mods", "type/planning"]
---

Scraper todos

- It always adds a nil line?!

- Replace @ with 1

- Icon = value

- Synthetic thought patterns listed as gestalt allowed

Builder

- Ai_weight block

- Prereq_for block

- Weight groups

- Repeatables

- Rare techs have a weight bonus when having tech ascendancy

- Choice groups (weight group, then only one allowed)

- Strategic resource utilization techs

- Civic based allow/disallow

- Ethic based allow/disallow

CSV columns

**Tech name tag**

~~Tier~~

~~Area~~

~~Category~~

~~Prerequisite~~

~~Prerequisite 2~~

Likely civic

Rare civic

Likely ethic

Banned ethic

Rare ethic

Banned Ethic

Normal potential

Machine potential

Lithoid potential

Hivemind potential

Modifier1name

Modifier1value

Modifier2name

Modifier2value

isRare

isDangerous

isReverseEngineerable

featureFlag

descritpionTag

titleTag

isRepeatable

aiUpdateType

weightGroup

localizedName

localizedDescription

**Calculated Values**

Cost

Potential block

Base Weight

Weight_modifier block

AI_weight block
