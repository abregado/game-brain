---
title: "Stellaris Empires"
source: "Game Stuff/Stellaris Empires"
modified: 2021-04-18
type: design-doc
area: game-idea
status: "designed"
projects: ["[[Stellaris mods]]"]
concepts: ["Stellaris mods"]
words: 749
summary: "Spreadsheet design of 12 custom Stellaris empires with ethics, civics, origins, species and traits."
tags: ["area/game-idea", "project/stellaris-mods", "type/design-doc"]
---

## Sheet: Empires

| Name | Kluugan Reformation | The Blessing | Deep Archive | Slagk Synconite | Growth of Equality | Omnian Intersection | Three Claws Union | Rahnian Delegation | Polloc Sedation | Shrill Corvidate | Googleplex Starthinker | Milliard Gargantubrain |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Team | Spirit | Auth | Mech | Mech/Auth | Egal/Spirit | Auth/Spirit | Egal | Egal/Spirit | None | Auth/Mech | Mech | Mech |
| Planet Type | Savanna | Tundra | Relic | Alpine | Gaia | Tropical | Relic World | Ocean | Desert | Arid | Continental | Arctic World |
| Authority | Corporate | Dictatorial | Machine | Dictatorial | Democratic | Imperial | Democratic | Democratic | Hive mind | Dictatorial | Machine | Machine |
| Origin | Scion | Necrophage | Remnants | Mechanist | Life-Seeded | Syncretic Evolution | Remnants | Common Ground | Prosperous Unification | Prosperous Unification | Prosperous Unification | Doomsday |
| Ethics 1 | Fanatic Spiritualist | Fanatic Authoritarian | Gestalt | Fanatic Materialst | Fanatic Egalitarian | Fanatic Authoritarian | Fanatic Militarist | Egalitarian | Gestalt | Authoritatian | Gestalt | Gestalt |
| Ethics 2 | Pacifist | Militarist |  | Militarist | Spiritualist | Spiritualist | Materialist | Xenophile |  | Fanatic Militarist |  |  |
| Ethics 3 |  |  |  |  |  |  |  | Spiritualist |  |  |  |  |
| Civic 1 | Gospel of the Masses | Corvee System | Memorialist | Nationalistic Zeal | Shared Burdens | Slaver Guilds | Warrior Culture | Beacon of Liberty | Empath | Technocracy | Rapid Replicator | Warbots |
| Civic 2 | Corporate Death Cult | Byzantine Bureaucracy | Factory Overclocking | Police State | Parliamentary System | Mining Guilds | Distinguished Admiralty | Diplomatic Corps | Natural Neural Network | Slaver Guilders | Rogue Servitor | Driven Assimilator |
| Civic 3 (intended) |  |  |  |  |  |  |  |  |  |  |  |  |
| Ship Type | Mamallian | Necroid | Arthropoid | Humanoid | Plant | Mollusc | Reptile | Fungoid | Lithoid | Avian | Fungoid | Necroid |
| Species 1 |  |  |  |  |  |  |  |  |  |  |  |  |
| Name | Kluug | Thanatite | Findar | Slagk | Rax | Omni | Kratz | Flisch | Polloc | Shrill | Pamperbot | Gargantudrone |
| Portrait | Reptile | Necroid | Machine | Fungus | Plant | Mollusc | Mammal | Humanoid | Enduring | Unruly | Machine | Machine |
| Trait | Thrifty | Slow Learners | Logic Engines | Very Strong | Natural Sociologists | Intellegent | Very Strong | Quick Learners | Industrious | Deviants | Emotion Simulators | High Bandwidth |
| Trait | Unruly | Weak | High Bandwidth | Ingeneous | Sedentary | Weak | Decadent | Talented | Solitary | Intellegent | High Bandwidth | Efficient Processors |
| Trait | Conformists | Unruly | Enhanced Memory | Slow Learners | Nonadpative | Deviants | Slow Breeders |  |  | Natural Engineers | High Maintenance |  |
| Trait |  | Intellegent | Bulky | Quarrelsome | Charismatic | Charismatic | Industrious |  |  | Rapid Breeders | Superconductive |  |
| Trait |  | Extremely Adaptive |  | Solitary | Conformists |  |  |  |  |  | Mass Produced |  |
| Trait |  |  |  |  |  |  |  |  |  |  |  |  |
| Species 2 |  |  |  |  |  |  |  |  |  |  |  |  |
| Name |  | Hildeen |  |  |  | Base |  |  |  |  | Gemterran | Human |
| Portrait |  | Humanoid |  |  |  | Mollusc |  |  |  |  | Lithoid | Industrious |
| Trait |  | Rapid Breeders |  |  |  | Industrious |  |  |  |  | Volatile Excretions |  |
| Trait |  | Very Strong |  |  |  | Agrarian |  |  |  |  | Traditional |  |
| Trait |  | Fleeting |  |  |  | Fleeting |  |  |  |  | Conservationalist |  |
| Trait |  | Quarrelsome |  |  |  | Unruly |  |  |  |  | Repugnant |  |
| Trait |  | Slow Learners |  |  |  |  |  |  |  |  |  |  |
| Trait |  |  |  |  |  |  |  |  |  |  |  |  |
