---
title: "Stellaris Jobs Simplification"
source: "Game Stuff/Game Ideas/Stellaris Jobs Simplification"
modified: 2021-10-04
type: design-doc
area: game-idea
status: "idea"
projects: ["[[Stellaris mods]]"]
concepts: ["Stellaris mods"]
words: 159
summary: "Short Stellaris mod/design idea to simplify pop jobs based on citizenship, equalise job weights, and rework slavery and AI-rights policies for robots."
tags: ["area/game-idea", "project/stellaris-mods", "type/design-doc"]
---

**Possible**

Based on citizenship.

All pops can work all jobs except:

Ruler jobs (or)

- Full Citizenship

Specialist Jobs

- Residence

- Slavery and type Indentured

- Slavery and type Battle Thralls (Duelists)

- Slavery and type Domestic (Entertainers)

Worker Jobs

- Is not Undesirable

**Weights**

All job base bonuses are the same. Upward pull comes from Living Conditions. Under shared burdens all base weights will be the same.

All jobs

- ++ Has correct Planet habitability

- ++ Job Specific production bonus

- Political power bonus from Living Conditions

Ruler Jobs

- ++ Empire main population

Specialist Jobs

Worker Jobs

**Robot Citizenship simplification**

Slavery allowed policy changes to:

- Outlawed

- Allowed (non egalitarian only)

- Mechanical only (all biologicals)

AI rights policy changes to

- Outlawed - mechanicals are dismantled

- Servitude - robots restricted to slavery

- Citizen rights - robots may have residence or full citizenship (unlocked with Synthetics tech)

Robots get normal Citizenship rules.
