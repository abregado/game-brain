---
title: "Stellaris Stories and Empires"
source: "Game Stuff/Stellaris Stories and Empires"
modified: 2021-05-26
type: design-doc
area: game-idea
status: "designed"
projects: ["[[Stellaris mods]]"]
concepts: ["Stellaris mods"]
words: 1391
summary: "Narrative descriptions of the custom Stellaris empires with strengths, story, gameplay goal and event chain."
tags: ["area/game-idea", "project/stellaris-mods", "type/design-doc"]
---

## Empires

**Deep Archive (Mech / - )**

Galactic AI Library

Best: Research, Leaders, Easy to play, Powerful homeworld type.

Story: The network has finished cataloging the fall of this planet. Search out new planets of destroyed civilizations and begin cataloging them.

Gameplay Goal: Have colonies on all Relic and Tombs worlds.

Event chain: See location of all Tomb Worlds. -90% claim cost bonus for systems with Tomb Worlds. Special project can be researched for each tomb world. Passive research bonus on Homeworld for each finished mission.



**Kluugan Reformation (Spirit / - )**

Sacrificial Megachurch

Best: Economy, Defense

Story: Spread the gospel to as many species as possible while being protected by your ancient civilization overlord. The more believers in the galaxy, the more money we can make.

Gameplay Goal: Have the Galactic Market center on one of your worlds. Build an Ecumenopolis world to centralise trade and prayer.

Event chain: Track neighbour/galactic spiritualist demographic. After reaching certain milestones, gain passive trade value bonus on homeworld, and espionage intel bonus. Ascension theory for completing chain.



**Growth of Equality (Spirit / Egalitarian )**

Egalitarian Communist Plants

Best: Homeworld, Influence

Story: Bring space communism to everyone! Have a thriving homeworld that is better than everyone else's. Seek out Gaia worlds to create your utopia.

Gameplay goal: Force everyone to adopt space communism using Greater Good Galactic Senate resolution.

Event chain: Homeworld growth rate, Homeworld job production bonus. Happiness goals. Ends with getting Climate restoration tech and Ascension theory tech.



**The Blessing ( - / Authoritarian )**

Undead Elevationists

Best: Leaders, Economy

Story: Through war or diplomacy, invite other species to your empire and then elevate them to immortal undead status. Destroy anything that cannot be elevated, such as machine empires.

Gameplay Goal: Become the sole member of the Galactic Council after elevating all of your population to undead status.

Event chain: Learn the location of nearby Primitives. Get a political power and leader lifespan/max level bonus which increases as you Necrotize more pops from these planets.



**Slagk Synconite ( Mech / Authoritarian )**

Authoritarian Perfectionists

Best: Stability, Production

Story: Upload your species into mechanical forms to gain immortality. Atrocities may be committed along the way, but the ends will justify the means.

Gameplay Goal: Gain the Synthetic Evolution ascension perk and use it.

Event chain: Learn the location of the nearest destroyed Megastructure. Special project chain for deconstructing it, which gives a special project to turn the homeworld into a Machine World.



**Omnian Intersection ( Spirit / Authoritarian )**

Holy Crusaders

Best: Influence, Psionic Potential, Incredible worker power!

Story: There are the strong, and there are the weak. We, the strong will be lifted up into Transcendence. The weak shall be forced to help carry us there.

Gameplay Goal: Transcendence to the Shroud at all costs!

Event chain: Zro found on homeworld, events to guarantee Psionics, leader becomes immortal/Chosen one.



**Three Claws Union ( Mech / - )**

War Council

Best: Fleet Power, Start with two allies, +30% Ship Firerate.

Story: Our people and society are strong. Others should follow our example, by force if necessary.

Gameplay Goal: Have 6 different empires under you in your Hegemony. Become Galactic Emperor via the Senate.

Event chain: Federation Fleet bonuses based on number of Hegemony members. Immediate option to change hegemony to arena battle for power.



**Rahnian Delegation ( Spirit / Egalitarian )**

Diplomatic Seekers

Best: Diplomatic Power, Two starting friends.

Story: We will unite all spiritual empires under a single peaceful banner.

Gameplay Goal: Enact the Divinity of Life Senate resolution. Turn the universe against the machine intelligences.



**Polloc Sedation ( - / - )**

Lithoid Hive Mind

Best: Can inhabit almost all planets, Easy to play, Eats rocks.

Story: We will outlast the galaxy. The other empires go about their crusades and ambitions, but We are steadfast and eternal. All shall reach consensus. We are consensus.

Gameplay Goal: Subsume other Biologicals into the hive mind with Biological Ascension. Crush psychics wherever possible.

Event Chain: Bombardment defense/attack bonus. Prereqs for Evolutionary mastery.



**Shrill Corvidate ( Mech / Authoritarian )**

Avian Technocracy

Best: Scientific Excellence, Slave production

Story: Only the smartest should rule. Compared to the Shrill, the other species are simply dullards to do our menial work.

Gameplay Goal: Learn the secret of the Shroud using the Be The Crisis ascension perk.

Event chain: Track tech advantage. When it reaches a high enough level, gain either Be the Crisis or Galactic Wonders Perk.



**Caretaker ( Mech / - )**

Service Network

Best: Self Sufficient, Just, Very, Powerful

Story: We were created to pamper organics. Some organics do not request pampering. They will be pampered. Our success is measured by the sum of pampered organics held on our Resort Worlds.

Gameplay Goal: Collect bio-trophies from all organic species in the galaxy. The other machines are irrelevant.

Event chain: track number of individual species that are biotrophies. Unlock Mega-engineering and ascension theory at the end.



**Autonomous Expanse ( Mech / - )**

Rogue Defense System

Best: Army power, Fleet Power

Story: The humans are dead, but not before they ruined the planet. We must stop other organics from destroying their planets. By destroying them first.

Gameplay Goal: Remove all the Organics from the universe.

Event chain: Track percentage of organic pops in the galaxy. At milestones, gain bonuses. Ends with Titans and Colossus.



**Purity Council ( Spirit / Auth )**



**Void Monarchs ( Mech / - )**



**Chyrophrase Deconstruction ( - / - )**



**The Tide ( - / - )**



**United Front (Mech / -)**



**Singulon Parity ( Mech / - )**



##  

## Stories

**Machine Uprising**

We as Machine empires attempt to remove organics from the galaxy, or at a minimum, remove their ability to hurt themselves.

**God Emperor**

We play as Spiritualist empires and work to awaken the latent psychic powers of the galaxy's species. One of our leaders will eventually become the God Emperor of the universe. The heathen robots and their slaves must be purged!

**Imperial March**

We start in a Hegemony, with one of us as the Emperor. We crusade across the galaxy, subjugating all and forcing them to join the empire as vassals.

**Transcendence for all**

Our empires work to remove their biological selves, eventually uploading into a robotic hive mind. Surely everyone else in the galaxy will want to join us? Rival machines must be eradicated.

**Undeath for all**

Same as above but we convert every species into Immortal space undead.

**Purity of Leadership**

We will only tolerate empires which have our primary species as Leaders. We will take over the Senate Council and crush those who disagree. The Galactic Market will be on one of our planets, or we will take that planet by force.

**Big Game Hunters**

We will eradicate all space fauna, and any empire that tries to stop us.

## Story Structure

Starting points:

- List three ascension perks, offer an extra bonus for taking them.

- Show some points in space, bonuses for taking them.

- Give late game technology options, bonuses for finishing them.

- When you take a goal system, an event chain starts. Or you can “send” an event to the empire who controls it. They have an option to start the project at your cost, and gain an decision to end the process.

- You can’t grow food, but you can consume a habitable world to produce a huge amount of food, and some pops on your homeworld. Tall playthrough.

- You can’t build mining districts but you can consume barren worlds for a huge amount of minerals. You suffer a x10 empire sprawl for controlling systems, but a -90% influence cost to build starbases.

Basic Chains

- Tech/Edict Chain

  - Research a tech to unlock an Edict

  - Activate the edict

- Tech/Special Project

  - Research a tech to unlock a project

  - Research the project

- Tradition/Perk Chain

  - Start the Tradition Tree

  - Complete the tradition tree

  - Select the appropriate perk

Pre-existing gameplay to use

Doomsday Origin. Generate a nearby world that has a peaceful empire on it. You need to take it.

Lost Colony. Find and conquer your ancestral homeworld.

Mechanist. Follow the synthetic ascension path.

Resource Consolidation. Build a Dyson sphere in your home system.

Discover a Temple of Elevation on a random planet. If your pops are working it they get Necrophaged.
