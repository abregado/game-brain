---
title: "Stellaris Tech Tree"
source: "Game Stuff/Game Ideas/Stellaris Tech Tree"
modified: 2021-04-29
type: planning
area: game-idea
status: "idea"
projects: ["[[Stellaris mods]]"]
concepts: ["Stellaris mods"]
words: 1126
summary: "Spreadsheet planning a Stellaris tech tree rework: bonuses and techs mapped to research fields and tiers 0-5, mostly empty, with some filled entries (gateway techs, psionic, population/slave control, terraforming)."
tags: ["area/game-idea", "project/stellaris-mods", "type/planning"]
---

## Sheet: Sheet1

| Bonus | Field | Tier 0 | Tier 1 | Tier 2 | Tier 3 | Tier 4 | Tier 5 |
|---|---|---|---|---|---|---|---|
| Gateway Society | Statecraft |  |  | Edicts | Capital Building, Civic +1 | Capital Building | Capital Building |
| Gateway Physics | Particles |  |  | Fusion | Cold Fusion | Antimatter | Zero Point Reactor |
| Gateway Engineering | Voidcraft |  |  | Battleships | Weather Control | Anti-Gravity Engineering | Mega Engineering |
| Energy Production (Jobs) | Field Manipulation |  |  |  |  |  |  |
| Energy Production (Stations) | Field Manipulation |  |  |  |  |  |  |
| Mineral Production (Jobs) | Industry |  |  |  |  |  |  |
| Mineral Production (Stations) | Industry |  |  |  |  |  |  |
| Food Production (Jobs) | Biology |  |  |  |  |  |  |
| Food Production (Stations) | Biology |  |  |  |  |  |  |
| Research Speed | Computing |  |  |  |  |  |  |
| Research Alternatives | Computing |  |  |  |  |  |  |
| Encryption | Computing |  |  |  |  |  |  |
| Decryption | Computing |  |  |  |  |  |  |
| Research Physics (Jobs) | Computing |  |  |  |  |  |  |
| Research Society (Jobs) | Biology |  |  |  |  |  |  |
| Research Engineering (Jobs) | Industry |  |  |  |  |  |  |
| Research (Stations) | Computing |  |  |  |  |  |  |
| Fleet Cap | Military Theory |  |  |  |  |  |  |
| Starbase Cap | New Worlds |  |  |  |  |  |  |
| Faction Influence / Influence | Statecraft |  |  |  |  |  |  |
| Envoys | Statecraft |  |  |  |  |  |  |
| Habitability | New Worlds |  |  |  |  |  |  |
| Terraforming | New Worlds |  |  |  |  |  |  |
| Specialist Building | Varied |  |  |  |  |  |  |
| Building Slot | Varied |  |  |  |  |  |  |
| Stability/Deviancy | Statecraft |  |  |  |  |  |  |
| Pop Growth/Assembly | Biology |  |  |  |  |  |  |
| Fleet Exp | Military Theory |  |  |  |  |  |  |
| Fleet Upgrade Cost | Military Theory |  |  |  |  |  |  |
| Army Experience | Military Theory |  |  |  |  |  |  |
| Defense Army Strength | Military Theory |  |  |  |  |  |  |
| Special Assault Army | Various |  |  |  |  |  |  |
| Soldier Job Efficiency | Military Theory |  |  |  |  |  |  |
| Alloy Specialization (building) | Materials |  |  |  |  |  |  |
| Consumer Goods Specialization (building) | Materials |  |  |  |  |  |  |
| Alloy Spec (edict) | Statecraft |  |  |  |  |  |  |
| Consumer Goods spec (edict) | Statecraft |  |  |  |  |  |  |
| Strategic Resource Creation | Materials |  |  |  |  |  |  |
| Strategic Resource Mining | Materials |  |  |  |  |  |  |
| Amenities Production | Statecraft |  |  |  |  |  |  |
| Deviancy Reduction | Statecraft |  |  |  |  |  |  |
| Zro Distilation | Psionic |  | Zro |  |  |  |  |
| Empire Sprawl pops | Psionic |  |  | 0.1 |  |  |  |
| Precog Interface | Psionic |  |  |  | Component |  |  |
| Thought Enforcement | Psionic |  |  |  |  | Edict |  |
| PsiJump Drive | Psionic |  |  |  |  |  | Component |
| Leader Level Cap | Biology |  |  |  |  |  |  |
| Leader Lifespan | Biology |  |  |  |  |  |  |
| Robotic Workers |  |  |  |  |  |  |  |
| Genetic Points |  |  |  |  |  |  |  |
| Sensors |  |  |  |  |  |  |  |
| Combat Computers |  |  |  |  |  |  |  |
| Colony Speed |  |  |  |  |  |  |  |
| Shields |  |  |  |  |  |  |  |
| Armor |  |  |  |  |  |  |  |
| Lasers |  |  |  |  |  |  |  |
| Mass Drivers |  |  |  |  |  |  |  |
| Wormhole Travel |  |  |  |  |  |  |  |
| Gateways |  |  |  |  |  |  |  |
| LGate |  |  |  |  |  |  |  |
| Point Defense |  |  |  |  |  |  |  |
| Flak |  |  |  |  |  |  |  |
| Hyperspace Speed |  |  |  |  |  |  |  |
| Population Control |  |  |  | Chemical Bliss | Tracking Implants |  |  |
| Slave Control |  |  | Slave Center/Army | Thrall World |  |  |  |
| Uplift |  |  |  |  | Uplift |  |  |
| Planet Terraforming Types |  |  |  |  |  | Tomb World | Gaia |
| Entertainment Building |  |  |  |  |  |  |  |
| Unity Building |  |  |  |  |  |  |  |
| Trade Building |  |  |  |  |  |  |  |
| Embassy Building |  |  |  |  |  |  |  |
| Culture Building |  |  |  |  |  |  |  |
| Robomodding points |  |  |  |  |  |  |  |
| Consumer Goods Building |  |  |  |  |  |  |  |
| Alloy Building |  |  |  |  |  |  |  |
| Betharian Mining |  |  |  |  |  |  |  |
| Living Metal |  |  |  |  |  |  |  |
| Planetary Build Speed |  |  |  |  |  |  |  |
| City District Housing |  |  |  |  |  |  |  |
| Thruster components (thurster+afterburner) |  |  |  |  |  |  |  |
| Missile components |  |  |  |  |  |  |  |
| Mass Driver components |  |  |  |  |  |  |  |
| Strike Craft components |  |  |  |  |  |  |  |
| Station Sizes |  |  |  |  |  |  |  |
| Starbase Upgrade cost/speed |  |  |  |  |  |  |  |
| Habitiats |  |  |  |  |  |  |  |
| Ship hull cost |  |  |  |  |  |  |  |
| Ship hull speed |  |  |  |  |  |  |  |
| Ship hull hp |  |  |  |  |  |  |  |
