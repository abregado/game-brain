---
type: index
---

# Project Attention Ranking

How much time and thought each idea has had. **Score** = words in main docs ÷ 1000 + 2 × main docs + 0.5 × docs that only mention it + 1.5 × distinct years it was touched. Private docs kept out of the vault still count. Years come from each Google Doc's last-modified date, so the active range is approximate.

## Named game projects

| # | Hub | Theme | Score | Main docs | Mentions | Words | Active | Years | Furthest status |
|---|---|---|---|---|---|---|---|---|---|
| 1 | [[FourEcks - 4X Space Empire\|FourEcks / 4X Space Empire]] | Space Strategy & 4X | 112.4 | 34 | 7 | 22,942 | 2011–2026 | 12 | designed |
| 2 | [[Stardrive\|Stardrive]] | Space Strategy & 4X | 75.9 | 19 | 6 | 27,389 | 2012–2020 | 5 | played/used |
| 3 | [[Kobold\|Kobold]] | Projects I Made | 65.7 | 18 | 8 | 18,175 | 2021–2026 | 5 | built/shipped |
| 4 | [[Space Station 13-14\|Space Station 13/14]] | Space Stations & Crew Co-op | 60.8 | 13 | 12 | 15,331 | 2013–2025 | 9 | played/used |
| 5 | [[Survival Space Station\|Survival Space Station]] | Space Stations & Crew Co-op | 49.4 | 9 | 9 | 11,904 | 2013–2026 | 10 | played/used |
| 6 | [[Coop Station\|Coop Station]] | Space Stations & Crew Co-op | 34.3 | 9 | 7 | 3,804 | 2013–2024 | 6 | played/used |
| 7 | [[Living World PvE\|Living World PvE]] | Space Sims, Trading & MMO Economies | 34.3 | 5 | 9 | 4,840 | 2011–2021 | 10 | designed |
| 8 | [[Emerge\|Emerge]] | Projects I Made | 33.8 | 8 | 5 | 3,313 | 2013–2026 | 8 | built/shipped |
| 9 | [[Ship Repair Squad\|Ship Repair Squad]] | Space Stations & Crew Co-op | 32.9 | 4 | 6 | 11,413 | 2015–2026 | 7 | played/used |
| 10 | [[Cyberdungeon\|Cyberdungeon]] | Dungeon Crawlers & Roguelikes | 29.4 | 10 | 1 | 5,919 | 2013–2022 | 2 | played/used |
| 11 | [[Player Market Hoardmode\|Player Market Hoardmode]] | Space Sims, Trading & MMO Economies | 29.3 | 2 | 12 | 7,272 | 2011–2021 | 8 | prototyped |
| 12 | [[The Factory\|The Factory]] | Factories & Automation | 29.2 | 7 | 4 | 2,668 | 2012–2026 | 7 | designed |
| 13 | [[Ice Tribe - Ice Nomad\|Ice Tribe / Ice Nomad]] | Builders, Colonies & Sandboxes | 25.6 | 5 | 6 | 5,069 | 2012–2023 | 5 | designed |
| 14 | [[Diablo-like Action Shooter\|Diablo-like Action Shooter]] | Dungeon Crawlers & Roguelikes | 18.4 | 3 | 5 | 890 | 2016–2026 | 6 | played/used |
| 15 | [[Xenosurge\|Xenosurge]] | Projects I Made | 13.8 | 2 | 4 | 296 | 2012–2020 | 5 | built/shipped |
| 16 | [[Spacetrauma\|Spacetrauma]] | Space Stations & Crew Co-op | 12.7 | 2 | 3 | 1,231 | 2013–2024 | 4 | prototyped |
| 17 | [[Pipe Game - Piperspace\|Pipe Game / Piperspace]] | Projects I Made | 12.0 | 3 | 1 | 2,509 | 2024–2025 | 2 | prototyped |
| 18 | [[Catastrophic Journey\|Catastrophic Journey]] | Projects I Made | 8.4 | 2 | 1 | 900 | 2021–2025 | 2 | prototyped |

## Tabletop projects & campaigns

| # | Hub | Theme | Score | Main docs | Mentions | Words | Active | Years | Furthest status |
|---|---|---|---|---|---|---|---|---|---|
| 1 | [[FDnD Campaign (Frankfurt)\|FDnD Campaign (Frankfurt)]] | D&D | 151.7 | 39 | 12 | 54,165 | 2015–2026 | 9 | played/used |
| 2 | [[WDnD Campaign\|WDnD Campaign]] | D&D | 103.5 | 26 | 3 | 41,020 | 2020–2025 | 6 | played/used |
| 3 | [[Necromunda Homebrew\|Necromunda Homebrew]] | Wargames | 85.1 | 24 | 8 | 21,118 | 2010–2026 | 8 | played/used |
| 4 | [[Kill Team & 40k Homebrew\|Kill Team & 40k Homebrew]] | Wargames | 61.5 | 15 | 5 | 16,963 | 2010–2026 | 8 | played/used |
| 5 | [[Stompy Robo & Battletech\|Stompy Robo & Battletech]] | Wargames | 47.1 | 14 | 4 | 11,141 | 2013–2026 | 4 | prototyped |
| 6 | [[Lego Wargame\|Lego Wargame]] | Wargames | 18.7 | 5 | 0 | 4,182 | 2011–2013 | 3 | designed |
| 7 | [[Wube Roleplay\|Wube Roleplay]] | D&D | 17.4 | 5 | 1 | 3,906 | 2019–2022 | 2 | played/used |
| 8 | [[Shemshimes - The Rhyme\|Shemshimes / The Rhyme]] | Other RPGs | 15.6 | 4 | 0 | 3,147 | 2021–2024 | 3 | designed |

## Idea themes (collections of many smaller ideas)

| # | Hub | Theme | Score | Main docs | Mentions | Words | Active | Years | Furthest status |
|---|---|---|---|---|---|---|---|---|---|
| 1 | [[D&D Homebrew\|D&D Homebrew]] | D&D | 166.4 | 39 | 45 | 50,877 | 2013–2026 | 10 | played/used |
| 2 | [[D&D One-shots\|D&D One-shots]] | D&D | 133.9 | 31 | 14 | 54,409 | 2019–2025 | 7 | played/used |
| 3 | [[EVE-like Player Economy\|EVE-like Player Economy]] | Space Sims, Trading & MMO Economies | 95.0 | 20 | 21 | 29,520 | 2011–2026 | 10 | played/used |
| 4 | [[Shooters & FPS\|Shooters & FPS]] | Shooters & Action | 94.1 | 26 | 13 | 17,613 | 2012–2026 | 12 | played/used |
| 5 | [[Playdate & Small Games\|Playdate & Small Games]] | Small, Mobile & Casual | 80.7 | 20 | 12 | 18,162 | 2013–2026 | 11 | prototyped |
| 6 | [[Game Business & Funding\|Game Business & Funding]] | Business & Funding | 80.4 | 21 | 26 | 8,906 | 2012–2026 | 11 | built/shipped |
| 7 | [[Non-Game Projects\|Non-Game Projects]] | Non-Game Ideas | 75.3 | 24 | 5 | 8,271 | 2013–2026 | 11 | prototyped |
| 8 | [[Elite-like Space Flight & Trading\|Elite-like Space Flight & Trading]] | Space Sims, Trading & MMO Economies | 72.2 | 17 | 10 | 15,210 | 2011–2026 | 12 | played/used |
| 9 | [[City & Colony Builders\|City & Colony Builders]] | Builders, Colonies & Sandboxes | 71.7 | 18 | 13 | 12,693 | 2011–2026 | 11 | prototyped |
| 10 | [[Factorio mods & ideas\|Factorio mods & ideas]] | Factories & Automation | 71.6 | 17 | 6 | 19,589 | 2015–2024 | 10 | built/shipped |
| 11 | [[Game Jams\|Game Jams]] | Projects I Made | 69.1 | 20 | 7 | 7,591 | 2012–2026 | 12 | played/used |
| 12 | [[Narrative & Story Games\|Narrative & Story Games]] | Narrative & Worldbuilding | 61.8 | 17 | 4 | 12,327 | 2012–2026 | 9 | designed |
| 13 | [[Minecraft & Voxel Building\|Minecraft & Voxel Building]] | Builders, Colonies & Sandboxes | 52.2 | 11 | 9 | 9,197 | 2013–2026 | 11 | prototyped |
| 14 | [[Other Wargames\|Other Wargames]] | Wargames | 49.1 | 12 | 10 | 8,067 | 2012–2026 | 8 | prototyped |
| 15 | [[RTS Ideas\|RTS Ideas]] | Tower Defense & RTS | 49.1 | 13 | 12 | 5,129 | 2011–2026 | 8 | played/used |
| 16 | [[Board & Card Games\|Board & Card Games]] | Board & Card Games | 42.3 | 11 | 3 | 8,267 | 2011–2026 | 7 | built/shipped |
| 17 | [[Other RPGs (FATE, Cypher, etc.)\|Other RPGs (FATE, Cypher, etc.)]] | Other RPGs | 41.5 | 10 | 2 | 14,482 | 2013–2024 | 4 | designed |
| 18 | [[Stellaris mods\|Stellaris mods]] | Space Strategy & 4X | 38.0 | 12 | 4 | 6,014 | 2021–2025 | 4 | designed |
| 19 | [[Couch Co-op & Party Games\|Couch Co-op & Party Games]] | Couch & Party Co-op | 36.5 | 9 | 5 | 4,008 | 2013–2026 | 8 | prototyped |
| 20 | [[Tower Defense\|Tower Defense]] | Tower Defense & RTS | 33.9 | 6 | 10 | 3,430 | 2012–2026 | 9 | played/used |
| 21 | [[Roguelikes & 7DRL\|Roguelikes & 7DRL]] | Dungeon Crawlers & Roguelikes | 30.0 | 6 | 1 | 8,523 | 2013–2026 | 6 | designed |
| 22 | [[Industry & Production Games\|Industry & Production Games]] | Factories & Automation | 28.0 | 6 | 6 | 4,022 | 2013–2025 | 6 | designed |
| 23 | [[Dwarf Fortress mods\|Dwarf Fortress mods]] | Factories & Automation | 27.0 | 6 | 4 | 5,539 | 2012–2024 | 5 | prototyped |
| 24 | [[Wikiverse & Worldbuilding\|Wikiverse & Worldbuilding]] | Narrative & Worldbuilding | 24.7 | 8 | 0 | 4,177 | 2013–2020 | 3 | designed |
| 25 | [[Dungeon Crawlers\|Dungeon Crawlers]] | Dungeon Crawlers & Roguelikes | 24.1 | 6 | 1 | 2,633 | 2013–2026 | 6 | prototyped |
| 26 | [[Pocket Monster Games\|Pocket Monster Games]] | Small, Mobile & Casual | 23.9 | 5 | 5 | 2,363 | 2016–2026 | 6 | played/used |
| 27 | [[Star Ruler mods\|Star Ruler mods]] | Space Strategy & 4X | 18.1 | 5 | 2 | 4,080 | 2011–2013 | 2 | designed |
| 28 | [[Farming Games\|Farming Games]] | Builders, Colonies & Sandboxes | 16.6 | 3 | 2 | 2,060 | 2013–2022 | 5 | played/used |
| 29 | [[Mech Games (video)\|Mech Games (video)]] | Shooters & Action | 15.2 | 3 | 2 | 707 | 2013–2026 | 5 | designed |
| 30 | [[Barotrauma mods\|Barotrauma mods]] | Space Stations & Crew Co-op | 9.9 | 3 | 0 | 2,422 | 2023–2023 | 1 | played/used |
