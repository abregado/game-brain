---
title: "DD - Simple Locational Strategy BG"
source: "Game Stuff/Game Ideas/DD - Simple Locational Strategy BG"
modified: 2011-03-11
type: design-doc
area: boardgame
status: "idea"
projects: ["[[Board & Card Games]]"]
concepts: ["Simple Locational Strategy Card Game"]
words: 196
summary: "Outline of a simple card/board game where two-effect cards move tokens between location cards; win by solely occupying four connected locations. Card and token sections are empty."
tags: ["area/boardgame", "project/board-card-games", "type/design-doc"]
---

# **SIMPLE CARD/BOARD GAME**

> [*SIMPLE CARD/BOARD GAME*](#simple-cardboard-game)
>
> [*CONCEPT*](#concept)
>
> [*GAMEPLAY*](#gameplay)
>
> [*ACTION CARDS*](#action-cards)
>
> [*LOCATION CARDS*](#location-cards)
>
> [*TOKENS*](#tokens)

##  

## **CONCEPT**

Through decisive choices, the combatants must fight out a war of attrition to secure their holdings and ultimately claim victory!

## **GAMEPLAY**

Players are dealt random cards at the start of the turn. There are only enough cards for everyone to receive a full hand. Each card has two effects on it. Players take it in turns playing a card and choosing which effect will be played on themselves, and also must choose another player to receive the secondary effect.

Each card effects the locations on the game board (constructed out of cards). Players power is represented by tokens which build up on the board. The card effects add, remove or force players to move these tokens around the board. Each location has a passive effect for the player with the most tokens, and one for the player with the least tokens. Occupying a region alone removes these abilities.

The winner is the player who solely occupies 4 connected locations.

## **ACTION CARDS**

## **LOCATION CARDS**

## **TOKENS**
