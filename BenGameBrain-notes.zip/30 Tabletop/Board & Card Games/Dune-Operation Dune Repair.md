---
title: "Dune-Operation Dune Repair"
source: "Game Stuff/Game Ideas/Dune-Operation Dune Repair"
modified: 2013-06-12
type: homebrew-rules
area: boardgame
status: "designed"
projects: ["[[Board & Card Games]]"]
concepts: ["Dune Repair"]
words: 534
summary: "Proposal to fix Dune's length and late-game boredom: simplified bidding and battle phases, fewer turns, fewer troops to tanks, more free revivals, and movement changes."
tags: ["area/boardgame", "project/board-card-games", "type/homebrew-rules"]
---

Operation Dune Repair:

Main issues with the game

Game Length

Roughly 45-90 mins per turn. 6 Turn Game is 4.5-9 hours long

Late Game is VERY boring

Once several battles have taken place, most Troops are in the tanks.

> Second build up is very slow

Most Territory has no strategic value

> Territories outside of sietches are unimportant
>
> Rock Territories are not very important

# **Ideas to reduce game length (keep it to 30 mins)**

## ***Simplify current turn structure***

Setup Phase: Take all 6 tokens and remove 1. Add the rest together to determine where the storm starts.

(Battle wheels are no longer being used)

Bidding Phase: Players place how as many spice as they wish to bid in their fist and hold it in front of them. Once all players have decided, they all reveal at once. The player with the highest bid wins the card and pays the Spice to the emperor. The rest keep their spice.

(This would help to keep the bidding round short, as well as keeping the price of cards down)

Battle Phase: All Voice and Prescience is performed at the start of the battle phase. Then players place their leader tokens face down in the regions they are fighting in. Players bid during the battle as they do during the Treachery Phase. The number of spice represents the number of troops that are being committed to battle. The Total is equal to the number of troops committed plus leaders (if they survive). Committed Troops are sent to the tanks.

(This increases the cost of doing battle as Spice is essential to winning, but it should keep the number of committed troops down. Increased costs of battle are balanced with more free revivals)

## ***Reduce number of turns***

Fremen player wins immediately at the end of turn 6 (~3 hours appox)

# **Late game ideas**

## ***Reduce number of troops sent to the tanks***

Only committed troops from both battles are sent to the tanks. The loser of a battle is ejected from the territory into adjacent one. The loser may pick which territory to move too, but it must be unoccupied. Also, half of the losers remaining troops are sent to the tanks.

## ***Remove need for second build up***

Players should not be completely ground into dust by the end of the game. Players who find themselves destroyed early in the game can still make a late game re-appearance.

## ***Increase number of revivable troops***

Number of free revivals increased by 2 for each team. Max revivals is 6. This should mean that all teams can afford to be involved in low level skirmishes for spice blows.

# **Ideas to improve territories**

## ***You may move all of your groups of troops***

This would promote players keeping some small groups of troops on rocks near the regions where spice blows form. Currently it costs 2 spice to ship troops directly to the spice and then they each harvest 2 spice, not very profitable after u fight. It might also promote some small battles in the desert.

Things I will need to repair dune

Leader Disks that can be held in the hand
