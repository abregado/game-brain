---
title: "BS -Geiger Game 2005"
source: "Game Stuff/Game Ideas/BS -Geiger Game 2005"
modified: 2013-06-12
type: design-doc
area: boardgame
status: "designed"
projects: ["[[Board & Card Games]]"]
concepts: ["Geiger Card Game"]
words: 285
summary: "Turn phase rules draft (Daylight, Dusk, Night, Dawn) for a 2005 card game with biomechanoids, Birthing Chambers, Artifacts and Destiny cards."
tags: ["area/boardgame", "project/board-card-games", "type/design-doc"]
---

Daylight Phase

Firstly each player is dealt two cards from the top of the deck.

Then, starting with the player who has the most souls captured, each player may play a single Location or Artifact card.

Also during this phase players can conceive new biomechanoids by placing them face up on top of Birthing Chambers that they control. Immediately after they are placed, all players may place Feature cards face down on top of the conceived creature.

Also any abilities that can be played during the Daylight Phase may be played now.

Dusk Phase

During this Phase all players prepare for the night phase. In the same order as the Daylight Phase, each player can play a single Destiny Card. These are played between

Night Phase

Dawn Phase

In the same order as the night phase, players must first discard cards until they have 7 cards or less in their hand. Any Destiny cards played during the Dawn phase are removed now as well. Move any biomechanoids that survived the night back in front of their owning players.

Any Artifacts that require Tribute must have it fulfilled in this Phase. If a player refuses to pay a Tribute then any other player may gain control of the Artifact by paying it instead. If nobody decided to pay Tribute to an Artifact then it is discarded.

Any creatures that were conceived during the last Daylight Phase are now removed from the Birthing Chambers and placed into the play area. Also at this point all feature cards played on a creature are revealed.

Finally all cards in the Discard pile are reshuffled into the remaining deck cards and placed face down ready for the next Daylight Phase.
