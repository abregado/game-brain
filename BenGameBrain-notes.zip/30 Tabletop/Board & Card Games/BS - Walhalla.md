---
title: "BS - Walhalla"
source: "Game Stuff/Game Ideas/BS - Walhalla"
modified: 2013-06-12
type: idea
area: boardgame
status: "idea"
projects: ["[[Board & Card Games]]"]
concepts: ["Walhalla CCG"]
words: 154
summary: "Idea for a CCG with Creature and Land decks where players build a shared city and enhance spawned creatures face-down."
tags: ["area/boardgame", "project/board-card-games", "type/idea"]
---

BS - Walhalla

CCG Game with two decks. Creatures and Land. Land gets arranged on the table. District cards get layed out portrait orientation, bridge cards get layed out landscape orientation. The players slowly build a city to explore and fight in.

Creatures are moved around on this city using tokens. A matching token is placed on the creature card near the owning player. All players have an opportunity to force their opponents creatures to move. Creatures can collect resources from the distric they are currently in.

Creatures are spawned upside down next to the player who wants to spawn them. He and all other players can place enhancement cards on top of it (face down) during their own turns. Players must leave a creature until their next turn to give all players an opportunity to enhance/mutate the creature. If two of the same enhancement is on a revealed creature, all copies are removed.
