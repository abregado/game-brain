---
title: "Card app tweaks"
source: "Game Stuff/Game Ideas/Card app tweaks"
modified: 2026-04-02
type: planning
area: other
status: "built/shipped"
projects: ["[[Board & Card Games]]"]
concepts: ["Card Game App"]
words: 96
summary: "Four small feature tweaks for a card-game app: zone names, spread offset, pan view, spread z-index."
tags: ["area/other", "project/board-card-games", "type/planning"]
---

Card app tweaks

Each snap zone should have a name setting, that appears under the zone on the play field.

If a zone has the spread display type, it has a Vector2 setting for card offset.

The user can pan the view by dragging right mouse button on desktop or long press and drag on the play area if using touch. There is a toggle on the toolbar for locking the view.

When short pressing on a card in a spread view zone, don't change its position, only it's z index so it can be seen.
