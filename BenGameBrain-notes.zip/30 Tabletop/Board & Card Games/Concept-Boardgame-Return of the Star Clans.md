---
title: "Concept-Boardgame-Return of the Star Clans"
source: "Game Stuff/Game Ideas/Concept-Boardgame-Return of the Star Clans"
modified: 2013-06-12
type: design-doc
area: boardgame
status: "designed"
projects: ["[[Board & Card Games]]", "[[Stompy Robo & Battletech]]"]
concepts: ["Return of the Star Clans", "Battletech homebrew"]
words: 555
summary: "Design document for a personal 3-5 player Battletech-themed boardgame where clans bid ever smaller forces to conquer planets, with combat resolution options and card play."
tags: ["area/boardgame", "project/board-card-games", "project/stompy-robo-battletech", "type/design-doc"]
---

Clans Return

or

Return of the Star Clans

--------------------------------------------------------------------------

A personal board game by Ben Buckton

**Abstract:** The players battle to re-conquer the galaxy using cunning, strategy and underhanded tactics.

**Setting:** The mighty Star Clans have returned to take back the universe, using their honour and powerful Omnimechs. Each player controls one tribe of these warriors, bidding his ever dwindling forces in battles to retake Terra. You must race to capture key planets before your opponents, while also working together lest the meagre forces of humanity halt the invasion for good!

**Vision:** To represent the military culture of the Star Clans in a boardgame.

**Mission Goals:**

Game mechanics focus on players bidding ever smaller groups of forces to take over planets

Simple combat resolution determined simultaneously (dice)

Positional strategy

Strategic Card play

Play time of roughly an hour

3-5 players

**Design Document**

Key Development Areas

Bidding System

Combat Resolution ideas

Cardplay

Art and playing pieces

Objective balancing and playtesting

Bidding System

In the fiction, the Star Clans meet at a council and each takes turns “bidding” for the right to conquer a planet. First one clan proclaims which planet they desire and exactly how much resources they wish to take. Any other clan can “bid” for the right to attack the planet instead simply by promising to complete the conquest with less resources. This bidding continues until one clan is set to attack a planet with a heroic (foolish) amount of Omnimechs and support vehicles. Often this leaves only a single “star” (group of 5 'mechs) to conquer a whole planet.

The bidding system should emulate this process as much as possible. Bidding is never hidden, always proclaimed aloud. In the fiction a bid is binding, as to reneg would damage a warriors honour. So let it be said that:

“Bids must be proclaimed aloud by a player. The exact amount of resources, as well as the location should be spoken aloud”

“Any player can bid a smaller amount of resources to the same planet. This continues until all players pass on their opportunity to bid. The player left with his bid is committed to attack this planet”

“NO TAKEBACKS on bids”

To determine what is a “smaller bid” we assign the following order of value to the resources:

Star of Assault Mechs (supported)

Star of Omnimechs (supported)

Star of Assault Mechs (unsupported)

Star of Omnimechs (unsupported)

NB\* These values are likely to change

Combat Resolution ideas

There are two separate ideas for combat resolution in the works. The first involves a Risk-esque(tm) dice rolling, the other is a fixed system of adding arbitrary values, the highest winning (no random factor).

The Dice rolling variant would see the two types of unit (Omnimech and Assault Mech) be represented in combat by D6 and D8 respectively. These will be further modified by having a support unit available which will add 1 to the die total.

Cardplay

Players will be dealt a hand of cards that can be used to effect the outcome of battles. The effects of these will be determined based on the type of combat resolution.

Art and playing pieces

The board shall be designed by Ben Buckton. The pieces will be taken from other boardgames, mainly Risk2033

Objective balancing and playtesting

Balancing shall be headed by our GamesNite(tm) team in Joshes Office tower.
