---
title: "Character Voicing"
source: "Game Stuff/Character Voicing"
modified: 2022-01-05
type: notes
area: other
status: "unknown"
projects: ["[[Other RPGs (FATE, Cypher, etc.)]]"]
concepts: ["Character Voicing"]
words: 48
summary: "Short notes on Laban efforts (weight, space, timing) applied to character voicing for acting."
tags: ["area/other", "project/other-rpgs-fate-cypher-etc", "type/notes"]
---

Laban Efforts

Weight = light or heavy

Spacial = direct or indirect

Timing = sudden or sustained

Dabbing = light, Direct and Sudden

Flicking = light, indirect and sudden

Pressing = strong, direct and sustained

Thrusting

Wrining

Slashing

Gliding

Floating = light, indirect, sustained

Throating, Nasally or Regular
