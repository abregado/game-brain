---
title: "Cypher Shorts Ideas"
source: "Game Stuff/Cypher Shorts Ideas"
modified: 2023-08-16
type: brainstorm
area: rpg-other
status: "idea"
projects: ["[[Other RPGs (FATE, Cypher, etc.)]]", "[[D&D One-shots]]"]
concepts: ["Cypher Shorts", "D&D one-shots"]
words: 299
summary: "List of one-line situation prompts (mecha kaiju battle, hostage, bomb, bar fight etc.) for short Cypher one-shot sessions, with a few sample complications."
tags: ["area/rpg-other", "project/d-d-one-shots", "project/other-rpgs-fate-cypher-etc", "type/brainstorm"]
---

For each of the situations below, come up with 5 interesting things that could happen that the players need to react too.

Mecha Kaiju battle!

- FIRE MAH LAZOR!

- Kaiju digs underground

- Kaiju splits in two / A buddy shows up

- The battle moves to a different location (harbour, city, power plant)

Stuck on a spaceship / Submarine

- Something outside needs your attention, who goes?

Dealing with visitors in a dangerous world. Who do you let in?

- A family shows up that is being hunted

- A wealthy trader with a bodyguard

- A sick person

Track something

- Signs of a battle with a different creature

Something is tracking you

Car/Horse/Plane/Boat Race, start in the middle

Make it out of a compound while hostile robots patrol outside.

- You hear that a drone has entered the building you are inside

- A flock of birds land, or a hostile dog shows up

- The macguffin starts making noise

Sitting on a train and someone demands your wallet and valuables.

You have a gun to someone’s head. How did you get here?

Someone has a gun to your head. How did you get here?

Encounter a strange beast

Uncover a magical effect

Explore an amazing place

Click! The trap is triggered.

Investigate a missing person

You exit the saloon and see a wanted criminal riding into town

Bar fight just breaks out

Alien crash site

Arriving at a burning building

Something happens on your private yacht

Wake up stranded on a deserted island

The bomb goes off and…

You are in front of the bomb, 5 minutes remain…

You have 5 hostages. How did it get like this?

You are one of 5 hostages. How did it get like this?

Locked in a cell.
