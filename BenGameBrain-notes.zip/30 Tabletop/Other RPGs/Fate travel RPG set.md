---
title: "Fate travel RPG set"
source: "Game Stuff/Fate travel RPG set"
modified: 2024-10-30
type: homebrew-rules
area: rpg-other
status: "designed"
projects: ["[[Other RPGs (FATE, Cypher, etc.)]]", "[[D&D Homebrew]]"]
concepts: ["Fate travel RPG set", "Fate house rules"]
words: 577
summary: "Kit list and house rule changes for running Fate with a travel set (card decks, tokens, colored markers), plus rule changes on compels, enemies, kill/resist ratings and prompts for declared actions."
tags: ["area/rpg-other", "project/d-d-homebrew", "project/other-rpgs-fate-cypher-etc", "type/homebrew-rules"]
---

Fate travel RPG set

Adjectives deck

Nouns Deck

Verbs Deck

Blank flash cards

Fate/Boost tokens (40)

2 sets of Fate Dice

Stress tokens (15 Physical and 15 Mental)

A5 paper sheets

Approaches deck (4,2,1 \* 1 of each) - 18 cards

Metaplay deck

Colored markers

- Aspect Color (Character and Situation are same color)

- Temp Aspect Color

- Consequence Color

- Zone Color

- Enemy/Obstacle Color

- Countdown Color

- Item/Enabler color

Rule Changes:

Ask and agree before the scene starts: What are at least two outcomes of this scene? What are the stakes?

“Failing” a scene is part of the story

Approaches:

Actions

Create an advantage - make something easier / change the situation

Overcome - get past something

Attack - remove something from the board “take them out”

Reactions (uses action)

Types

Challenge - Against set target, Succeed at cost, Style

Conflict- VS, Style, Both at risk

Contest - VS race, Style

Roll, invoke, resolve

Consequences are aspects on characters with free invokes for the Guide. They are there to raise the stakes.

Complication Round. Together discuss what could go wrong now based on the active Aspects. The Guide offers FATE points from the bank to players to have the compel take effect. Any player can suggest a compel, and the Guide can accept it by giving a Fate point from the bank.

Each compel in the round is negotiated, but the Guide has the final say and can retract or shoot down an offer at any time.

Compels are not mechanical effects, they are narrative changes. They are based on Aspects and should always create a complication for the characters, not a benefit.

Enemies always act first but can be interrupted. The Guide narrates an action for each actor that can act (hazards/enemies). Obstacles do not act. Counters count down if nothing is done about them. Once all the actions are declared, the players can state what they are doing to interfere.

Armor and Stress on enemies/obstacles

Enemies have 3 skill levels. One for their highest skill, one of their lowest, and one for the rest. Players can narrate their attacks and propose a defence value for the enemy.

Enemies have a Kill rating which is how many shifts at once they need to be destroyed

They have a Resist value which is how many shifts and below will do nothing to the target.

A shift score equal or higher than the Resist score, and less than the kill score will add an aspect to the target.

Players always say the aspect they want to add before they roll.

Weakened/Mitigated/Removed

Distracted/Disabled/Killed

When you

- Choose to succeed with cost…

- Succeed with style…

- Invoke your main aspect…

- Invoke an aspect to reroll…

- Invoke an aspect in a zone…

- Create an Advantage successfully…

- Attempt an Overcome action with your highest skill…

  - This is my jam

- Succeed in a challenge…

- Succeed in a conflict…

- Use a free invoke…

- Have your compel accepted by the Guide…

- Suffer a consequence…

- Spend stress…

- Accept a compel from the Guide…

- Begin a conflict against a target…

- When you choose to concede…

When an action is declared:

What do you expect to happen?

How are you going to achieve that?

What is the worst case?

What is the worst version of success?

If this goes your way, what changes?

Does this move the story along?
