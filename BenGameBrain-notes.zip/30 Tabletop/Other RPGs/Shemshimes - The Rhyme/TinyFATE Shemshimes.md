---
title: "TinyFATE Shemshimes"
source: "Game Stuff/TinyFATE Shemshimes"
modified: 2024-11-02
type: campaign-prep
area: rpg-other
status: "designed"
projects: ["[[Shemshimes - The Rhyme|Shemshimes / The Rhyme]]"]
concepts: ["Shemshimes / The Rhyme", "TinyFATE"]
words: 1423
summary: "Scenario prep for the Shemshimes one-shot in TinyFATE: information to learn after each event, timed scene list (intro tour, breakfast quarantine, outbreaks of singing, puppets), zones and aspects, and the book/demon resolution in a haunted restoring library."
tags: ["area/rpg-other", "project/shemshimes-/-the-rhyme", "type/campaign-prep"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Crinkle</strong></th>
</tr>
<tr class="odd">
<th>Job: Keeper of the Fireflies, Janitor, Cook</th>
<th></th>
</tr>
<tr class="header">
<th><p><strong>Aspects</strong></p>
<p>Keeper of the fireflies</p>
<p>Everybody talks too much</p>
<p>Amazed by shiny things</p></th>
<th><p>Defensiveness</p>
<p>Shaking head all the time</p>
<p>Holding a book as a shield</p>
<p>Body shielding (turning the body away from a person)</p>
<p>Eyes darting for escape</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Varnyr</strong></th>
</tr>
<tr class="odd">
<th>Job: <strong>Project Management and Rebinding</strong></th>
<th></th>
</tr>
<tr class="header">
<th><p><strong>Aspects</strong></p>
<p>Overworked for the last 100 years</p>
<p>Can resist the humming</p>
<p>(hidden) Feels responsible for everything</p></th>
<th><p>Pride -&gt; insecurity</p>
<p>Expansive movements. Hands clasped</p>
<p>A knowing grin</p>
<p>Self deprecating laugh</p>
<p>Asking others for reassurance</p>
<p>Hair over face, touching lips</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Tulah</strong></th>
</tr>
<tr class="odd">
<th>Job: <strong>Researcher of Folk Tales</strong></th>
<th></th>
</tr>
<tr class="header">
<th><p><strong>Aspects</strong></p>
<p>Easily distracted</p>
<p>Under pressure to succeed</p>
<p>(hidden) Hates being Locked up</p></th>
<th><p>Emotion. Anxiety -&gt; hysteria</p>
<p>Rubbing neck, twisting watch on wrist.</p>
<p>“Chopping” with two hands while speaking. Hold herself while listening.</p>
<p>Hands clenched</p>
<p>Vehement head shaking</p>
<p>Thrashing</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Gailby Smallstone</strong></th>
</tr>
<tr class="odd">
<th>Job: <strong>School</strong></th>
<th></th>
</tr>
<tr class="header">
<th><p><strong>Aspects</strong></p>
<p>Dangerously inquisitive</p>
<p>Never where you left her</p></th>
<th><p>Emotion. Admiration -&gt; intimidated</p>
<p>Nodding and grinning</p>
<p>Asking for more information</p>
<p>Compliments</p>
<p>Interrupting to ask questions</p>
<p>Hiding behind someone else</p>
<p>Go away! Your just a fairy tale</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Ebder Smallstone</strong></th>
</tr>
<tr class="odd">
<th>Job: <strong>Scribe. Rewriting the books</strong></th>
<th></th>
</tr>
<tr class="header">
<th><p><strong>Aspects</strong></p>
<p>Books are nicer than people</p>
<p>Loving single parent</p>
<p>(hidden) Feels powerless</p></th>
<th><p>Overwhelmed -&gt; powerlessness</p>
<p>Muttering, mumbling. Rubbing temples.</p>
<p>Hands shaking, dropping things</p>
<p>Severe noise sensitivity</p>
<p>Verbal denial</p>
<p>“I deserve this”</p>
<p>Looking at hands</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# After breakfast what can they learn?

- The jobs of each person

- Gailby was up early this morning and already “went exploring”, but only inside the cellar because “Dad says I shouldnt bother the people upstairs”

- Gailby likes to draw but doesnt like to show her dad the pictures

- Crinkle is more agitated than normal

- Ebders wedding ring has gone missing

- Tulah has a music box in her room

- Varnyr remembers there was an instance of a “singing plague” about 600 years ago

- One of the players items is missing

- There is a massive stone statue of a book suspended above the balcony on the top floor

- The restoration project is 50 years into its 300 year length

# After event 2 what can they learn?

- If 5 people are in the same place, then bad things happen

- Ebder was in the Scriptorum until this happened

- Gailby was the first to sing the song

- She woke up and started singing it

- A book is missing from the workshop

- Tulahs music box calms her down

# After event 3 what can they learn?

- If 4 people are in the same place then bad things happen.

- The lyrics to the song can be heard

- They also find the words carved into the capstone

- The name of the skull

- The people under the stone are a mix of merchants and library staff from 600 years ago

- The name of the book that came with the merchants is Shemshimes Bedtime Rhyme

- More people singing, means Shemshime will be more powerful

# After event 4 what can they learn?

- Bad things happen if 3 people are in the same place

- Tulah Hates being locked up

- Varnyr has the key to get out

- Varnyr knows that the singing curse is infectious

# After they have the book

- If they sing loudly together then the book will summon Shemshime

- The rhyme tells that you need to crush the demon to destroy it temporarily, remove the curse and seal it once again in the book

- Destroying the book does nothing, as the book just reforms.

- Any interesting way of banishing the demon should be accepted.

#  

# Scenes

## Scene 1: Intro Tour

Purpose: Introduce the layout of the area and the characters who inhabit it.

Player choice: Which bedroom they stay in (make some aspects)

Varnyr and Crinkle sorting books on the top floor

NO FIRE! - Varnyr

You are very welcome to explore - Varnyr

They give the players a lantern and a pile of books. Crinkle goes with them to the Scriptorium

Downstairs Crinkle and Ebder. Ebder in the Scriptorium. Crinkle in the firefly room.

Ebder takes the books and sends the characters with more books to Tulah

Tulah in her room, Then Ebder comes in and tells everyone to be quiet because Gailby is asleep.

Characters choose their rooms and go to bed.

## Event 1: Breakfast and Quarantine

Purpose: Let the players explore

Choice: Who they talk to first

Tulah and Ebder at breakfast, humming

Varnyr comes in and tells we are quarantined

Tulah leaves to her room

Ebder leaves to Scriptorium

Gailby comes in from upstairs

Crinkle is cleaning the stone statue

## Event 2

20 minutes in Event 2 Ebders Outburst

Purpose: Raise the stakes

## Event 3

40 minutes in Event 3: Singing Skull

Purpose: Provide the lyrics

Humming becomes singing

## Event 4

60 minutes in Event 4: Tulahs escape

Purpose: Provide a conflict to get too many people into one room

Tulah and Varnyr Fight about leaving

## Event 5 (optional)

80 minutes: Puppets + Gailby possessed

Purpose: To “give”” the players the book

Ebder and Tulah become puppets, and attack the players

Crinkle and Gailby run away to Crinkles room

When the players arrive, Gailby has attacked Crinkle with the book

## Event Final

Players get the Book, repair it, summon Shemshime and destroy it.

The Book resets to show new scenes based on a character or an area of the library

# Zones and Aspects

Top level:

Piles of old books

Old Stone shelves

Enormous statue

Middle level

Construction work

Rolling ladders

Dusty

Scriptorium

Firefly Room

Glass everywhere

Bindery

Kitchen

Modern “fire-free” appliances

Stone dining table

Bedrooms

# Shemshime

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>Knusper, knusper Knäuschen</p>
<p>wer knuspert an meinem Häuschen</p>
<p>Ene, meme, miste</p>
<p>Was rappelt in der Kiste?</p>
<p>Ene, mene, meck</p>
<p>Und Du bist weg!</p>
<p>Eins, Zwei, Drei</p>
<p>Und du bist frei!</p>
<p>Eins, Zwei, Drei</p>
<p>Auf der Treppe liegt ein Ei</p>
<p>Wer darauf tritt</p>
<p>Spielt nicht mit</p>
<p>Drei, vier funf</p>
<p>Der Storch hat keine Strumpf</p>
<p>Der Frosch hat kein Haus</p>
<p>Und du musst raus!</p>
<p>6 ist kein Wort</p>
<p>Und du bist fort!</p>
<p>Regen, Regen, Tröpfchen,</p>
<p>fall mir auf mein Köpfchen,</p>
<p>fall mir nicht daneben,</p>
<p>dass ich lang soll leben!</p></th>
<th><p>Move by flowing along shadows</p>
<p>Shadows become sharper</p>
<p>Earworm shadows going into peoples ears</p>
<p>Howling Babble</p>
<p>Whispers of Violence</p>
<p>Maddening Touch</p>
<p>Fireflies die in an area and the lights go out</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>See a Mother Scything Wheat</p>
<p>Forgotten Husband Sleeping near</p>
<p>with One Swing She Took His Feet</p>
<p>with Another Took His Ear</p>
<p>Does the shadow have a name? SHEMSHIME SHEMSHIME</p>
<p>Causes grief, avoids the blame SHEMSHIME SHEMSHIME</p>
<p>See a dog that knows how to heel</p>
<p>Never heeds plea nor command</p>
<p>Mother gave it a tasty meal</p>
<p>Dog chose instead to eat her hand</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p>
<p>See a son doing his chore</p>
<p>Washing clothes for folk in town</p>
<p>Fell into the river's roar</p>
<p>Sank to the bottom and drowned</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p></th>
<th><p>See a Mother Scything Wheat</p>
<p>Forgotten Husband Sleeping near</p>
<p>with One Swing She Took His Feet</p>
<p>with Another Took His Ear</p>
<p>Does the shadow have a name? SHEMSHIME SHEMSHIME</p>
<p>Causes grief, avoids the blame SHEMSHIME SHEMSHIME</p>
<p>See a dog that knows how to heel</p>
<p>Never heeds plea nor command</p>
<p>Mother gave it a tasty meal</p>
<p>Dog chose instead to eat her hand</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p>
<p>See a son doing his chore</p>
<p>Washing clothes for folk in town</p>
<p>Fell into the river's roar</p>
<p>Sank to the bottom and drowned</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p></th>
</tr>
<tr class="odd">
<th><p>See a Daughter Grinding Grain</p>
<p>Wish the spirit's time was through</p>
<p>Trap set for the shadow bane</p>
<p>Her millstone killed it true</p></th>
<th><p>See a Daughter Grinding Grain</p>
<p>Wish the spirit's time was through</p>
<p>Trap set for the shadow bane</p>
<p>Her millstone killed it true</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>A dog with a human hand in its mouth. The hand is bleeding.</p>
<p>A black shadow hovers over the scene.</p></th>
<th>A shocked woman with a scythe stands over a man who is lying down. The man has his feet cut off. A black shadow is watching them.</th>
</tr>
<tr class="odd">
<th>A boy is underwater. He clutches his throat as he drowns. A black shadow hovers above the water.</th>
<th>When the music box plays you MUST hum or whistle along with it. If someone asks you why or notices you, pass this card to them.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
