---
title: "The Rhyme"
source: "Game Stuff/The Rhyme"
modified: 2021-10-28
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[Shemshimes - The Rhyme|Shemshimes / The Rhyme]]"]
concepts: ["Shemshimes / The Rhyme"]
words: 410
summary: "Fuller slide deck for The Rhyme one-shot with additional NPCs (Belanor Brightwood, Sanah, Snitch Ghoulstrummer) alongside the library residents; scenes include breakfast, a scream, a dry voice singing a rhyme."
merged_versions: ["Game Stuff/The Rhyme Mini"]
tags: ["area/dnd", "project/shemshimes-/-the-rhyme", "type/campaign-prep"]
---

<!-- Slide number: 1 -->

### Notes:

<!-- Slide number: 2 -->



### Notes:

<!-- Slide number: 3 -->






Morticia Morningsun
Lady Lucilia Heartweaver

### Notes:

<!-- Slide number: 4 -->








Belanor Brightwood
Sanah

### Notes:

<!-- Slide number: 5 -->








Elias Everhorn
Snitch Ghoulstrummer

### Notes:

<!-- Slide number: 6 -->

### Notes:

<!-- Slide number: 7 -->







Varnyr
Crinkle

### Notes:

<!-- Slide number: 8 -->





### Notes:

<!-- Slide number: 9 -->





Ebder

### Notes:

<!-- Slide number: 10 -->





Tulah

### Notes:

<!-- Slide number: 11 -->
# The next morning at breakfast...

### Notes:

<!-- Slide number: 12 -->






Gailby

### Notes:

<!-- Slide number: 13 -->



### Notes:

<!-- Slide number: 14 -->












Elias
Everhorn
Morticia
Morningsun
Belanor
Brightwood

Snitch
Ghoulstrummer
Lucilia
Heartweaver
Sanah










Varnyr
Tulah
Ebder
Gailby
Crinkle

### Notes:

<!-- Slide number: 15 -->
# A scream from above!

### Notes:

<!-- Slide number: 16 -->
# A dry voice sings a rhyme...

### Notes:

<!-- Slide number: 17 -->
# The sounds of an argument above...

### Notes:

<!-- Slide number: 18 -->
# Shouting from the kitchen...

### Notes:

<!-- Slide number: 19 -->



### Notes:

<!-- Slide number: 20 -->



### Notes:

<!-- Slide number: 21 -->

### Notes:

<!-- Slide number: 22 -->



### Notes:

---

## Differences from other versions

_This document existed in several versions. The text above is the most complete one, unchanged. Below are the lines that appear only in the other versions._

### Only in “The Rhyme Mini” (Game Stuff, modified 2022-10-28)

_No differences – identical content._
