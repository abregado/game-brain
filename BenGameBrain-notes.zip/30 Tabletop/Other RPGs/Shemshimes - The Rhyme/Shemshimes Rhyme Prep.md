---
title: "Shemshimes Rhyme Prep"
source: "Game Stuff/Shemshimes Rhyme Prep"
modified: 2024-11-02
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[Shemshimes - The Rhyme|Shemshimes / The Rhyme]]", "[[D&D One-shots]]"]
concepts: ["Shemshimes / The Rhyme", "D&D one-shots"]
words: 1314
summary: "DM prep for a Candlekeep haunting one-shot: roleplay rules, NPCs, six events around a humming/singing curse, concentration mechanic, ability cards and clues."
tags: ["area/dnd", "project/d-d-one-shots", "project/shemshimes-/-the-rhyme", "type/campaign-prep"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>A dog with a human hand in its mouth. The hand is bleeding.</p>
<p>A black shadow hovers over the scene.</p></th>
<th>A shocked woman with a scythe stands over a man who is lying down. The man has his feet cut off. A black shadow</th>
</tr>
<tr class="odd">
<th>A boy is underwater. He clutches his throat as he drowns. A black shadow hovers above the water.</th>
<th>When the music box plays you MUST hum or whistle along with it. If someone asks you why or notices you, pass this card to them.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>See a Mother Scything Wheat</p>
<p>Forgotten Husband Sleeping near</p>
<p>with One Swing She Took His Feet</p>
<p>with Another Took His Ear</p>
<p>Does the shadow have a name? SHEMSHIME SHEMSHIME</p>
<p>Causes grief, avoids the blame SHEMSHIME SHEMSHIME</p>
<p>See a dog that knows how to heel</p>
<p>Never heeds plea nor command</p>
<p>Mother gave it a tasty meal</p>
<p>Dog chose instead to eat her hand</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p>
<p>See a son doing his chore</p>
<p>Washing clothes for folk in town</p>
<p>Fell into the river's roar</p>
<p>Sank to the bottom and drowned</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p></th>
<th><p>See a Mother Scything Wheat</p>
<p>Forgotten Husband Sleeping near</p>
<p>with One Swing She Took His Feet</p>
<p>with Another Took His Ear</p>
<p>Does the shadow have a name? SHEMSHIME SHEMSHIME</p>
<p>Causes grief, avoids the blame SHEMSHIME SHEMSHIME</p>
<p>See a dog that knows how to heel</p>
<p>Never heeds plea nor command</p>
<p>Mother gave it a tasty meal</p>
<p>Dog chose instead to eat her hand</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p>
<p>See a son doing his chore</p>
<p>Washing clothes for folk in town</p>
<p>Fell into the river's roar</p>
<p>Sank to the bottom and drowned</p>
<p>Does the shadow have a name? SHEMSHIME Causes grief, avoids the blame SHEMSHIME</p></th>
</tr>
<tr class="odd">
<th><p>See a Daughter Grinding Grain</p>
<p>Wish the spirit's time was through</p>
<p>Trap set for the shadow bane</p>
<p>Her millstone killed it true</p></th>
<th><p>See a Daughter Grinding Grain</p>
<p>Wish the spirit's time was through</p>
<p>Trap set for the shadow bane</p>
<p>Her millstone killed it true</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Roleplay Disclaimer

State your intent: What do you expect to achieve with this action

Narrate only what YOUR character does.

Try to leave hook open for others to use

It’s ok in this adventure to split up

You can do non-risky do any action without spending a card

Do a Risky action without spending a card. Your chance for success will be decided by the DM

Play a card to do a risky action with a guaranteed result. Still roll a dice.

Some challenges require multiple successes.

Concentration rules are 10+ to succeed.

Intro -

Characters Arrive in the Cellar

*Our story tonight takes place in a far away place known as Candlekeep. Greatest of Libraries, or so it is known by some, Candlekeep lies on the coast of Faerun just a days travel south from Baldurs Gate.*

You had to donate a rare book to enter Candlekeep

Environment

- Lanterns with Fireflys

- Odd firefly loose in the room

Introduced to Vanyr

- Vanyr is an important scribe

- Cleaning the Book Sculpture on a ladder

- “No fire possibke”

- Small Restoration project (300 years)

- Opportunity: Books carried down to Ebder

Introduced to Crinkle

- Holding a lantern filled with fireflies to help Vanyr

- Doesn't say anything

Introduced to Ebder

- Mentions his daughter “I just put her to bed, keep your voices down!”

- Gives hook for Tulah “Those books are for Tulah”

- He repairs the books

Optional: Introduction for Tulah

- Explains her work

- Describe the Metal Oyster

**Event 1** - Breakfast

One player starts humming something

The first player to say something about it has to also start humming

Introduce Gailby

- Cuteness

- Skipping

- Distracting

Vanyr gets up and leaves to visibly lock the hatch with magic and puts the key into her pocket.

You can concentrate on the humming and stop doing it. Whenever a character enters a group, recheck if their concentration fails. 10+ on D20 to succeed.

After explaining the quarantine, the players can take actions to explore the cellar and find the following information

- Crinkle is the Firefly Caretaker

- There are records of a singing madness from 600 years ago. Several people were infected, including a book merchant and some staff from the Firefly Cellar. There is no record of what happened to the affected people.

- Tulah is not dealing well with being “buried in a tomb”

- Ebder is in charge of repairing books

- Something from one of the characters is missing.

- A book is missing from the workshop.

- Something of Ebders is missing (the ring)

- A page from the missing book with the song lyrics

**Event 2 - Ebders Outburst**

Be sure to trigger a moment when all the characters lose concentration to roll on the Haunting Occurrences.

**Event 3 - Singing Skull**

Every time a character moves through the center give a clue as to the sound.

**Event 4 - Escape Attempt**

Takes place on the top floor

**Event 5 - Puppets**

Use breaking out into song as the indication something changed.

Use Ebder, Vanyr or Tulah as the first puppet.

Crinkle and Gailby retreat to safety of Crinkles room here during the confusion.

**Event 6 - Shemshine and Gailby**

Don’t over do it on the blood

If the book is already found, then this only happens if the book is left alone.

**Event 6.5 - Singing The Song + Summoning**

The book transforms first to show the new scenes.

“It's time for a new chapter” Says Shemshime as it emerges from the shadows around the book.

**Concentration and Humming/Singing**

You can concentrate on the humming and stop doing it. Whenever a character enters a group, recheck if their concentration fails. 10+ on D20 to succeed.

Loud noises, jump scares, or being pushed will cause the characters to lose concentration. Also being absorbed in something for a while will cause the characters to lose concentration.

**Shemshime abilities**

**Images needed**

Candlekeep outside

House of Rest

Firefly Cellar

Characters

- Vanyr

- Tulah

- Gailby

- Ebder

Book closed

Book Open

Train ideas for Shemshimes

**Talking with the grubs in Crinkles room**

Yes they have heard the song.

The bugs start to sway in time with the music

Some form a book shape in the middle of the room, others drop from the roof and Blink on and off to show crinkle turning the crank.

**Talking to the dead in the secret room**

He was a merchant of the halladay trading family.

That family traded a lot with candlekeep as it dealt in antiquities.

**Skeleton**

Medicine. Cause and time of death. 600 years, stabbing.

History. The Halladay family specialised in selling old books.

**When someone is a puppet**

Shadowy strings connect to their joints and neck

Clockwork sounds come from their joints.

**Medicine skill**

Relaxing massage, calming poultice, strong coffee stimulants. Coffee has ongoing effect +1 if one player can't drink it. Otherwise it gives immunity for this and the next event.

Ability Cards

Jewellry Box

A box with a padded compartment for a ring. When the box is opened a glass figurine of a woman stands up. There is a small crank on the side of the box. The ring is missing.

Musical Oyster

A palm sized music box with a key to wind it up.

Shemshimes Bedtime Rhyme

A large book which is latched shut. There is a crank on the side.

Potion of Gaseous Form

Drinking this potion will turn the drinker and all their belongings into a flying gaseous cloud until the end of the scene, or they decide to turn back. While in gaseous form, they cannot interact with anything, but can move through small gaps and around obstacles without penalty.

**Shemshime**
