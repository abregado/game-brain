---
title: "Stompy Robo Jr chapters"
source: "Game Stuff/Stompy Robo Jr chapters"
modified: 2026-04-11
type: planning
area: wargame
status: "idea"
projects: ["[[Stompy Robo & Battletech]]"]
concepts: ["Stompy Robo"]
words: 105
summary: "Outline of rulebook chapters for Stompy Robo Jr: phases, campaign, appendix."
tags: ["area/wargame", "project/stompy-robo-battletech", "type/planning"]
---

Stompy Robo Jr chapters

Player story

Quick play + simple rules

Board setup w/example forces

Phases

- Initiative

- Strategy

- Movement

- Electronic Warfare

- Shooting

- Clean up

Initiative

Rolling for initiative

Initiative modifiers

Strategy

Ability triggers

Movement

How many units to select

Unit selection

Movement type selection

Movement

EWar phase

Place tokens

Shooting

One side then the other. Initiative order.

Every unit fires

End of phase, generate heat if it's a thing

Clean up

Remove all token

Remove dead units

Campaign

Force selection

- Pilots

- Mechs

Pre battle and objective

Post battle

- Experience ticks

Appendix

Specials description

Mech list

Principles
