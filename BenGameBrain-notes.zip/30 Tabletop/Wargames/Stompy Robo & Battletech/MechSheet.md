---
title: "MechSheet"
source: "Game Stuff/MechSheet"
modified: 2024-12-15
type: reference-data
area: wargame
status: "unknown"
projects: ["[[Stompy Robo & Battletech]]"]
concepts: ["Battletech homebrew"]
words: 505
summary: "Spreadsheet of Battletech/Alpha Strike mechs with PV, size, TMM, movement and S/M/L damage columns; later columns empty."
contains_external_material: "stats from official Alpha Strike cards"
tags: ["area/wargame", "project/stompy-robo-battletech", "type/reference-data"]
---

## Sheet: Sheet1

| Model | PV | SZ | TMM | MV | Skill | S | M | L | OV | EN | FP | FP | MP | MP | WP |  | Armor/Structure |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Clint | 21.0 | 2.0 | 2.0 | 6j | 4.0 | 2.0 | 2.0 | 1.0 | 0.0 |  |  |  |  |  |  |  |  |
| Panther | 29.0 | 1.0 | 1.0 | 4j | 4.0 | 2.0 | 2.0 | 1.0 | 0.0 |  |  |  |  |  |  |  |  |
| Blackjack | 26.0 | 2.0 | 1.0 | 4j | 4.0 | 2.0 | 2.0 | 0* | 1.0 |  |  |  |  |  |  |  |  |
| Urbanmech | 11.0 | 1.0 | 1.0 | 2j | 4.0 | 2.0 | 1.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Ostscout | 21.0 | 1.0 | 3.0 | 8j | 4.0 | 1.0 | 1.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Valkyrie | 19.0 | 1.0 | 2.0 | 5j | 4.0 | 1.0 | 1.0 | 1.0 | 0.0 |  |  |  |  |  |  |  |  |
| Cicada | 22.0 | 2.0 | 3.0 | 8.0 | 4.0 | 2.0 | 1.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Locust | 18.0 | 1.0 | 3.0 | 8.0 | 4.0 | 1.0 | 1.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Awesome | 39.0 | 4.0 | 1.0 | 3.0 | 4.0 | 3.0 | 3.0 | 3.0 | 0.0 |  |  |  |  |  |  |  |  |
| Hunchback | 28.0 | 2.0 | 1.0 | 4.0 | 4.0 | 4.0 | 3.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Phoenix Hawk | 26.0 | 2.0 | 2.0 | 6j | 4.0 | 2.0 | 2.0 | 0.0 | 0.0 |  |  |  |  |  |  |  |  |
| Blackjack | 26.0 | 2.0 | 1.0 | 4j | 4.0 | 2.0 | 2.0 | 0* | 0.0 |  |  |  |  |  |  |  |  |
| Goliath | 39.0 | 4.0 | 1.0 | 4.0 | 4.0 | 2.0 | 3.0 | 3.0 | 0.0 |  |  |  |  |  |  |  |  |
| Centurion | 28.0 | 2.0 | 1.0 | 4.0 | 4.0 | 2.0 | 3.0 | 1.0 | 0.0 |  |  |  |  |  |  |  |  |
| Rifleman | 26.0 | 3.0 | 1.0 | 4.0 | 4.0 | 2.0 | 2.0 | 1.0 | 2.0 |  |  |  |  |  |  |  |  |
| Jagermech | 26.0 | 3.0 | 1.0 | 4.0 | 4.0 | 3.0 | 3.0 | 2.0 | 0.0 |  |  |  |  |  |  |  |  |
