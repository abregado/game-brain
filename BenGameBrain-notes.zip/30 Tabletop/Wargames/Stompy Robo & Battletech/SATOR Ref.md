---
title: "SATOR Ref"
source: "Game Stuff/SATOR Ref"
modified: 2026-02-08
type: reference-data
area: wargame
status: "designed"
projects: ["[[Stompy Robo & Battletech]]"]
concepts: ["Battletech homebrew", "Stompy Robo"]
words: 251
summary: "Quick reference tables for a to-hit system (Skill, Attacker movement, Target movement, Other, Range) and a 2D6 critical hit table for mechs."
tags: ["area/wargame", "project/stompy-robo-battletech", "type/reference-data"]
---

| **S** | Skill rating                     |
|-------|----------------------------------|
| **A** | Attacker movement modifier (AMM) |
| **T** | Target movement modifier (TMM)   |
| **O** | Other (Terrain, cover, heat)     |
| **R** | Range                            |

| Attacker movement modifier |        |
|----------------------------|--------|
| Standstill or Immobile     | **-1** |
| Jumping                    | **+2** |

| Target movement modifier                                 |           |
|----------------------------------------------------------|-----------|
| Ground move                                              | **TMM**   |
| Jumping                                                  | **TMM+1** |
| Jumping Weak                                             | **TMM**   |
| Jumping Strong                                           | **TMM+2** |
| Immobile                                                 | **-4**    |
| Standstill                                               | **0**     |
| Target has 2+ heat while using Ground move or Standstill | **-1**    |

| Other modifiers    |           |
|--------------------|-----------|
| Target in water    | **+1**    |
| Target behind hill | **+1**    |
| Attacker is hot    | **+heat** |

| Range modifiers |        |        |
|-----------------|--------|--------|
| Up to 6”        | Short  | **+0** |
| Up to 24”       | Medium | **+2** |
| Up to 42”       | Long   | **+4** |

| Critical Hits |                  |
|---------------|------------------|
| 2D6           | Effect           |
| **2**         | Ammo hit         |
| **3**         | Engine hit       |
| **4**         | Fire Control hit |
| **5**         | No Critical hit  |
| **6**         | Weapon hit       |
| **7**         | MP hit           |
| **8**         | Weapon hit       |
| **9**         | No Critical hit  |
| **10**        | Fire Control hit |
| **11**        | Engine hit       |
| **12**        | Mech Destroyed   |
