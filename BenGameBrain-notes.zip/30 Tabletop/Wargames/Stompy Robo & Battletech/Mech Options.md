---
title: "Mech Options"
source: "Game Stuff/Mech Options"
modified: 2026-02-08
type: reference-data
area: wargame
status: "designed"
projects: ["[[Stompy Robo & Battletech]]"]
concepts: ["Battletech homebrew"]
words: 1245
summary: "Alpha Strike (Battletech) unit table of Clan/Inner Sphere mech stats with PV, mappings from one mech to equivalents, a shopping list of accessories and a list of mech names grouped by colour."
contains_external_material: "stat lines copied from official Alpha Strike unit data"
tags: ["area/wargame", "project/stompy-robo-battletech", "type/reference-data"]
---

| **Mech**          | **Role** | **TP** | **SZ** | **TMM** | **Spd** | **OV** | **S** | **M** | **L** | **Ar** | **St** | **PV** | **Spec**                         |
|-------------------|----------|--------|--------|---------|---------|--------|-------|-------|-------|--------|--------|--------|----------------------------------|
| Bane 3            | Msl      | BM     | 4      | 1       | 6       | 0      | 8     | 8     | 8     | 10     | 5      | 69     | CASE, IF7, LRM7/7/7              |
| Bane 5            | Sniper   | BM     | 4      | 1       | 6       | 1      | 5     | 5     | 5     | 10     | 5      | 55     | CASEII, ECM, IF1, LRM1/1/1, OVL  |
| Dire Wolf B       | Sniper   | BM     | 4      | 1       | 6       | 2      | 5     | 5     | 4     | 10     | 5      | 51     | CASE, FLK0\*/0/0, OMNI, OVL      |
| Howler            | Msl      | BM     | 1      | 3       | 14      | 0      | 1     | 1     | 1     | 2      | 2      | 20     | CASE, IF1                        |
| Howler 5          | Striker  | BM     | 1      | 3       | 14      | 2      | 3     | 3     | 0     | 2      | 2      | 29     | ENE                              |
| Howler 6          | Striker  | BM     | 1      | 3       | 14      | 0      | 2     | 2     | 0     | 2      | 2      | 23     | CASEII, SRM2/2, TUR              |
| Locust IIC        | Striker  | BM     | 1      | 3       | 16      | 0      | 5     | 5     | 0     | 3      | 2      | 42     | ENE                              |
| Locust IIC 4      | Scout    | BM     | 1      | 3       | 16      | 0      | 5     | 1     | 0     | 3      | 2      | 26     | ENE                              |
| Marauder IIC 10   | Brawl    | BM     | 4      | 1       | 8/12j   | 1      | 6     | 6     | 4     | 7      | 5      | 52     | ENE, JMPS1                       |
| Marauder IIC 6    | Skirm    | BM     | 4      | 1       | 8/12j   | 1      | 4     | 5     | 3     | 8      | 5      | 47     | CASE, FLK1/1/1, JMPS1            |
| Mist Lynx Prime   | Scout    | BM     | 1      | 3       | 14/12j  | 0      | 2     | 2     | 1     | 2      | 1      | 27     | CASE, IF1, OMNI, PRB, RCN, JMPW1 |
| Rifleman C2       | Skirm    | BM     | 3      | 2       | 12/18j  | 1      | 3     | 3     | 2     | 6      | 3      | 45     | CASE, JMPS1                      |
| Rifleman C3       | Sniper   | BM     | 3      | 1       | 8       | 1      | 4     | 4     | 4     | 6      | 5      | 38     | CASE                             |
| Shadow Cat II 2   | Skirm    | BM     | 3      | 2       | 12/14j  | 0      | 3     | 3     | 3     | 5      | 3      | 42     | CASE, IF1, JMPS1, LRM1/1/1       |
| Stormcrow TC      | Skirm    | BM     | 2      | 2       | 12      | 0      | 5     | 5     | 2     | 6      | 3      | 43     | CASE, OMNI                       |
| Summoner A        | Sniper   | BM     | 3      | 2       | 10j     | 0      | 3     | 4     | 3     | 6      | 4      | 40     | CASE, OMNI                       |
| Summoner H        | Skirm    | BM     | 3      | 2       | 10j     | 0      | 5     | 5     | 0     | 6      | 4      | 43     | AMS, CASE, OMNI                  |
| Thunderbolt IIC   | Brawl    | BM     | 3      | 2       | 10      | 2      | 5     | 5     | 2     | 7      | 4      | 48     | CASEII                           |
| Thunderbolt IIC 2 | Skirm    | BM     | 3      | 1       | 8j      | 2      | 4     | 4     | 2     | 7      | 6      | 43     | CASE, ECM                        |
| Vulture IV B      | Brawl    | BM     | 3      | 2       | 10      | 1      | 5     | 5     | 4     | 8      | 3      | 51     | CASE, CR, OMNI                   |
| Clan Foot ENE     | Amb      | CI     | 1      | 0       | 2f      | \-     | 1     | 1     | 0     | 3      | 1      | 11     | AM, CAR3                         |
| Fulcrum Heavy     | Striker  | CV     | 2      | 4       | 20h     | \-     | 2     | 2     | 1     | 5      | 3      | 42     | ECM, IF1, SRCH, TAG, TUR         |
| Fulcrum Heavy 2   | Striker  | CV     | 2      | 4       | 20h     | \-     | 3     | 3     | 1     | 5      | 3      | 48     | ECM, IF1, SRCH, TAG, TUR         |
| Heavy APC MG      | Scout    | CV     | 1      | 3       | 16h     | \-     | 1     | 0     | 0     | 2      | 1      | 12     | EE, IT3, REAR0\*/0/0, SRCH       |
| Elemental Gauss   | Amb      | BA     | 1      | 1       | 6j      | \-     | 2     | 2     | 0     | 2      | 2      | 21     | AM, CAR5, MEC                    |
| Turret HVY        |          | BD     | \-     | 0       | 0       | \-     | 2     | 2     | 0     | 6      | 6      | 15     | CF6, AC2/2/0, IMMOBILE           |
| Turret Light      |          | BD     | \-     | 0       | 0       | \-     | 0\*   | 1     | 1     | 3      | 3      | 9      | CF3, IMMOBILE                    |
| Turret M          |          | BD     | \-     | 0       | 0       | \-     | 1     | 1     | 1     | 4      | 4      | 10     | CF4, AC1/1/1, IMMOBILE           |

| Pouncer Prime | \>  | Viper L         |
|---------------|-----|-----------------|
| Pouncer T     | \>  | Mist lynx Prime |
| Nova Prime    | \>  | Shadow cat II 2 |
| Nova T        | \>  | Stormcrow TC    |
| Fire moth D/G | \>  | Howler 5        |
| Warhawk C     | \>  | Dire wolf B     |
| Warhawk T     | \>  | Vulture IV B    |

Pouncer Prime 31pv sniper

- Viper L

- Stormcrow attwater

- Mist lynx J

- Blackjack C

Pouncer T 29pv scout

- Mist lynx prime

- Shadow cat II 2

Nova Prime/T 41pv skirmisher

- Shadow cat II 2

- Stormcrow TC

Fire moth D/G 30pv striker

- Mist lynx H

- Howler 5

Timber wolf Prime 54pv brawler

- Timber wolf

- Archer C 2

Timber wolf T 62pv missile boat

Warhawk C 53pv sniper

- Dire wolf B

- Vulture IV A

- Annihilator C

Warhawk T 50pv brawler

- Vulture IV B

- Archer C 2

Thunderbolt IIC 48 Brawler

Summoner H 43 Skirmisher

- Hellbringer G

Howler 6 23 Striker

Bane 3 69 Missile Boat

Rifleman C2 45 Skirmisher

- Hellbringer Prime

Locust IIC 42 Striker

- Ice Ferret E

Marauder IIC 10 52 Skirmisher

- Gargoyle D

Alpha strike box

Card sleeves

Wipe able markers

10xdice pair

Or dice box

Or dice app

Move/sprint/jump tokens

Trees

Desert Mat

Inch measures

Heat markers

Notes

Jump strong gives tmm

Blue

Spider \* 2/2 16j

Panther \* 12A

Jagermech

Cicada

Dervish

Quickdraw

Awesome \* 9Q 4/4/4 ecm ene

Cyclops

Atlas

Hermes

Vindicator

Hunchback \* HBK-5H

Red

Commando

Jenner

Assassin

Trebucht

Dragon \* 7N 3/4/2

Catapult c4c

Grasshopper 7X

Zeus \* 9s-DC 3/3/3

Banshee

Clint

Whitworth

Enforcer \* 6G 4/4/2

Other

Ostscout 7jb

Raven-1x

Timber wolf

Summoner

Dire wolf

Viper

**Ice ferret**

Mad dog

**Hell bringer**

**Gargoyle**

Stormcrow

Shadow cat

Mist lynx

**Annihilator**

Rifleman

**Archer**

**Blackjack**
