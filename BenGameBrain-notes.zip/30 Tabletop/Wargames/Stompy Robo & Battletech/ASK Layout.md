---
title: "ASK Layout"
source: "Game Stuff/ASK Layout"
modified: 2026-06-18
type: design-doc
area: wargame
status: "designed"
projects: ["[[Stompy Robo & Battletech]]", "[[Game Business & Funding]]"]
concepts: ["Battletech homebrew", "ACES Survival Kit", "Game business & funding"]
words: 740
summary: "Write-up of the 'ACES Survival Kit' print-and-play add-on for the Alpha Strike (Battletech) ACES campaign: log/pilot/force sheets, tokens (mech feet, TMM/aim, targeting, heat), behavior card holders, new game+ rules and minor rules simplifications. Written by Ben and Peter."
tags: ["area/wargame", "project/game-business-funding", "project/stompy-robo-battletech", "type/design-doc"]
---

# Intro

After playing through the ACES campaign there were a few things that we felt were missing from both it and the Alpha Strike starter box. We put our crafty skills to use to produce a set of components and changes. Thus the ACES Survival kit was born.

Our changes are focused on clearer information accessibility while playing. We are old school tabletop gamers so prefer paper force lists over the cards provided in the Alpha Strike sets. The tiny dots on unit cards trigger us. The idea of print and play appeals greatly.

Thanks for trusting us. We hope that these changes make the game more enjoyable for you.

Ben and Peter

# 

#  

# Campaign Upgrades

## Updated Log Sheet

These allow you to keep an entire campaign on one sheet. During the post battle phase you will not need to do any cross referencing with another sheet.

## Updated Pilot sheets

While playing we wanted to track more information about our pilots. The new sheets track which mechs the pilots used, how many kills they scored. We have included more portraits. If you are playing with a group who gets possessive about which mechs they pilot, the pilot sheets also allow each player to track the stats of their own mech.

## Mech force sheet

Collecting all information for your units in one place. These are printer friendly, written in large text. Referencing from these is easier than from the cards, and does not take as much space as printing out enlarged cards from the master unit list.

## Enemy force sheets

To accelerate setup, we also provide enemy force sheets for every scenario. We have included one copy of each scenario in the box so you can start immediately, but others can be printed out from the pdfs.

## New game+

To spice up a second playthrough, here are some rules for randomising the enemy mech force. These assume you already own the Alpha Strike starter box. We recommend rolling for each enemy mech only after selecting your own forces for the mission.

#  

# Tactical Combat Upgrades

The changes here focus on adding information to the board using tokens, so that when choosing targets during the Combat phase it is much easier to assess the tactical information landscape. This speeds up the game dramatically and lowers the error rate.

## Mech Feet

These are used to mark units which have pilots, commanders or different skill ratings. Place a foot on the base on each unit that has one of these. Use the numbered chips to mark the Pilot skill of the unit. Use a star to mark the enemy commander. Use the other symbols to match up which of your pilots is in which mech.

## Behavior Card Holders

When the game begins, place the enemy unit cards into the front of the holders and the units behavior stack (or portion thereof) into the back of the holder. Once a unit has moved, then flip the front card and place it at the front of the stack. Once the unit has fired in the Combat phase, move the card to the back of the stack (without flipping it back).

## TMM/Aim Tokens

After moving a unit, place an appropriate TMM marker next to the unit so that the arrow points toward the base. If the unit Jumped or was Stationary, then use the Aim tokens to mark that the unit will get a bonus to malus to its shooting later in the Combat phase.

## Targeting tokens

Aces Rulebook (pXXX) explains how BLUE/RED/YELLOW targets are calculated. What we found was that the IDEAL target for each color is necessary every turn from the first moment. Therefore at the end of the turn, if the enemy Commander card changes, you can immediately recalculate the IDEAL target for each color and place one of the colored targeting tokens pointing at it.

## Heat Tokens

It is very easy to forget which mechs have overheated. This information is crucial during the combat phase. We have included some heat tokens which can be placed next to a mech to show its level, rather than tracking this on its unit card.

#  

# Rules simplifications

Moving through, into or out of a river costs 2”.

Moving through, into or out of a forest costs 2”.

# Suggested other products

3D printed buildings + terrain

Snakey rulers

Colored dice set
