---
title: "Stompy Robo"
source: "Game Stuff/Stompy Robo"
modified: 2025-01-30
type: reference-data
area: wargame
status: "prototyped"
projects: ["[[Stompy Robo & Battletech]]"]
concepts: ["Stompy Robo", "Battletech homebrew"]
words: 11023
summary: "Spreadsheet of Stompy Robo mech stat balancing: level tables for movement/armor/structure/weapon bands, lists of mechs with stats (Battletech names like Raven, Viper, King Crab) and a price calculator."
tags: ["area/wargame", "project/stompy-robo-battletech", "type/reference-data"]
---

## Sheet: Initiative Test

|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  | Arctic Cheetah | 5.0 | 3.0 | 1.0 |  | 1 | 3 | 8 | 3 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Enforcer | 2.0 | 5.0 | 2.0 |  | 2 | 4 | 4 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Mauler | 1.0 | 4.0 | 5.0 |  | 5 | 8 | 3 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Wolfhound | 3.0 | 3.0 | 3.0 |  | 3 | 5 | 6 | 1 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | King Crab | 1.0 | 5.0 | 4.0 |  | 4 | 6 | 3 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Raven | 4.0 | 4.0 | 1.0 |  | 1 | 3 | 7 | 2 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Viper | 4.0 | 3.0 | 2.0 |  | 2 | 4 | 7 | 2 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Ice Ferret | 3.0 | 4.0 | 2.0 |  | 2 | 4 | 6 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | Ice Ferret | 3.0 | 4.0 | 2.0 |  | 2 | 4 | 6 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |
|  | King Crab | 1.0 | 5.0 | 4.0 |  | 4 | 6 | 3 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |

## Sheet: Levels

| Level | Movement | Agility |  | S | M | L | A | S |  |  | Weapon | Level | S | M | L | Special |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1.0 | 3.0 | 1.0 |  | 2.0 | 2.0 |  | 1.0 | 3.0 |  |  |  | 5.0 | 3.0 | 5.0 | 2.0 | 1 bonus |
| 2.0 | 4.0 | 1.0 |  | 2.0 | 3.0 |  | 2.0 | 4.0 |  |  |  | 5.0 | 6.0 | 3.0 |  | 1 bonus |
| 3.0 | 6.0 | 1.0 |  | 2.0 | 4.0 |  | 3.0 | 5.0 |  |  |  | 5.0 | 4.0 | 4.0 | 1.0 | 1 bonus |
| 4.0 | 7.0 | 2.0 |  | 4.0 | 4.0 |  | 4.0 | 6.0 |  |  |  | 5.0 |  | 3.0 | 3.0 | 1 bonus |
| 5.0 | 8.0 | 3.0 |  | 3.0 | 5.0 | 2.0 | 5.0 | 8.0 |  |  |  | 5.0 | 4.0 | 4.0 |  | 2 bonuses |
|  |  |  |  |  |  |  |  |  |  |  |  | 5.0 | 5.0 | 3.0 |  | 2 bonuses |
|  |  |  |  |  |  |  |  |  |  |  | Twin weapon: | 5.0 | One lvl 4 and one lvl 2 |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Adv weapon:  | 5.0 | One lvl 4 with +1 bonus |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 4.0 | 4.0 |  | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 5.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 3.0 | 3.0 | 1.0 | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 1.0 | 1.0 | 2.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | Twin Weapon: | 4.0 | One lvl 3 and one lvl 2 |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Adv weapon:  | 4.0 | One lvl 4 with +1 bonus |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 2.0 | 4.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 3.0 | 3.0 |  | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 5.0 | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 2.0 | 2.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | Twin weapon: | 3.0 | Two lvl 2 |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Adv weapon:  | 3.0 | One lvl 4 with +1 bonus |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 2.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 4.0 | 1.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 1.0 | 1.0 | 1.0 | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 3.0 | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 | 2.0 | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 1.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 | 3.0 | 1.0 |  |  |

## Sheet: Levels (less damage)

| Level | Movement | Agility |  | S | M | L | A | S |  |  | Weapon | Level | S | M | L | Special |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1.0 | 3.0 | 1.0 |  | 2.0 | 2.0 |  | 1.0 | 3.0 |  |  |  | 5.0 | 5.0 | 4.0 | 2.0 |  |
| 2.0 | 4.0 | 1.0 |  | 2.0 | 3.0 |  | 2.0 | 4.0 |  |  |  | 5.0 | 5.0 | 4.0 |  | 1 bonus |
| 3.0 | 6.0 | 1.0 |  | 2.0 | 4.0 |  | 3.0 | 5.0 |  |  |  | 5.0 | 4.0 | 3.0 | 2.0 | 1 bonus |
| 4.0 | 7.0 | 2.0 |  | 4.0 | 4.0 |  | 4.0 | 6.0 |  |  |  | 5.0 |  | 2.0 | 3.0 | 1 bonus |
| 5.0 | 8.0 | 3.0 |  | 3.0 | 5.0 | 2.0 | 5.0 | 8.0 |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Twin weapon: | One lvl 4 and one lvl 2 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 4.0 | 4.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 4.0 | 3.0 |  | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 5.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 2.0 | 3.0 | 1.0 | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 2.0 | 2.0 | 2.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | Twin Weapon: | One lvl 3 and one lvl 2 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 3.0 | 2.0 |  | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 3.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 1.0 | 1.0 | 1.0 | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  | Twin weapon: | Two lvl 2 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 3.0 | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 1.0 | 1.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 2.0 | 2.0 |  | 1 bonus |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 1.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 | 2.0 | 1.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Highest in range |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | 5.0 |  | 6.0 | 4.0 | 3.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | 4.0 |  | 5.0 | 3.0 | 2.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | 3.0 |  | 4.0 | 3.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | 2.0 |  | 3.0 | 2.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 2.0 | 2.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | Level | S | M | L |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 5.0 | 5.0 | 4.0 | 2.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 4.0 | 4.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 5.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 4.0 | 2.0 | 2.0 | 2.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 3.0 | 3.0 | 3.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 1.0 | 1.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 2.0 | 3.0 | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 2.0 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 |  | 1.0 | 1.0 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | 1.0 | 2.0 | 1.0 |  |  |

## Sheet: All Mechs (Levels)

|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  | Arctic Cheetah | 5.0 | 3.0 | 1.0 |  | 1 | 3 | 8 | 3 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 5.0 | 2.0 | 2.0 |  | 2 | 4 | 8 | 3 | Weapons | 2 | 3 |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  |  | xx |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 5.0 | 1.0 | 3.0 |  | 3 | 5 | 8 | 3 | Weapons | 2 | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | Raven | 4.0 | 4.0 | 1.0 |  | 1 | 3 | 7 | 2 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | Viper | 4.0 | 3.0 | 2.0 |  | 2 | 4 | 7 | 2 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 4.0 | 2.0 | 3.0 |  | 3 | 5 | 7 | 2 | Weapons | 2 | 3 |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  |  | x |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 4.0 | 1.0 | 4.0 |  | 4 | 6 | 7 | 2 | Weapons | 2 | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 3.0 | 1.0 | 5.0 |  | 5 | 8 | 6 | 1 | Weapons | 2 | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 3.0 | 2.0 | 4.0 |  | 4 | 6 | 6 | 1 | Weapons | 2 | 3 |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | Wolfhound | 3.0 | 3.0 | 3.0 |  | 3 | 5 | 6 | 1 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | Ice Ferret | 3.0 | 4.0 | 2.0 |  | 2 | 4 | 6 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  | xx |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 3.0 | 5.0 | 1.0 |  | 1 | 3 | 6 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 2.0 | 5.0 | 2.0 |  | 2 | 4 | 4 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 2.0 | 4.0 | 3.0 |  | 3 | 5 | 4 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 2.0 | 3.0 | 4.0 |  | 4 | 6 | 4 | 1 | Weapons | 2 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  |  | 2.0 | 2.0 | 5.0 |  | 5 | 8 | 4 | 1 | Weapons | 2 | 3 |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | Mauler | 1.0 | 4.0 | 5.0 |  | 5 | 8 | 3 | 1 | Weapons | 4 | 4 |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  |  |
|  | Mech Name | M | W | T |  | A | S | Walk | Agility |  | S | M | L |  |  |  |  |  |  |  |  |  |  |  | Weapons | Specials |  |  |  |  |
|  | King Crab | 1.0 | 5.0 | 4.0 |  | 4 | 6 | 3 | 1 | Weapons | 3 | 5 | 2 |  |  |  |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |

## Sheet: RowPrice

|  | Mech Name | Walk | Run | Jump | Armor | Structure | S | M | L | Weapons | Specials | Price | Price Actual | Total | Mod | Tech | Specials Cost | Walk | Jump | Armor | Structure | Weapon Count | Walk | Jump | Armor | Structure | Weapon Count |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| x | Hunchback | 4.0 | 6 |  | 5.0 | 4.0 | 4.0 | 3.0 |  | 7 |  | 25 | 24.15 | 10.5 | 2.3 | 6.25 | 0.0 | 0 | 0 | 5 | 2 | 3.5 | 0.8 | 0 | 0.5 | 0 | 0 |
|  | Urbanmech | 2.0 | 3 | 2.0 | 3.0 | 3.0 | 2.0 | 1.0 |  | 3 |  | 12 | 11.9 | 7 | 1.7 | 4 | 0.0 | 0 | 1 | 3 | 1.5 | 1.5 | 0.4 | 0 | 0.3 | 0 | 0 |
|  | Stinger | 6.0 | 9 | 6.0 | 2.0 | 2.0 | 1.0 | 1.0 |  | 2 |  | 17 | 16.8 | 7 | 2.4 | 8.5 | 0.0 | 0 | 3 | 2 | 1 | 1 | 1.2 | 0 | 0.2 | 0 | 0 |
|  | Wasp | 6.0 | 9 | 6.0 | 2.0 | 2.0 |  | 1.0 | 1.0 | 2 |  | 17 | 16.8 | 7 | 2.4 | 8.5 | 0.0 | 0 | 3 | 2 | 1 | 1 | 1.2 | 0 | 0.2 | 0 | 0 |
|  | Commando | 6.0 | 9 | 0.0 | 2.0 | 2.0 | 2.0 | 2.0 |  | 4 |  | 12 | 12 | 5 | 2.4 | 6 | 0.0 | 0 | 0 | 2 | 1 | 2 | 1.2 | 0 | 0.2 | 0 | 0 |
|  | Javelin | 6.0 | 9 | 6.0 | 2.0 | 3.0 |  | 1.0 | 1.0 | 2 |  | 18 | 18 | 7.5 | 2.4 | 6 | 0.0 | 0 | 3 | 2 | 1.5 | 1 | 1.2 | 0 | 0.2 | 0 | 0 |
|  | Charger | 5.0 | 7 |  | 5.0 | 6.0 | 2.0 |  |  | 2 |  | 23 | 22.5 | 9 | 2.5 | 3.833333333 | 0.0 | 0 | 0 | 5 | 3 | 1 | 1 | 0 | 0.5 | 0 | 0 |
| x | Locust | 8.0 | 12 |  | 2.0 | 2.0 | 1.0 | 1.0 |  | 2 |  | 12 | 11.2 | 4 | 2.8 | 6 | 0.0 | 0 | 0 | 2 | 1 | 1 | 1.6 | 0 | 0.2 | 0 | 0 |
|  | Panther | 4.0 | 6 | 4.0 | 3.0 | 3.0 | 2.0 | 2.0 | 1.0 | 5 |  | 19 | 18.9 | 9 | 2.1 | 6.333333333 | 0.0 | 0 | 2 | 3 | 1.5 | 2.5 | 0.8 | 0 | 0.3 | 0 | 0 |
| x | Valkyrie | 5.0 | 7 | 5.0 | 3.0 | 3.0 | 1.0 | 1.0 | 1.0 | 3 |  | 20 | 19.55 | 8.5 | 2.3 | 6.666666667 | 0.0 | 0 | 2.5 | 3 | 1.5 | 1.5 | 1 | 0 | 0.3 | 0 | 0 |
|  | Firestarter | 6.0 | 9 | 6.0 | 3.0 | 3.0 | 2.0 | 1.0 |  | 3 |  | 23 | 22.5 | 9 | 2.5 | 7.666666667 | 0.0 | 0 | 3 | 3 | 1.5 | 1.5 | 1.2 | 0 | 0.3 | 0 | 0 |
|  | Hatchetman | 4.0 | 6 | 4.0 | 3.0 | 4.0 | 2.0 | 2.0 |  | 4 |  | 19 | 18.9 | 9 | 2.1 | 4.75 | 0.0 | 0 | 2 | 3 | 2 | 2 | 0.8 | 0 | 0.3 | 0 | 0 |
|  | Clint | 6.0 | 9 | 6.0 | 2.0 | 3.0 | 2.0 | 2.0 | 1.0 | 5 |  | 22 | 21.6 | 9 | 2.4 | 7.333333333 | 0.0 | 0 | 3 | 2 | 1.5 | 2.5 | 1.2 | 0 | 0.2 | 0 | 0 |
|  | Ostscout | 8.0 | 12 | 5.0 | 2.0 | 3.0 | 1.0 | 1.0 |  | 2 |  | 20 | 19.6 | 7 | 2.8 | 6.666666667 | 0.0 | 0 | 2.5 | 2 | 1.5 | 1 | 1.6 | 0 | 0.2 | 0 | 0 |
|  | Spider | 8.0 | 12 | 8.0 | 2.0 | 3.0 | 1.0 | 1.0 |  | 2 |  | 24 | 23.8 | 8.5 | 2.8 | 8 | 0.0 | 0 | 4 | 2 | 1.5 | 1 | 1.6 | 0 | 0.2 | 0 | 0 |
|  | Cicada | 8.0 | 12 |  | 2.0 | 3.0 | 2.0 | 1.0 |  | 3 |  | 14 | 14 | 5 | 2.8 | 4.666666667 | 0.0 | 0 | 0 | 2 | 1.5 | 1.5 | 1.6 | 0 | 0.2 | 0 | 0 |
|  | Hermes II | 6.0 | 9 |  | 4.0 | 3.0 | 2.0 | 1.0 | 1.0 | 4 |  | 20 | 19.5 | 7.5 | 2.6 | 6.666666667 | 0.0 | 0 | 0 | 4 | 1.5 | 2 | 1.2 | 0 | 0.4 | 0 | 0 |
|  | Assassin | 7.0 | 10 | 5.0 | 2.0 | 3.0 | 2.0 | 1.0 |  | 3 |  | 20 | 19.5 | 7.5 | 2.6 | 6.666666667 | 0.0 | 0 | 2.5 | 2 | 1.5 | 1.5 | 1.4 | 0 | 0.2 | 0 | 0 |
|  | Vulcan | 6.0 | 9 | 6.0 | 4.0 | 3.0 | 2.0 | 2.0 |  | 4 |  | 28 | 27.3 | 10.5 | 2.6 | 9.333333333 | 0.0 | 0 | 3 | 4 | 1.5 | 2 | 1.2 | 0 | 0.4 | 0 | 0 |
|  | Enforcer | 4.0 | 6 | 4.0 | 5.0 | 4.0 | 3.0 | 2.0 |  | 5 |  | 27 | 26.45 | 11.5 | 2.3 | 6.75 | 0.0 | 0 | 2 | 5 | 2 | 2.5 | 0.8 | 0 | 0.5 | 0 | 0 |
|  | Whitworth | 4.0 | 6 | 4.0 | 4.0 | 3.0 | 2.0 | 2.0 | 2.0 | 6 |  | 24 | 23.1 | 10.5 | 2.2 | 8 | 0.0 | 0 | 2 | 4 | 1.5 | 3 | 0.8 | 0 | 0.4 | 0 | 0 |
| x | Blackjack | 4.0 | 6 | 4.0 | 5.0 | 4.0 | 1.0 | 2.0 | 1.0 | 4 |  | 26 | 25.3 | 11 | 2.3 | 6.5 | 0.0 | 0 | 2 | 5 | 2 | 2 | 0.8 | 0 | 0.5 | 0 | 0 |
| x | Jagermech | 4.0 | 6 |  | 3.0 | 5.0 | 3.0 | 3.0 | 2.0 | 8 |  | 20 | 19.95 | 9.5 | 2.1 | 4 | 0.0 | 0 | 0 | 3 | 2.5 | 4 | 0.8 | 0 | 0.3 | 0 | 0 |
|  | Jenner | 7.0 | 10 | 5.0 | 2.0 | 3.0 | 2.0 | 2.0 |  | 4 |  | 21 | 20.8 | 8 | 2.6 | 7 | 0.0 | 0 | 2.5 | 2 | 1.5 | 2 | 1.4 | 0 | 0.2 | 0 | 0 |
| x | Phoenixhawk | 6.0 | 9 | 6.0 | 4.0 | 4.0 | 2.0 | 2.0 |  | 4 |  | 29 | 28.6 | 11 | 2.6 | 7.25 | 0.0 | 0 | 3 | 4 | 2 | 2 | 1.2 | 0 | 0.4 | 0 | 0 |
| x | Rifleman | 4.0 | 6 |  | 4.0 | 5.0 | 2.0 | 2.0 | 1.0 | 5 |  | 20 | 19.8 | 9 | 2.2 | 4 | 0.0 | 0 | 0 | 4 | 2.5 | 2.5 | 0.8 | 0 | 0.4 | 0 | 0 |
|  | Scorpion | 6.0 | 9 |  | 4.0 | 5.0 | 2.0 | 2.0 | 1.0 | 5 |  | 24 | 23.4 | 9 | 2.6 | 4.8 | 0.0 | 0 | 0 | 4 | 2.5 | 2.5 | 1.2 | 0 | 0.4 | 0 | 0 |
|  | Vindicator | 4.0 | 6 | 4.0 | 5.0 | 4.0 | 2.0 | 2.0 | 2.0 | 6 |  | 28 | 27.6 | 12 | 2.3 | 7 | 0.0 | 0 | 2 | 5 | 2 | 3 | 0.8 | 0 | 0.5 | 0 | 0 |
| x | Centurion | 4.0 | 6 |  | 5.0 | 4.0 | 2.0 | 3.0 | 1.0 | 6 |  | 23 | 23 | 10 | 2.3 | 5.75 | 0.0 | 0 | 0 | 5 | 2 | 3 | 0.8 | 0 | 0.5 | 0 | 0 |
|  | Trebuchet | 5.0 | 7 |  | 4.0 | 4.0 | 2.0 | 2.0 | 2.0 | 6 |  | 22 | 21.6 | 9 | 2.4 | 5.5 | 0.0 | 0 | 0 | 4 | 2 | 3 | 1 | 0 | 0.4 | 0 | 0 |
|  | Dervish | 5.0 | 7 | 5.0 | 4.0 | 5.0 | 2.0 | 2.0 | 2.0 | 6 |  | 29 | 28.8 | 12 | 2.4 | 5.8 | 0.0 | 0 | 2.5 | 4 | 2.5 | 3 | 1 | 0 | 0.4 | 0 | 0 |
|  | Wolverine | 5.0 | 7 | 5.0 | 5.0 | 5.0 | 2.0 | 2.0 | 1.0 | 5 |  | 32 | 31.25 | 12.5 | 2.5 | 6.4 | 0.0 | 0 | 2.5 | 5 | 2.5 | 2.5 | 1 | 0 | 0.5 | 0 | 0 |
|  | Shadowhawk | 5.0 | 7 | 4.0 | 5.0 | 5.0 | 2.0 | 2.0 | 1.0 | 5 |  | 30 | 30 | 12 | 2.5 | 6 | 0.0 | 0 | 2 | 5 | 2.5 | 2.5 | 1 | 0 | 0.5 | 0 | 0 |
|  | Griffin | 5.0 | 7 | 5.0 | 5.0 | 5.0 | 1.0 | 2.0 | 2.0 | 5 |  | 32 | 31.25 | 12.5 | 2.5 | 6.4 | 0.0 | 0 | 2.5 | 5 | 2.5 | 2.5 | 1 | 0 | 0.5 | 0 | 0 |
|  | Catapult | 4.0 | 6 | 4.0 | 5.0 | 5.0 | 2.0 | 3.0 | 2.0 | 7 |  | 30 | 29.9 | 13 | 2.3 | 6 | 0.0 | 0 | 2 | 5 | 2.5 | 3.5 | 0.8 | 0 | 0.5 | 0 | 0 |
|  | Crusader | 4.0 | 6 |  | 6.0 | 5.0 | 2.0 | 2.0 | 2.0 | 6 |  | 28 | 27.6 | 11.5 | 2.4 | 5.6 | 0.0 | 0 | 0 | 6 | 2.5 | 3 | 0.8 | 0 | 0.6 | 0 | 0 |
|  | Dragon | 5.0 | 7 |  | 5.0 | 5.0 | 2.0 | 2.0 | 2.0 | 6 |  | 27 | 26.25 | 10.5 | 2.5 | 5.4 | 0.0 | 0 | 0 | 5 | 2.5 | 3 | 1 | 0 | 0.5 | 0 | 0 |
|  | Quickdraw | 5.0 | 7 | 5.0 | 4.0 | 5.0 | 2.0 | 3.0 | 1.0 | 6 |  | 29 | 28.8 | 12 | 2.4 | 5.8 | 0.0 | 0 | 2.5 | 4 | 2.5 | 3 | 1 | 0 | 0.4 | 0 | 0 |
|  | Warhammer | 4.0 | 6 |  | 5.0 | 6.0 | 3.0 | 3.0 | 2.0 | 8 |  | 28 | 27.6 | 12 | 2.3 | 4.666666667 | 0.0 | 0 | 0 | 5 | 3 | 4 | 0.8 | 0 | 0.5 | 0 | 0 |
| x | Ostsol | 5.0 | 7 |  | 5.0 | 5.0 | 3.0 | 3.0 | 0.0 | 6 |  | 27 | 26.25 | 10.5 | 2.5 | 5.4 | 0.0 | 0 | 0 | 5 | 2.5 | 3 | 1 | 0 | 0.5 | 0 | 0 |
|  | Cyclops | 4.0 | 6 |  | 5.0 | 7.0 | 3.0 | 3.0 | 1.0 | 7 |  | 28 | 27.6 | 12 | 2.3 | 4 | 0.0 | 0 | 0 | 5 | 3.5 | 3.5 | 0.8 | 0 | 0.5 | 0 | 0 |
| x | Ostroc | 5.0 | 7 |  | 5.0 | 5.0 | 3.0 | 3.0 | 0.0 | 6 |  | 27 | 26.25 | 10.5 | 2.5 | 5.4 | 0.0 | 0 | 0 | 5 | 2.5 | 3 | 1 | 0 | 0.5 | 0 | 0 |
|  | Thunderbolt | 4.0 | 6 |  | 8.0 | 5.0 | 2.0 | 2.0 | 2.0 | 6 |  | 36 | 35.1 | 13.5 | 2.6 | 7.2 | 0.0 | 0 | 0 | 8 | 2.5 | 3 | 0.8 | 0 | 0.8 | 0 | 0 |
| x | Marauder | 4.0 | 6 |  | 6.0 | 6.0 | 2.0 | 3.0 | 3.0 | 8 |  | 32 | 31.2 | 13 | 2.4 | 5.333333333 | 0.0 | 0 | 0 | 6 | 3 | 4 | 0.8 | 0 | 0.6 | 0 | 0 |
|  | Zeus | 4.0 | 6 |  | 6.0 | 6.0 | 3.0 | 3.0 | 2.0 | 8 |  | 32 | 31.2 | 13 | 2.4 | 5.333333333 | 0.0 | 0 | 0 | 6 | 3 | 4 | 0.8 | 0 | 0.6 | 0 | 0 |
|  | Archer | 4.0 | 6 |  | 7.0 | 6.0 | 2.0 | 2.0 | 2.0 | 6 |  | 33 | 32.5 | 13 | 2.5 | 5.5 | 0.0 | 0 | 0 | 7 | 3 | 3 | 0.8 | 0 | 0.7 | 0 | 0 |
|  | Victor | 4.0 | 6 | 4.0 | 6.0 | 6.0 | 4.0 | 4.0 | 0.0 | 8 |  | 36 | 36 | 15 | 2.4 | 6 | 0.0 | 0 | 2 | 6 | 3 | 4 | 0.8 | 0 | 0.6 | 0 | 0 |
|  | Grasshopper | 4.0 | 6 | 4.0 | 7.0 | 6.0 | 3.0 | 4.0 | 0.0 | 7 |  | 39 | 38.75 | 15.5 | 2.5 | 6.5 | 0.0 | 0 | 2 | 7 | 3 | 3.5 | 0.8 | 0 | 0.7 | 0 | 0 |
| x | Awesome | 3.0 | 4 |  | 8.0 | 6.0 | 3.0 | 3.0 | 3.0 | 9 |  | 38 | 37.2 | 15.5 | 2.4 | 6.333333333 | 0.0 | 0 | 0 | 8 | 3 | 4.5 | 0.6 | 0 | 0.8 | 0 | 0 |
| x | Goliath | 4.0 | 6 |  | 8.0 | 6.0 | 2.0 | 3.0 | 3.0 | 8 |  | 39 | 39 | 15 | 2.6 | 6.5 | 0.0 | 0 | 0 | 8 | 3 | 4 | 0.8 | 0 | 0.8 | 0 | 0 |
|  | Orion | 4.0 | 6 |  | 8.0 | 6.0 | 3.0 | 3.0 | 1.0 | 7 |  | 38 | 37.7 | 14.5 | 2.6 | 6.333333333 | 0.0 | 0 | 0 | 8 | 3 | 3.5 | 0.8 | 0 | 0.8 | 0 | 0 |
|  | Battlemaster | 4.0 | 6 |  | 8.0 | 7.0 | 3.0 | 3.0 | 1.0 | 7 |  | 39 | 39 | 15 | 2.6 | 5.571428571 | 0.0 | 0 | 0 | 8 | 3.5 | 3.5 | 0.8 | 0 | 0.8 | 0 | 0 |
|  | Stalker | 4.0 | 6 |  | 7.0 | 7.0 | 3.0 | 4.0 | 2.0 | 9 |  | 38 | 37.5 | 15 | 2.5 | 5.428571429 | 0.0 | 0 | 0 | 7 | 3.5 | 4.5 | 0.8 | 0 | 0.7 | 0 | 0 |
|  | Banshee | 3.0 | 4 |  | 8.0 | 8.0 | 4.0 | 4.0 | 2.0 | 10 |  | 41 | 40.8 | 17 | 2.4 | 5.125 | 0.0 | 0 | 0 | 8 | 4 | 5 | 0.6 | 0 | 0.8 | 0 | 0 |
|  | Atlas | 3.0 | 4 |  | 10.0 | 8.0 | 5.0 | 5.0 | 2.0 | 12 |  | 52 | 52 | 20 | 2.6 | 6.5 | 0.0 | 0 | 0 | 10 | 4 | 6 | 0.6 | 0 | 1 | 0 | 0 |
|  | Vulture | 6.0 | 9 |  | 5.0 | 3.0 | 3.0 | 5.0 | 2.0 | 10 |  | 32 | 31.05 | 11.5 | 2.7 | 0.9 | 0.0 | 0 | 0 | 5 | 1.5 | 5 | 1.2 | 0 | 0.5 | 0 | 0 |
|  | Timber Wolf | 5.0 | 7 |  | 8.0 | 4.0 | 5.0 | 5.0 | 4.0 | 14 |  | 48 | 47.6 | 17 | 2.8 | 0.7 | 0.0 | 0 | 0 | 8 | 2 | 7 | 1 | 0 | 0.8 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  |  |  | 0 |  |  |  |  |  |  | 0 |  | 0 | 0 | 0 | 1 | #DIV/0! | 0.0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## Sheet: Constants

|  | Base Cost | Mod |
|---|---|---|
| Move | 0.0 | 0.2 |
| Jump | 0.5 | 0.0 |
| Weapon | 0.5 | 0.0 |
| Armor | 1.0 | 0.1 |
| Structure | 0.5 | 0.0 |

## Sheet: Pilot Advancement

|  |  | PILOT ABILITY |  |  |  |  |  |  | PILOT TYPES |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  | 1-2 | Specialization |  |  |  |  |  | XP | Green | Regular | Veteran |
|  |  |  | 1 | Opportunist | Skill up when operating a mech with a specific Weapon Upgrade |  |  |  | 0.0 | 9 Skill | 7 Skill | 6 Skill, 1x Ability |
|  |  |  | 2 | Expert | Skill up when operating a mech with specific Upgrade |  |  |  | 1 |  |  |  |
|  |  |  | 3 | Gymnast | Skill up when operating a frame with speed 4 or more |  |  |  | 2 | Skill Up |  |  |
|  |  |  | 4 | Heavyweight | Skill up when operating a frame with toughness 4 or more |  |  |  | 3 |  |  |  |
|  |  |  | 5 | Sniper | Skill up when firing at Long range. Skill down when firing at Medium range. |  |  |  | 4 | Ability | Ability |  |
|  |  |  | 6 | Brawler | Skill up when firing at short range. |  |  |  | 5 |  |  |  |
|  |  | 3 | Control |  |  |  |  |  | 6 | Skill Up |  | Ability |
|  |  |  | 1-2 | Sprinter | 2 free moves if you spend no Agility during an activation |  |  |  | 7 |  |  |  |
|  |  |  | 3-4 | Risk taker | Roll one extra dice when making Risky moves. Discard the lowest dice. |  |  |  | 8 | Ability | Ability |  |
|  |  |  | 5 | Quick flush | When you dump heat you may roll a D6. On a 1, only remove 1 Heat. On 6 you flush Heat and may fire this turn (which still generates one Heat) |  |  |  | 9 |  |  |  |
|  |  |  | 6 | Redliner | If you would gain a Shutdown token, roll a D6 per Heat token. As long as no 1’s are rolled, you don’t gain a Shutdown token. If you roll any duplicates, suffer D6 Structure damage. |  |  |  | 10 | Ability |  |  |
|  |  | 4 | Fieldcraft |  |  |  |  |  | 11 |  |  |  |
|  |  |  | 1-2 | Ghost | Reroll failed MIA and Ejection rolls |  |  |  | 12 | Skill Up | Skill Up | Skill Up |
|  |  |  | 3-4 | Field Tech | Reroll failed permanent damage rolls for this pilots mech. |  |  |  |  |  |  |  |
|  |  |  | 5 | Ambusher | Deploy 2 hexes closer than allowed |  |  |  |  |  |  |  |
|  |  |  | 6 | Pathfinder | At the start of each campaign, select one type of terrain that is Difficult. This pilot ignores Difficult for that terrain. That terrain also gives this pilot Cover. |  |  |  |  |  |  |  |
|  |  | 5 | Tactics |  |  |  |  |  |  |  |  |  |
|  |  |  | 1-2 | Frontliner | When a friendly mech within Medium range would activate, you may choose to activate this mech instead |  |  |  |  |  |  |  |
|  |  |  | 3 | Distractor | When activating your first mech on a new turn, you may choose to activate this mech instead |  |  |  |  |  |  |  |
|  |  |  | 4 | Provoker | When this mech activates, you may choose an enemy mech in short range. That mech must activate first. |  |  |  |  |  |  |  |
|  |  |  | 5-6 | Command | When this mech activates, you can activate another friendly mech within Medium range instead. |  |  |  |  |  |  |  |
|  |  | 6 | Choose a category |  |  |  |  |  |  |  |  |  |
|  |  | MECH SPECIALS |  |  |  |  |  |  |  |  |  |  |
|  |  | 1-3 | Frame |  |  |  |  |  |  |  |  |  |
|  |  |  | 1 | Low Profile | "+3 from Obstructed (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 2 | Foldable | "+3 from Cover (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 3 | Protected Weapons | Reroll Arm Crits once (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 4 | Armored Actuators | Reroll Leg Crits once (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 5 | Sealed Reactor | Ignore Heat Crits on 4+ (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 6 | Steady | Ignore Vulnerable Crits on 4+ (-1 Structure) |  |  |  |  |  |  |  |
|  |  | 4-5 | Movement |  |  |  |  |  |  |  |  |  |
|  |  |  | 1 | Redline Gyro | You can make two Risky Moves per activation (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 2 | Jets | Ignore 2 Difficult Hexes per turn (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 3 | Hardened Armor | "+1 Armor (-2 Structure)" |  |  |  |  |  |  |  |
|  |  |  | 4 | Skates | 2 free moves when on Roads for the entire activation (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 5 | Deployable | To hit -1 when shooting after staying in the same hex (-1 Structure) |  |  |  |  |  |  |  |
|  |  |  | 6 | Stealth | Deploy 2 hexes closer than allowed (-1 Structure) |  |  |  |  |  |  |  |
|  |  | 6 | Tech |  |  |  |  |  |  |  |  |  |
|  |  |  | 1 | Targeting computer | Ignore Obstructed within 2 hexes (-2 Structure) |  |  |  |  |  |  |  |
|  |  |  | 2 | Overrides | You may fire two weapons but gain 3 heat when you do (-2 Structure) |  |  |  |  |  |  |  |
|  |  |  | 3 | Reactive Armor | "+1 Armor. Gain a Heat when losing your first armor point. |  |  |  |  |  |  |  |
|  |  |  | 4 | Ejection+ | Pilot always passes Ejection rolls |  |  |  |  |  |  |  |
|  |  |  | 5 | ECM |  |  |  |  |  |  |  |  |
|  |  |  | 6 | Modular | Make two weapon choices when designing this mech. You may pick a configuration before each battle. |  |  |  |  |  |  |  |
|  |  | MECH QUIRKS |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 1 | Stress fracture |  -1 Structure |  |  |  |  |  |  |  |
|  |  |  | 2 | Weak point | Roll twice on Crits, attacker chooses |  |  |  |  |  |  |  |
|  |  |  | 3 | Faulty Ejection | Roll twice on MIA. Take lowest roll. |  |  |  |  |  |  |  |
|  |  |  | 4 | Leaky Coolant | On a 4+ Gain a Vulnerable when you vent Heat |  |  |  |  |  |  |  |
|  |  |  | 5 | Stiff Actuator | -2 Damage on lowest range band on one weapon |  |  |  |  |  |  |  |
|  |  |  | 6 | Fried Electronics | -1 Damage on highest range band on one weapon |  |  |  |  |  |  |  |

## Sheet: Weapon Upgrades v1

|  | Special 1 | Special 2 | Name | Effect |
|---|---|---|---|---|
|  | Flash |  | Laser | Ignore Cover hexes |
|  | Indirect |  | Rocket | Ignore Obstructed hexes except Mechs |
|  | Seeking |  | Missile | For each Heat on the target, +1 to hit. |
|  | Overpowered |  | Particle Cannon | When you fire, you may take a Vulnerable token to increase damage by 2. |
|  | Burst |  | Gatling | When on zero Heat, +1 damage. |
|  | Pierce |  | Autocannon | Critical hits on 11+. Add 2 to the Internal Damage roll. |
|  | Flash | Indirect | Cluster MIRV |  |
|  | Flash | Seeking | Microwave beam |  |
|  | Flash | Overpowered | Fusion blaster |  |
|  | Flash | Burst | Coilgun Gatling |  |
|  | Flash | Pierce | Coilgun Sniper |  |
|  | Indirect | Seeking | Seeker Missiles |  |
|  | Indirect | Overpowered | Artillery cannon |  |
|  | Indirect | Burst | Missile Pod |  |
|  | Indirect | Pierce | HEAP Missile |  |
|  | Seeking | Overpowered | Plasma cannon |  |
|  | Seeking | Burst | Missile Swarm |  |
|  | Seeking | Pierce | EMP Cannon |  |
|  | Overpowered | Burst | Autocannon |  |
|  | Overpowered | Pierce | Penetrator rifle |  |
|  | Burst | Pierce | Splinter gatling |  |
|  | Flash | Indirect/Seeking | Quicksilver Warheads |  |
|  | Indirect | Indirect/Seeking | Panther Warheads |  |
|  | Overpowered | Indirect/Seeking | Fusion Warheads |  |
|  | Burst | Indirect/Seeking | Plasma Warheads |  |
|  | Pierce | Indirect/Seeking | EMP Warheads |  |
|  | Seeking | Indirect/Seeking | Hunter Warheads |  |
|  | Indirect | Flash/Overpowered | Gammaray Tube |  |
|  | Seeking | Flash/Overpowered | Melter Stage |  |
|  | Overpowered | Flash/Overpowered | Overdrive Capacitor |  |
|  | Burst | Flash/Overpowered | Regulator Bank |  |
|  | Pierce | Flash/Overpowered | Focus Extension |  |
|  | Flash | Flash/Overpowered | Tightbeam Modulator |  |
|  | Flash | Burst/Pierce | HV Rounds |  |
|  | Indirect | Burst/Pierce | Penetrator Rounds |  |
|  | Seeking | Burst/Pierce | Thermite Rounds |  |
|  | Overpowered | Burst/Pierce | Feed Overdrive |  |
|  | Pierce | Burst/Pierce | AP Rounds |  |
|  | Burst | Burst/Pierce | Drum Magazine |  |

## Sheet: Weapon Upgrades v2

|  | Name | Special 1 | Special 2 |  | Effect |
|---|---|---|---|---|---|
|  | Laser | Flash |  |  | Ignore Cover hexes |
|  | Rocket | Indirect |  |  | Ignore Obstructed hexes except Mechs |
|  | Gatling | Burst |  |  | When on zero Heat, +1 damage. |
|  | Thermal | Seeking |  |  | For each Heat on the target, +1 to hit. |
|  | Fusion | Overpowered |  |  | When you fire, you may take a Vulnerable token to increase damage by 2. |
|  | EMP | Pierce |  |  | Critical hits on 11+. Add 2 to the Internal Damage roll. |
|  | Cluster MIRV | Flash | Indirect |  |  |
|  | Microwave beam | Flash | Seeking |  |  |
|  | Fusion blaster | Flash | Overpowered |  |  |
|  | Coilgun Gatling | Flash | Burst |  |  |
|  | Coilgun Sniper | Flash | Pierce |  |  |
|  | Seeker Missiles | Indirect | Seeking |  |  |
|  | Artillery cannon | Indirect | Overpowered |  |  |
|  | Missile Pod | Indirect | Burst |  |  |
|  | HEAP Missile | Indirect | Pierce |  |  |
|  | Plasma cannon | Seeking | Overpowered |  |  |
|  | Missile Swarm | Seeking | Burst |  |  |
|  | EMP Cannon | Seeking | Pierce |  |  |
|  | Autocannon | Overpowered | Burst |  |  |
|  | Penetrator rifle | Overpowered | Pierce |  |  |
|  | Splinter gatling | Burst | Pierce |  |  |
|  | Quicksilver Warheads | Flash | Indirect |  |  |
|  | Fusion Warheads | Overpowered | Indirect |  |  |
|  | Plasma Warheads | Burst | Indirect |  |  |
|  | EMP Warheads | Pierce | Indirect |  |  |
|  | Hunter Warheads | Seeking | Indirect |  |  |
|  | Gammaray Tube | Indirect | Flash |  |  |
|  | Melter Stage | Seeking | Flash |  |  |
|  | Overdrive Capacitor | Overpowered | Flash |  |  |
|  | Regulator Bank | Burst | Flash |  |  |
|  | Focus Extension | Pierce | Flash |  |  |
|  | HV Rounds | Flash | Burst |  |  |
|  | Penetrator Rounds | Indirect | Burst |  |  |
|  | Thermite Rounds | Seeking | Burst |  |  |
|  | Feed Overdrive | Overpowered | Burst |  |  |
|  | AP Rounds | Pierce | Burst |  |  |
