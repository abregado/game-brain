---
title: "Battletech campaign"
source: "Game Stuff/Game Ideas/Battletech campaign"
modified: 2024-12-05
type: design-doc
area: wargame
status: "designed"
projects: ["[[Stompy Robo & Battletech]]", "[[Necromunda Homebrew]]"]
concepts: ["Battletech homebrew", "Necromunda homebrew"]
words: 435
summary: "Design pillars and mechanics for an Alpha Strike Battletech campaign system: risking pilots, personal goals, reserves, salvage, no cash."
tags: ["area/wargame", "project/necromunda-homebrew", "project/stompy-robo-battletech", "type/design-doc"]
---

# Battletech campaign

## Player expectations

Salvage

Modification

Advancement

## Pillars and Goals

The campaign exists to:

- Facilitate the playing of AS games

- Provide interesting pre and post battle choices

- Balance battles against players

The campaign should

- Promote players self balancing

The campaign should not:

- Be it's own game

- Have an optimal strategy in which players do not play

- Give players an unbeatable advantage in the AS game

## Interesting mechanics

### Risking pilots

Battlemechs can almost always be salvaged. Pilots not so much. Any pilot taken into battle has a chance to die. Pilots only gain experience by taking part in battles. No risk, no advancement.

### Personal goals

For each player randomly determine at the start of a mission, two goals that are secondary to the main task. Your opponent gets to place them on the board. These provide extra experience to pilots who complete them. Theme this as televised events and Merc reputation.

### Scenario Reserves

The players are generally accompanied by reserve units which are expendable. These units are randomized so players cannot include them in their pre-game strategy. These can also be used to supply some faction theming to the campaign.

Salvage comes from these reserves. You will want to put them in front of our own troops, but also limit how many you let the opponent kill.

### Reserve kill based salvage

Each rolled reserve adds a salvage option to the post battle based on what it is. These are added if the mech is downed with reactors intact.

### Pilots are “free”

Pilots don't increase mech value, and are assigned before each mission secretly. Building these up and keeping them alive is how you get ahead in the campaign. Choosing who to risk and when is a big pre battle choice.

### Set range in pre battle

Players roll for determining the range before choosing forces, but then discover exactly which mission they are doing after choosing forces.

### Do upgrades together

Necromunda style. All upgrades are sighted by your opponent. Lists do not change between battles. Options are rolled and then chosen before finishing the post battle.

### Modifier based customization

Salvage options can be converted instantly into resources when rolled, or resources can be paid to add it to a mech.

Or a simpler option: one of the rolled bonuses can be taken and fitted, or converted into cash.

The second modification causes also a negative modification to be added.

### No Cash

The players do not collect cash resources. Their “wealth” comes from Pilot experience and mech customization.
