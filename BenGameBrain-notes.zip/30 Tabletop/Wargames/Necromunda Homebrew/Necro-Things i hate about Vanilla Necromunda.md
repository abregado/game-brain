---
title: "Necro-Things i hate about Vanilla Necromunda"
source: "Game Stuff/Wargaming/Necro-Things i hate about Vanilla Necromunda"
modified: 2023-06-01
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Necromunda Homebrew]]", "[[City & Colony Builders]]"]
concepts: ["Necromunda homebrew", "Necromunda Backer System", "Necromunda Campaign Territories", "Necromunda Outlander Fixes", "Necromunda Fortifications and Pets"]
words: 2015
summary: "Ben's list of problems with vanilla Necromunda and his house-rule fixes (weapon balance, armour, rescues, gang creation/backers, outlander gangs, injuries, scenarios) plus campaign ideas, territory-level progression, new territories, vassal gangs, pets/fortifications and scavenger creature costs."
tags: ["area/wargame", "project/city-colony-builders", "project/necromunda-homebrew", "type/homebrew-rules"]
---

Things i hate about Vanilla Necromunda

Lasgun/Shotgun better than most things  
Shotguns and Launchers can only have a single type of ammunition. Lasguns have increase value (30 creds). Tempted to remove multiple firemodes on Plasma weapons (High power only).

Armor useless for its value  
4^(th) Edition WH40k armor rules are used. If armor is not totally nullified then it saves at full effect.

A few items useless  
Stummer, Screamers, Weapon Reloads, Lobochip, Blindsnake Pouch, Mung Vase, Autorepairer all removed. Silencers and Flak armor are uncommon items sold in quantities (D3), Flashbangs, Smoke common items, Needle Rifle removed, Web pistol removed. Stubguns changed to handguns, dum dums removed. Skull Chip is a rare bionic.

Rescues cause a lot of problems  
Fixed by not playing another full game, but a smaller mini-game. No Experience or income is earned from the original game until after the rescue. Injured models cannot take part in the rescue.

Housegang creation limited in options  
Fixed with new gang creation system. Each gang has a bonus, limited weapon options, and a variety of options for Special Member types.

Outlander gangs unbalanced  
See below for fixes

Players not encouraged to retire gangs  
Gang Backers give bonues that are unlocked by retiring old gang that reach 2000 credits or more. Re-created gangs have the same options as the first one but have a slectedable extra.

Players not encouraged to trade  
limited starting weapons will allow players to trade during post battle

Some scenarios useless  
Rescue modified to be a mini-game, Raids will disadvantage enemy gangs but provide extra experience for the attacking gang. Scavengers will give the players a chance to bag large game creatures and collect bounties (creature attacks are actually fully fleshed out monsters).

Weapon Damage roll clarification needed  
When wounded, roll one D6 for each extra wound over the targets Wound score.

Some skills useless, some UBER  
New necromunda Skills Version2 from necromunda.com

Injuries problems  
Simplified Hand Injuries, introduction of new Bionic parts to repair other injuries. Bitter Enmity gives Hatred on all models from the enemy gang.

Multiple Shots targeting rules classification  
Secondary shots from Fast Shot, Gunfighter or Rapid Fire may be alloctated as if they are Sustained Fire shots.

Scenarios – All allow, rescue and raid have minor changes.  
Both use less figures. The defender is allowed 5 Sentries while the attacker only has 3 models. Rescue missions are played immediately after the Serious Injuries are rolled, before either gang rolls for experience or income.

Or remove rescue scenarios for captured members. The capturing gang can use the captive to generate income and then returns them. The gang the captive came from can't use them for income.

Campaign ideas:

10 Regular Territories total for the whole campaign. These are shared out amongst all non-outlaw/outlander gangs.

New gangs gain a single territory from the player with the most territories when they win their first game. Until they win, they have a Wastes Terrain.

Unlimted Outlaw/Wastes terrain.

Gangs without terrain gain one Wastes territory immediately after income has been generated. The gang spends its entire post battle finding its new home. Gangs can have unlimited Wastes terrains.

Each time a gang wins a combat it gains access to the next level of Hab-13. Once a gang has reached higher than Level 4 they cannot work territories anymore and must feed their members as per the Outlaw rules. When they are higher than level 6, they can no longer forage or purchase ANY equipment. Gangs at this level must have enough credits worth of food to survive their journey.

Beating a gang on the same level gives +1 level.

Beating a gang up to two levels lower than you gives +0 level.

Losing to a gang that is up to two levels higher than you gives +1 Level.

Winning against a gang that is up to two levels higher than you gives +2 levels.

All gangs can visit the Trading post until Outlawed. Scavvies and Spyrers cannot visit.

Re-jigger costs for common items.  
Pre-generated hired guns

Outlander Fixes

Spyrer Hunt Party – use new rules  
When a Spyrer party completes its vow, its two most powerful members become the Patriarch and Matriarch rolling 3 additional Power Boosts each. Any remaining members may be re-purchased as normal to lead the new Hunting Party.

Ratskin Renegades – Unallowed  
Players with Ratskin models can use them as regular Gang models with the Suvivalist Gang Bonus.

Redemptionist Crusade – Alllowed with new rules  
Redemptor Preists and Deacons cannot be purchased until the gang has cycled once.

Scavvy Hoard – as per new rules  
Scavies may work a captured territory once, but it is not destroyed afterwards. It is given to the smallest gang with no territories. Mutated Scavvies and Scalies can never visit the trading post.

Becoming Outlawed  
Do not keep a territory when you become outlawed. Roll a new Badzones territory. All Outlaw Scenarios are allowed except for the Caravan.

House gang creation

Selecting Common Items.

All gangs have a common list that includes:

Knife  
Autogun  
Stubgun  
Autopistol  
Heavy Stubber  
Respirator

To this list they can add up to 8 items from the following lists  
Hand to Hand: Sword, Club, Chainsword, Flail, Massive Axe  
Pistol: Bolt Pistol, Laspistol, Hand Flamer, Plasma Pistol  
Basic Weapons: Boltgun, Lasgun, Shotgun  
Special: Flamer, grenade Launcher, Meltagun, Plasmagun  
Heavy: Autocanon, Heavy Bolter, Heavy Plasma Gun, Missile Launcher  
Grenades: Frag, Krak, Smoke, Flash  
Armor: Junk Armor  
Equipment: Photovisor, Clip Harness, Lobo-Chip  
Ammo: Dum Dums, Man-stopper, Hotshot, Bolt shells,

New Territories

Bazaar – D6x3 per member (9 creds average, 18 Max)  
*“Your gang spends some time at the bazaar, extorting protection money from the local traders and sometime lending an honest hand as labourers or messengers. Gang members are always looking out for any good deals they can report to the Leader.”*  
Each member who is sent to generate income from this territory increases the number of rare trade items offered by 1 in addition to earning income.

Train Station – D6x5 per member (15 creds average, 30 Max)  
“A small party of intrepid adventurers is sent below to explore the ancient disused rail tunnels below the city. Safety always come in numbers and often one of the explorers does not return”  
If the result on all dice rolled are greater than the number of Gang members sent, one random sent member is injured and suffers a Serious Injury. Income is still generated as normal.

Highway – 2D6x2 per member (9 creds average, 24 Max)  
“Some of your gang protect groups of civilians while they scavenge for scrap metal on the old highway. Attacks and dehydration are common place due to lack of cover”  
For each 1 rolled, remove the highest scoring dice from the total roll.

Casino – 2D6x4 per member (24 creds average)  
*“Employed as dealers and security, your members have an opportunity to make a little extra cash. Counting cards and accepting door brides is always a risk...”*  
If any dice rolls a 1 you collect no income. If a 6 is rolled, you may choose to roll an additional dice.

Foundry – D6x4 (6 Creds average)  
Roll an additional dice for each captive your gang has taken.

Fighting Pit – AttacksxStrength (9 Creds average)  
Members sent to work at the Fighting Pit roll dice equal to their attacks and times the result by their Strength value.

Power Plant – D6x3 or Special  
When controlling two or more territories, for each member working at the Power Plant, double the income of another member who is working a different territory.

Industrial Sector – 2D6x5 Each member (30 Creds Average)  
If the Industrial Sector is used to generate income, the resulting credits may only be used to purchase new Common and Uncommon equipment.

Slum Quarter – D6x2 (6 Creds average)  
For each 6 rolled, add a “Follower” to your stash. These may be used in any Post battle phase to add a free Juve to your gang roster.

Desalination Plant

Controlling an Empire

While there are only a limited number of territories available, it is possible for a single gang to control more than one. This allows more and more Gangers to generate income after each game, but also makes it easier for opposing gangs to steal territories from your gang.

For each territory above the first, it becomes increasingly easy to capture territories from you. Each scenario has the following special rules.

Gang Fight/Hit and Run – The ratio of casualties increases as you own more territories.

| Territory Owned by Enemy | You cause to steal | You suffer to steal |
|--------------------------|--------------------|---------------------|
| 1                        | 3 or more          | 1 or 0              |
| 2                        | 2 or more          | 1 or 0              |
| 3                        | 2 or more          | 2 or less           |
| 4+                       | 2 or more          | 3 or less           |

Ambush/Raid

| Territory Owned by Enemy | Steal on D6 |
|--------------------------|-------------|
| 1                        | 6+          |
| 2                        | 5+          |
| 3                        | 4+          |
| 4+                       | 3+          |

Vassal Gangs

You may employ gangs that have no territories to work and protect your empire. These gangs work your territories during their post battle but do not earn any income. Instead tally up the amount they earn and add it to the Controlling Gangs income during their next post battle. The Controlling Gang may negotiate a fixed rate of payment for the work of the Vassal or may pay them in any other way. A contract is not necessary, but can add a bit of history to your gang (and prevents Controllers from being dodgy).

You may subtract the number of Vassal Gangs from the total number of territories when determining if one is stolen during a battle. Apart from the increased income, this is the main advantage of vassal gangs.

The downside is that during the Controlling Gangs post battle their own workers generate less (Income/Vassal Gangs) because most of the heavy work has already been done. The added income from your Vassals should make up for this loss. Alternatively you can rely totally on your Vassal gangs for income, using your members to do other things.

Once a Vassal, your gang remains a Vassal until you play an Uprising Scenario. This is played against the Controlling Gang and is similar to a Gang Fight scenario. The winner of the scenario will control the contested Territory.

Uprising Scenario  
This is set up exactly as a Gang Fight. The objective is to take out your opponents Leader with your own. You may not charge or fire at the enemies Leader except with your own. Leaders may still charge and fire upon enemy figures as normal. Due to their determination to succeed, neither gang needs to roll Bottle Tests and neither can bottle out voluntarily. If the revolution wins it may take a territory of its choice from the Controlling gang. If the Controlling gang wins, the rebellion is crushed and the Vassal Contract is broken (although it may be remade again during Post battle).

Optional – If the revolution is successful, all members of the Controlling Gang will now have Hatred towards the revolting gang due to the betrayal.

Pets and Fortifications  
Pets and Fortifications may be purchased for use during Sentry Missions. These are placed by the defender when he sets up his Sentries. These should be modelled by the purchasing gang. The prices are listed below.

Barricade – 10 Creds  
a 4”x1” obstacle that gives partial cover to any model standing behind it

Fence – 15 Creds  
a 6” long obstacle that is Impassable

Alarm/Guard Dog – 30 Creds  
A token with Initiative 6. Stationary. Cannot be deployed within 8” of the target. Sounds alarm as normal. Toughness 4 with 1 wound. Small Target.

Raised Watchtower – 30 Creds  
3” high, 1” square. Increases sight range of model by 50%. Roll only for direction.

Alternate Basic Territory Rules

Scavenger Creature Rules

Large 20

Crawler 15

Resilient x 3 45

Strong x2 30

Tough 15

Fear 20

Grab Attack 15

Enhanced Senses 15

Regen 20

Total - 195
