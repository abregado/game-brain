---
title: "Necromunda-Campaign Setting"
source: "Game Stuff/Wargaming/Necromunda-Campaign Setting"
modified: 2013-06-12
type: campaign-prep
area: wargame
status: "played/used"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda homebrew", "Necromunda Backer System", "Necromunda Hired Guns", "Necromunda Campaign Setting (Hab3 Melbourne)"]
words: 5057
summary: "Earlier version of the Hab3/Melbourne Necromunda campaign handout with backer gang creation, territories, post-battle changes and hired guns."
merged_versions: ["Game Stuff/Wargaming/Necro-Things were different once", "Game Stuff/Wargaming/Necromunda - Campaign Setting (modified)"]
tags: ["area/wargame", "project/necromunda-homebrew", "type/campaign-prep"]
---

*“Things were different once, boy. Before the Imperial Explorator fleet arrived our planet was a beautiful place filled with amazing flora and fauna. We had no idea that our descendants had arrived here as colonists over 4000 years ago. We didnt know that the ancient tales of prophets and miricles we actually true.*

*Several months later, a ship from the Administratum Imperialis arrived accompanied by the Cruxis, a Battle Barge of the Imperial Fists Space Marine chapter. A team of Negotiators held talks with every major power to decide the future of the planet once it returned to the galactic fold. Some disagreed with the appointing of a new Govenor but thier cries of resistances were quickly squashed by the mighty power of the Imperial Fists.*

*Due to its already large population, our planet was decreed to become a Hive World. We would live and die to construct the Imperiums weapons and to populate the planet far beyond the numbers that nature had decided apon. Huge prefabricated factory-habitats were constructed across the globe, each one housing millions of people.”*

*Over the next 100 years the planet fell into ruin, and some of those unlucky enough to find themselves with no place in the new society, like you and me, live outside the Habitats, fighting for our lives against all the other scavengers.”*

This necromunda campaign takes place far in the future in the location of a city once known as Melbourne. In its place is a polluted wasteland, oppressed by harsh days and cold nights, and dominated by three huge structures known as Habitats. The battles you will be participating in all take place around the smallest of these, Hab3.

**GANG CREATION**

For this series of battles you will control a small group of fighters that you can design and customise to suit your playing style.

All new gangs will start with 1000 credits in which to recruit fighters. The weapons and equipment available will come from a new list called a Backer List.

Each player will receive a sheet for recording his gang’s progress. On the back of this sheet the Backer List shows exactly what the gang can purchase during its career.

A player must select 8 items and tick/colour the “Common” box next to them. These are the items his gang can purchase freely during the campaign. Other items can be purchased, but not as often (See: Rare Trade).

Each player must also select three Skill Types and place them in the boxes labelled Training Available. This shows what type of skills the Backer can teach your gang members during their career. One of the remaining skill types should be placed in the Unavailable Training box to show which one your gang can never train. The Skill Types are: **Agility, Combat, Ferocity, Shooting, Stealth, Techno**. The Special class skill tables and the Leader skills cannot be chosen at this point.

Next, select one of the Backer Bonus’ from the list provided below:

**Shooty Training**  
When rolling 6 or 8 (WS/BS) on the Advance Table, add 1 to the secondary dice roll  
Also, When rolling 7 (I/Ld) on the Advance Table, subtract 1 from the secondary dice roll

**Melee Training**  
When rolling 6 or 8 (WS/BS) on the Advance Table, subtract 1 from the secondary dice roll  
Also, When rolling 5 (Str/A) on the Advance Table, add 1 to the secondary dice roll

**Strong Gang**  
When rolling 5 (Str/A) on the Advance Table, subract 1 from the secondary dice roll  
Also, When rolling 7 (I/Ld) on the Advance Table, add 1 to the secondary dice roll

**Tough Gang**  
When rolling 9 (W/T) on the Advance Table, add or subtract 1 to the secondary dice roll.  
Also, Count a result of 8 (WS/BS) as if 9 (W/T) was rolled

**Skilled Gang**  
The first Advance of every member is a random Skill from the Primary Skill Table for your gang. This includes Leaders and Specials as well.

**Fantastic Traders**  
Your gang is always offered an additional Rare Trade Item. Items are sold for 3/4 value instead of 1/2

**Outlawed**  
Your gang begins the game as an Outlawed Gang. This is both a Blessing and a Curse.

**Survivalist Gang**  
When rolling Treacherous Conditions, you may roll twice and pick the conditions

**Military Backers**  
You may purchase bulk weaponry during your post battle phase. Pay 4 times the cost for the item to receive a crate of them containing D6+1. The type of item must be decided before rolling.

**Engineer Backers**  
If you give a rare item to your backer, they may be able to reverse engineer it. You gain a Fixer(4+) for the item.

**Scientist Backers**  
Any inventors or chemists in your gang may select which item they invent if they pay half the item cost. You must choose before rolling for the random free item.

**Agricultural Backers**  
Your gang can purchase Food for 1 credit Also, When collecting income, your gang is considered one size class smaller (easier to feed)

**Mutants!**  
Your gang can purchase Mutations and can select random mutations when a "New Skill any table" is rolled

**The Law**  
You begin the game as a Watchman Gang. You cannot visit the Outlaw Trading Post or commit Crimes (outlaw scenarios, Ambush, shootout or Raid).

Finally, select one of the Special gang members you would like your gang to have access to. The special rules for these are listed below.

**Heavy Weapons Specialist**  
Weilding the heaviest weapons available in the undercity, Heavies command both respect and fear.

**Berkerker**  
These warriors are dedicated melee fighters. They attack without hesitation and rarely back down from a fight.

**Cyborg**  
Enhanced humans, these constructs can survive damage from weapons that would normally kill a man.

**Sniper**  
Specializing in getting the most out of Basic weapons, the sniper can pick targets on the battlefield freely.

**Hunter**  
These lone-wolves can infiltrate onto the battlefield and are experts in tracking.

**TERRITORIES**

Each new gang will receive 5 regular Territories. Any gang that selects “Outlaws” as its gang bonus will receive only one Territory.

**POST BATTLE CHANGES**

Several changes have been made to the way that the Post Battle is organised. After a battle each gang will work through Injuries, Experience and then Income.

**INJURIES  
** *“Hand Injury”* is simplified. Roll to see which hand is affected. If two Hand Injuries are inflicted on the same hand, it can no longer be used. Each causes -1 Weapon Skill. *“Bitter Enmity”* always causes Hatred of the entire opposing gang.

**SKILLS  
**During the campaign all gangs will use the Version 2 Necromunda Skill tables available from the Necromunda website. A compiled skill list is available from the Campaign Organiser.

**RARE TRADE  
**Whenever generating Rare Trade Offers use the new table that is provided on each Gang Roster and also at the end of this document.

**RESCUE MISSIONS  
**If a Rescue mission is necessary it must be played immediately after Injuries have been rolled. Only members that were uninjured during the last game can participate in the rescue. Using the same terrain, the game is played immediately. After the game is over roll for Injuries substituting further “Captured” results as “Full Recovery”. Continue with the other two Post Battle sections.

**GAMEPLAY CHANGES**

Several Changes have been made to the way battles work to balance some gameplay issues.

**ARMOUR  
**Armour saves that are not fully nullified may be taken at full effect. *Example: A ganger wearing Carapace Armour (4+ Save) is hit with a Lasgun (-1 Save). Instead of modifying the save to 5+, the ganger may take his save at 4+ (full effect).*

**MULTISHOT  
**When firing multiple shots using Fast Shot, Gunfighter or Rapid Fire skills the shots may be distributed as if they are Sustained Fire.

**MULTIWOUNDS  
**When dealing damage with a weapon that causes multiple wounds, determine the amount caused and then roll additional times on the Injury Chart to see if the target goes Out of Action. This replaces the “High Impact” special rule.

**MULTIAMMO  
**All weapons that could normally have multiple ammo types can now only have one. These can be changed after the battle but once a battle has started they cannot be modified.

**NEW ITEMS**

**Envirosuit** (Rare)  
This armor incorporates a sealed filtration system with ballistic protection. It counts as Flak Armor with both a Respirator and Photocontacts built in.

**Heavy Armour** (Common)  
Any member wearing Heavy Armour gains a 5+ saving throw but has his Initiative lowered to 1. In addition, this model can be detected during a Raid at twice the sentries normal viewing range.

**Exoskeleton** (Rare)  
The heaviest armour available in the undercity. Member wearing this armour gain a 3+ saving throw and are immune to Pinning. However the exoskeleton moves at a slow pace and the member may not Run or Charge. A member wearing this armour must also be fully modelled to show the armour.

HIRED GUNS

**Simon the Scum**  
The undercity is full of freelancers but there will only ever be one Simon. Known for his deadeye shooting and his odious personal habits, Simon is a local legend.

| M   | Ws  | Bs  | S   | T   | W   | I   | A   | Ld  |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| 4   | 3   | 5   | 3   | 4   | 2   | 3   | 1   | 7   |

**Skills:** Killer Rep (Ferocity), Hip Shooting (Shooting)

**Weapons:** Plasma Pistol, Laspistol, Knife

**Fee:** 15 Creds per game.

**Rating:** 75

**Jackson Wilcox**  
A newcomer to the mercenary crowd, Jackson is well known as the fastest draw in the city.

| M   | Ws  | Bs  | S   | T   | W   | I   | A   | Ld  |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| 4   | 5   | 4   | 3   | 3   | 1   | 4   | 1   | 7   |

**Skills:** Gunfighter (Shooting), Quickdraw (Agility)

**Weapons:** 2x Bolt Pistols, Knife

**Fee:** 15 Creds per game

**Rating:** 75

**Misery**  
A bounty hunter from out of town. If anyone knows anything about her they are keeping quiet about it. Well equipped and extremely dangerous.

| M   | Ws  | Bs  | S   | T   | W   | I   | A   | Ld  |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| 4   | 4   | 5   | 3   | 3   | 2   | 4   | 1   | 8   |

**Skills:** Marksman (Shooting), Leap (Agility)

**Weapons:** Shotgun w/ Manstopper, Bolt Pistol w/ Reddot sight, Powersword, Bio-Booster

**Fee:** 35 Creds

**Rating:** 175

SUMMARY

NEW RARE TRADE LISTS

TRETCHEROUS CONDITIONS

---

## Differences from other versions

_This document existed in several versions. The text above is the most complete one, unchanged. Below are the lines that appear only in the other versions._

### Only in “Necro-Things were different once” (Wargaming, modified 2013-06-12)

*“Things were different once, boy. Before the Imperial Explorator fleet arrived our planet was a beautiful place filled with amazing flora and fauna. We had no idea that our descendants had arrived here as colonists over 4000 years ago. We didnt know that the ancient tales of prophets and miricles were actually true.*
*Several months later, a ship from the Administratum Imperialis arrived accompanied by the Cruxis, a Battle Barge of the Imperial Fists Space Marine chapter. A team of Negotiators held talks with every major power to decide the future of the planet once it returned to the galactic fold. Some disagreed with the appointing of a new Govenor but thier cries of resistance were quickly squashed by the mighty power of the Imperial Fists.*
*Due to its large population, our planet was decreed to become a Hive World. We would live and die to construct the Imperiums weapons and to populate the planet far beyond the numbers that nature had decided upon. Huge prefabricated factory-habitats were constructed across the globe, each one housing millions of people.”*
Your gang may purchase bulk weaponry during your post battle phase. Pay 4 times the cost for the item to receive a crate of them containing D6+1. The type of item must be decided before rolling.
Wielding the heaviest weapons available in the undercity, Heavies command both respect and fear.
**Berzerker**  

### Only in “Necromunda - Campaign Setting (modified)” (Wargaming, modified 2013-06-12)

_No differences – identical content._
