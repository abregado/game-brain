---
title: "Necromunda-Campaign Hired Guns"
source: "Game Stuff/Wargaming/Necromunda-Campaign Hired Guns"
modified: 2013-06-12
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda Hired Guns", "Necromunda homebrew"]
words: 139
summary: "Rough list of Necromunda campaign hired guns with credit fees and skills (Simon the Scum, Quick Billy, bounty hunters, Techno Beatmaster, Pyromaniac Wyrd, Hunter, Mutant Hero)."
tags: ["area/wargame", "project/necromunda-homebrew", "type/homebrew-rules"]
---

Campaign Hired Guns

Simon the Scum – Plasma Scum – 15 Creds  


+2 Ballistic Skill, Hip Shooting, Killer Rep, +1 Wound, +1 Toughness, Plasma Pistol, Laspistol, Knife

Quick Billy – Gunfighter Scum – 15 Creds  
Gunfighter, +3 Ballistic Skill, +1 Init, Quickdraw, Twin Boltpistols

– Shotgun/Sword Bounty Hunter – 35 Creds  
Marksman, Leap, +1 Ballisticm Shotgun w/Manstoppers, Bolt Postol withRed Dot Sight, Powersword, Bio-Booster.

Techno Bounty Hunter – Combat and Armor – 40 Creds  
  
+1 WS, +1 A, Killer Rep, Carapace Armor, Twin Powerswords, Nerves of Steel

Techno Beatmaster – Drone remote creatures – 25 Creds  


120 creds of Creatures per game  
Sence Presence, Cameleon, - Seconadary Powers

Pyromaniac Wyrd – Fire Spells – 30 Creds

Molten Man, Melta – Primary Powers  
Bang-Flash, Freeze Time, Float – Secondary Powers

Hunter – Creature Bonuses  


Mutant Hero – Melee Scaly Monstrosity
