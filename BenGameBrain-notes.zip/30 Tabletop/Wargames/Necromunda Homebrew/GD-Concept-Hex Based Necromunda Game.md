---
title: "GD-Concept-Hex Based Necromunda Game"
source: "Game Stuff/Game Ideas/GD-Concept-Hex Based Necromunda Game"
modified: 2013-06-12
type: planning
area: wargame
status: "idea"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda homebrew", "Hex Based Necromunda Game"]
words: 288
summary: "Notes toward a computer adaptation of Necromunda: expectations, design choices, considerations and a three-phase development timeplan."
tags: ["area/wargame", "project/necromunda-homebrew", "type/planning"]
---

Necromunda Computer Game Ideas

Mainly writing this becasue Doha brings it up all the time. Many many people online have attempted and failed to deliver even an exact tabletop replica on any platform.

Expectations:

- Same odds as tabletop

- Similar size of gangs

- The same advancement structure

- Similar engagement environments

- 3d graphics and terrain

Choices to be made

- Turn based or Real Time

- Similtaneous or Sequential play

- Play by Email or Liveplay

- Fixed View or Free

- Fog of War or Revealed as in tabletop

- D6 usage or Percentile

- Concealed enemy stats or not as in tabletop

- Campaign players locked from start or Single Battles joined together

- Look and feel of weapons/hand to hand

Considerations

- Pathfinding and FOV based on Hexes?

- Elevation Modelling?

- Adequate modifications to avoid IP infringment

- Weapon Range Modelling

- Imperfections in the system

- Opportunity for modding (ease of adding new skills and equipment)

- Modelling gangers based on stats and skills

- Interrupt skills and abilities if not liveplay

- Picking up weapons from fallen members

- Swapping weapons before battle

- Postbattle after a fight or before next fight

Timeplan

Phase 1 – Movement

- Character Entity Generation

- Selection of Destination

- Restricted Distance of move

- Basic obstacle

- Pathfinding around obstacle

- ending turn/resetting movment allowance

Phase 2 – Shooting

- Determine if you can see (Line of Sight)

- Display chance to hit

- To Hit, Wound and Injury Roll

- Armor Calculations

- Modifier Breakdown

Phase 3 – Cover and Advanced Obstacles

- Directional Cover

- Movement Penalties

- Special Terrain Effects

- Pinning

- Moving while Downed

- 

&nbsp;

-
