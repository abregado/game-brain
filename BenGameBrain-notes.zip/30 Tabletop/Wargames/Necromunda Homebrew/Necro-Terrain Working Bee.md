---
title: "Necro-Terrain Working Bee"
source: "Game Stuff/Wargaming/Necro-Terrain Working Bee"
modified: 2013-06-12
type: planning
area: wargame
status: "idea"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda Terrain Working Bee", "Necromunda homebrew"]
words: 52
summary: "Short checklist of terrain pieces to build for a Necromunda terrain working bee (towers, gantry buildings, walls, barricades, slime pools, loot tokens)."
tags: ["area/wargame", "project/necromunda-homebrew", "type/planning"]
---

Terrain Working Bee  
The Complete List

3 Centre Tower Pieces  
Pumping Station, Power Plant, Foundry

10 Multi (2) Level Gantry Buildings (3 with Walkways)  
5 Multi (3) Level Gantry Buildings (2 with Walkways)

10 Wall Pieces

10 Barricade Pieces

3 Slime Pools

12 Loot Tokens

1 Water Still

1 Gateway

1 Watchtower
