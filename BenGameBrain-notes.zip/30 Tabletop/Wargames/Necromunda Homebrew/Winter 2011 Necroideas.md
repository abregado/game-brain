---
title: "Winter 2011 Necroideas"
source: "Game Stuff/Wargaming/Winter 2011 Necroideas"
modified: 2010-12-16
type: homebrew-rules
area: wargame
status: "idea"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda homebrew", "Necromunda Alien Factions", "Necromunda Primary Territories", "Necromunda Alien Technology"]
words: 1116
summary: "Ideas for a Necromunda campaign (Nevermaw): MIA shamblers/Flayed ones, Eldar guardians, regional treacherous conditions, trading post with alien tech, primary territories with lockdown, and outlaw rules."
tags: ["area/wargame", "project/necromunda-homebrew", "type/homebrew-rules"]
---

New Necromunda ideas.

Necrons. Groups of “MIA” fighters shamble around on the board. They can be targetted by both players. They can be saved by moving into base contact. When this happens there is a chance the model is actually a Flayed and will attack.

If left alone with a HTH victim, Flayed ones will drag them away and butcher them slowly.

Safest way is to shoot every shambler on the board. Gangs will be tempted to rescue members of their own gang if they see them, and shoot the other teams members. Shamblers do not count for the closest target rule, and any Shambler can be fired upon if any are targetted. Shamblers are not armed at all, if rescued they have no equipment, and gain the Soulburn trait (explained later, or perhaps does nothing).

Eldar will be guardians. Each squad will consist of 5 members. Stats will be normal, armed with shuriken and las weapons. perhaps one shuriken shreiker. The squad will have D6+4 tokens which can be used for the following:

Auto wound on one hit

1 free hit in HTH even if lost

Re-roll one armor save

Run/Charge triple for this turn.

Special equipment activation.

If an eldar is taken down or out, they are left on the board. The nearest other, non-down member will move to base to base to recover the injured member. Once base contact is made, remove both models at the end of the turn. The surviving eldar has carried his squadmate to safety.

Region based Treacherous Conditions

Each region will have its own 2D6 table for treacherous conditions and weather. Use these instead of the original table when rolling.

Northlock Trading Table

This is similar to the Outlaw Trading table, except all gangs can visit it. Being in possession of illegal items inflicts a penalty with the law. Once the Eldar arrive, some exotic items may also be available.

Other items available include: Illegal Operations, Gambling opportunites, Drugs, Psychic/Daemonic blessings, alien technologies, non-sanctioned weapon upgrades, outlaw territory (rackets, illegal business, ect)

Alien technolgies

Some artifacts from alien civs will be available. These will not be described as “Necron weaon X” but by unidentified names. Named by the gang that finds/buys the item.

Item Ideas: Alien “implants” (tyranid biomorph creatures/necron living metal infections) Gauss/Nano grenades/Traps. Territory upgrades (alien power sources). acheotech type weapons (random effects per game discovered when fired for the first time). Special attacks against nearby targets (canister of nanobugs). Food/Ammo synths. Alien healing technologies/techniques. Small pets (area effect boni or extra attacks in hth) Bonuses to Overwatch. Saves against particular weapons. Tokens to spend on combat. Inititative range increases and unpinning bonuses (alien communicators) Once per game stat boosts. Special deployment rules. After game effects to recharge some items.

Primary Territories.

**What are Regions?**

The campaign area is broken up into 4 zones. Each territory is allocated to one of these regions. mainly used for narrative, regions do not modify who and what you can attack. Each region has a Primary Territory linked to it.

**What are Primary Territories?**

These are special territories that when claimed give the controlling gang an advantage over other gangs with territories in the same region. Gangs must complete special objectives to capture each PT, and once controlled, they can “lockdown” the PT by changing their play style.

Once per Campaign event, the controlling gang earns 10% of the entire income generated from the region they control.

**What is the Safe Region?**

One region is controlled by law abiding groups, Enforcers or some other organised group. These regions are not taxed, but gangs with territories in these must abide by the law. Using the normal Outlaw rules, there are a number of things that gangs may do that will put them at risk of being outlawed (See the Outlaw Rules).

**Gaining a Primary Territory**

Each PT has a set of special objectives that a gang must complete to take initial control of the region. These include things such as owning a number of territories in the same region, area control in a number of matches, giving up Trading Post opportunities and the like (ask the Arbitrator).

**Putting a PT into “lockdown”**

Once a gang controls a PT, they can block other gangs from taking control by fulfilling the lockdown prerequisites. These take the form of battlefield conditions, making the battles a little more difficult for the controlling gang. Often these will require the controlling gang to place special terrain on the board and protect/destroy them, in addition to other mission criteria. Some others include: Failing no more than 2 ammo rolls, suffering no more than 3 out of action results, chance of members not showing up, Loot tokens collected, not firing a weapon within distance of a particular terrain piece, certain member being unharmed, ect. These goals should always be declared to your opponent.

**Losing a PT**

If a controlling gang fails to achieve the lockdown prerequisites, and another gang achieves the capture prerequisites in the same Campaign Meet, the PT changes ownership. If no challenging gangs achieve the capture objectives, then the current controlling gang has no reason to complete the lockdown objectives either.

**Community Spirit**

When a gang controls the PT for a region, all regular territory in the region that gang owns doesn't pay tax and instead generates 10% more income than normal.

**Protectorate or Directorate**

The gangs which control regions can use their power in two distinct ways. One way is to choke all gangs in their region, fighting to gain control over ALL territories, and become the sole power.

They may also choose to be benevolent. Forgoing taxation on their underlings in a hope that they are challenged for power less often. Tax status must be declared at the start of a Campaign meeting, and stays the same until the beginning of the next meet.

**Outlaw Status**

Should a gang become outlawed, it loses all of its Nevermaw teritory. Do not remove them from the roster, but mark them as non-workable. The gangers families still own and operate them, but the income cannot reach the banished gang. Gangs may regain legal status by paying the guild fee as per the normal outlaw rules. Outlaw gangs may also be given the Outlaw Hideout (30 creds) territory, placing it in a region of their choice. This territory may never be stolen.

**Outlaw Income**

In the Nevermaw campaign outlaws generate income as if they are a normal gang. Territory income is not halved. The difference between being an outlaw and a law abiding gang is not so different.

**Outlaw Trade Table**

Although all gangs may visit the Northlock Trading Post, Outlaw gangs may ONLY visit this trading post.
