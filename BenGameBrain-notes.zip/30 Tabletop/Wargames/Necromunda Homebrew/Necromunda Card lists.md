---
title: "Necromunda Card lists"
source: "Game Stuff/Wargaming/Necromunda Card lists"
modified: 2013-06-12
type: reference-data
area: wargame
status: "designed"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda Card Game", "Necromunda homebrew"]
words: 1250
summary: "Spreadsheet of probability/chance weightings for Necromunda items (weapons, grenades, sights, armour, equipment), injury results and advance outcomes, apparently for a card-based random distribution (36 cards)."
tags: ["area/wargame", "project/necromunda-homebrew", "type/reference-data"]
---

## Sheet: Sheet1

|  |  |  |  | Chance Base |  |  |  |  |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Power Weapon | 4.0 | 4.0 |  | 0 | 0 |  |  | Dead | 6.0 |  | New Skill AT | 2.0 |  |  |  |
| Power Axe |  | 4.0 | 0.1666666667 | 1.851851852 | 2 |  |  | Multiple Injuries | 1.0 |  | New Skill | 4.0 |  |  |  |
| Power Fist |  | 4.0 | 0.1666666667 | 1.851851852 | 2 |  |  | Chest Wound | 1.0 |  | Strength | 0.5 |  |  |  |
| Power Maul |  | 4.0 | 0.1666666667 | 1.851851852 | 2 |  |  | Leg Wound | 1.0 |  | Attacks | 0.5 |  |  |  |
| Power Sword |  | 4.0 | 0.5 | 5.555555556 | 6 |  |  | Arm Wound | 1.0 |  | WS | 1.0 |  |  |  |
| Rare Weapon | 1.0 | 1.0 |  | 0 | 0 |  |  | Head Wound | 1.0 |  | BS | 1.0 |  |  |  |
| Needle Rifle |  | 1.0 | 0.1666666667 | 0.462962963 | 1.0 |  |  | Blinded in One Eye | 1.0 |  | Init | 0.5 |  |  |  |
| Needle Pistol |  | 1.0 | 0.3333333333 | 0.9259259259 | 1 |  |  | Partially deaf | 1.0 |  | Ld | 0.5 |  |  |  |
| Web Pistol |  | 1.0 | 0.3333333333 | 0.9259259259 | 1 |  |  | Shell Shock | 1.0 |  | Wound | 0.5 |  |  |  |
| OIAM |  | 1.0 | 0.1666666667 | 0.462962963 | 1.0 |  |  | Hand Injury | 1.0 |  | Tough | 0.5 |  |  |  |
| Gas Grenades | 1.0 | 1.0 |  | 0 | 0 |  |  | Old Battle Wound | 3.0 |  |  |  |  |  |  |
| Choke |  | 1.0 | 0.3333333333 | 0.9259259259 | 1 |  |  | Full Recovery | 11.0 |  |  |  |  |  |  |
| Scare |  | 1.0 | 0.3333333333 | 0.9259259259 | 1 |  |  | Bitter Enmity | 3.0 |  | NSAT | 2.0 | 5.555 | 1.0 | 2 |
| Hallucinogen |  | 1.0 | 0.3333333333 | 0.9259259259 | 1 |  |  | Captured | 1.0 |  | NS | 3.0 | 27.766 | 5.0 | 10 |
| Grenades | 1.0 | 2.0 |  | 0 | 0 |  |  | Horrible Scars | 1.0 |  | Strength | 5.0 | 5.555 | 1.0 | 2 |
| Melta |  | 2.0 | 0.1666666667 | 0.9259259259 | 1 |  |  | Impressive Scars | 1.0 |  | Attacks |  | 5.555 | 1.0 | 2 |
| Photon |  | 2.0 | 0.3333333333 | 1.851851852 | 2 |  |  | Survival against the odds | 1.0 |  | BS | 6.0 | 13.888 | 2.5 | 5 |
| Plasma |  | 2.0 | 0.1666666667 | 0.9259259259 | 1 |  |  |  | 36 |  | Init | 7.0 | 8.333 | 1.5 | 3 |
| Smoke |  | 2.0 | 0.3333333333 | 1.851851852 | 2 |  |  |  |  |  | Ld |  | 8.333 | 1.5 | 3 |
| Hotshot Pack | 2.0 | 2.0 |  | 0 | 0 |  |  |  |  |  | WS | 8.0 | 13.888 | 2.5 | 5 |
| Gunsight | 3.0 | 3.0 |  | 0 | 0 |  |  |  |  |  | Wnd | 9.0 | 5.555 | 1.0 | 2 |
| Red Dot |  | 3.0 | 0.3333333333 | 2.777777778 | 3 |  |  |  |  |  | Tough |  | 5.555 | 1.0 | 2 |
| Mono |  | 3.0 | 0.1666666667 | 1.388888889 | 1.0 |  |  |  |  |  |  |  |  |  | 36 |
| Tele |  | 3.0 | 0.1666666667 | 1.388888889 | 1.0 |  |  |  |  |  |  |  |  |  |  |
| Infra |  | 3.0 | 0.3333333333 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Armour | 3.0 | 3.0 |  | 0 | 0 |  |  |  |  |  |  |  |  |  |  |
| Flak |  | 3.0 | 0.6666666667 | 5.555555556 | 6 |  |  |  |  |  |  |  | 99.983 |  |  |
| Mesh |  | 3.0 | 0.1666666667 | 1.388888889 | 2.0 |  |  |  |  |  |  |  |  |  |  |
| Carapace |  | 3.0 | 0.1666666667 | 1.388888889 | 1.0 |  |  |  |  |  |  |  |  |  |  |
| Bionics | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Autorepairer | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Bio-Booster | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Bioscanner | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Blindsnake Pouch | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Concealed Blade | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Grav Chute | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Grapnel | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Infragoggles | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Isotropic Fuel Rod | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Medipack | 2.0 | 2.0 | 1.0 | 5.555555556 | 6 |  |  |  |  |  |  |  |  |  |  |
| MungVase | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Ratskin Map | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Screamers | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Skullchip | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Silenced Autopistol | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Stummers | 1.0 | 1.0 | 1.0 | 2.777777778 | 3 |  |  |  |  |  |  |  |  |  |  |
| Ammo Bandoleir | 2.0 | 2.0 | 1.0 | 5.555555556 | 6 |  |  |  |  |  |  |  |  |  |  |
|  | 35 |  |  | 94.44444444 | 102 |  |  |  |  |  |  |  |  |  |  |

## Sheet: Sheet2

_(empty)_

## Sheet: Sheet3

_(empty)_
