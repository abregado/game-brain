---
title: "Necromunda-Card Idea"
source: "Game Stuff/Wargaming/Necromunda-Card Idea"
modified: 2013-06-12
type: design-doc
area: wargame
status: "designed"
projects: ["[[Necromunda Homebrew]]"]
concepts: ["Necromunda Card Game", "Necromunda homebrew"]
words: 251
summary: "Idea for a simplified card-based Necromunda gang builder: pre-levelled Leaders/Specials/Regulars drafted from a pool, with a simplified non-Warhammer weapon and equipment list and a card layout."
tags: ["area/wargame", "project/necromunda-homebrew", "type/design-doc"]
---

Necromunda Card Idea

Each member has a card to reference their characteristics. All members are pre-leveled up to a certain number of points. The Three types of members are.

Leaders – One per Gang

Specials – One for every 5 members

Regulars – Unlimited

Players simply take it in turns creating a gang by selecting members from a pool. Players may select in any order, but must end up with a complete gang.

Regulars will be created from 100 points spread over both Equipment and Experience. Their experience upgrades will be based on a Juves experience track.

All members will NOT start with a knife

Specials can select a single Heavy, Special Weapon or Armour Item for their equipment

Leaders can select a single Special Weapon, Armour or Rare Item for their equipment

Equipment will be simplified into NON-warhammer classed weaponry. Weapons will include:

Handgun  
Revolver  
Submachine Gun  
Carbine  
Shotgun  
Rifle

Knife  
Sword  
Axe  
Club  
Two Handed Weapon  
Flail  
Polearm

Plasma Rifle  
Laser Carbine  
Flamethrower  
Fusioncannon  
50cal Rifle  
Grenade Launcher

Heavy Machine Gun  
Autocannon  
Particle Rifle  
Suncannon

Common Armor and Equipment  
Bullet proof Vest  
Kevlar Ballistics Suit  
Clip Harness  
Silencer  
Frag Grenades  
Flashbangs

Rare Armor  
Full Body Carapace (Combat Suit)  
Salvagers Rig (Powered Exoskeleton)

Rare Equipment  
Grav Chute  
Grapnel  
Vision Goggles  
Plasma Greandes  
Bio-Scanner  
Bio-Booster  
Bionic Parts  
Combat Drugs

All information needed on the card

Name

Type

Costs (points)

Stat line (Move, Weaponskill, Ballistic Skill, Strength,

Toughness, Wounds, Initiative, Attacks, Leadership)

Skills (no description)

Weapons (stats a possibility)

Multiple Weapons stats?
