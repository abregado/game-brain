---
title: "Concept - Lego Game"
source: "Game Stuff/Game Ideas/Concept - Lego Game"
modified: 2013-06-12
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Lego Wargame]]"]
concepts: ["Lego Wargame"]
words: 1103
summary: "Rules for LEGOWARS, a tabletop game where Lego vehicles are built and fought with: build phase, fuel, weapon/cortex/shield components, damage by removing bricks, phase order."
tags: ["area/wargame", "project/lego-wargame", "type/homebrew-rules"]
---

|     |             |
|-----|-------------|
|     | Ben Buckton |

| **\[LEGOWARS™\]** |
|-------------------|
|                   |

Setting Up

Making Lego Dice and rulers

Take a tall 2x2 stud brick and attach a flat, smooth 2x2 piece to the top. Count the bottom as 1 and the flat top at 6.

Set aside a long 12x1 stud brick to measure the distance that Legomen can move in a single turn.

Legomen

You will also need to set aside any Legomen in your collection. These little dudes are the corner stone of any Legowars(tm) operation. Feel free to decorate them however you like as there are no rules for clothing and equipment.

Construction Rules

Vehicles can be built in any order. During each Build phase, each player may Select a number of bricks from his piles equal to the number of Legomen available for building. These are shown to all other players. Once bricks are selected, the construction phase begins. Players may add these bricks to any construction that is at the same location as the bricks.

Dismantling Vehicles and Fortifications

Any legoman that does not build in the build phase may dismantle 2 bricks from any vehicle or fortification on the same baseboard.

Declaring construction complete

Once bricks have been added, each player has a chance to declare that one or more of this constructions is complete. That player must declare out-loud “Contruction Complete”, audible to all players. Each completed construction is detailed with a type and any corresponding statistics. The vehicle or weapon is then available for fueling next turn.

Joining Contructions

If two or more constructions need to be joined, such as if a vehicle needs to have a weapon fitted, the weapon counts as a single brick for the purposes of construction.

Construction Types and regulations

Pilotable: The vehicle requires a Legoman to operate it. At least one Control surface must be fitted to the vehicle and the Legoman must be positioned touching this control surface.

AI Controlled: The vehicle doesn’t require a Legoman to operate it. Instead it must include a component that has been declared an Cortex.

Cortex (Component): This is a component used to control a single vehicle and all of its weapons. Each turn it consumes a unit of fuel. It must be constructed from 3 or more parts.

Walker: any vehicle that can support itself on two or more legs. The legs must be articulated. Movement is determined by moving each leg once during the movement phase.

Tracked Vehicle: a vehicle that is held up completly by tank tracks. These vehicles are rare, however their movment systems are completly immune to damage. These vehciels move distance equal to their chassis length.

Wheeled Vehicle: any vehicle that is held up by at least two wheels. These move up to twice their chassis length during the movement phase.

Hover Vehicle: Any vehicle held up completly by clear bricks. The only rule is that it must be free-standing, and if at any time a part of the construction touches the table, it is considered immobile until repaired.

Shield Generator (Component): This Component must be build out of 3 or more bricks. A number of studs should be kept free for fuelbricks.

Weapon (Component): Declaring a component as a weapon is a little more complicated than a vehicle. All players must agree that it looks like a weapon. A number of stats are generated from the number and type of bricks used.

Damage Rating = number of bricks used in the weapon base

Rate of Fire = number of barrels attached to the base.

Phases

Each Turn is broken up into several Phases. All players act during each phase before moving on to the next phase.

1.  Vehicle Movement

2.  Fuelling Phase

3.  Other Movement

4.  Aiming Phase

5.  Melee Resolution

6.  Shooting Resolution

7.  Build Phase

Vehicle Movement  
Each player takes it turns moving a single vehicle starting with the player who controls the most vehicles. There are 4 types of movement

Fuelling Phase  
Vehicles that are parked on a baseboard that has fuel bricks available may transfer as many as they like to their components and weapons.

Other Movement  
Each player takes it in turn to move each of his Legomen.

Aiming Phase  
Players can reposition weapons and legomen to aim at targets. Vehicles may not be moved, but any part that can actuate may be re-positioned. Melee attacks will be made by physically touching the weapon to the target.

Melee Resolution  
Resolve melee damage. Damage is applied to the location that is struck.

Shooting Resolution  
Resolve Shooting Damage. 1:miss 2-5:hit (defender chooses damage) 6:hit (attacker chooses)

Build Phase  
Players select the bricks they wish to use this turn. Once all bricks have been chosen, all players may build using those bricks.

Calculating Damage

Determine who chooses damage location. Damage = largest brick that can be removed in “studs”. Only one brick can be removed per attack. If removing the brick disconnects a section of the vehicle, then place the disconnected bricks on the table next to the vehicle. Only bricks which can be removed may be targeted.

Any damage done to a Legoman will disconnect this body from his legs. This means he cannot move. If a immobilized torso is hit, remove its head and it now cannot perform any building actions.

Damage from Melee weapons is always applied to the brick that is making contact with the melee weapon.

Fortifications and Tank parts cannot be removed by damage, but may be disassembled by Legomen.

Dismounting from a Vehicle

Instead of moving a vehicle during the Vehicle Movement Phase, you may instead Dismount as many Legomen as you like. These are placed adjacent to the vehicle and may move in the following Other Movement phase.

Mounting a Vehicle

During the Other Movement phase a Legoman than can move to a friendly or unoccupied vehicle may board it. Simply place the Legoman where you like on the model.

Using Fuel

Fuel may be expended to perform the following actions based on where the fuel is connected:

(Movement/Wheels/Legs/Tracks/Hover) Move twice in a single turn

(Shield Generator) Deflect a single hit

(Weapon) Fire with double strength or rate of fire

Once a Fuel brick is expended, it is removed from the vehicle and placed in the BrickPile furthest from the vehicle.

Making Lego Dice and rulers

Take a tall 2x2 stud brick and attach a flat, smooth 2x2 piece to the top. Count the bottom as 1 and the flat top at 6.

Use any long 12x1 stud brick to measure the distance that Legomen can move in a single turn.
