---
title: "Lego Wargame Ideas"
source: "Game Stuff/Game Ideas/Lego Wargame Ideas"
modified: 2011-03-14
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Lego Wargame]]"]
concepts: ["Lego Wargame"]
words: 1813
summary: "Extensive draft rules for a Lego wargame (axioms, minifig actions, power studs, damage by brick removal, weapon/vehicle construction, collisions), noting borrowed ideas from Brikwarz."
contains_external_material: "Self-noted 'plenty of stolen stuff from Brikwarz' but written in Ben's words"
tags: ["area/wargame", "project/lego-wargame", "type/homebrew-rules"]
---

# **A LEGO WARGAME:** 

By Ben Buckton (with plenty of stolen stuff from Brikwarz)

A reminder than I should really order this stuff properly and actually make it readable for other people!!! Ben your not a nub at writing this stuff so why do you always make it so damn ugly!

> [*A LEGO WARGAME:*](#a-lego-wargame)
>
> [*AXIOMS*](#axioms)
>
> [*OTHER IDEAS*](#other-ideas)
>
> [*MINIFIG ACTIONS*](#minifig-actions)
>
> [*POWER STUDS*](#power-studs)
>
> [*POWER STUD RESPAWN*](#power-stud-respawn)
>
> [*MINIFIGS POWER STUD USE*](#minifigs-power-stud-use)
>
> [*NORMAL DAMAGE*](#normal-damage)
>
> [*TARGETED DAMAGE*](#targeted-damage)
>
> [*SIZE OF A BRIK*](#size-of-a-brik)
>
> [*SIZE OF A CONSTRUCTION*](#size-of-a-construction)
>
> [*CONSTRUCTING A WEAPON*](#constructing-a-weapon)
>
> [*WEAPON POWER*](#weapon-power)
>
> [*WEAPON RANGE*](#weapon-range)
>
> [*WEAPON FIRE RATE*](#weapon-fire-rate)
>
> [*ATTACHING A WEAPON*](#attaching-a-weapon)
>
> [*MINIFIG WEAPONS*](#minifig-weapons)
>
> [*CONSTRUCTING A VEHICLE*](#constructing-a-vehicle)
>
> [*CONSTRUCING A STRUCTURE*](#construcing-a-structure)
>
> [*SPEED*](#speed)
>
> [*ATTACHING POWER STUDS*](#attaching-power-studs)
>
> [*COLLISIONS*](#collisions)
>
> [*SPECIAL ABILITIES FOR THINGS THAT SHOULD BE IN*](#special-abilities-for-things-that-should-be-in)

# 

# 

## **AXIOMS**

Things that MUST BE for a lego game:

Minifigs must play a pivotal role!

No one build style should be unbalanced

The shape, size, number of bricks and any articulation should have game effects

Damage should be represented by removing blocks

No tokens

All effects to be represented with lego

Cinematic Feel (You must position the lego when it performs actions)

It should be VERY EASY AND LAID BACK TO PLAY!!

## **OTHER IDEAS**

Quantity vs Quality; each strike only removes a single brick (specials miht change this)

Movement is based on locomotion and measured in studs (you must roll the vehicles along the ground or walk them successfully. Hover vehicles must slide.

Repairs can be completed during the game.

perhaps all objects must be built during the game

Units can be whatever you want them to be. Smaller table? Use smaller units.

Part recovery could be an integral part of the game

One special brick is used for ammuntion (probably glowing bricks)

Each stud of ammunition used adds a large amount of extra firepower.

Without ammunition, weapons only deal slight damage

Melee MUST be involved

Minifigs MUST be involved (drivers, repairers, gunners)

Perhaps each minifig gets ONE action point, the number of minifigs is how many actions you can take as a player.

## **MINIFIG ACTIONS**

Attach/Detach D6 studs worth of lego to/from one contruction in the area (1 unit)

Walk one “unit of distance”

Fire a personal weapon

Drive a vehicle its basic speed (1 unit) and make one normal attack

Drive a vehicle its top speed (2 units) and make one turn

Drive a vehicle twice its top speed (4 units) and make no turns.

make a targeted attack with one weapon on a piloted vehicle

Collect 2D6 studs worth of lego and load it into a vehicle (without joining)

Claim Victory points (lord knows what this means)

Attach one Power Stud to a creation

A Minifig may after Moving, declare a second action and roll a dice. 50% of the time it may take the second action (ONLY AFTER A MOVEMENT ACTION)

## **POWER STUDS**

Power studs are a single type of brick as dictated by the players. Normally this will be a unique style of brick such has transparent one stud cylinders that are in limited supply.

Power studs are the “currency” of this wargame. Every time a player uses a minifig to perform an action using a creation he may spend power studs to increase the effect of the action.

Example; when a minifig:

activates a weapon device, he may spend one attached Power Stud (tm) to double the damage it causes.

drives a vehicle, he may spend one attached Power Stud (tm) to move twice as far

Fire a weapon at double range

Strategic use of your Power Studs is crucial to winning the battle!

Power studs should also have passive effects when built into creations.

## **POWER STUD RESPAWN**

Whenever a power stud is used, it is removed from the creation and placed onto the power generator with the most Power Studs stored in it. Power Generators are the focal points for fighting during the game as all players will be attempting to seize control of them all.

Power Generators can be elaborate creations or simply designated areas (if briks are in short supply).

THIS NEEDS TO BE BALANCED LATER TO PROMOTE PROPER BATTLE FLOW!!!

UPDATE: Perhaps used Power Studs are moved to the side of the game area until there studs equal to or more than the available Power Generators. Then one is placed on each power generator. This favours the player who uses his power studs sparingly.

## **MINIFIGS POWER STUD USE**

Survive one hit regardless of size

Reduce a creation to component parts

Reconstruct another Minifig (when all parts are nearby)

Teleport anywhere

Attach one brik of any size to a creation

Minifigs can use a Power Stud attached to their current vehicle.

## **NORMAL DAMAGE**

When a weapon does damage to a creation, the defender disconnects a block of equal or greater size than the damage inflicted. If this causes other blocks to fall off (even if its accidental) then these blocks are also lost.

Removed blocks should be scattered around nearby to the target.

Normal Damage applied to minifigs can be applied to anything (terrain/creation) within 10 1 Unit of range

## **TARGETED DAMAGE**

If a weapon is aimed (a minifig uses a whole action just to fire it), the damage is considered targeted. The attacker can chose a single brick of size EQUAL TO OR LOWER THAN the amount of damage inflicted. This can only effect a brik that the firer can see and can cause large sections of the target to be removed. When building remember to protect your weak spots.

Targeted Damage only hits 50% of the time, making them more risky than Normal Damage (especially when using Power Studs)

Targeted Damage of 3 against a Minifig will wound it (remove legs), while Targeted Damage of 5 will kill it (remove head). More than 6 damage will explode it (remove the hands and place each piece about 1 range unit away from the body. Minifigs inside vehicles cannot be affected by Targeted Damage.

## **SIZE OF A BRIK**

Each brik has a size equal to the number of studs it contains. In situations where a brik has very few studs for its size (smooth briks) count the number of stud sockets on the back. Some parts have no studs or sockets, mesure the longest dimension with a long brik and use the number of studs as its size (for example Bionicle parts). A minifig is consider size 3.

## **SIZE OF A CONSTRUCTION**

The size of a construction is measured in “Distance Units”. Use your standard measurer and find out how many units long the creation is in its LONGEST dimension.

## **CONSTRUCTING A WEAPON**

After briks have been attached to a creation, the entire thing can be declared a weapon. The cardinal rule of weapons is that that must LOOK like weapons. Three cows stacked on each other is NOT a weapon, it is a stack of cows (still fearsome). Once declared, a weapon cannot be modified anymore.

## **WEAPON POWER**

The strength of a weapon is determined by its barrels Width. Measure the number of studs wide. This is the number of dice rolled for its Damage when firing without Power Studs.

## **WEAPON RANGE**

If the weapons widest point is wider than the tip of the barrel, the weapon has one additional range unit.

Total Length of Weapon:

5 Studs or less Range 2

10 Studs or less Range 3

20 Studs of less Range 4

40 Studs or less Range 5

## **WEAPON FIRE RATE**

The weapon may fire as many times as it has barrels. Barrels must be identical in construction. Two barrels of different sizes simply count as more barrel width. Power is not added together, instead the weapon can cause more than one brik to be removed per turn. Weapons with more than one barrel may use a Power Stud to fire twice as many shots instead of doubling the number on the rolled dice.

## **ATTACHING A WEAPON**

A minifig may attach a single weapon to a creation as an action without rolling for size.

## **MINIFIG WEAPONS**

Weapons up to a minifig in height always roll one dice and have a range of 2.

## **CONSTRUCTING A VEHICLE**

After briks have been attached to a creation the whole thing can be declared a vehicle. At this point the type of locomotion must also be declared. Available types of locomotion are: Wheeled, Tracked, Walking, Hover.

Wheels Vehicles must be held off the ground by wheels and must be able to move without being picked up (they must roll).

Tracked Vehicles must only touch the ground with their tracks. The tracks do not have to roll along the ground. For going through the trouble of building a tracked unit, your vehicle can never be immobilized through damage (the tracks are immune the damage).

Walking Vehicles must be held off the ground by two or more legs. They must be able to move by being articulated. They may move over obstacles as long as the legs can be moved over the top.

Hover vehicles must have Power Studs equal to their size built into their construction. They can be held off the ground by any brik and do not have to be pushed along the table when moved.

Once declared, a vehicle cannot have more briks attached to it.

## **CONSTRUCING A STRUCTURE**

Structures are simply vehicles that have no motive power. Once declared they may never move

## **SPEED**

Cant really think of a simple and decent equation for this. Most likely all vehicles have a basic speed of 2 range units per move

After moving a vehicle must face in the direction that it was last travelling.

## **ATTACHING POWER STUDS**

Each Minifig Action can attach a single available Power Stud to a weapon or vehicle. Once attached, Power Studs cannot be removed except to be used. Power Studs can be added to creations after they are declared.

## **COLLISIONS**

When two creations collide, they are both dealt damage. The owner deals the damage to his own creations. The damage applied is the Number of Distance Units travelled before the crash (or part thereof) multiplied by the Size of the other vehicle.

## **SPECIAL ABILITIES FOR THINGS THAT SHOULD BE IN**

Shields, Mines, Digging Machines, Jumping Machines, Winches (THAT WORK!), Single Use Missiles and Projectiles (SCUUUD!), Cranes/Lifters, Teleports, Catapults, Resurrection Machines, Orbital Weapons, Pipes, Communication Arrays, “Wireless Technology”, Slow Beams, Afterburners, JETPACKS!, Traps, Harpoons, Crushers, Chainsaws, Tractor Beams, Plants, Power Reactors, Throwing Objects, Mega Over-Charge Weapons, Building Machines, Detpacks, Nanostudtechnology, Creatures (Dinosaurs, Monsters, ect), Artillery, Paratroopers, Care Packages,

WEAPON SPECIALS

Penetrator, Exploder, DOT, Slowing Effects, Knockback,
