---
title: "BS - Lego rules and stuff"
source: "Game Stuff/Game Ideas/BS - Lego rules and stuff"
modified: 2013-06-12
type: brainstorm
area: wargame
status: "idea"
projects: ["[[Lego Wargame]]"]
concepts: ["Lego Wargame"]
words: 625
summary: "Design notes for Lego brick vehicle destruction rules: removing bricks, card and dice damage options, special attachments (radar, harvester, shield), called shots and color matching."
tags: ["area/wargame", "project/lego-wargame", "type/brainstorm"]
---

Vehicle Destruction mechanics for lego brikgame

Must include:

- removing briks

- random element

Color Matching?

Discard briks from your stockpile to fire

Discard briks from your vehicle to fire

Each shot should do more damage to your opponent than to you (even with random)

Brik selection

Opportunity to split vehicles into large chunks

some briks more important (targets of opportunity)

Removing only easy briks

target can chose to defend, forfeiting thier next action

fixed emplacements

third party decides which briks to remove

fixed damage (how many briks)

certain briks represent hit points

size overall determines power, players build the biggest thing with the least briks

briks can be strengthened with power briks or with more minifigs

early game build up must be fast

all plays should be doing something all the time

card usage:

Players have a hand of Build, Collect, Move. Each player puts one of these cards into a pile and these cards make up which phases are in the turn.

Cards are used to determine damage. Each card has a color and a number. Draw a number of cards and choose one for the color and one for the number of studs. More powerful/accurate attacks allow for more cards to be drawn.

Dice usage:

Use lego dice. Players can place what they want on the dice before rolling

As above but players can only change one face of the dice, leaving it as is for the next roll, regardless of player.

Use regular dice. Players can create combinations of the numbers to get the result they desire.

Use regular dice. Players can only select one of the rolled dice. More dice simply improves accuracy.

Dice Pool. Players roll a number of dice all together at the start of the round. These are used up in each phase. Players should keep their best dice for the phases they are most interested in.

Special attachments

Radar. Any dish part on a hinge and swivel, power brik and three other briks. Increases initiative for this player. Additional briks are simply ablative armor.

Harvestor. Any structure with 2 or more tubes, a power brik and 7 other parts. Increases the amount of bloks collected from this baseplate.

Shield. 4 powerbriks joined to a strucutre so they face in diferent directions. Increases defence or lowers accuracy of attacks.

Other ideas

Everyone builds and collects at the same speed. Emphasis is on how you use the briks you take. Winner will be the player who builds the most efficent vehicle. Watch what your opponent does and build a counter.

*Problems: Multiple players could gang up on the best vehicle to take it down, High demand briks will be taken very quickly and may cause imbalance*

Vehcile weapons are more effective against the same color vehicles. When attacking a vehicle with briks of the same color, declare an aimed attack at that color and increase your attack power. Only briks of that color are effected. Each weapon must have its color declared when it is contructed.

*Considerations: Players will try to use the same color as their opponents vehicles in their weapons. Odd colored briks will be popular for armor. Common ones will be highly available.*

When damage is rolled and the attacker chooses a brik (called shot), the defender must remove that brik and any others that must be removed to get it out. These are placed on the table next to the vehicle to be collected later.

*Consider: This may cause some vehicles to be very vulnerable to called shots.*

Equipment for minifigs could increase their efficency. All minifigs start off with only legs, body and head. Upgrades all do the same thing, and can be discarded to ignore damage. Each one counts as a brik.
