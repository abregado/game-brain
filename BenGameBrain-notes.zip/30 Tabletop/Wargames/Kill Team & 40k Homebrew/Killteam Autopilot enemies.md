---
title: "Killteam Autopilot enemies"
source: "Game Stuff/Game Ideas/Killteam Autopilot enemies"
modified: 2026-11-08
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Kill Team homebrew"]
words: 521
summary: "Design notes for an automated solo/co-op enemy AI system for Kill Team (order tokens, behaviour triggers, extra actions, Tyranid turn-start events)."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/homebrew-rules"]
---

Autopilot enemies

Combination of:

- Npo team

- Extra action

- Which Action decks

Tokens with increasing numbers 1-10

- 

Proc-points

Turn start -

- Randomly assign numbers face down to all enemies, then flip

- feedback given to players that they can act on

- Enemy activation order visible. Enemies can have multiple counts

Activation

- Activate lowest number

- Draw Card

- Calculate behaviour outcome

Extra action (is team specific) always costs 1ap.

Hunker down - 1ap - add a shield token.

Shield token: when being shot, adds cover if not in cover, or obscured if in cover.

Recover - 1ap. Regain d3 hit points

Alarm - 1ap. As one to the next reinforcement roll

Slink - 1ap. Move 2” ignoring control

Strategize. Move a down token 2” closer to an objective

Deck of cards

Triggers

Can charge

Has attackable target

Is injured

In range of objective

Has friendly in range

Within X of board edge

In cover of closest enemy

No targets

Has engage order

List of actions. Do from top to bottom. Extra ap spent on default action.

Modifiers.

Closest

Has targetable Enemy:

Engage + Move to cover + attack closest

Engage + attack closest

Else

Conceal + Move to cover

Is injured:

Engage + move to be in cover of most enemies + attack weakest

Prioritize

If there is a target you can attack this turn

- Mark the closest enemy you can attack this turn.

Move toward

Sneak attack

If you have skulk and can attack, then do so the

First try

Proc-points

Turn start -

- Priority targets laid out

- feedback given to players that they can act on

- Enemy activation order visible. Enemies can have multiple counts

Activation

- Activate lowest number

- Determine behavior type

- Calculate behaviour outcome

Tyranid turn start events

Gang Up

If two tyranid models are within 6” of each other and are also within charge range of a single enemy target, place a number of order tokens equal to the number of models in this group (the lowest tokens first) in a stack next to them. Place a primary target token on the enemy within charge range. Otherwise, place the primary target token on the unit closest to a tyranid unit.

Cower

Of tyranid units with an engage order, if any are injured, place the lowest order number on the unit which has taken the most damage. Otherwise place it on the unit with Engage that can see the most enemy units.

Wait

Of tyranid units with an engage order, choose the one closest to an enemy unit and the one furthest from the enemy unit. Place a stack of highest and lowest order numbers on those units. Place the primary target token on the enemy unit furthest from any tyranid unit.

Behaviors

Primary target can be attacked

- Engage

- Attack

Unit is injured

- (Engage) Assist friendly in melee

- (Engage) Move to cover closer to a friendly + Shoot

- (Conceal) Move to cover closer to a friendly

- (Conceal) Move to position seen by least enemies that have not activated.

Otherwise
