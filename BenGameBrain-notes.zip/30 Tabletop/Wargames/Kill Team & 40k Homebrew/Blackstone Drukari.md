---
title: "Blackstone Drukari"
source: "Game Stuff/Game Ideas/Blackstone Drukari"
modified: 2025-03-04
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Blackstone Fortress homebrew"]
words: 120
summary: "Homebrew rules for Drukari (Dark Eldar) Wytches, Troopers and Space Marine in Blackstone Fortress, including Pain tokens and weapon effects."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/homebrew-rules"]
---

Blackstone Drukari

Wytches

Lasher with blast pistol - moves heroes out of position and increases movement cost

Shard net and spear - removed action die

Splinter pistol and cc weapon

Troopers

Shredder - hit every target in space

Dark lance - ignore cover

Splinter cannon

Splinter rifle - hit every target in hex

Splinter weapons - do not deal wounds or grievous wounds. Instead they add Pain tokens to activation slots, but do not block activation die

Pain Token: Each token increases the minimum die needed for the Move Action. Pain tokens can be removed by making a Move action and not moving.

Space Marine

Always counts as in cover

Other heroes cannot benefit from cover in the same hex
