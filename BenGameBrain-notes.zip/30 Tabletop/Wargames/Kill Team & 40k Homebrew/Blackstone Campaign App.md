---
title: "Blackstone Campaign App"
source: "Game Stuff/Game Ideas/Blackstone Campaign App"
modified: 2023-11-20
type: idea
area: wargame
status: "idea"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Blackstone Fortress homebrew"]
words: 17
summary: "One-line idea: create an app that adds value to something people own but no longer use (Blackstone Fortress)."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/idea"]
---

Concept

Create an app that adds value to something that people already own but no longer use.
