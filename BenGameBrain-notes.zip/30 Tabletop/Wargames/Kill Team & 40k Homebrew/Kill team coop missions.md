---
title: "Kill team coop missions"
source: "Game Stuff/Kill team coop missions"
modified: 2026-10-31
type: homebrew-rules
area: wargame
status: "idea"
projects: ["[[Kill Team & 40k Homebrew]]", "[[Other Wargames]]"]
concepts: ["Kill Team homebrew", "Kill Team Coop Missions", "Grim Squad"]
words: 445
summary: "List of coop mission ideas for Kill Team: card-driven scanning, exfil points, shared command points, boss behaviours, enemy tokens and shoot action limits."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "project/other-wargames", "type/homebrew-rules"]
---

Enemies start set up all over board but are not activated. Then are activated one by one, and one extra when one is killed.

4 locations, 3 cards. Draw a random one per location when scanned.

Extra card to draw if you scan a location when the deck is empty.

Two cards need to be found to exit mission.

Friendly models swap with an enemy whenever an enemy is killed.

Defend 6 points but enemy is severe enough you need to sacrifice strategically. Spend them to give yourself buffs.

Last mission, one card explains what is behind each of three other cards Bomb, Trap or Lock.

Each of those cards say “if you have the solution to this card goto X otherwise draw another card. If you already drew another card, you fail”

In the previous missions, give cards that explain they are a key for one of the things, but in a narrative way.

Each turn you distribute dice to your figures. Increasing amounts of dice. End of the turn, roll them and the result causes damage. Putting them on the protag gives different results. Large amounts of damage give a bonus as well.

You can only make 4 shoot actions per turn. Further shoot actions cause a roll that causes negative effects (more enemies, paths get blocked, exits get closed)

Three exits on the board. Spending an action in command range reveals the type of exit. Types are: 1 model can exit here, 3 models can exit here, all models can exit here. Models can only exit on turn 4.

Exfil occurs at a random point out of three. Which one is only discovered at the start of the third turn. Start in the centre. Couple with various other objectives. Start of turn 2 a group of enemies spawn at one of the points.

Each team only gets one of each ploy and one piece of equipment. Command points are shared and only one is generated per turn.

Approach point on board. Each model that reaches it is assigned another point they must reach.

Enemy models which are targeted get a token, even if not hit. Start of turn, models which have no token get a huge buff.

When an enemy is removed, place a token. The token can be destroyed with a mission action. Enemy counter actions can be used to resurrect and act with a token.

Enemies on platforms cannot be fired upon by enemies on the ground.

Enemy boss places a semi circular shield in the direction of the biggest hit this turn.

Enemy boss only suffers the largest damage source inflicted this turn.

Enemy boss acts after every activation
