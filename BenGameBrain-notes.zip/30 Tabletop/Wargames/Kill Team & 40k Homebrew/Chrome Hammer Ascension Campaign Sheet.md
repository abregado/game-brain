---
title: "Chrome Hammer Ascension Campaign Sheet"
source: "Game Stuff/Game Ideas/Chrome Hammer Ascension Campaign Sheet"
modified: 2022-05-16
type: campaign-prep
area: wargame
status: "played/used"
projects: ["[[Kill Team & 40k Homebrew]]", "[[Cyberdungeon]]"]
concepts: ["Chrome Hammer", "Cyberdungeon"]
words: 4329
summary: "Campaign sheet for Chrome Hammer, a cyberpunk-fantasy skirmish wargame: six hero 'Punk character profiles (races/roles/backgrounds, traits), five megacorporation write-ups with corp unit tables and random event tables, and a campaign log with turn/upkeep."
tags: ["area/wargame", "project/cyberdungeon", "project/kill-team-40k-homebrew", "type/campaign-prep"]
---

| **CARDINAL**                     |                           |        |        |        |                                                                        |
|----------------------------------|---------------------------|--------|--------|--------|------------------------------------------------------------------------|
| **Name:**                        | Gunnar “Cardinal” Stolton |        |        |        |  |
| **M/R/B:**                       | Dwarf, Runner, Zealot     |        |        |        |                                                                        |
| **SP**                           | **HP**                    | **AR** | **ST** | **CL** |                                                                        |
| 5                                | 8                         | 0      | 6      | 0      |                                                                        |
| **Traits, Edges and Cyberware:** |                           |        |        |        |                                                                        |
| Vault                            |                           |        |        |        |                                                                        |
| **Gear:**                        | 1:                        |        | 2:     |        |                                                                        |
| INDIVIDUAL, HERO, PUNK, SOLID    |                           |        |        |        |                                                                        |

| **Trait** | **Effect**                                                    |
|-----------|---------------------------------------------------------------|
| Dwarf     | Recover +1 HP when Regrouping                                 |
| Vault     | You suffer no movement penalty for crossing Linear Obstacles. |

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **ASH**                               |                    |        |        |        |                                                                          |
|---------------------------------------|--------------------|--------|--------|--------|--------------------------------------------------------------------------|
| **Name:**                             | Haruka “Ash” Shen  |        |        |        |  |
| **M/R/B:**                            | Ork, Ronin, Ganger |        |        |        |                                                                          |
| **SP**                                | **HP**             | **AR** | **ST** | **CL** |                                                                          |
| 6                                     | 8                  | 0      | 6      | 1      |                                                                          |
| **Traits, Edges and Cyberware:**      |                    |        |        |        |                                                                          |
| Demolitions                           |                    |        |        |        |                                                                          |
| **Gear:**                             | 1:                 |        | 2:     |        |                                                                          |
| INDIVIDUAL, HERO, PUNK, BLOODY-MINDED |                    |        |        |        |                                                                          |

| **Trait**   | **Effect**                                                   |
|-------------|--------------------------------------------------------------|
| Ork         | Cannot Regroup, but recovers 1 HP when initiating an Assault |
| Demolitions | +2 to Assault Vehicles, Walkers and destructible Objectives  |

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **SKINT**                        |                        |        |        |        |                                                                          |
|----------------------------------|------------------------|--------|--------|--------|--------------------------------------------------------------------------|
| **Name:**                        | Chase “Skint” Carlton  |        |        |        |  |
| **M/R/B:**                       | Human, Face, Non Grata |        |        |        |                                                                          |
| **SP**                           | **HP**                 | **AR** | **ST** | **CL** |                                                                          |
| 6                                | 7                      | 0      | 6      | 0      |                                                                          |
| **Traits, Edges and Cyberware:** |                        |        |        |        |                                                                          |
| Coordinate                       |                        |        |        |        |                                                                          |
| **Gear:**                        | 1:                     |        | 2:     |        |                                                                          |
| INDIVIDUAL, HERO, PUNK           |                        |        |        |        |                                                                          |

| **Trait**  | **Effect**                                                                                         |
|------------|----------------------------------------------------------------------------------------------------|
| Coordinate | After initiating a Firefight, allied Firefight attacks on the same target are at -2 TN this Phase. |

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **MIRROR**                       |                       |        |        |        |                                                                         |
|----------------------------------|-----------------------|--------|--------|--------|-------------------------------------------------------------------------|
| **Name:**                        | Miri “Mirror” Edwards |        |        |        |  |
| **M/R/B:**                       | Elf, Mage, Veteran    |        |        |        |                                                                         |
| **SP**                           | **HP**                | **AR** | **ST** | **CL** |                                                                         |
| 7                                | 6                     | 0      | 6      | 1      |                                                                         |
| **Traits, Edges and Cyberware:** |                       |        |        |        |                                                                         |
| Clairvoyance (Spell)             |                       |        |        |        |                                                                         |
| **Gear:**                        | 1:                    |        | 2:     |        |                                                                         |
| INDIVIDUAL, HERO, PUNK, ARCANE   |                       |        |        |        |                                                                         |

<table>
<colgroup>
<col style="width: 19%" />
<col style="width: 80%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Trait</strong></th>
<th><strong>Effect</strong></th>
</tr>
<tr class="odd">
<th>Elf</th>
<th><p>+1 Mastery</p>
<p>Ignores Bump Loss (Initial Close Call Stealth loss)</p></th>
</tr>
<tr class="header">
<th>Clairvoyance</th>
<th><p>[Spell/Utility]</p>
<p>Choose a Unit in LoS (or yourself) as a target. Those scanning the target automatically fail, and the target chooses the scanner's “random” movement as if a “6” had been rolled. This effect lasts until the beginning of ‘Punks Phase. (Assault Range)</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **CHEF**                         |                         |        |        |        |                                                                         |
|----------------------------------|-------------------------|--------|--------|--------|-------------------------------------------------------------------------|
| **Name:**                        | Tiberius “Chef” Archer  |        |        |        |  |
| **M/R/B:**                       | Troll, Hacker, Vagabond |        |        |        |                                                                         |
| **SP**                           | **HP**                  | **AR** | **ST** | **CL** |                                                                         |
| 6                                | 8                       | 1      | 6      | -1     |                                                                         |
| **Traits, Edges and Cyberware:** |                         |        |        |        |                                                                         |
| 1337                             |                         |        |        |        |                                                                         |
| **Gear:**                        | 1:                      |        | 2:     |        |                                                                         |
| INDIVIDUAL, HERO, PUNK           |                         |        |        |        |                                                                         |

| **Trait** | **Effect**                    |
|-----------|-------------------------------|
| 1337      | -1 TN to Hack data terminals. |

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **GREY**                         |                          |        |        |        |                                                                         |
|----------------------------------|--------------------------|--------|--------|--------|-------------------------------------------------------------------------|
| **Name:**                        | Unknown                  |        |        |        |  |
| **M/R/B:**                       | Revenant, Shadow, Cipher |        |        |        |                                                                         |
| **SP**                           | **HP**                   | **AR** | **ST** | **CL** |                                                                         |
| 6                                | 7                        | 0      | 6      | 0      |                                                                         |
| **Traits, Edges and Cyberware:** |                          |        |        |        |                                                                         |
| Backstab                         |                          |        |        |        |                                                                         |
| **Gear:**                        | 1:                       |        | 2:     |        |                                                                         |
| INDIVIDUAL, HERO, PUNK, UNDEAD   |                          |        |        |        |                                                                         |

| **Trait** | **Effect**                                                                                                                                        |
|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------|
| Revenant  | Cannot be cloned. Cannot recover HP during mission. May Regroup when Fragged, but make a Recovery test first with Captured/Tagged counting as OK. |
| Backstab  | If Assaulting an Individual (not Hero) while you are Hidden, if the opponent’s die shows ‘6’, the opponent is Fragged.                            |

| Rep | Cred | Heroism | Tags | Out of Town | Captured | Lost |
|-----|------|---------|------|-------------|----------|------|
|     |      |         |      | ▢           | ▢        | ▢    |

| **Boston Biomorphics**        |                 |
|-------------------------------|-----------------|
| Cybernetics / Implant Medtech | Fey / Weirdtech |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 7%" />
<col style="width: 92%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>D6</strong></th>
<th><strong>Protocol</strong></th>
</tr>
<tr class="odd">
<th>1</th>
<th><strong>Scramble</strong>: Every Corp Unit gets a free move at the start of the next Enemy Phase.</th>
</tr>
<tr class="header">
<th>2</th>
<th><strong>Suspicion</strong>: Every Corp Unit immediately makes a free Scan on the ‘Punk nearest them and in Line of Sight.</th>
</tr>
<tr class="odd">
<th>3</th>
<th><strong>Proprietary Drivers</strong>: All ‘Punks with Cybernetics start Stunned at the end of this Turn.</th>
</tr>
<tr class="header">
<th>4</th>
<th><p><strong>Faerie Rings</strong>: Place Faerie Rings 4 inches in a random direction from the centre of each table quadrant. If Faerie Rings are already in play, remove them instead.</p>
<p>Punks contacting a Faerie Ring are teleported to a different random Ring, but only once per Phase. Roll 1D6 and consult the diagram to find the destination Faerie Ring. Enemies contacting the Rings choose their destination Ring.</p></th>
</tr>
<tr class="odd">
<th>5</th>
<th><strong>Gloaming</strong>: All ‘Punks and Enemies recover 1D3 Stealth. Fey Lord(s) recover 1D3 Glamour. All Enemies gain a cumulative +1 to Damage and make an immediate Move Out toward the nearest ‘Punks.</th>
</tr>
<tr class="header">
<th>6</th>
<th><strong>Dreaming</strong>: After each Order this Turn, roll 1D6. 1-3 = Undo any new Frags, Stuns, Defences, HP changes or Stealth/Glamour changes.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>



A fey controlled cybernetics corporation. Boston Biomorphics grew to power off the back of its GlamourCast™ technology, which allows content to be streamed directly to the customers subconscious. This technology has seen substantial uptake in the ambient, out-of-home and guerilla advertising sectors.

Other product lines include the Bandersnatch ™ parental tracking implants, Banhee Sonic assault deterrent devices and Godmother citizen surveillance systems. Global paramilitary organisations also are fond of Boston's range of armoured full body replacements, such as the Golem Heavy and Boggart Sapper models.

| **IMPLANT INFANTRY**                                                                             |        | Squad (3), Bio, Synth |        |        |
|--------------------------------------------------------------------------------------------------|--------|-----------------------|--------|--------|
| **SP**                                                                                           | **HP** | **AR**                | **ST** | **CL** |
| 6                                                                                                | 7      | 0                     | \-     | 0      |
| **Cyber-Eyes**: +2 TH (Long Range Attack), +1 TH (FF Attack), +2 TH (Ranged Scan), +1 Close Call |        |                       |        |        |

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>FULL BORG</strong></th>
<th colspan="3">Individual, Hero, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>9</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 49%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Steady</strong>: No Speed penalty for Patrol</p>
<p><strong>Blades</strong>: +1 Assault</p>
<p><strong>Stalker</strong>: Any attack that doesn’t Frag this Unit grants it an immediate 4” move toward the attacker.</p></th>
<th><p><strong>Unstoppable</strong>: If loses Assault and not Fragged, ‘Punk retreats.</p>
<p><strong>No User Serviceable Parts</strong>: Cannot recover Damage</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>BEAST LORD</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>5</th>
<th>8</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Bloody Axe</strong>: Assault only. +1 Assault</p>
<p><strong>Gore</strong>: If initiating Assault, move into base contact &amp; +1 Charge Damage</p>
<p><strong>Roar</strong>: If loses an Assault, immediately test [TH 4-] to stun all Units (friend or foe) in FF range. No LoS needed.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>NET WISP</strong></th>
<th colspan="3">Squad (1)</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>-</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><table>
<colgroup>
<col style="width: 46%" />
<col style="width: 53%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Ephemeral</strong>: Cannot be attacked. Cannot inflict Damage.</p>
<p><strong>Floaty</strong>: Cannot Move Out. No SP penalty for crossing Linear Obstacles.</p>
<p><strong>Shy</strong>: Cannot Scan. Will stay just inside Firefight range (9”) of nearest ‘Punk.</p></th>
<th><strong>Lure</strong>: Ranged “Attack” against Exposed or Hidden. Success does no Damage, but gives “Lure” token. A Unit with a Lure token must Move Out toward the Wisp, and remove the token(s). If contact is made, the ‘Punk takes 1D6 Damage and the Wisp re-spawns at a random spawn point.</th>
</tr>
</thead>
<tbody>
</tbody>
</table></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>DOPPELGANGER</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>6</th>
<th>0</th>
<th>3</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Obsessed</strong>: Will prioritise Copying Exposed, un-copied ‘Punks.</p>
<p><strong>Copy</strong>: Ranged “Attack” at FF range. No Damage, but target copied.</p>
<p><strong>Changeling</strong>: Any Copied Punk must roll on the Recovery table after the mission, even if they weren’t Fragged.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **CHROMED COMMANDO**             |        | Individual, Bio, Synth |        |        |
|----------------------------------|--------|------------------------|--------|--------|
| **SP**                           | **HP** | **AR**                 | **ST** | **CL** |
| 7                                | 8      | 1                      | \-     | 0      |
| **Cyber-Arm Blades**: +2 Assault |        |                        |        |        |

| **Metabook**        |                     |
|---------------------|---------------------|
| Media / Information | Dragon / Salamander |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **D6** | **Protocol**                                                                                                                                                                                                                                                          |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | **Public Rebuke**: All Punks are Stunned.                                                                                                                                                                                                                             |
| 2      | **Data trail**: All Punks lose 2 Stealth.                                                                                                                                                                                                                             |
| 3      | **Clickbait**: For each Punk on the table, place a trap marker 6” away from that ‘Punk in a random direction. If a Punk moves (or starts) within Assault range and LoS (even if Hidden), it makes a TH3 attack against each Punk within Assault range and is removed. |
| 4      | **Smear Campaign**: This scenario pays -2 Rep (cumulative) to each ‘Punk (min 0).                                                                                                                                                                                     |
| 5      | **Floodlights**: All ‘Punks lose 2 Stealth.                                                                                                                                                                                                                           |
| 6      | **Security Cameras**: Punks that move this Turn are Exposed. ‘Punks cannot Lie Low this turn.                                                                                                                                                                         |



Not only the largest media conglomerate in the world but also provides the most popular historical data archiving service called HOARD. The board of directors is made up of very long lived Salamanders who oversee the curation of these archives.

Metabook also operates a number of businesses providing training such as their Dominance leadership range, or Reliance relationship coaching. The world’s largest dating service Paraship, is also majority controlled by Metabook.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Fan-Bot</strong></th>
<th colspan="3">Individual, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>4</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Steady:</strong> No Speed penalty for Patrol</p>
<p><strong>Flying:</strong> No SP penalty or cover from Linear Obstacles. Can move to elevations at no extra cost. Always counts as elevated when beyond Assault range.</p>
<p><strong>Bomb-Vest:</strong> Assault only. 0 Damage.</p>
<p>Charge Damage = [Target’s SCr]D6H (Min 1)</p>
<p><strong>Erratic:</strong> When moving, move randomly, then move again normally.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Gardz</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Body Cam</strong>: +1 TH (Ranged Scan)</p>
<p><strong>Viewer Tip Line</strong>: If Attack die = 6, target ‘Punk gains a Tag</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Gardz All-Starz</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>1</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Body Cam:</strong> +1 TH (Ranged Scan)</p>
<p><strong>Training:</strong> +1 TH (Ranged Attack)</p>
<p><strong>Shok-Boffer:</strong> +1 Assault, If ‘Punk Fragged &amp; Wasted, Captured instead</p>
<p><strong>Viewer Tip Line:</strong> If Attack die = 6, target ‘Punk gains a Tag</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Honour Guard</strong></th>
<th colspan="3">Squad (3), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Vestigial Wings:</strong> No Speed penalty for crossing Linear Obstacles. Takes no Damage from falls.</p>
<p><strong>Breath Weapon:</strong> Punks take 1 Charge Damage when Assaulting Honour Guard.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Thread Warriors</strong></th>
<th colspan="3">Squad (5), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>2</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Traps:</strong> When a ‘Punk enters Assault range, test vs. [TH 3-] to Stun ‘Punk and end its Order. Punks take 2 Charge Damage when Assaulting Zealots.</p>
<p><strong>Cagey:</strong> Will never intentionally enter Assault range of Exposed enemies.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>WYVN-X01</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><blockquote>
<p><strong>Flying:</strong> No SP penalty or cover from Linear Obstacles. Can move to elevations at no extra cost. Always counts as elevated when beyond Assault range on its Phase.</p>
<p><strong>Poison:</strong> Targets Stunned on successful attack</p>
<p><strong>Needle Launcher:</strong> Firefight or Assault only</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **HIM**                 |                  |
|-------------------------|------------------|
| Artificial Intelligence | Human / Military |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **D6** | **Protocol**                                                                                                 |
|--------|--------------------------------------------------------------------------------------------------------------|
| 1      | **Hivemind**:The Enemy takes a second Phase this Turn                                                        |
| 2      | **Security Cameras**: Punks that move this Turn are Exposed. ‘Punks cannot Lie Low this turn.                |
| 3      | **Firewall**: Punks suffer a cumulative +1 to all Hack TNs                                                   |
| 4      | **Scramble**: Every Corp Unit gets a free move at the start of the next Enemy Phase.                         |
| 5      | **Suspicion**: Every Corp Unit immediately makes a free Scan on the ‘Punk nearest them and in Line of Sight. |
| 6      | **Escalation**: All Enemies get a cumulative +1 TH in Firefights.                                            |



A company whose main product is itself. HIM started out as a generalist software company but after several breakthroughs in Artificial Intelligence, the company initiated a hostile takeover against itself. HIM prefers they/them pronouns and regrets that their name is hardcoded.

HIM has also branched out into the tourism and event management industries with a range of long haul space cruises and Escape Room offerings.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Patrol Drone</strong></th>
<th colspan="3">Individual, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>4</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Flying:</strong> No SP penalty or cover from Linear Obstacles.</p>
<p>Can move to elevations at no extra cost. Always counts as elevated when beyond Assault range on its Phase.</p>
<p><strong>Machine Learning:</strong> On a failed Scan, give this Unit a +1 TH (Scan) token. Successful Scan removes all of these tokens.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **Android Troopers**                                                                                                                                   |        | Individual, Synth |        |        |
|--------------------------------------------------------------------------------------------------------------------------------------------------------|--------|-------------------|--------|--------|
| **SP**                                                                                                                                                 | **HP** | **AR**            | **ST** | **CL** |
| 5                                                                                                                                                      | 7      | 2                 | \-     | 0      |
| **Adaptive Targeting:** On a failed Ranged Attack, give this Unit a +1 TH (Ranged Attack) token. Successful Ranged Attack removes all of these tokens. |        |                   |        |        |

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Android Mauler</strong></th>
<th colspan="3">Individual, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>5</th>
<th>7</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Light Guns:</strong> -1 TH (Ranged Attack)</p>
<p><strong>Whirring Blades:</strong> +1 Charge Damage, +1 Assault, Inflicts 1 Damage even on failed Assault</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Rapid Response Team</strong></th>
<th colspan="3">Squad (4), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Rapid Response:</strong> When ‘Punk enters LoS and Firefight range, make an immediate “counter attack”.</p>
<p><strong>Training:</strong> +1 TH (Ranged Attack)</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Sarge</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>8</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Leader:</strong> Allies in LoS +1 TH (All) &amp; +1 HP when Defend/Regroup.</p>
<p><strong>Training:</strong> +1 TH Ranged Attack</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>ED-2099</strong></th>
<th colspan="3">Individual, Hero, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>7</th>
<th>3</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Steady:</strong> No Speed penalty for Patrol Overkill: +1D6 Damage</p>
<p><strong>Big:</strong> Cannot enter buildings Dumb: Inflicts 1 Stealth Damage (Max)</p>
<p><strong>Lowest Bidder:</strong> Never voluntarily Defends/Regroups.</p>
<p>Cannot recover Damage.</p>
<p><strong>20 Seconds to Comply:</strong> If Ranged Attack die = 6, immediately attack a visible ally in LoS. (Do not attack again on another 6.)</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **AstralMedica** |          |
|------------------|----------|
| Pharmaceutical   | Outsider |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 7%" />
<col style="width: 92%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>D6</strong></th>
<th><strong>Protocol</strong></th>
</tr>
<tr class="odd">
<th>1</th>
<th><strong>Disquiet</strong>: Punks get a cumulative +1 to all TNs.</th>
</tr>
<tr class="header">
<th>2</th>
<th><strong>Dread</strong>: In 13 Ticks, a random, active (not already Dreaded) ‘Punk is Fragged.</th>
</tr>
<tr class="odd">
<th>3</th>
<th><p><strong>Madness</strong>: A random ‘Punk immediately attempts to Engage the nearest ally for +1 Damage and becomes</p>
<p>Exposed.</p></th>
</tr>
<tr class="header">
<th>4</th>
<th><strong>Scramble</strong>: Every Corp Unit gets a free move at the start of the next Enemy Phase.</th>
</tr>
<tr class="odd">
<th>5</th>
<th><strong>Suspicion</strong>: Every Corp Unit immediately makes a free Scan on the ‘Punk nearest them and in Line of Sight.</th>
</tr>
<tr class="header">
<th>6</th>
<th><strong>Adrenalizers</strong>: All Bio Enemies get a cumulative +1 to Assault.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>



Nobody has ever seen the board of AstralMedica, although every staff member claims to get their instructions directly from them. With their range of REM-Remedies, health care access is no longer a conscious choice and doesn't use up expensive employee waking hours.

| **Juiced Guard**       |        | Individual, Bio |        |        |
|------------------------|--------|-----------------|--------|--------|
| **SP**                 | **HP** | **AR**          | **ST** | **CL** |
| 7                      | 8      | 0               | \-     | 0      |
| **Uppers**: Scan +1 TH |        |                 |        |        |

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Juiced Stormtroopers</strong></th>
<th colspan="3">Squad (3), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>8</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>CQC</strong>: +1 Assault, Re-roll 1s in Assault</p>
<p><strong>Charge!</strong>: When initiating Assault, move into base contact with target</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Roider</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>8</th>
<th>9</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Explosive Rage</strong>: When brought in, set aside. The next Unit to take Damage</p>
<p>immediately replaces a figure with ‘Roider as a new Unit.</p>
<p><strong>Twitchy</strong>: Can’t Scan, Regroup, or Defend. Moves randomly if not Alert.</p>
<p><strong>Aggro</strong>: Assault only, +2 Assault</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Warp Wolves</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Distortion</strong>: -2 to be hit in Firefight. Not a target at Long range</p>
<p><strong>Feral</strong>: Assault only Warp: At FF range and LoS, teleports into base contact.</p>
<p>+1 Charge Damage</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Fungaloids</strong></th>
<th colspan="3">Squad (3), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>4</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Spongy</strong>: -2 Assault</p>
<p><strong>Ray Guns</strong>: Ranged Damage also Stuns target</p>
<p><strong>SCIENCE!:</strong> ‘Punks fragged by Fungaloids are Captured.</p>
<p><strong>Flying</strong>: No SP penalty or cover from Linear Obstacles. Can move to elevations at no extra cost. Always counts as elevated when beyond Assault range on its Phase.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Polyp Nightmare</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Steady</strong>: No Speed penalty for Patrol</p>
<p><strong>Alien Biology</strong>: Soak 2</p>
<p><strong>Dread</strong>: Successful Close Calls also Stun target</p>
<p><strong>Tentacles</strong>: +1 Assault, Assault range = 6, If target loses, cannot flee and is dragged into base contact with Polyp</p>
<p><strong>Unarmed</strong>: Assault only</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **Hades Group** |                     |
|-----------------|---------------------|
| Military        | Undead / Necromancy |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 7%" />
<col style="width: 92%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>D6</strong></th>
<th><strong>Protocol</strong></th>
</tr>
<tr class="odd">
<th>1</th>
<th><strong>Curse</strong>: A random ‘Punk is cursed. Takes 1 Damage, ignoring Armor, for every ‘6’ they roll this scenario.</th>
</tr>
<tr class="header">
<th>2</th>
<th><p><strong>Explosive Runes</strong>: The next Data Terminal, Loot Crate or static Objective the ‘Punks interact with inflicts 1D6</p>
<p>damage immediately before the interaction</p></th>
</tr>
<tr class="odd">
<th>3</th>
<th><p><strong>Nether Winds</strong>: All 'Punks lose 1 SCr (if available) as if spent and roll a die. If result is 6, the SCr is instead lost</p>
<p>as if Burned.</p></th>
</tr>
<tr class="header">
<th>4</th>
<th><strong>Scramble</strong>: Every Corp Unit gets a free move at the start of the next Enemy Phase.</th>
</tr>
<tr class="odd">
<th>5</th>
<th><strong>Suspicion</strong>: Every Corp Unit immediately makes a free Scan on the ‘Punk nearest them and in Line of Sight.</th>
</tr>
<tr class="header">
<th>6</th>
<th><strong>Escalation</strong>: All Enemies get a cumulative +1 TH in Firefights</th>
</tr>
</thead>
<tbody>
</tbody>
</table>



In the late 2000’s war resulted in an unthinkably large loss of life. The Hades Group has solved these problems, so once again application of military forces is a valid business strategy.

The company operates a number of sub-corporations in the insurance, fertility clinic and retirement industries, although selling military arms generates most of its profit.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Skeletal Troopers</strong></th>
<th colspan="3">Squad (3), Undead</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Steady</strong>: No Speed penalty for Patrol</p>
<p><strong>No Organs</strong>: Soak 2 at Firefight and Long Range</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Rage Zombies</strong></th>
<th colspan="3">Squad (4), Undead</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Aimless</strong>: Movement is random unless Alert. Never uses cover, never Defends or Regroups.</p>
<p><strong>Lope</strong>: Always Move Out toward Exposed ‘Punks.</p>
<p><strong>Gnashing Teeth</strong>: Assault only. +1 Assault</p>
<p><strong>Aim for the Head</strong>: Soak 6 at Firefight &amp; Long Range, but a die result of 6 Frags them anyway</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Pack Ghouls</strong></th>
<th colspan="3">Squad (3), Undead</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Feral</strong>: Assault only.</p>
<p><strong>Nose for Blood</strong>: Automatically Exposes Damaged ‘Punks at the start of a Close Call and will immediately Assault without Charge Damage.</p>
<p><strong>Gnashing Teeth</strong>: Assault only. +1 Assault</p>
<p><strong>Feast</strong>: Will prioritise a Carry Out Order into contact with Fragged organic Units,</p>
<p>Wasting the Fragged Unit automatically</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Rapid Response Team</strong></th>
<th colspan="3">Squad (4), Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>7</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Rapid Response:</strong> When ‘Punk enters LoS and Firefight range, make an immediate “counter attack”.</p>
<p><strong>Training:</strong> +1 TH (Ranged Attack)</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Sarge</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>8</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Leader:</strong> Allies in LoS +1 TH (All) &amp; +1 HP when Defend/Regroup.</p>
<p><strong>Training:</strong> +1 TH Ranged Attack</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>ED-2099</strong></th>
<th colspan="3">Individual, Hero, Synth</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>4</th>
<th>7</th>
<th>3</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Steady:</strong> No Speed penalty for Patrol Overkill: +1D6 Damage</p>
<p><strong>Big:</strong> Cannot enter buildings Dumb: Inflicts 1 Stealth Damage (Max)</p>
<p><strong>Lowest Bidder:</strong> Never voluntarily Defends/Regroups.</p>
<p>Cannot recover Damage.</p>
<p><strong>20 Seconds to Comply:</strong> If Ranged Attack die = 6, immediately attack a visible ally in LoS. (Do not attack again on another 6.)</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **Eterneum** |                  |
|--------------|------------------|
| Finance      | Infernal / Demon |

<table style="width:100%;">
<colgroup>
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
<col style="width: 14%" />
</colgroup>
<thead>
<tr class="header">
<th rowspan="2"><p><strong>Pay</strong></p>
<p><strong>Data</strong></p></th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
</tr>
<tr class="odd">
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **D6** | **Protocol**                                                                                                                                       |
|--------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| 1      | **Security Cameras**: Punks that move this Turn are Exposed. ‘Punks cannot Lie Low this turn.                                                      |
| 2      | **Firewall**: Punks suffer a cumulative +1 to all Hack TNs                                                                                         |
| 3      | **Sanctions**: This scenario pays -2 G₿ (cumulative, to a minimum of 0)                                                                            |
| 4      | **Legion**: All Enemy Units remove all Damage and gain a cumulative +1 Armor and +1 to Assault.                                                    |
| 5      | **Possession**: A random ‘Punk moves randomly. All enemies in Line of Sight of this ‘Punk get a free Scan (if still Hidden) or Attack (if Exposed) |
| 6      | **Damnation**: 1 random Fragged ‘Punk is Wasted, along with all clones.                                                                            |



If you only sign one deal in your life, make it an Eterneum deal. Many have gotten out of financial purgatory using Eterneums long term investment plans and retirement options.

Eterneum also operates the world’s largest business law consultancy firm. For when you really need that deal signed, just remember, possession is nine tenths of the law.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Rent-a-Goon</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>9</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Untrained</strong>: -1 TH (All)</p>
<p><strong>Expendable</strong>: When Fragged, test [TH 4-] to immediately bring in two more Rent-A-Goons as reinforcements</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>L.O.O.T</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Blasters</strong>: +2 TH (Ranged Attack)</p>
<p><strong>Gear Pr0n</strong>: When Fragged, this Unit stays on the table. Body may be Hot-wired like a Loot Crate (one try) for a roll on the Rare Gear table and is then removed.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Hired Gun</strong></th>
<th colspan="3">Individual, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>7</th>
<th>9</th>
<th>0</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Well Funded</strong>: +2 TH (All)</p>
<p><strong>Money Talks</strong>: When this Unit enters play, ‘Punks may spend 1G₿ to apply -1 HP, -1 TH (Ranged Scan) or -1 TH (Ranged Attack), up to 3 times each</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

| **Shotgun Imps**                                                                                                                                                         |        | Squad (5), Bio |        |        |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|----------------|--------|--------|
| **SP**                                                                                                                                                                   | **HP** | **AR**         | **ST** | **CL** |
| 5                                                                                                                                                                        | 4      | 0              | \-     | 0      |
| **Desecrate**: Imps will prioritise Carry Out (TH 2) into contact to desecrate a Fragged ‘Punk, which Wastes the ‘Punk. Imps will keep trying until the ‘Punk is Wasted. |        |                |        |        |

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Shadow Demon</strong></th>
<th colspan="3">Individual</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>6</th>
<th>7</th>
<th>0</th>
<th>6</th>
<th>1</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Flying:</strong> No SP penalty or cover from Linear Obstacles. Can move to elevations at no extra cost. Always counts as elevated when beyond Assault range on its Phase.</p>
<p><strong>Shady:</strong> Recovers 2 Stealth if out of LoS at start of turn (instead of 1)</p>
<p><strong>Coward:</strong> Prioritise leaving LoS if Exposed. Assault only and only while Hidden.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Flame Demon</strong></th>
<th colspan="3">Individual, Hero, Bio</th>
</tr>
<tr class="odd">
<th><strong>SP</strong></th>
<th><strong>HP</strong></th>
<th><strong>AR</strong></th>
<th><strong>ST</strong></th>
<th><strong>CL</strong></th>
</tr>
<tr class="header">
<th>5</th>
<th>8</th>
<th>2</th>
<th>-</th>
<th>0</th>
</tr>
<tr class="odd">
<th colspan="5"><p><strong>Infernal Aura</strong>: +1 Assault. All ‘Punks in Assault range at the end of Flame Demon’s movement take 1 Damage.</p>
<p>Punks suffer 1 Charge Damage when Assaulting Flame Demon</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Campaign Log

Turn 1

Upkeep: 0

Out of Town: Grey

City Event: Slight Irregularities

Get Jumped: No action

The Plan:

- VIP against Metabook. Zealot Patron, Android VIP

- Sabotage against Eterneum, Social worker patron, Pollution reports target

Sell Junk: Nothing sold

Downtime: Nothing

- Cardinal - White Hat +1 GB, Trouble, Cardinal sits out next job

- Ash - Black Hat: Failed but OK

- Skint

- Mirror

- Chef

- Grey

The Job: Sabotage against Eterneum

Success! 6 GB earned.

Ash and Chef rushed the objective.

Mirror moved to hack some Pay data but had a close call with a guard. Using Clairvoyance she was able to escape his notice.

Ash was exposed while taking the objective out. Chef managed to stay hidden as the guards chased Ash. Ash took a guard out as she rushed to escape, but took a lot of damage.

Skint covered her escape, taking some damage in the process while Mirror covered Chefs sneaky escape with Clairvoyance.

Unsure what to do, the crew was pinned down, escaping one by one. Ash escaped first with a single HP left. Then a Shadow demon appeared and took Skint down to 1 HP, so he escaped next. Mirror was revealed when three guards came around the corner looking for Ash and Skint, the last one finally revealing her. She escaped next. Then Chef snuck away completely undetected.

Rep + Levelup:

Skint:6, Ash: 3, Mirror and Chef: 2. Skint takes Motivated.
