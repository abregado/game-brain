---
title: "Blackstone House rules"
source: "Game Stuff/Game Ideas/Blackstone House rules"
modified: 2025-08-19
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Blackstone Fortress homebrew"]
words: 274
summary: "House rules and mission ideas for Blackstone Fortress: maglev portal, save roll, resource card limits, AI targeting, token mission types, exit types, enemy triggers, character book and specials."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/homebrew-rules"]
---

**Call Maglev Transport:** Roll D12 Action dice, if failed, that portal becomes locked from escape. Last remaining is an automatic success. Hostiles can still appear from here.

**Chaos Space Marine Save Roll:** 17+ on D20 is a Save for Chaos Space Marines.

**Resource Card Restriction:** Only one Resource Card can be utilized per Hero/Hostile Action. (Excludes Passive/Persistent Resources)

**AI Targeting:** If there are more than one non-adjacent valid targets for an AI attack roll (Ranged Attack) any targets which are not in cover will be first priority even if there is a closer Explorer behind cover.

Mission Types

Token game types

Search at all Tokens

Bring back to start: Search at tokens and then return to start. One token per hero.

Connect cables: Search at tokens to discover if they are plug or socket

Wack a Mole: Tokens change every turn. Search them in the right order to complete

Damage tokens: Place damage on each token

Activate multiple on same turn

Wipe out group to spawn token

Time limit get to token

Keep Enemies away from Tokens

Kill enemies near Tokens

Exit types

Exit at Farthest

Exit at Random, decided at start

Exit at Random, decided on goal completion

Exit at Start

Enemy Effects Trigger

When moving adjacent

When spending a dice on search/move/heal

After being attacked

If no heroes in vision

When killed

Character book

Story events per character

Chart with events to cross off

Items come from the book

Character specials

Targeting token. 6+ to place. Rerolls on targets that are adjacent

Inspiration changes between ranged/melee but only costs 1 Inspiration token.

Place token on kill, bonus for being in visual range
