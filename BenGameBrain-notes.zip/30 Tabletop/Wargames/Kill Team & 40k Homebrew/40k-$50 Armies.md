---
title: "40k-$50 Armies"
source: "Game Stuff/Wargaming/40k-$50 Armies"
modified: 2013-06-12
type: reference-data
area: wargame
status: "unknown"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["40k Budget Armies"]
words: 80
summary: "Short list of cheap $40-50 starter armies for 40k (Space Marines, Necrons, Imperial Guard, Tyranids) with prices and points."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/reference-data"]
---

\$40 Warhammer 40k Armies

Space Marines

1x Terminator Captain \$25 300pts

2x Tactical Space Marines \$10 200pts each

1x Assault Marine Sergeant \$5 300pts

1x Devastator Marine \$5 300pts

\$45 1200pts

Necrons

1x Necron Lord \$25 200pts

1x Necron Immortal \$18 300pts

2x Necron Warrior \$10 800pts

\$53 1300pts

Imperial Guard

1x Lietenant \$10

4x Guardsman \$10

1x Kaskrin \$15

1x Heavy Weapons \$22

\$52

Tyranids

1x Warrior \$17 350pts

5x Gaunts \$20 1750pts

2x Genestealers \$10 500pts

\$47 2600pts
