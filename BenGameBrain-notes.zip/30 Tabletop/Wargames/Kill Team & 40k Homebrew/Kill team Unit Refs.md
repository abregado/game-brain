---
title: "Kill team Unit Refs"
source: "Game Stuff/Kill team Unit Refs"
modified: 2026-03-06
type: reference-data
area: wargame
status: "played/used"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Kill Team homebrew"]
words: 2490
summary: "Stat tables for Kill Team operatives, mix of homebrew Technomancer/Tyranid-style and official datacard units (Mechanicus, Tyranids, Intercessors) with APL, move, save, wounds and weapon rules."
contains_external_material: "Includes official Games Workshop datacard stats"
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/reference-data"]
---

|                 | APL | MOVE | SAVE | W   |     |     | WEAPONS        | ATK | HIT | DMG | WR                                              |
|-----------------|-----|------|------|-----|-----|-----|----------------|-----|-----|-----|-------------------------------------------------|
| TECHNOMANCER    | 3   | 6”   | 3+   | 14  |     | R   | Staff of Light | 6   | 3+  | 3/4 | Rending, Magnify                                |
|                 |     |      |      |     |     | M   | Staff of Light | 4   | 4+  | 3/5 | Rending                                         |
| PC ACCELLERATOR | 2   | 7”   | 5+   | 5   |     | R   | Spark          | 4   | 4+  | 2/3 | Range 4”, Piercing 1                            |
|                 |     |      |      |     |     | M   | Claws          | 3   | 5+  | 1/2 |                                                 |
| PC REANIMATOR   | 2   | 7”   | 5+   | 5   |     | R   | Atomiser beam  | 4   | 4+  | 3/4 | Range 6”, Lethal                                |
|                 |     |      |      |     |     | M   | Claws          | 3   | 5+  | 1/2 |                                                 |
| APPRENTEK       | 3   | 6”   | 3+   | 11  |     | R   | Arcane Conduit | 4   | 3+  | 4/5 | Piercing 1, Magnify                             |
|                 |     |      |      |     |     | M   | Arcane Conduit | 3   | 4+  | 3/5 |                                                 |
| DEATHMARK       | 2   | 5”   | 3+   | 10  |     | R   | Disintegrator  | 4   | 2+  | 4/3 | Devastating 2, Heavy (Dash), Piercing 1, Severe |
|                 |     |      |      |     |     | M   | Fists          | 3   | 3+  | 3/4 |                                                 |
| DESPOTEK        | 2   | 5”   | 3+   | 11  |     | R   | Gauss Blaster  | 4   | 3+  | 4/5 | Piercing 1                                      |
| GUARDIAN        | 2   | 5”   | 3+   | 10  |     | R   | Tesla Carbine  | 5   | 3+  | 3/3 | 2: Devastating 1                                |
|                 |     |      |      |     |     | M   | Bayonet        | 4   | 3+  | 3/4 |                                                 |

|                                           | APL | MOVE | SAVE | W   |     |     | WEAPONS                | ATK | HIT | DMG | WR                                         |
|-------------------------------------------|-----|------|------|-----|-----|-----|------------------------|-----|-----|-----|--------------------------------------------|
| ARCHEOLOGIST                              | 3   | 6”   | 3+   | 9   |     | R   | Eradication Pistol     | 4   | 3+  | 4/2 | Range 8”, 1” Devastating 3, Lethal 5+      |
| Seeker of Divine Arcana, OMNISCANNER      |     |      |      |     |     | M   | Servo-arc Claw         | 4   | 4+  | 3/4 | Severe, Shock                              |
|                                           |     |      |      |     |     |     |                        |     |     |     |                                            |
| AUTO-PROXY                                | 2   | 5”   | 4+   | 8   |     | M   | Taser Goad             | 4   | 4+  | 3/4 | Lethal 5+, Shock                           |
| Achillan Eye, GAZE OF THE OMNISSIAH       |     |      |      |     |     |     |                        |     |     |     |                                            |
|                                           |     |      |      |     |     |     |                        |     |     |     |                                            |
| BREACHER                                  | 2   | 5”   | 4+   | 8   |     | R   | Lascutter (Close)      | 4   | 3+  | 4/5 | Range 2”, Lethal 5+, Piercing 2            |
| BREACH                                    |     |      |      |     |     | R   | Lascutter (Short)      | 4   | 3+  | 4/5 | Range 6”, Lethal 5+                        |
|                                           |     |      |      |     |     | M   | Pincer + Cutter        | 4   | 4+  | 4/6 | Lethal 5+                                  |
|                                           |     |      |      |     |     |     |                        |     |     |     |                                            |
| UNDERSEER                                 | 3   | 6”   | 3+   | 9   |     | R   | Radium Pistol          | 4   | 3+  | 2/4 | Range 8”, Balanced, Rending                |
| DATACORONAL ACCUMULATOR, NETWORK OVERRIDE |     |      |      |     |     | M   | Dataspikes             | 3   | 5+  | 2/3 |                                            |
|                                           |     |      |      |     |     |     |                        |     |     |     |                                            |
| TECHNOMEDIC                               | 2   | 5”   | 4+   | 8   |     | M   | Servo-chirugic Claw    | 4   | 4+  | 3/4 | Rending                                    |
| Mechanosuture Array, EXPEDIENT REPAIR     |     |      |      |     |     |     |                        |     |     |     |                                            |
|                                           |     |      |      |     |     |     |                        |     |     |     |                                            |
| COMBAT SERVITOR                           | 2   | 5”   | 4”   | 8   |     | R   | Incendine igniter      | 4   | 2+  | 4/4 | Range 6”, Saturate, Torrent                |
|                                           |     |      |      |     |     | R   | Meltagun               | 4   | 4+  | 6/3 | Range 6”, Devastating 4, Piercing 2        |
|                                           |     |      |      |     |     | R   | Phosphor blaster       | 4   | 4+  | 3/4 | Severe                                     |
|                                           |     |      |      |     |     | M   | Servo-claw             | 3   | 4+  | 3/4 |                                            |
| GUN SERVITOR                              | 2   | 5”   | 4+   | 11  |     | R   | Heavy Arc Rifle        | 5   | 4+  | 4/6 | Heavy (Dash), Piercing 1, Stun             |
|                                           |     |      |      |     |     | R   | Heavy Bolter (focused) | 5   | 4+  | 4/5 | Heavy (Dash), Piercing Crits 1             |
|                                           |     |      |      |     |     | R   | Heavy Bolter (sweep)   | 4   | 4+  | 4/5 | Heavy (Dash), Piercing Crits 1, Torrent 1” |
|                                           |     |      |      |     |     | M   | Augmetic Claw          | 3   | 4+  | 4/5 | Brutal                                     |

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Seeker of Divine Arcana - Strategy Ploy</strong><br />
You can immediately change this operative’s order and/or it can immediately perform a free Omniscanner, Fall Back, Place Marker, Pick Up Marker, Reposition or mission action.</th>
<th><p><strong>OMNISCANNER - 1 AP</strong></p>
<p>Select one enemy operative visible to or within 8" of this operative to gain one of your Omniscanner tokens. Whenever a friendly BATTLECLADE operative is shooting against, fighting against or retaliating against an enemy operative that has one of your Omniscanner tokens, that friendly operative’s weapons have the Ceaseless weapon rule.</p></th>
<th><p><strong>NETWORK OVERRIDE - 1 AP (SUPPORT)</strong></p>
<p>Select one friendly BATTLECLADE SERVITOR operative within 6" of either this operative or a friendly BATTLECLADE AUTO-PROXY operative to immediately NETWORK COUNTERACT (you don’t have to TRANSFER POWER to do so). Continue this operative’s activation after doing so. For the purposes of the Comms Device universal equipment, the operative the distance is being determined from must control that marker.</p></th>
</tr>
<tr class="odd">
<th><p><strong>Achillan Eye</strong>:</p>
<p>Whenever a friendly BATTLECLADE operative is shooting an enemy operative visible to this operative, that friendly operative’s ranged weapons have the Saturate weapon rule. This rule has no effect if this operative is within control range of an enemy operative.</p></th>
<th><p><strong>BREACH - 1 AP</strong></p>
<p>Place one of your Breach markers within this operative’s control range as close as possible to a terrain feature within control range of it. Whenever an operative is within 1" of that marker, it treats parts of that terrain feature that are no more than 1" thick as Accessible terrain.</p></th>
<th><strong>EXPEDIENT REPAIR - 1AP</strong><br />
Select one friendly BATTLECLADE operative within this operative’s control range to regain up to D3+3 lost wounds. It cannot be an operative that the Mechanosuture Array rule was used on during this turning point.</th>
</tr>
<tr class="header">
<th rowspan="3"><p><strong>Mechanosuture Array:</strong></p>
<p>Once per turning point, when another friendly BATTLECLADE operative would be incapacitated while visible to and within 3" of this operative, you can use this rule, providing neither this nor that operative is within control range of an enemy operative. If you do, that friendly operative isn’t incapacitated, has 1 wound remaining and cannot be incapacitated for the remainder of the action. After that action, that friendly operative can immediately perform a free Dash action, but must end that move within this operative’s control range. If this rule was used during that friendly operative’s activation, that activation ends. You cannot use this rule if this operative is incapacitated, or if it’s a Shoot action and this operative would be a primary or secondary target.</p></th>
<th><p><strong>DATACORONAL ACCUMULATOR - 1 AP (SUPPORT)</strong></p>
<p>Determine the friendly BATTLECLADE operatives within 6" of this operative and/or a friendly BATTLECLADE AUTO-PROXY operative, then roll one D3. If the result is equal to or less than the number of objective markers those friendly operatives contest, you gain 1CP. For the purposes of the Comms Device universal equipment, the operative the distance is being determined from must control your Comms Device marker to add 3" to its distance requirement for this rule.</p></th>
<th><p><strong>GAZE OF THE OMNISSIAH - 1 AP</strong></p>
<p>Select one enemy operative visible to this operative. Until the end of the turning point, whenever a friendly BATTLECLADE operative is shooting that enemy operative, you can use this effect. If you do:</p>
<ul>
<li><blockquote>
<p>That friendly operative’s ranged weapons have the Seek Light weapon rule.</p>
</blockquote></li>
<li><blockquote>
<p>That enemy operative cannot be obscured.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="odd">
<th colspan="2" rowspan="2"><p><strong>Noospheric Network - NETWORK COUNTERACT</strong></p>
<p>Once during each friendly BATTLECLADE SERVITOR operative’s activation, before or after it performs an action, you can spend 1AP to TRANSFER POWER.</p>
<p>After that activation, you can NETWORK COUNTERACT with one other friendly BATTLECLADE SERVITOR operative before your opponent activates. Whenever you NETWORK COUNTERACT with a friendly operative, first select its order. It can then perform a 1AP action for free, but cannot move more than 2" during that action. Once it’s done so, your opponent then activates as normal.</p>
<p>An operative cannot TRANSFER POWER or NETWORK COUNTERACT if it has an APL stat of less than 2 (e.g. if the stat has been changed to less than 2 by a rule). NETWORK COUNTERACT is a counteraction, but the operative doesn’t need to be expended with an Engage order to do it. That means if they’re ready when they NETWORK COUNTERACT, they can still be activated as normal later in the turning point. An operative that does NETWORK COUNTERACT cannot do so again, or counteract, during the same turning point.</p></th>
</tr>
<tr class="header">
</tr>
</thead>
<tbody>
</tbody>
</table>

|                                                          | APL | MOVE | SAVE | W   |     |     | WEAPONS                   | ATK | HIT | DMG | WR                         |
|----------------------------------------------------------|-----|------|------|-----|-----|-----|---------------------------|-----|-----|-----|----------------------------|
| Hormagaunt (Brawler)                                     | 2   | 7    | 5+   | 7   |     | M   | Scything talons           | 4   | 3+  | 3/4 |                            |
|                                                          |     |      |      |     |     |     |                           |     |     |     |                            |
| Ripper Swarm (Brawler)                                   | 2   | 6    | 5+   | 10  |     | M   | Claws & teeth             | 5   | 4+  | 1/2 |                            |
| Special: Ignores Vantage                                 |     |      |      |     |     |     |                           |     |     |     |                            |
|                                                          |     |      |      |     |     |     |                           |     |     |     |                            |
| Barbgaunt (Marksman)                                     | 2   | 6    | 4+   | 12  |     | M   | Claws                     | 3   | 4+  | 2/3 |                            |
| Special: Ignores Vantage                                 |     |      |      |     |     | R   | Barblauncher (mobile)     | 5   | 4+  | 3/5 | Blast 2”                   |
|                                                          |     |      |      |     |     | R   | Barblauncher (stationary) | 5   | 4+  | 3/5 | Blast 2”, Ceaseless, Heavy |
|                                                          |     |      |      |     |     |     |                           |     |     |     |                            |
| Termagant (Marksman)                                     | 2   | 6    | 5+   | 7   |     | R   | Fleshborer                | 4   | 4+  | 3/4 |                            |
|                                                          |     |      |      |     |     | M   | Claws                     | 3   | 4+  | 2/3 |                            |
|                                                          |     |      |      |     |     |     |                           |     |     |     |                            |
| Leaper (Brawler)                                         | 3   | 7    | 5+   | 12  |     | M   | Scything talons           | 5   | 3+  | 4/5 |                            |
| Special: Dual Fight                                      |     |      |      |     |     |     |                           |     |     |     |                            |
| Psycophage (Brawler)                                     | 3   | 6    | 3+   | 14  |     | M   | Mouth tendrils            | 5   | 3+  | 4/5 | Ceaseless                  |
| Special: Dual Fight, Ignores Injured, Counts as 2 units. |     |      |      |     |     |     |                           |     |     |     |                            |

|                                   | APL   | MOVE   | SAVE   | W      |     |     | WEAPONS                | ATK   | HIT    | DMG     | WR                                           |
|-----------------------------------|-------|--------|--------|--------|-----|-----|------------------------|-------|--------|---------|----------------------------------------------|
| Intercessor Sergeant              | **3** | **6”** | **3+** | **15** |     | M   | Power weapon           | **5** | **3+** | **4/6** | Lethal 5+                                    |
| Doctrine Warfare, Chapter Veteran |       |        |        |        |     | R   | Stalker rifle (heavy)  | **4** | **3+** | **3/5** | Heavy (Dash only), Lethal 5+, Piercing Crits |
|                                   |       |        |        |        |     | R   | Stalker rifle (mobile) | **4** | **3+** | **3/4** |                                              |
| Intercessor Warrior               | **3** | **6”** | **3+** | **14** |     | M   | Fists                  | **4** | **3+** | **3/4** |                                              |

<table>
<colgroup>
<col style="width: 3%" />
<col style="width: 66%" />
<col style="width: 30%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><strong>Chapter Tactics:</strong> Select one primary and one secondary</th>
<th rowspan="5"><p><strong>Astartes:</strong> During each friendly ANGEL OF DEATH operative’s activation, it can perform either two Shoot actions or two Fight actions. If it’s two Shoot actions, a bolt weapon must be selected for at least one of them, and if it’s a bolt sniper rifle or heavy bolter, 1 additional AP must be spent for the second action if both actions are using that weapon.</p>
<p>Each friendly ANGEL OF DEATH operative can counteract regardless of its order.</p></th>
</tr>
<tr class="odd">
<th></th>
<th><strong>AGGRESSIVE</strong>: This operative’s melee weapons have the Rending weapon rule.</th>
</tr>
<tr class="header">
<th></th>
<th><strong>DUELLER</strong>: Whenever this operative is fighting or retaliating, each of your normal successes can block one unresolved critical success (unless the enemy operative’s weapon has the Brutal weapon rule).</th>
</tr>
<tr class="odd">
<th></th>
<th><strong>RESOLUTE</strong>: You can ignore any changes to this operative’s APL stat. and it isn’t affected by enemy operatives’ Shock weapon rule.</th>
</tr>
<tr class="header">
<th></th>
<th><strong>STEALTHY</strong>: Whenever an operative is shooting this operative, if you can retain any cover saves, you can retain one additional cover save, or you can retain one cover save as a critical success instead. This isn’t cumulative with improved cover saves from Vantage terrain.</th>
</tr>
<tr class="odd">
<th></th>
<th><strong>MOBILE</strong>: This operative can perform the Fall Back action for 1 less AP and can perform the Charge action while within control range of an enemy operative, and can leave that operative’s control range to do so (but then normal requirements for that move apply).</th>
<th><strong>Adaptive Tactics - Strategy Ploy:</strong> Change your secondary Chapter tactic until the end of the turning point.</th>
</tr>
<tr class="header">
<th></th>
<th><strong>HARDY</strong>: Whenever an operative is shooting this operative, defence dice results of 5+ are critical successes. Whenever this operative is retaliating, the first time an attack dice inflicts Normal Dmg of 3 or more on this operative during that sequence, that dice inflicts 1 less damage on it.</th>
<th><strong>Combat Doctrine - Strategy Ploy:</strong> All weapons have Balanced in one of the following situations: Shooting &gt; 6”, Shooting &lt; 6”, Fight or retaliation.</th>
</tr>
<tr class="odd">
<th></th>
<th><strong>SHARPSHOOTER</strong>: Whenever this operative is shooting during an activation in which it hasn’t performed the Charge, Fall Back or Reposition action, its bolt weapons have the Accurate 1 and Severe weapon rules.</th>
<th><strong>Transhuman Physiology - Firefight Ploy:</strong> On a Defense roll, retain a normal success as a critical success.</th>
</tr>
<tr class="header">
<th></th>
<th><strong>SIEGE SPECIALIST</strong>: This operative’s ranged weapons have the Saturate weapon rule. Whenever this operative is fighting or retaliating, enemy operatives cannot assist.</th>
<th><strong>Wrath of Vengeance - Firefight Ploy:</strong> Counteract with two different 1AP actions.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
