---
title: "Blackstone challenges"
source: "Game Stuff/Game Ideas/Blackstone challenges"
modified: 2023-11-12
type: homebrew-rules
area: wargame
status: "designed"
projects: ["[[Kill Team & 40k Homebrew]]"]
concepts: ["Blackstone Fortress homebrew"]
words: 368
summary: "A set of custom challenge cards for Blackstone Fortress expeditions using leader order, agility/defense tests, Archeotech and Encounter cards."
tags: ["area/wargame", "project/kill-team-40k-homebrew", "type/homebrew-rules"]
---

Blackstone challenges

In leader order each player can discard a discovery or equipment card. Then each player rolls a D6 adding the number of discarded items. On a roll of 4+ the player avoids suffering one wound.

In leader order, each player selects one equipment card if they can. Then all players take an Agility test. If all players fail, the equipment cards are unusable for the rest of the expedition.

Same as above but Defense rolls.

Each player in leader order can discard an Archeotech card to make a number of Agility rolls equal to the cards value. If at least one roll is successful, draw a clue card from the Discovery deck.

Same as above with Defense

Each player in leader order can discard an Archeotech card to make a number of Agility rolls equal to the cards value. If any rolls are successful, this card is kept until the end of the expedition. Play this card when an Encounter card is drawn yo draw another Encounter card and choose which one to use.

Each player in leader order can choose to place one of their wounds on this card. Then, all players make an Agility or Defense roll (their choice). The wounds are divided up amongst players who failed their check. If no players fail, then no wounds are returned.

In leader order, each player can choose to suffer a wound. As long as one player suffered a wound, Search and Summon actions only require a 3+ activation dice during the next combat. Keep this card as a reminder.

Draw an Encounter card. During the next Combat in which that enemy appears, as long as one model of the type shown is on the field, Heroes may reroll their Attack dice. Enemies of the shown type may also reroll their Attack dice. Keep this card and the Encounter card as a reminder.

Each player in leader order can discard an Archeotech card to make a number of Agility rolls equal to the cards value. If at least one roll is successful, keep this card until the end of the next combat. While you have this card, double the effective wounds caused when rolling for inspiration.
