---
title: "Wargame terrain links"
source: "Game Stuff/Wargame terrain links"
modified: 2022-05-09
type: reference-data
area: wargame
status: "unknown"
projects: ["[[Other Wargames]]"]
concepts: ["Wargame Terrain Sources"]
words: 18
summary: "List of bookmarked links to 28mm sci-fi terrain shops, free STL files on Thingiverse and a Dakka MDF suppliers wiki page."
tags: ["area/wargame", "project/other-wargames", "type/reference-data"]
---

[*https://northernlightsterrain.com/product-category/28mm-sci-fi/*](https://northernlightsterrain.com/product-category/28mm-sci-fi/)

[*https://brutalcities.com/collections/adamant-range*](https://brutalcities.com/collections/adamant-range)

[*https://www.zenterrain.com/en_US/p/Shanty-Town-full-table-bundle/243*](https://www.zenterrain.com/en_US/p/Shanty-Town-full-table-bundle/243)

[*https://northernlightsterrain.com/product/bi911-basic-infinity-4x4-table-set-with-detail-set/*](https://northernlightsterrain.com/product/bi911-basic-infinity-4x4-table-set-with-detail-set/)

[*https://shop.microartstudio.com/en/225-scenery*](https://shop.microartstudio.com/en/225-scenery)

Free STLS

[*https://www.thingiverse.com/thing:4058267*](https://www.thingiverse.com/thing:4058267)

[*https://www.thingiverse.com/bilbostomper/collections/octagonal-structures-collection*](https://www.thingiverse.com/bilbostomper/collections/octagonal-structures-collection)

[*https://www.thingiverse.com/bilbostomper/collections/walkway-collection*](https://www.thingiverse.com/bilbostomper/collections/walkway-collection)

[*https://www.thingiverse.com/thing:4057549*](https://www.thingiverse.com/thing:4057549)

[*https://www.thingiverse.com/thing:2554067*](https://www.thingiverse.com/thing:2554067)

[*https://www.thingiverse.com/thing:3562751*](https://www.thingiverse.com/thing:3562751)

[*https://www.thingiverse.com/thing:3645341*](https://www.thingiverse.com/thing:3645341)

Dakka massive list

[*https://www.dakkadakka.com/wiki/en/MDF_Scenery_Suppliers*](https://www.dakkadakka.com/wiki/en/MDF_Scenery_Suppliers)
