---
title: "Random Geometry Terrain"
source: "Game Stuff/Game Ideas/Random Geometry Terrain"
modified: 2014-06-28
type: idea
area: game-idea
status: "idea"
projects: ["[[Other Wargames]]"]
concepts: ["Random Geometry Terrain"]
words: 106
summary: "Short idea for a fictional world with terrain composed of stacked geometric shapes, biome shape sets, node-map based generation and reserved colors for friendly/hostile."
tags: ["area/game-idea", "project/other-wargames", "type/idea"]
---

A fictional world where the terrain is made from geometric shapes stavked onto eachother.

low number of height levels (3-5)

each 'biome' has a small set different shapes

example: one type of forest might have hex shpes trees and octogon rocks

rivers and chasms follow fixed angle corners.

villages are all of the same style, all with shapes

generate a nodemap, add biomes to them and then blend biomes together in the final map. Features can be added to the nodemap and then placed in the final step.

reserve one color for hostile creatures, and another for friendlies. These colors shouldnt be used in the environment.
