---
title: "Spells to Items"
source: "Game Stuff/Spells to Items"
modified: 2022-11-06
type: template
area: dnd
status: "unknown"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items"]
words: 21
summary: "Empty three-column table template for converting spells into items."
tags: ["area/dnd", "project/d-d-homebrew", "type/template"]
---

| Spell Name | Changes | Item Description |     |
|------------|---------|------------------|-----|
|            |         |                  |     |
|            |         |                  |     |
