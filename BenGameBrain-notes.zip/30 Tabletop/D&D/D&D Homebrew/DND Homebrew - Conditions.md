---
title: "DND Homebrew - Conditions"
source: "Game Stuff/DND Homebrew_ Conditions"
modified: 2024-02-20
type: homebrew-rules
area: dnd
status: "idea"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items"]
words: 11
summary: "Two homebrew conditions: Bound and Wet."
tags: ["area/dnd", "project/d-d-homebrew", "type/homebrew-rules"]
---

Bound: Lose use of one hand.

Wet: Vulnerability to lightning damage
