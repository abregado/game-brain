---
title: "FDnD2 House Rules"
source: "Game Stuff/D&D/FDnD2 House Rules"
modified: 2021-06-17
type: homebrew-rules
area: dnd
status: "designed"
projects: ["[[D&D Homebrew]]", "[[FDnD Campaign (Frankfurt)]]"]
concepts: ["D&D house rules", "FDnD campaign (Frankfurt)"]
words: 178
summary: "Short list of house rules: half HP only healable by rest, exhaustion on failed death saves, max damage on crits, shared inspiration pool and Bad Luck token mechanic, leader initiative swap."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/homebrew-rules"]
---

### Hit Points

Half your Hit Points are only healable during a rest.

### Injuries.

If you fail any Death Saving throw, gain one level of exhaustion.

### Critical Damage

You deal maximum damage when you crit in addition to the regular damage.

### Inspiration and Luck

Inspiration is added to a shared pool. Anyone can spend an Inspiration to add Advantage or remove Disadvantage.

Any player can spend their reaction and an Inspiration to reroll a combat roll.

Whenever a 1 is rolled, the player can take a reroll and add a token to the “Bad Luck” pool or they can remove one token from the Bad Luck pool and say “let me have it”.

Whenever a saving throw or ability check is made, the player can spend a token from the Bad Luck pool to increase the difficulty by 5.

Bad Luck tokens can be used as Inspiration by boss monsters.

### Initiative and Leadership

After an initiative roll is made, the group leader can choose to swap the values of two heroes with one another.
