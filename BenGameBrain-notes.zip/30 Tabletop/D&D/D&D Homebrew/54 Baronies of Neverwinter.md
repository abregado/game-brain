---
title: "54 Baronies of Neverwinter"
source: "Game Stuff/54 Baronies of Neverwinter"
modified: 2024-10-28
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign (Frankfurt)", "Neverwinter Baronies NPC Roster"]
words: 2043
summary: "List of ~30 NPC nobles (barons/baronesses) of the Neverwinter region grouped by background (military, merchant, newcomer, agricultural, seafaring, religious), each with a barony number, a core trait and acting/body-language notes for roleplay."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

The Lords Alliance promotes rule by noble families and has partitioned the land around neverwinter into 54 baronies.

# Military Nobility

These families earned their baronies through martial prowess, either as commanders in battle or through generations of military service.

## Baron Harlan Ironclad: 

A stoic war veteran known for his iron will and strong leadership over his barony.

Barony 22

Resolve

Strong, unmoving stance, clenched fists, and a firm, set jaw that shows an unbreakable focus.

## Baroness Lydia Stormblade: 

A fierce warrior trained in the arts of both sword and sorcery.

Barony 45

Fury

Sharp, sudden gestures, clenched fists, and an intense, narrowed gaze; always ready to spring into action.

## Baron Darius Blackthorn: 

Once a general, now an aging but cunning strategist who protects his lands with an iron fist.

Barony 2

Strategy

Steeples his fingers, a calculating look in his eyes, standing with one hand resting on his chin as he contemplates.

## Baron Valrik Ashguard: 

Known for a long tradition of commanding knights, he upholds strict laws within his barony.

Barony 19

Honor

Upright and formal, chest puffed out slightly, with a hand often resting on his heart or sword hilt in solemn respect.

# Merchant Houses

These families gained control due to their wealth, often having made deals with the Lords Alliance to maintain trade routes or economic stability.

## Baron Oren Goldriver: 

A shrewd and charismatic merchant-lord, who controls much of the trade along the rivers.

Barony 34

Ambition

Leaning in, hands rubbing together or tapping his fingers, always eager, with a sharp, focused look.

## Baroness Elysia Silvershade: 

A cunning negotiator whose fortune comes from controlling lucrative mining operations.

Barony 16

Greed

Quick, darting eyes, fingers constantly toying with a coin or jewelry, a smile that doesn’t reach her eyes.

## Baron Matthias Thornebrooke: 

Known for his monopoly on timber and shipbuilding in the region, he is well-respected among the merchant elite.

Barony 39

Prestige

Standing tall, adjusting his fine clothes, with a look of approval as he surveys his surroundings; never slouches.

## Baroness Amara Vandemir: 

A brilliant financier who controls several markets in Neverwinter through subtle political moves.

Barony 17

Cunning

Tilts her head slightly, with an amused smirk, fingers tapping thoughtfully against her lips, always in thought.

# Magical Dynasties

Families with a history of magical talent, often tasked with defending their lands using arcane knowledge.

## Baron Lucan Faelan: 

A powerful wizard with a mysterious past, who keeps to his tower and leaves most governance to trusted lieutenants.

Barony 13

Secrecy

Stands with a closed posture, arms often crossed or hidden beneath robes, eyes glancing sideways or down.

## Baroness Melisandre Arkanis: 

A sorceress with ties to ancient fey powers, her barony is shrouded in mystery and enchantment.

Barony 44

Mystery

Moves slowly, deliberately, often with a hand raised as if holding something unseen; her face remains unreadable.

## Baron Aleron Starborn: 

A master of astral magic, his family is known for their control of celestial magic and divination.

Barony 15

Wisdom

Paces with hands behind his back, eyes gazing skyward or toward distant horizons, his expression thoughtful.

## Baron Elric Zephyros: 

His family is famous for elemental magic, especially wind and weather control, which they use to influence farming and sea routes.

Barony 9

Curiosity

Quick, sudden movements, fingers constantly tracing magical symbols in the air, with wide, fascinated eyes.

# Old Blood Nobility

Families whose heritage dates back centuries, known for their deep-rooted traditions and political power.

## Baron Edric Greyfall: 

An elderly, calculating ruler with a vast network of spies, ensuring his barony stays secure.

Barony 25

Control

Standing with arms behind his back, a tight-lipped expression, and a commanding gaze that rarely wavers.

## Baroness Isolde Ravenshade: 

Cold and aloof, she has ruled her lands with both charm and a reputation for ruthlessness.

Barony 33

Pride

Chin held high, a haughty smile with slow, deliberate movements that radiate self-confidence.

## Baron Cedric Wynterborn: 

A stern traditionalist who values order and formality, with a long-standing feud with House Ravenshade.

Barony 40

Tradition

Stands rigid and formal, hands folded behind him or on his sword hilt, never breaking from expected decorum.

## Baroness Seraphina Duskveil: 

A family with a dark reputation, known for keeping secrets and ruling from the shadows.

Barony 35

Intrigue

Leans slightly forward, hands clasped with fingers intertwined, a slight smirk, and half-lidded, knowing eyes.

# Newcomers

Families that recently rose to power, sometimes viewed with suspicion or jealousy by the more established nobility.

## Baron Toran Ironroot: 

A former commoner who gained his title through heroism in battle, now struggling to fit in with high society.

Determination

Clenched fists, forward-leaning stance, feet planted firmly, and a focused, intense stare.

## Baroness Valeria Thornspire: 

Young, ambitious, and ruthless, she is determined to make her name known in noble circles.

Barony 52

Ambition

Sharp, quick movements, fingers tapping or steepling, eyes always searching for opportunity with a confident grin.

## Baron Gareth Emberwind: 

A former pirate captain who leveraged his influence to gain a noble title, now trying to leave his shady past behind.

Barony 50

Redemption

Shoulders slightly hunched, often clasping his hands together or rubbing his chin, eyes filled with longing and resolve.

## Baroness Elowen Frostveil: 

Newly wealthy due to the discovery of rich mineral deposits in her barony, her family is still adjusting to its sudden rise in status.

Barony 51

Adaptability

Quick, nimble movements, with hands gesturing fluidly, her expression constantly shifting with the conversation.

# Agricultural Backgrounds

These barons and baronesses oversee fertile lands, focusing on crops, livestock, and trade with nearby cities. Many come from generations of farmers or landholders, often prioritizing stability and the wellbeing of their workers.

## Baroness Talia Greenmeadow: 

A kind-hearted yet shrewd ruler, Talia comes from a long line of landowners known for growing some of the best wheat in the region. She personally oversees the harvest and has introduced new farming techniques to increase yields. Her barony is considered the breadbasket of the area.

Barony 28

Nurturing

Always leans in when speaking, hands gently clasped in front, offering a reassuring smile.

## Baron Osric Emberleaf: 

A jovial elf with a talent for cultivating rare herbs and medicinal plants. His fields are famous for their golden wheat and a particular herb known as *Sunweed*, which has healing properties. Osric has formed alliances with several alchemists in Neverwinter who rely on his crops.

His Baroness is an active socialite. His second daughter is participating in the Barony contest.

Barony 41

Joy

Open arms, wide gestures, with an infectious grin that lights up his face, always in motion.

## Baroness Linara Windgrove: 

A pragmatic leader who rules over a vast orchard. Known for her family's legacy of apple farming, her cider is renowned throughout the region. Linara is fiercely protective of her lands and has expanded into honey production, ensuring her barony thrives even in lean years.

Barony 48

Pragmatism

Stands with hands on hips, eyes scanning her surroundings with calculating precision, shoulders squared.

## Baron Gregor Thornfield: 

A stern but fair ruler, Gregor’s family has specialized in cattle farming for generations. His barony supplies much of the region’s meat, leather, and wool. Though gruff, Gregor is known for his deep connection to the land and a strong sense of responsibility to his workers.

Barony 26

Duty

Stiff posture, arms crossed, furrowed brow; always at attention and rarely relaxed.

## Baroness Maelin Ironhill: 

Known for overseeing expansive vineyards in the rolling hills of her barony, Maelin’s wines are famous across the Sword Coast. She’s skilled in the art of negotiation, having secured trade deals that keep her barony prosperous even in harsh seasons. Her family’s winery has operated for centuries.

Barony 30

Pride

Chin slightly raised, a confident stance with one hand resting on her hip, often adjusts her clothes or jewelry.

## Baron Edric Briarvale: 

A reclusive but respected man, Edric governs a barony known for its vast flax fields, producing linen for export. He’s also an expert in animal husbandry, raising some of the finest sheep and horses. Edric is a quiet man who values the old ways and shuns much of the political maneuvering common among other nobles.

Barony 24

Tranquility

Soft, deliberate movements, hands often folded neatly, with a calm, slow blink and gentle nods.

## Baroness Isolde Mosswood: 

A passionate protector of her lands, Isolde’s barony is mostly forested, and she oversees the production of timber and a variety of mushrooms and forest herbs. Isolde has a strong affinity with nature and works closely with druids in her barony to ensure the sustainable management of her resources.

Barony 32

Reverence

Head bowed slightly, palms together in front of her chest, with a quiet, respectful gaze that rarely wavers.

# Seafaring Backgrounds

These barons and baronesses control coastal territories or islands, with economies tied to fishing, shipbuilding, and maritime trade. They often have a strong connection to the sea and are adept navigators, sailors, or traders.

## Baron Calder Seastrider: 

A legendary former sailor turned noble, Calder commands a river barony renowned for its shipyards. His family built their fortune through shipbuilding and river trade, and he maintains a fleet of swift trading vessels. He’s a pragmatic leader, known for his salty language and unshakable loyalty to his crew and people.

Barony 36

Loyalty

Strong, direct eye contact, often claps a hand on a shoulder in camaraderie, firm stance like a sailor at sea.

## Baroness Lyra Driftmoor: 

Her family has been involved in fishing and maritime trade for generations. Lyra’s barony sits at the sea and abundant fishing grounds. She’s an expert navigator and sailor in her own right, often taking to the seas herself to inspect her fisheries and ships.

Barony 10

Freedom

Fluid, graceful movements, often pacing as she speaks, gestures wide like she’s used to the open seas.

## Baron Taric Wavecrest: 

A charismatic, swashbuckling ruler who once captained his own ship, Taric’s barony is a hub for fishing and whaling. His people are renowned for their daring deep-sea hunts, providing oil, blubber, and valuable materials from sea creatures. He’s known for his wild parties, often held in the grand halls of his cliffside keep.

Barony 5

Adventure

Restless energy, hands on his sword or belt, constantly shifting his weight, ready to spring into action.

## Baroness Evelyne Saltspire: 

A no-nonsense ruler, Evelyne’s barony is centered around a natural bay perfect for harboring ships. Her family has long dominated the salt trade, exporting salt from seawater and keeping a careful watch on smugglers. Evelyne is respected for her sharp mind and unyielding enforcement of maritime law.

Barony 6

Discipline

Rigid posture, hands behind her back, with a stern, controlled expression and sharp, precise movements.

## Baron Corwin Blackreef: 

A grim and silent man, Corwin’s barony sits on a storm-battered coastline. His family has been salvaging shipwrecks for centuries, profiting off the treasures brought to their shores by ill-fated vessels. Though his methods are sometimes viewed as unsavory, Blackreef commands fierce loyalty from his people.

Barony 4

Resilience

Still and quiet, arms folded, jaw set tightly, with a hard stare and an unyielding posture, rarely showing emotion.

## Baroness Selene Tidebreaker:

Known for her skill in negotiation and diplomacy, Selene controls an barony that is a vital stopping point for merchant ships traveling along the Sword Coast. Her barony’s economy thrives on fishing and trading, but she also has a keen eye on potential pirate activity, striking lucrative deals with privateers to ensure her security.

Barony 14

Cunning

Subtle, quick glances, arms folded with one hand cupping her chin, a sly smile often playing at the corners of her mouth.

# Religious background

## High Priestess Rhiannon Everwatcher

When the Lords Alliance reorganized the baronies, Rhiannon was granted control of the land surrounding Helm’s Hold due to her reputation for selflessness and her deep-rooted connections to the church. She rules not as a noble seeking wealth or power, but as a devoted servant of Helm, ensuring that the people under her protection are well cared for, that justice prevails, and that the fortress remains a symbol of safety and sanctuary.

Barony 3

Compassion

Hands extended in offering or reassurance, calm, soft gestures with a gentle gaze and a warm smile.
