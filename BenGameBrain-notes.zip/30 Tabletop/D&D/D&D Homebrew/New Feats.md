---
title: "New Feats"
source: "Game Stuff/New Feats"
modified: 2024-01-14
type: idea
area: dnd
status: "idea"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items", "Feat: Poisonmaking", "Feat: Potion Dilution"]
words: 27
summary: "Stub for new D&D feats aimed at giving players gold sinks, listing only Poisonmaking and Potion dilution."
tags: ["area/dnd", "project/d-d-homebrew", "type/idea"]
---

Goals

- Give players things to spend their gold on

Constraints

- Expand on a previously available but not well fleshed out fantasy

- 

Poisonmaking

Potion dilution
