---
title: "FDnD Ancient Ones"
source: "Game Stuff/D&D/FDnD Ancient Ones"
modified: 2020-02-15
type: homebrew-rules
area: dnd
status: "designed"
projects: ["[[D&D Homebrew]]", "[[FDnD Campaign (Frankfurt)]]"]
concepts: ["D&D homebrew items", "FDnD campaign (Frankfurt)"]
words: 637
summary: "Homebrew warlock patron flavour: five alien Ancient One patrons with names and domains (repressed terror, waking dreams, void pit, mirror of soul, lost certainty)."
merged_versions: ["Game Stuff/D&D/5e Warlock Patron Ideas"]
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/homebrew-rules"]
---

## Warlock Patron Ancient ones

Ancient ones are older than the gods, older than pretty much everything. Certainly they are older than conscious thought, which they tend to have some aspect of. They are your patron in the same way that humans are the patrons of ants, or perhaps bed bugs. They are totally alien in their thinking, both in scale and detail. Ancient ones are well above good and evil, law and order. They just are.

Your patron does not know your name, or even that you exist, but your connection allows you to draw on its strengths. Your telepathy uses the old one as a conduit.

When you call on your powers, you are tapping into this ancient one. It shapes your powers narratively. But, How much can the ant take until the human decides to exterminate the nest… or put the nest to work.

Lorbath'ebbungen - The Repressed Terror. Where your repressed memories go. Subconscious remnants of these terrors connect us all through this ancient one.

Korna'depelnath - Traveller of Waking Dreams. When you remember an event and it feels as real as if you were there, you probably are. The Traveller has been and always will have been, everywhere.

Felplah'betlungett - The Pit in the Void. When sentient creatures experience vertigo their consciousness is actually falling. You know those dreams of falling...

Gablunggen'regganath - Mirror of The infinite Soul. Dejavu, when it happens, perhaps a different you is experiencing this from a different angle. When you recognize yourself in a crowd, you are gazing into the Mirror.

Samlar'zettlorch - Collector of lost certainty - when you have lost something conceptual: faith, certainly, confidence, ect, it won't be found by anyone. But there is one thing that could happen by and be interested. It will keep it's link to you open, so you will always remember that you have lost something, even after you forgot what it was.

---

## Differences from other versions

_This document existed in several versions. The text above is the most complete one, unchanged. Below are the lines that appear only in the other versions._

### Only in “5e Warlock Patron Ideas” (D&D, modified 2020-05-28)

_No differences – identical content._
