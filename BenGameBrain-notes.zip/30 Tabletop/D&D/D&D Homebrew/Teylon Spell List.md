---
title: "Teylon Spell List"
source: "Game Stuff/D&D/Teylon Spell List"
modified: 2023-09-21
type: reference-data
area: dnd
status: "unknown"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D characters"]
words: 2502
summary: "Spell list for Teylon; only empty table placeholders survived conversion."
tags: ["area/dnd", "project/d-d-homebrew", "type/reference-data"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><h2 id="prestidigitation">Prestidigitation</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p>
<p><strong>or 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>This spell is a minor magical trick that novice spellcasters use for practice. You create one of the following magical effects within range:</p>
<p>If you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action.</p></th>
<th><ul>
<li><blockquote>
<p>You create an instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.</p>
</blockquote></li>
<li><blockquote>
<p>You instantaneously light or snuff out a candle, a torch, or a small campfire.</p>
</blockquote></li>
<li><blockquote>
<p>You instantaneously clean or soil an object no larger than 1 cubic foot.</p>
</blockquote></li>
<li><blockquote>
<p>You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.</p>
</blockquote></li>
<li><blockquote>
<p>You make a color, a small mark, or a symbol appear on an object or a surface for 1 hour.</p>
</blockquote></li>
<li><blockquote>
<p>You create a non-magical trinket or an illusory image that can fit in your hand and that lasts until the end of your next turn.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="cantrip">Cantrip</h3></th>
</tr>
<tr class="odd">
<th><h2 id="mage-hand">Mage Hand</h2></th>
<th><h2 id="eldritch-blast">Eldritch Blast</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A spectral, floating hand appears at a point you choose within range. The hand lasts for the duration or until you dismiss it as an action. The hand vanishes if it is ever more than 30 feet away from you or if you cast this spell again.</p>
<p>You can use your action to control the hand. You can use the hand to manipulate an object, open an unlocked door or container, stow or retrieve an item from an open container, or pour the contents out of a vial. You can move the hand up to 30 feet each time you use it.</p>
<p>The hand can't attack, activate magic items, or carry more than 10 pounds.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A beam of crackling energy streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 force damage.</p>
<p>The spell creates more than one beam when you reach higher levels: two beams at 5th level, three beams at 11th level, and four beams at 17th level. You can direct the beams at the same target or at different ones. Make a separate attack roll for each beam.</p></th>
</tr>
<tr class="odd">
<th><h3 id="cantrip-1">Cantrip</h3></th>
<th><h3 id="cantrip-2">Cantrip</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="summon-lesser-demons">Summon Lesser Demons</h2></th>
<th><h2 id="fly">Fly</h2></th>
</tr>
<tr class="odd">
<th rowspan="4"><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a vial of fresh humanoid blood)</strong></p>
<p>You utter foul words, summoning demons from the chaos of the Abyss. Roll on the following table to determine what appears.</p>
<table>
<colgroup>
<col style="width: 22%" />
<col style="width: 77%" />
</colgroup>
<thead>
<tr class="header">
<th>d6</th>
<th>Demons Summoned</th>
</tr>
<tr class="odd">
<th>1-2</th>
<th>2x CR 1</th>
</tr>
<tr class="header">
<th>3-4</th>
<th>4x CR 1/2</th>
</tr>
<tr class="odd">
<th>5-6</th>
<th>8x CR 1/4</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>The DM chooses the demons, such as manes or dretches, and you choose the unoccupied spaces you can see within range where they appear. A summoned demon disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The demons are hostile to all creatures, including you. Roll initiative for the summoned demons as a group, which has its own turns. The demons pursue and attack the nearest non-demons to the best of their ability.</p>
<p>As part of casting the spell, you can form a circle on the ground with the blood used as a material component. The circle is large enough to encompass your space. While the spell lasts, the summoned demons can't cross the circle or harm it, and they can't target anyone within it. Using the material component in this manner consumes it when the spell ends.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 6th or 7th level, you summon twice as many demons. If you cast it using a spell slot of 8th or 9th level, you summon three times as many demons.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: Concentration, up to <strong>10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a wing feather from a bird)</strong></p>
<p>You touch a willing creature. The target gains a flying speed of 60 feet for the duration. When the spell ends, the target falls if it is still aloft, unless it can stop the fall.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 4th level or higher, you can target one additional creature for each slot level above 3rd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="distort-value">Distort Value</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Illusion</strong></p>
<p>Casting time: <strong>1 Minute</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>8 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You cast this spell on an object no more than 1 foot on a side, doubling the object's perceived value by adding illusory flourishes or polish to it, or reducing its perceived value by half with the help of illusory scratches, dents, and other unsightly features. Anyone examining the object can ascertain its true value with a successful Intelligence (Investigation) check against your spell save DC.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the maximum size of the object increases by 1 foot for each slot level above 1st.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-1">Level 3</h3></th>
<th><h3 id="level-3-2">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="mirror-image">Mirror Image</h2></th>
<th><h2 id="magic-circle">Magic Circle</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Illusion</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Three illusory duplicates of yourself appear in your space. Until the spell ends, the duplicates move with you and mimic your actions, shifting position so it's impossible to track which image is real. You can use your action to dismiss the illusory duplicates.</p>
<p>Each time a creature targets you with an attack during the spell's duration, roll a d20 to determine whether the attack instead targets one of your duplicates.</p>
<p>If you have three duplicates, you must roll a 6 or higher to change the attack's target to a duplicate. With two duplicates, you must roll an 8 or higher. With one duplicate, you must roll an 11 or higher.</p>
<p>A duplicate's AC equals 10 + your Dexterity modifier. If an attack hits a duplicate, the duplicate is destroyed. A duplicate can be destroyed only by an attack that hits it. It ignores all other damage and effects. The spell ends when all three duplicates are destroyed.</p>
<p>A creature is unaffected by this spell if it can't see, if it relies on senses other than sight, such as blindsight, or if it can perceive illusions as false, as with truesight.</p></th>
<th rowspan="4"><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Minute</strong></p></th>
<th><p>Range: <strong>10 feet</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (holy water or silver powder worth 100gp)</strong></p>
<p>You create a 10-foot-radius, 20-foot-tall cylinder of magical energy centered on a point on the ground that you can see within range. Glowing runes appear wherever the cylinder intersects with the floor or other surface.</p>
<p>Choose one or more of the following types of creatures: celestials, elementals, fey, fiends, or undead. The circle affects a creature of the chosen type in the following ways:</p>
<ul>
<li><blockquote>
<p>The creature can't willingly enter the cylinder by non-magical means. If the creature tries to use teleportation or interplanar travel to do so, it must first succeed on a Charisma saving throw.</p>
</blockquote></li>
<li><blockquote>
<p>The creature has disadvantage on attack rolls against targets within the cylinder.</p>
</blockquote></li>
<li><blockquote>
<p>Targets within the cylinder can't be charmed, frightened, or possessed by the creature.</p>
</blockquote></li>
</ul>
<p>When you cast this spell, you can elect to cause its magic to operate in the reverse direction, preventing a creature of the specified type from leaving the cylinder and protecting targets outside it.</p>
<p><strong>At Higher Levels</strong>: When you cast this spell using a spell slot of 4th level or higher, the duration increases by 1 hour for each slot level above 3rd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-3">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="hunger-of-hadar">Hunger of Hadar</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>150 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (octopus tentacle)</strong></p>
<p>You open a gateway to the dark between the stars, a region infested with unknown horrors. A 20-foot-radius sphere of blackness and bitter cold appears, centered on a point within range and lasting for the duration. This void is filled with a cacophony of soft whispers and slurping noises that can be heard up to 30 feet away. No light, magical or otherwise, can illuminate the area, and creatures fully within the area are blinded.</p>
<p>The void creates a warp in the fabric of space, and the area is difficult terrain. Any creature that starts its turn in the area takes 2d6 cold damage. Any creature that ends its turn in the area must succeed on a Dexterity saving throw or take 2d6 acid damage as milky, otherworldly tentacles rub against it.</p></th>
</tr>
<tr class="odd">
<th><h2 id="level-3-4">Level 3</h2></th>
<th><h3 id="level-3-5">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="incite-greed">Incite Greed</h2></th>
<th><h2 id="detect-magic">Detect Magic</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a gem worth at least 50gp)</strong></p>
<p>When you cast this spell, you present the gem used as the material component and choose any number of creatures within range that can see you. Each target must succeed on a Wisdom saving throw or be charmed by you until the spell ends, or until you or your companions do anything harmful to it. While charmed in this way, a creature can do nothing but use its movement to approach you in a safe manner. While an affected creature is within 5 feet of you, it cannot move, but simply stares greedily at the gem you present.</p>
<p>At the end of each of its turns, an affected target can make a Wisdom saving throw. If it succeeds, this effect ends for that target.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action or Ritual</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any.</p>
<p>The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-6">Level 3</h3></th>
<th><h3 id="level-1">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="disguise-self">Disguise Self</h2></th>
<th><h2 id="section"></h2></th>
</tr>
<tr class="header">
<th><h3 id="section-1"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-illusion">School: Illusion</h3>
<h3 id="casting-time-1-action">Casting time: 1 Action</h3>
<h3 id="section-2"></h3></th>
<th><h3 id="range-self">Range: Self</h3>
<h3 id="duration-1-hour">Duration: 1 hour</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-3"></h3>
<h3 id="components-v-s">Components: V, S</h3>
<h3 id="section-4"></h3>
<h3 id="the-changes-wrought-by-this-spell-fail-to-hold-up-to-physical-inspection.-for-example-if-you-use-this-spell-to-add-a-hat-to-your-outfit-objects-pass-through-the-hat-and-anyone-who-touches-it-would-feel-nothing-or-would-feel-your-head-and-hair.-if-you-use-this-spell-to-appear-thinner-than-you-are-the-hand-of-someone-who-reaches-out-to-touch-you-would-bump-into-you-while-it-was-seemingly-still-in-midair.">The changes wrought by this spell fail to hold up to physical inspection. For example, if you use this spell to add a hat to your outfit, objects pass through the hat, and anyone who touches it would feel nothing or would feel your head and hair. If you use this spell to appear thinner than you are, the hand of someone who reaches out to touch you would bump into you while it was seemingly still in midair.</h3>
<p>To discern that you are disguised, a creature can use its action to inspect your appearance and must succeed on an Intelligence (Investigation) check against your spell save DC.</p>
<h3 id="section-5"></h3></th>
<th><h3 id="section-6"></h3>
<h3 id="section-7"></h3></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-1">Level 1</h3></th>
<th><h3 id="section-8"></h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="blur">Blur</h2></th>
<th><h2 id="branding-smite">Branding Smite</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Illusion</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>Your body becomes blurred, shifting and wavering to all who can see you. For the duration, any creature has disadvantage on attack rolls against you. An attacker is immune to this effect if it doesn't rely on sight, as with blindsight, or can see through illusions, as with truesight.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Bonus action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>The next time you hit a creature with a weapon attack before this spell ends, the weapon gleams with astral radiance as you strike. The attack deals an extra 2d6 radiant damage to the target, which becomes visible if it's invisible, and the target sheds dim light in a 5-foot radius and can't become invisible until the spell ends.</p>
<p>At Higher Levels.</p>
<p>When you cast this spell using a spell slot of 3rd level or higher, the extra damage increases by 1d6 for each slot level above 2nd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2">Level 2</h3></th>
<th><h3 id="level-2-1">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="wrathful-smite">Wrathful Smite</h2></th>
<th><h2 id="shield">Shield</h2></th>
</tr>
<tr class="header">
<th><h3 id="section-9"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-evocation">School: Evocation</h3>
<h3 id="casting-time-1-bonus-action">Casting time: 1 Bonus action</h3>
<h3 id="section-10"></h3></th>
<th><h3 id="range-self-1">Range: Self</h3>
<h3 id="duration-concentration-up-to-1-minute">Duration: Concentration, up to 1 minute</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-11"></h3>
<h3 id="components-v">Components: V</h3>
<h3 id="section-12"></h3>
<h3 id="the-next-time-you-hit-with-a-melee-weapon-attack-during-this-spells-duration-your-attack-deals-an-extra-1d6-psychic-damage.-additionally-if-the-target-is-a-creature-it-must-make-a-wisdom-saving-throw-or-be-frightened-of-you-until-the-spell-ends.-as-an-action-the-creature-can-make-a-wisdom-check-against-your-spell-save-dc-to-steel-its-resolve-and-end-this-spell.">The next time you hit with a melee weapon attack during this spell's duration, your attack deals an extra 1d6 psychic damage. Additionally, if the target is a creature, it must make a Wisdom saving throw or be frightened of you until the spell ends. As an action, the creature can make a Wisdom check against your spell save DC to steel its resolve and end this spell.</h3>
<h3 id="section-13"></h3></th>
<th><h3 id="section-14"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-abjuration">School: Abjuration</h3>
<h3 id="casting-time-1-reaction">Casting time: 1 Reaction</h3>
<h3 id="section-15"></h3></th>
<th><h3 id="range-self-2">Range: Self</h3>
<h3 id="duration-1-round">Duration: 1 round</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-16"></h3>
<h3 id="components-v-s-1">Components: V, S</h3>
<p>When you are hit by an attack or targeted by the magic missile spell. An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-2">Level 1</h3></th>
<th><h3 id="level-1-3">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="blink">Blink</h2></th>
<th><h2 id="elemental-weapon">Elemental Weapon</h2></th>
</tr>
<tr class="odd">
<th><h3 id="section-17"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-transmutation">School: Transmutation</h3>
<h3 id="casting-time-1-action-1">Casting time: 1 Action</h3>
<h3 id="section-18"></h3></th>
<th><h3 id="range-self-3">Range: Self</h3>
<h3 id="duration-1-minute">Duration: 1 minute</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-19"></h3>
<h3 id="components-v-s-2">Components: V, S</h3>
<h3 id="section-20"></h3>
<h3 id="roll-a-d20-at-the-end-of-each-of-your-turns-for-the-duration-of-the-spell.-on-a-roll-of-11-or-higher-you-vanish-from-your-current-plane-of-existence-and-appear-in-the-ethereal-plane-the-spell-fails-and-the-casting-is-wasted-if-you-were-already-on-that-plane.-at-the-start-of-your-next-turn-and-when-the-spell-ends-if-you-are-on-the-ethereal-plane-you-return-to-an-unoccupied-space-of-your-choice-that-you-can-see-within-10-feet-of-the-space-you-vanished-from.-if-no-unoccupied-space-is-available-within-that-range-you-appear-in-the-nearest-unoccupied-space-chosen-at-random-if-more-than-one-space-is-equally-near.-you-can-dismiss-this-spell-as-an-action.">Roll a d20 at the end of each of your turns for the duration of the spell. On a roll of 11 or higher, you vanish from your current plane of existence and appear in the Ethereal Plane (the spell fails and the casting is wasted if you were already on that plane). At the start of your next turn, and when the spell ends if you are on the Ethereal Plane, you return to an unoccupied space of your choice that you can see within 10 feet of the space you vanished from. If no unoccupied space is available within that range, you appear in the nearest unoccupied space (chosen at random if more than one space is equally near). You can dismiss this spell as an action.</h3>
<h3 id="while-on-the-ethereal-plane-you-can-see-and-hear-the-plane-you-originated-from-which-is-cast-in-shades-of-gray-and-you-cant-see-anything-there-more-than-60-feet-away.-you-can-only-affect-and-be-affected-by-other-creatures-on-the-ethereal-plane.-creatures-that-arent-there-cant-perceive-you-or-interact-with-you-unless-they-have-the-ability-to-do-so.">While on the Ethereal Plane, you can see and hear the plane you originated from, which is cast in shades of gray, and you can't see anything there more than 60 feet away. You can only affect and be affected by other creatures on the Ethereal Plane. Creatures that aren't there can't perceive you or interact with you, unless they have the ability to do so.</h3>
<h3 id="section-21"></h3></th>
<th><h3 id="section-22"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-transmutation-1">School: Transmutation</h3>
<h3 id="casting-time-1-action-2">Casting time: 1 Action</h3>
<h3 id="section-23"></h3></th>
<th><h3 id="range-touch">Range: Touch</h3>
<h3 id="duration-concentration-up-to-1-hour">Duration: Concentration, up to 1 hour</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-24"></h3>
<h3 id="components-v-s-3">Components: V, S</h3>
<p>A non-magical weapon you touch becomes a magic weapon. Choose one of the following damage types: acid, cold, fire, lightning, or thunder. For the duration, the weapon has a +1 bonus to attack rolls and deals an extra 1d4 damage of the chosen type when it hits.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 5th or 6th level, the bonus to attack rolls increases to +2 and the extra damage increases to 2d4. When you use a spell slot of 7th level or higher, the bonus increases to +3 and the extra damage increases to 3d4.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-7">Level 3</h3></th>
<th><h3 id="level-3-8">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
