---
title: "Hamas Recipe book"
source: "Game Stuff/D&D/Hamas Recipe book"
modified: 2020-05-16
type: homebrew-rules
area: dnd
status: "played/used"
projects: ["[[D&D Homebrew]]", "[[FDnD Campaign (Frankfurt)]]"]
concepts: ["D&D homebrew items", "FDnD campaign (Frankfurt)"]
words: 322
summary: "Homebrew magic item recipes (Aegis Blade, Branding Blade, Hero's Armor, Ravenclaw Warblade) that an Artificer can turn into infusions, for Hama's character."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/homebrew-rules"]
---

Select one to become an infusion as per the Artificer rules (increasing the max infusions by 1). The others you can keep as recipes for creating copies, but can’t be used as infusions (unless you take the Replicate Item infusion at later Artificer levels). As you examine more magic items in the campaign, I will keep adding new options here.

**Aegis Blade**

Uncommon Bladed weapon

Crafting time/cost: 2 weeks/200gp

Required tools and reagents: A holy symbol and access to a regular forge.

Infusion available at lvl 2 Artificer.

Attunement by Good Alignment

Bonus Action: Place an Aegis Mark on a creature you can see. The mark lasts for 1 minute. The marked creature suffers -1d6 to attack rolls on creatures other than you. You may only place two marks per long rest.

**Branding Blade**

Uncommon Bladed weapon

Crafting time/cost: 2 weeks/200gp

Required tools and reagents: Access to a regular forge and magical workshop

Infusion available at lvl 2 Artificer.

Attunement by Human

Bonus Action: Place a Branding Mark on a creature that you can see. The mark lasts 1 minute. The marked creature takes an additional d4 fire damage from this weapon. You may only place one mark per long rest.

**Hero’s Armor**

Uncommon Medium armor

Crafting time/cost: 2 weeks/200gp

Required tools and reagents: Access to the spellforge

Infusion available at lvl 2 Artificer.

Attunement by Fighter

While wearing this armor, you gain +1 to your AC and saving throws for 1 minute after using an Action Surge.

**Ravenclaw Warblade**

Rare Bladed Weapon

Crafting time/cost: 10 weeks/2000gp

Required tools and reagents (when creating): Hook Horror or Roc parts, Forge of Spells access.

Infusion available at lvl 6 Artificer.

Attunement by Fighter

Passive: While wielding this weapon, whenever you have no remaining hit dice, this weapon does an additional die of damage. Twice per long rest, when you kill a creature with this weapon, you may spend a hit die to heal yourself.
