---
title: "Custom 5e Monsters"
source: "Game Stuff/D&D/Custom 5e Monsters"
modified: 2020-05-20
type: homebrew-rules
area: dnd
status: "unknown"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items"]
words: 851
summary: "Document with only two unconverted tables (monster stat blocks presumably); no readable text."
tags: ["area/dnd", "project/d-d-homebrew", "type/homebrew-rules"]
---

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="4"><h2 id="king-grol-bugbear"><strong>King Grol (Bugbear)</strong></h2>
<p>Medium humanoid (goblinoid), Chaotic Evil</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>14</strong></p>
<p>Hit Points: <strong>65+3d10</strong></p></th>
<th><p>STR: <strong>18 (+3)</strong></p>
<p>DEX: <strong>14 (+2)</strong></p>
<p>CON: <strong>15 (+2)</strong></p>
<p>INT: <strong>13 (+1)</strong></p>
<p>WIS: <strong>11 (+0)</strong></p>
<p>CHA: <strong>9 (-1)</strong></p></th>
<th colspan="2"><p>Skills: <strong>Survival +2</strong></p>
<p>Senses: <strong>passive Perception 10, Darkvision 60ft</strong></p>
<p>Languages: Common, Goblin</p>
<p>Speed: <strong>30 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="special-rules"><strong>Special Rules</strong></h3>
<p><strong>Brute.</strong> Grol deals an additional die of damage whenever he hits with a melee weapon (included below).</p>
<p><strong>Bulky.</strong> If Grol is forced to squeeze through a space not large enough for a medium creature, he does so at quarter speed.</p>
<p><strong>Legendary Resistance (1/Day):</strong> If Grol fails a saving throw, he can choose to succeed instead.</p>
<h3 id="actions"><strong>Actions</strong></h3>
<p><strong>Multiattack:</strong> Grol makes two attacks. First either one Knee Slam or Cruel Demise attack. After this is resolved he attacks once with his Darksteel Greatsword. If there is an incapacitated target within 5ft, he always chooses to make a Cruel Demise attack.</p>
<p><strong>Knee Slam:</strong> +5 to hit, reach 5ft, one target. Hit: 7 (1d8+3) bludgeoning damage, or 11 if the target is already Prone. On a hit, the target must pass a DC 15 Strength saving throw or be knocked prone.</p>
<p><strong>Cruel Demise:</strong> Automatic hit against an Incapacitated target. The target is killed automatically without a saving throw.</p>
<p><strong>Darksteel Greatsword:</strong> +5 to hit, reach 5ft, one target. Hit: 17 (3d8+5) slashing damage.</p>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
</tbody>
</table></th>
<th colspan="2"><p><strong>Cinematic Actions</strong></p>
<p>Grol can use each of the following actions once per encounter. Grol cannot recover the use of these actions.</p>
<p><strong>Surprising Speed:</strong> If there are no targets within 5ft, after killing or incapacitating a target, Grol may take the Dash action as a free action if it will bring him within 5ft of a new target.</p>
<p><strong>Full Body Slam:</strong> If Grol used the Dash action during his turn to move straight toward a target, and did not get to attack that target, he may spend his reaction to slam into that target. The target must pass a DC 12 Dexterity saving throw or be pushed back 5ft for every 5ft of remaining movement that Grol has. The target suffers 2d8 + 3 bludgeoning damage, plus 1d6 for every 5ft pushed.</p>
<p><strong>Sweeping Strike:</strong> On his turn, When there are 3 or more targets within 5ft, Grol can spend his reaction to make an additional Darksteel Greatsword attack against each target. Until his next turn, melee attacks against Grol have advantage (and he cannot make attacks of opportunity, due to no reaction).</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="4"><h2 id="cryovain-young-white-dragon"><strong>Cryovain (Young White Dragon)</strong></h2>
<p>Large Dragon, Chaotic Evil</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>17</strong></p>
<p>Hit Points: <strong>106+4d10</strong></p></th>
<th><p>STR: <strong>18 (+4)</strong></p>
<p>DEX: <strong>10 (+0)</strong></p>
<p>CON: <strong>18 (+4)</strong></p>
<p>INT: <strong>6 (-2)</strong></p>
<p>WIS: <strong>11 (+0)</strong></p>
<p>CHA: <strong>12 (+1)</strong></p></th>
<th colspan="2"><p>Skills: <strong>Perception +6, Stealth +3</strong></p>
<p>Saves: <strong>Dex +3, Con +7, Wis +3, Cha +4</strong></p>
<p>Senses: <strong>passive Perception 16, Darkvision 120ft, Blindsight 30ft</strong></p>
<p>Languages: Common, Draconic</p>
<p>Speed: <strong>40 ft., burrow 20ft, fly 80ft, swim 40ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="special-rules-1"><strong>Special Rules</strong></h3>
<p><strong>Ice Immune.</strong> Cryovain is immune to cold damage.</p>
<p><strong>Ice Walk.</strong> The dragon can walk across and climb icy surfaces without needing to make an ability check. Additionally, difficult terrain composed of ice or snow doesn’t cost extra movement.</p>
<h3 id="actions-1"><strong>Actions</strong></h3>
<p><strong>Multiattack:</strong> The dragon chooses one cinematic action or it makes three attacks: one with its bite, and two with its claws.</p>
<p><strong>Bite:</strong> +7 to hit, reach 10ft, one target. Hit: 15 (2d10+4) piercing damage plus 4 (1d8) cold damage. If the target is hit, it has advantage to hit the dragon on its next turn.</p>
<p><strong>Claw:</strong> +7 to hit, reach 5ft, one target. Hit: 11 (2d6+4) slashing damage.</p>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
</tbody>
</table></th>
<th colspan="2"><p><strong>Cinematic Actions</strong></p>
<p>Cryovain can use each of the following actions once per encounter.</p>
<p><strong>Ice Wing Blast:</strong> The dragon beats its wings. Each creature within 10 ft. of the dragon must succeed on a DC 15 Dexterity saving throw or take 13 (2d6 + 6) bludgeoning damage and be knocked prone. The dragon may then fly up to half its flying speed.</p>
<p><strong>Cold Breath:</strong> The dragon exhales an icy blast in a 30-foot cone. Each creature in that area must make a DC 12 Constitution saving throw, taking 16 (3d8 +4) cold damage on a failed save, or half as much on a successful one. Targets that fail, and are standing on slippery ice, are also Restrained until they pass a Strength saving throw DC 10, at the start of their turn.</p>
<p><strong>Strike the weak:</strong> The dragon may move up to 10ft along the ground without causing attacks of opportunity. It targets the creature it deems most weak. If there is a target it can kill, it will always choose this one. +7 to hit, reach 15ft, one target. Hit: 20 (5d6+4) piercing damage. The dragon also takes the Dodge action as a free action.</p>
<p><strong>Frightful Roar:</strong> If there are no enemies within 30ft of the dragon. Each creature of the dragon's choice that is within 120 feet of the dragon and aware of it must succeed on a DC 13 Wisdom saving throw or become Frightened for 1 minute. A creature can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.</p>
<p>Until the start of its next turn, all attacks against the dragon are made with advantage.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
