---
title: "Teylon - Warlock"
source: "Game Stuff/D&D/Teylon - Warlock"
modified: 2022-03-29
type: character
area: dnd
status: "unknown"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D characters"]
words: 529
summary: "Character sheet for Teylon, a level 3 Hexblade/Pact of the Blade warlock (stats, invocations, hex curse, equipment, spells known)."
tags: ["area/dnd", "project/d-d-homebrew", "type/character"]
---

# Teylon

# Pactbound

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +2      | +1      | +2      | 0       | +4      |
| 8       | 15      | 12      | 14      | 10      | 18      |

| **Armor Class** | **Hitpoints** | **Rest Dice** |
|-----------------|---------------|---------------|
| 17+2            | 45            | 5d8           |

### 

### Major Skills and Languages:

Arcana, Deception, Persuasion, Insight, Medicine

Languages: Common, Infernal, Gnomish, Elvish

Simple weapons, Light Armor, Medium armor, martial weapons, shields

Gambling (cards)

Saving throws: Wisdom, Charisma

Proficiency +3

### Resource Features

Spell slots 2

### Passive Features

### Eldritch Sight

You can cast detect magic at will, without expending a spell slot.

### Mask of Many Faces

You can cast disguise self at will, without expending a spell slot.

### 

###  

### Tomb of Levistus

As a reaction when you take damage, you can entomb yourself in ice, which melts away at the end of your next turn. You gain 10 temporary hit points per warlock level, which take as much of the triggering damage as possible. Immediately after you take the damage, you gain vulnerability to fire damage, your speed is reduced to 0, and you are incapacitated. These effects, including any remaining temporary hit points, all end when the ice melts.

Once you use this invocation, you can't use it again until you finish a short or long rest.

### Pact of the Blade

**As an action:** Create a pact weapon in your empty hand.

Pact weapon: You are proficient with it. Counts as magical.

Your pact weapon disappears if it is more than 5 feet away from you for 1 minute or more.

**As a 1hour ritual:** Transform one magic weapon into your pact weapon.

### Hexblade Curse

As a bonus action, choose one creature you can see within 30 feet of you. The target is cursed for 1 minute. The curse ends early if the target dies, you die, or you are incapacitated. Until the curse ends, you gain the following benefits:

- You gain a bonus to damage rolls against the cursed target. The bonus equals your proficiency bonus.

- Any attack roll you make against the cursed target is a critical hit on a roll of 19 or 20 on the d20.

- If the cursed target dies, you regain hit points equal to your warlock level + your Charisma modifier (minimum of 1 hit point).

You can't use this feature again until you finish a short or long rest.

###  

### Hex Warrior

When you attack with your pact weapon, you can use your Charisma modifier, instead of Strength or Dexterity, for the attack and damage rolls.

### Equipment

Arcane focus

Traveling Robe, Longsword

Mask of the Stubborn mind. Advantage on saving throws against being charmed or commanded.

Retractable Shield bracer. Bonus action to change from Shield to Bracer.

Breast plate

Silver powder for Magic Circle x2

Gemstone for Incite greed

### Spells

6 spells known, lvl 3

3 cantrips

Personality

Ideal

Everything in life is transactional

Bond

Flaw

I obey the law, even if the law causes misery.

White shield on blue background
