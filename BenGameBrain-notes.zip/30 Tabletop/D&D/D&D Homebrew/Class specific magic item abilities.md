---
title: "Class specific magic item abilities"
source: "Game Stuff/Class specific magic item abilities"
modified: 2022-07-26
type: homebrew-rules
area: dnd
status: "idea"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items", "D&D house rules"]
words: 696
summary: "Per-class brainstorm of magic item types, effect triggers and effects for D&D 5e classes (Monk through Ranger; Bard and Cleric empty)."
tags: ["area/dnd", "project/d-d-homebrew", "type/homebrew-rules"]
---

Monk

- Item types

  - Jewellery

  - Monk weapons: Tonfa, Kai, Quarterstaff

  - Robes, wraps, light clothing, shoes

- Effect triggers

  - When using deflect missile

  - When spending ki

  - When using patient defence

  - When using step of the wind

  - When you force a creature to move

  - Grapple or shove target

- Effects

  - Gain temp hit points

  - Next martial arts die upgraded

  - Martial arts die change damage type

  - Ki store

  - Steam rolling effects that grow in intensity

Paladin

- Item types

  - Sword and shield

  - Heavy armour, helm greaves, gauntlets

- Effect triggers

  - When using channel divinity

  - When spending a spell slot

  - When killing a creature of type X

  - When you take damage

- Effects

  - Empowered strikes

  - Temporary hit points

  - Force creatures to attack you

  - Give protection to others

  - Apply debuffs to target

Fighter

- Item types

  - Weapons and armor

  - Belts, boots and hats

- Effect triggers

  - Attack and hit

  - Opportunity attack

  - Spend bonus action after using attack action

- Effects

  - Gain maneuvers

  - Free movement

  - Resistance to damage

Druid

- Item types

  - Staves, wands

  - Heavy clothing

  - Totems and carvings

- Effect triggers

  - When using wild shape

  - When spending a spell slot

  - When casting a spell from their circle list

  - When you kill in your wild shape form

  - Spend hit dice

- Effects

  - Wildshape evolutions

  - Wildshape spend for other effects

  - Direct wildshape swap without changing back

  - Learn monster wildshapes

Wizard

- Items types

  - Wands, staves, orbs

  - Spell books, apparatus

  - Robes, light clothing, hats

- Effect triggers

  - When you cast a spell

  - Spend your reaction

- Effects

  - Reduce spell components

  - Convert spell slots

  - Learn spells easier

  - Copy spell scrolls

  - Create spell scrolls

  - Use spells outside your class

  - School spell bonuses

Sorcerer

- Item types

  - Charms, light clothing

  - Armor

- Effect triggers

  - Spend meta magic

  - Use specific meta magic ability

  - Spend sorcery points

  - Reaction

  - Kill with spell

- Effects

  - Enhance meta magic

  - Recharge sorcery points

  - Free Movement

  - Focus spell slots

  - More spell slot recharge on short rest

Warlock

- Item types

  - Charms

  - Wands, staves, blades

- Effect triggers

  - Creatures unser effect of your spells

  - Creatures killed by you

  - Spend a hit die

- Effects

  - Give temp hit points

  - Stop healing

  - Spells cast at higher level

  - Damage reflection

Barbarian

- Item Types

  - Weapons, all of them

  - Belts, Boots, ect

- Effect Triggers

  - When you Rage

  - When you leave Rage

  - When you take damage

  - When you are knocked unconscious

  - Spend a hit die

- Effects

  - Resistances

  - Movement

  - Hit dice to damage

  - Saving throw bonuses

  - Immunity to being moved

Rogue

- Item types

  - Ranged weapons

  - Melee weapons with the Light or Finesse property

  - Tools, cloaks, boots

- Effect triggers

  - When you pass/fail a stealth check

  - When you deal sneak attack damage

  - When you pass/fail a skill test

  - When you move

  - When you trigger an opportunity attack

  - When you use Cunning Action

- Effects

  - Skill check bonuses

  - Downgrade/Immunity from Critical hits

  - Teleports

  - Immunity to opportunity attacks

Artificer

- Item types

  - Anything really

- Effect triggers

  - When you drink a potion

  - Skill test success/fail

  - Craft an item

  - Take damage

  - Your companion attacks

- Effects

  - Magical tinkering options

  - Infusion options

  - Infusion amounts

  - Multi tool

Ranger

- Item types

  - Bows, Swords

  - Light armor, cloaks

  - Pet armor

- Effect triggers

  - When your pet attacks

  - When you use hunters mark

  - When you hit your marked target

  - When you are fighting against your favored enemy

  - When you are within range of your pet

- Effects

  - Initiative bonuses

  - Ambush chance up

  - Teleports/teleport your pet

  - Pet actions

  - Apply conditions

Bard

Cleric
