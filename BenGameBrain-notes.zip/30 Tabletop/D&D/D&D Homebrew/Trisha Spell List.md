---
title: "Trisha Spell List"
source: "Game Stuff/D&D/Trisha Spell List"
modified: 2023-09-21
type: reference-data
area: dnd
status: "unknown"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D characters"]
words: 381
summary: "Spell list for Trisha; only an empty table placeholder survived conversion."
tags: ["area/dnd", "project/d-d-homebrew", "type/reference-data"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="blade-ward">Blade Ward</h2></th>
<th><h2 id="erase">Erase</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Reaction</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>1 round.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>When you are hit by an attack, you extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30ft</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (Any writing implement)</strong></p>
<p>You remove writing from a single scroll, one page of paper, a sheet of parchment, or a similar surface that you can see within range that is no larger than a 2-foot-square area.</p>
<p>This spell can also automatically remove a glyph of warding or a glyph created by the symbol spell. If the glyph was created using a spell slot of 4th level or higher, you must make an ability check using your spellcasting ability. The DC equals 10 + the spell's level. On a successful check, the glyph is erased.</p></th>
</tr>
<tr class="header">
<th><h3 id="cantrip">Cantrip</h3></th>
<th><h3 id="level-1">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="charmalaines-kiss">Charmalaine’s Kiss</h2></th>
<th><h2 id="mending">Mending</h2></th>
</tr>
<tr class="header">
<th><h3 id="section"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-illusion">School: Illusion</h3>
<h3 id="casting-time-1-reaction">Casting time: 1 Reaction</h3>
<h3 id="section-1"></h3></th>
<th><h3 id="range-60ft">Range: 60ft</h3>
<h3 id="duration-instantaneous">Duration: Instantaneous</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-2"></h3>
<h3 id="components-v">Components: V</h3>
<h3 id="section-3"></h3>
<p>When a creature you can see within 60 feet of yourself succeeds on an attack roll, an ability check, or a saving throw you magically distract the triggering creature and turn its momentary uncertainty into encouragement for another creature. The triggering creature must reroll the d20 and use the lower roll.</p>
<p>You can then choose a different creature you can see within range (you can choose yourself). The chosen creature has advantage on the next attack roll, ability check, or saving throw it makes within 1 minute. A creature can be empowered by only one use of this spell at a time.</p>
<h3 id="section-4"></h3></th>
<th><h3 id="section-5"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-transmutation">School: Transmutation</h3>
<h3 id="casting-time-1-minute">Casting time: 1 minute</h3>
<h3 id="section-6"></h3></th>
<th><h3 id="range-touch">Range: Touch</h3>
<h3 id="duration-instantaneous-1">Duration: Instantaneous</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-7"></h3>
<h3 id="components-v-s-m-two-lodestones">Components: V, S, M (two lodestones)</h3>
<h3 id="section-8"></h3>
<h3 id="this-spell-repairs-a-single-break-or-tear-in-an-object-you-touch-such-as-broken-chain-link-two-halves-of-a-broken-key-a-torn-cloak-or-a-leaking-wineskin.-as-long-as-the-break-or-tear-is-no-larger-than-1-foot-in-any-dimension-you-mend-it-leaving-no-trace-of-the-former-damage.">This spell repairs a single break or tear in an object you touch, such as broken chain link, two halves of a broken key, a torn cloak, or a leaking wineskin. As long as the break or tear is no larger than 1 foot in any dimension, you mend it, leaving no trace of the former damage.</h3>
<h3 id="this-spell-can-physically-repair-a-magic-item-or-construct-but-the-spell-cant-restore-magic-to-such-an-object.">This spell can physically repair a magic item or construct, but the spell can't restore magic to such an object.</h3>
<h3 id="section-9"></h3></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-1">Level 1</h3></th>
<th><h3 id="cantrip-1">Cantrip</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
