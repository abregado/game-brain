---
title: "Thokk Abilities"
source: "Game Stuff/D&D/Thokk Abilities"
modified: 2020-05-08
type: homebrew-rules
area: dnd
status: "designed"
projects: ["[[D&D Homebrew]]"]
concepts: ["D&D homebrew items", "D&D characters"]
words: 222
summary: "Homebrew 'Combat Trance' ability for the character Thokk (paralysed then rage-like trance with resistances, removed at level 6) plus a Paralyzed condition reminder."
tags: ["area/dnd", "project/d-d-homebrew", "type/homebrew-rules"]
---

### Combat Trance

**Action:** You gain the Paralysed condition until the start of your next turn. At the start of your next turn take a Wisdom test (DC 10). On a success you begin the trance.

While in a trance:

- You have advantage on Strength checks and Strength saving throws.

- When you make an attack using Strength, you gain a +1 bonus to the damage roll.

- You have resistance to bludgeoning, piercing, and slashing damage.

If you are able to cast spells, you can’t cast them or concentrate on them while in a trance.

Your trance lasts for 1 minute. It ends early if you are knocked unconscious or if your turn ends and you haven’t attacked a hostile creature since your last turn or taken damage since then.

You can also end your trance on your turn as a bonus action.

Once you have entered the trance, you cannot enter it again until you finish a long rest.

This ability is removed when you reach level 6.

**Paralyzed (Condition):** A paralyzed creature is incapacitated (see the condition) and can’t move or speak, the creature automatically fails Strength and Dexterity Saving Throws. Attack rolls against the creature have advantage. Any Attack that hits the creature is a critical hit if the attacker is within 5 feet of the creature.
