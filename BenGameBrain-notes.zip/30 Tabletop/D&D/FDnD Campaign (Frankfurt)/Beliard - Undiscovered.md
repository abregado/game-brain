---
title: "Beliard - Undiscovered"
source: "Game Stuff/D&D/FDnD Files/Beliard - Undiscovered"
modified: 2020-04-25
type: reference-data
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)", "FDnD campaign", "Beliard"]
words: 703
summary: "Town write-up for Beliard in the Dessarin Valley (shops, travel times) exported from a campaign tool, and a list of replacement PC ideas."
contains_external_material: "Beliard description text copied from published Wizards of the Coast material (Storm King's Thunder); the NPC list at the end is Ben's"
merged_versions: ["Game Stuff/D&D/FDnD Files/Undiscovered - Beliard"]
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/reference-data"]
---

# Beliard

Town

One of the more pleasant-looking villages in the Dessarin Valley thanks to its many trees, Beliard is a market-moot for local cattle drovers. It surrounds the intersection of the Dessarin Road with the Stone Trail. Beliard is home to many cattle ranchers whose herds roam the hills around it, particularly to the east. The village offers a public well, as well as a pond where

harnessed horses or oxen can be driven through the water to bathe them, drive off flies, and let them drink. It's also home to a tanner, a smith, some horse dealers and trainers who keep extensive stables, and an inn: the venerable, popular, and several-times-expanded Watchful Knight.

## Unplaced NPCs

None

## Locations

None

## Unvisited Locations

### Watchful Knight (Inn)

This patchwork building has obviously been expanded many times over the years.

### Ornra Butchery and Jail (Business)

Four identical single-story stone buildings, running back from the street in a line. The front building has a painted sign of a ham being carved by a cleaver, accompanied by no words.

### Luruth’s Tannery (Business)

The only tannery in a town dedicated to livestock. The building shows how successful this business must be with its well maintained facade and expensive fittings.

### Tarnlar’s Fine Vestments

The square two-story building stands at the center of town. Its signboard is painted with the images of a well-dressed lord and lady, one on each side of the board. Ornate scrollwork iron bars protect the windows.

### Vallivoe’s Sundries (General store)

Aside from the bewildering profusion of doors, barrels,

rotting old furniture, and tools leaning against its

outside walls, this building looks like a private home.

## Travel Times

| **Destination**                                                                               | **Trail type**     | **Distance**       |
|-----------------------------------------------------------------------------------------------|--------------------|--------------------|
| [*Westbridge*](https://drive.google.com/open?id=1uCMZbNF4boMkIdK-dfg9E6Af9qM5gSW_nBND_-hUHr0) | Rough road         | 36 miles           |
| Red larch                                                                                     | Rough road         | 44 miles           |
| Summit Hall                                                                                   | Rough road         | 28 miles           |
| Womford                                                                                       | Rough road         | 64 miles           |
| Stone Bridge                                                                                  | Rough road         | 8 miles            |
| Yatar                                                                                         | Rough road / River | 8 miles / 68 miles |
| Ironford                                                                                      | Rough road / River | 8 miles / 76 miles |

---

## Differences from other versions

_This document existed in several versions. The text above is the most complete one, unchanged. Below are the lines that appear only in the other versions._

### Only in “Undiscovered - Beliard” (D&D, modified 2020-04-12)

# Undiscovered Beliard
**NPCs**
Garlen Harkathurl - Owner
Justin Daehl - Owner - Crushing Wave Informant
| **Service**                                      | **Cost** |
|--------------------------------------------------|----------|
| Single Bed, Board and Meal (per room, per night) | 1gp      |
| Stabling and Feed (per animal, per night)        | 1gp      |
Four identical single-story stone buildings, running back from the
street in a line. The front building has a painted sign
of a ham being carved by a cleaver, accompanied by
no words.
**NPCs**
Jalessa Ornra - Butcher/Owner
Harburk Tuthmarillar - Sherrif/Worker
**NPCs**
Ulric Luruth - Owner - Beleiver
The square two-story building
stands at the center of town. Its signboard is painted with the images
of a well-dressed lord and lady, one on each side of the
board. Ornate scrollwork iron bars protect the windows.
**NPCs**
Henry Tarnlar - Owner
Megan Tarnlar - Owner
**NPCs**
Edgar Vallivoe - Owner
Has one of Brulthendars books
