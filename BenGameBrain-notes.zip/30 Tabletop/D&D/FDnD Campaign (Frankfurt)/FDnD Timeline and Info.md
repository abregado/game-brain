---
title: "FDnD Timeline and Info"
source: "Game Stuff/D&D/FDnD Timeline and Info"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign (Frankfurt)", "Forgotten Realms Timeline"]
words: 307
summary: "Forgotten Realms historical timeline up to 1482 DR plus a day-by-day outline of the party's 1482 campaign events from Neverwinter through Phandalin, Cragmaw Castle, Wave Echo Cave and Thundertree."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

### Historical events

-7800 Calim Empire founded

-4420 Dwarven nation of Besilmer founded

-4320 Construction of Tyar-Besil

-4160 Tyar-Besil abandoned

-3900 Delzoun nation founded

-100 Delzoun nation disbanded

893 Founding of the Haunted Keeps by Knights of the Silver Horn

951 Phandalin/Wave echo cave overrun by Orcs

1385 Spellplague

1452 Eruption of Mount Hotenow

1477 Phandalin rebuilt

1479 Last battle of Skyfire in Calisham, destroys the city of Suldolphor (150,000 souls lost)

1481 Hama leaves Calisham to come to Phandalin

1482 Present year - Bhaal returns and ascends

### 1482 Timeline

- Evening: Bar fight and Gundren asks the party to take the mission

- Party leaves Neverwinter with the caravan

- 2

- 3

- Midday: Goblin ambush, Afternoon: Goblin Hideout, Evening: Camped at road

- Morning: Arrive in Phandalin, Evening: Redbrands terrorize Alderleaf farm

- Afternoon: Sildar gives a speech, Hama and Thokk join the party. Evening: Raid on Redbrands complete

- Morning: Party sets out for Cragmaw Castle

- 2

- Afternoon: Party arrives at Cragmaw Castle, scouts it

- Morning: Party sneaks into Cragmaw Castle, defeats Grol and rescues Gundren. Afternoon: leave for Phandalin

- 2

- Midday: Forest chase with Doppleganger

- Evening: Arrive Phandalin

- 2

- Evening: Festival, Livias Gift

- Morning: Leave for Wave Echo cave.

- Midday: Arrive at Wave echo cave, Evening: return to Gundrens camp

- Morning: re-enter Wave Echo Cave, Evening: return after defeating Spider

- Rest

- Morning: Leave for Neverwinter

- 2

- 3

- Midday: Arrive Neverwinter

- Shopping

- Shopping

- Evening: Theatre

- Shopping

- Morning: leave for Thundertree

- Evening: Meet Favric

- Morning: Explore Thundertree, defeat Venomfang, Evening: stay with Reidoth

- Morning: Leave for Neverwinter

- Morning: Arrive Neverwinter, Hire heroes to guard Thundertree

- Morning: Leave for Phandalin

- 2

- 3

- Midday: Arrive Phandalin
