---
title: "FDnD Notes"
source: "Game Stuff/D&D/FDnD Notes"
modified: 2020-04-12
type: notes
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Feathergale Spire"]
words: 174
summary: "Short notes on the Feathergale Society, Thurl Merosska, the Red Larch and Beliard battles, Dessarin raiders and the flying hunt."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/notes"]
---

### Thurl Merosska

Leader since 5 years

Very controlling leader

Had issues with lies from an underling

### Feathergale Society

There has been two battles, one in Red Larch, one in Beliard

Trisha suspects they are not telling the truth about missing people

The Feathergale knights will take care of the Red larch quarry

Thurl said Gnolls live in the canyon

Peryton was attacked by a manticore

There seems to be some hierarchy, and internal mistrust

### Red Larch battle

One Feather cloak guy

One stone cloak guy

Two mirabarens

### Beliard Battle

The diplomats might have been in a fight

Corpses from the Beliard fight were removed

Some of the servants might have some of these cloaks(?)

### Dessarin River

Raiders on the Dessarin river between Yatar and Ironford

### The hunt

Griffon - Hama + Best pilot

Hippogriff - Trisha + Livia

Giant Vulture - Thokk

Hippogriff - Kildrak + Knight

Signet ring with HUUUUGE gem (precious) for prize to winner

Towns and Locations

Triboar

Wesbridge

Red larch

Beliard

Ironford/Womford

Yatar

NPCS
