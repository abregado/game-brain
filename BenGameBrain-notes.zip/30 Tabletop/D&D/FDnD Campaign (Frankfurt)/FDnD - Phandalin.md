---
title: "FDnD - Phandalin"
source: "Game Stuff/D&D/FDnD - Phandalin"
modified: 2020-02-23
type: reference-data
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign (Frankfurt)", "D&D homebrew items"]
words: 218
summary: "Phandalin town reference: list of shops and NPCs from Lost Mine of Phandelver, shop price lists and spell service costs."
contains_external_material: "NPC names from published module Lost Mine of Phandelver; prices Ben-adapted"
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/reference-data"]
---

Miners Exchange

Halia Thornton

Lionshield Coster

Linene Greywind

Barthans Provisions

Elmar Barthan

Shine of Luck

Sister Garaele

| **Item Name**      | **Price** | **Item Name**                        | **Low** |
|--------------------|-----------|--------------------------------------|---------|
| Holy Symbol        | 5g        | Potion of Healing (vial)             | 50g     |
| Spell Components   | x1.5      | Draught of Stamina (vial)            | 25g     |
| Glass Flask/Bottle | 1g        | Flask of Oil                         | 15s     |
| Glass Vial         | 1g        | Vial of Acid                         | 25g     |
| Herbalism Kit      | 5g        | Vial of Antitoxin                    | 50g     |
| Poisoner's Kit     | 50g       | Sheet of parchment                   | 1s      |
| Healer's Kit       | 5g        | Spell Charm (Guidance or Resistance) | 70g     |
| Brewers Supplies   | 20g       | Spell Scroll (Cleric Spells)         | 100gp   |

| **Spell Services** | **Level** | **Cost** |
|--------------------|-----------|----------|
| Cure Wounds        | 1         | 10g      |
| Gentle Repose      | 2         | 50g      |
| Lesser Restoration | 2         | 50g      |
| Remove Curse       | 3         | 100g     |
| Revivify           | 3         | 400g     |
| Raise Dead         | 5         | 1000g    |

Ratimir Carpentry

Suzannah Ratimir

-Small house (2 work weeks, 500g)

Stonehill Tavern

Toblen Stonehill

Townmasters Hall

Sildar Hallwinter

Iarno Albrek

Edermath Apples and Citrus

Daran Edermath

Phandelver Mine and Forge

Gundren Rockseeker
