---
title: "FDnD Lazahra Timeline"
source: "Game Stuff/D&D/FDnD Lazahra Timeline"
modified: 2022-05-20
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["Lazahra", "Dragon of Icespire Peak", "D&D homebrew items", "FDnD campaign"]
words: 894
summary: "Session prep notes for Lazahra's storyline around Icespire Peak: Icespire Hold orc/dragon encounter, cinematic dragon attacks, session 7 abbey notes, Destiny's Vision with three futures, and a day-by-day timeline of the Dragon of Icespire Peak adventure."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

Icespire Hold

- You have been tracking the remaining orcs since you routed them at the Stone Circle.

- You have seen that they can summon creatures using animal hearts.

- Orcs have a dead green dragons heart to perform a summoning ritual.

- The orc stragglers made their way to a fortified Abbey

- They met up with a small army of orcs and ogres.

- An hour after they arrived, a small scouting party of orcs left the Abbeyand headed up the mountain

- The rest of the camp began mobilizing.

- Knowing they are going after the dragon.

- You decided to try and beat them up the mountain.

Cinematic Attacks

- Tail slap. Take 10 bludgeoning damage. Contested Strength test. Pass, thrown 15ft. Fail, 30ft. Dex save to not fall off if thrown too far.

- Readied Blast. Disengage, move off the edge of the castle. Ready action for free to breath attack at half efficiency if someone approaches the edge.

- Ice layer. Reaction if the dragon is not yet alerted and attacked. Adds 50 temporary hitpoints to the dragon which melt at the start of its turn. It gains vulnerability to fire damage during this time.

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><p>Path and Gatehouse</p>
<p>Exploration</p>
<p>Orcs go straight into the main castle through a hole in the side (h10)</p>
<p>Notice the secret entrance</p></th>
</tr>
<tr class="odd">
<th><p>Gatehouse</p>
<p>Roleplay</p>
<p>Iron Alarm Bell in tower</p></th>
<th><p>Ruined Entrance to main castle</p>
<p>Exploration</p>
<p>Notice the secret entrance underneath</p></th>
</tr>
<tr class="header">
<th colspan="2"><p>Main Castle</p>
<p>Exploration</p>
<p>Let the orcs complete the ritual, or attack them here</p>
<p>Describe each room, noticing which rooms the dragon could get into</p>
<p>Notice crypts automatically</p></th>
</tr>
<tr class="odd">
<th colspan="2"><p>Castle Roof</p>
<p>Combat</p>
<p>Frozen armored wagon</p>
<p>Slippery ice covering scattered gold coins</p>
<p>Short tower</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Cool things that can happen

- The dragon stalks them through the keep

- The demon begins to be summoned. A “hole” in ground opens and horns appear

- The characters learn the dragon can dig

- The characters discover the fireplaces

- The orcs set up an Earthbind ritual under the dragon.

- The dragon snatches an Ogre and brings it back to the keep.

- The players discover the secret crypt

- The characters discover some starved orcs in the gatehouse.

- Evidence of orcs living here are all around.

- Orcs freezer in H18.

Session 7

Lazarah is tracking the orcs, they arrive at the Abbey

The heart is strapped to an Ogre and a group leaves the Abbey towards the north.

The Half orc priest performs a ritual leaving a mark on the grass, then leaves with the group.

12 orcs, 1 ogre and the half orc priest leave in the party. Falcon leaves to track the group.

Choice, stay or go?

Things to explore in the Abbey

- Yard + Towers

  - An ogre stays in each tower, waiting for noise.

- Guardtower

  - An orc keeps watch from here.

- Bell Tower

  - Trap setup

- Main hall + Sanctuaries

  - Tapestries

  - Gaps in walls that you can slip through. Too big for an ogre.

- Reliquary

  - Altar with a wooden rod.

Destiny's Vision

You have a vision. You are flying up the Sword Mountains to a Keep. Something sparkles on the roof so you fly lower. A white dragon sleeps on the roof of the keep, wrapped around a caravan which is completely encased in ice. The entire floor has been covered in perfectly clear ice. The ice floor has thousands of gold coins frozen within it, creating a beautiful sparkle.

You see three futures.

You see a powerful demon fighting the dragon, supported by a horde of orcs. The dragon is defeated but kept alive. A ritual begins using its still beating heart, which opens a portal. Within the portal is indescribable storm of horror.

You see the demon defeated by the dragon, behind it the horde of orcs is frozen solid. The demon howls as it is sent back to the Abyss.

You see yourself standing by the corpse of the dragon, knowing your task is complete and wishing to go home.

Things to learn in session 6

- Half orc priests are responsible for the dark magic

- The priests are going to summon something

- The dragon was here to get something from the Manse

- A map to the Dragon Barrows

- The orcs have fled from the dragon and are working with the half orcs

- There is a summoning circle north of the Manse

- The location of the dragon (diving magic?)

- The location of Falcons hunting lodge

- The half orcs can change into bears and summon lightning magic

Timeline

- Arrive Phandalin, Leave for Excavation

- Morning: Arrive Excavation, Clear Excavation, Meet Dragon

- Save the Midwife, Stay with midwife

- Morning: Arrive Phandalin. Recruit Nightbreeze, rest

- Morning leave for Logging Camp,

- Afternoon arrive at Camp, Evening: Finish at Logging camp

- Morning: Leave for Gold Mine

- Morning: Arrive Gold Mine, Meet miners, Meet Wererats. Evening: Fight Carrion Crawler

- Morning: Leave for Conyberry, Investigate dragon sighting. Afternoon: Arrive Conyberry

- Morning: meet Nightbreeze, head to Butterskull Ranch. Evening: Storm and Finish saving Kalazorn.

- Morning: Leave for Woodland Manse (Dragon spotted)

- Midday: Arrive at Manse, encounter Dragon

- Evening: Arrive at Falcons lodge

- Day: Visit Stone Circle. Fight orcs

- Evening: Stealth camped at the Abbey
