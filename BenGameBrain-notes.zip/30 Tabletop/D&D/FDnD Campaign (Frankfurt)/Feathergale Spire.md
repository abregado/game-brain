---
title: "Feathergale Spire"
source: "Game Stuff/D&D/FDnD Files/Feathergale Spire"
modified: 2020-04-17
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Feathergale Spire"]
words: 156
summary: "Location sheet for Feathergale Spire: NPCs of the Feathergale Society, creatures encountered, and travel times by air."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Feathergale Spire

Location

**[Feathergale Spire](#feathergale-spire) 1**

> [NPC’s](#npcs) 1
>
> [Creatures encountered](#creatures-encountered) 1
>
> [Travel Times](#travel-times) 1

## NPC’s

Thurl Merosska - Lord Commander of the Feathergale Society

Military Leader. Been the Lord Commander for the last 5 years.

Savras Belabranta - Feathergale initiate

Young. New to the Feathergale society. Parents are nobles in Waterdeep.

Alonso - Feathergale Zoologist - Trishas friend

Feathergale Racing enthusiast

Feathergale Knights (numerous)

## Creatures encountered

Griffon

Hippogriff

Giant Vulture

Peryton

## Travel Times

| **Destination**                                                                              | **Trail type**              | **Distance**      |
|----------------------------------------------------------------------------------------------|-----------------------------|-------------------|
| [*Red Larch*](https://drive.google.com/open?id=1wcjSAWDDWge1mE8a7sJpAbnohWBWT0u4FA-K-CXgo2c) | Rough road / Mountain Trail | 8 miles / 4 miles |
| Red Larch                                                                                    | Air travel                  | 10 miles          |
| Summit Hall                                                                                  | Air travel                  | 25 miles          |
| Beliard                                                                                      | Air travel                  | 27 miles          |
| Ironford                                                                                     | Air travel                  | 30 miles          |
| Westbridge                                                                                   | Air travel                  | 34 miles          |

[*Undiscovered Triboar*](https://drive.google.com/open?id=1MI0gDCDyQLy6xgzqHWlkZOstEhn7UpifmvgktABjv_8)
