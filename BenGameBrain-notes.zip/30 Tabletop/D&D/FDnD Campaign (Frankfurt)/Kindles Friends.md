---
title: "Kindles Friends"
source: "Game Stuff/D&D/Kindles Friends"
modified: 2023-09-30
type: character
area: dnd
status: "unknown"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 477
summary: "Nearly empty; only unreadable tables, presumably NPC friends of the character Kindle."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="5"><p><strong>Tiny Servant</strong></p>
<p>Tiny Construct, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>15</strong></p>
<p>Hit Points: <strong>10</strong></p></th>
<th><p>STR: <strong>-3</strong></p>
<p>DEX: <strong>+3</strong></p>
<p>CON: <strong>+0</strong></p></th>
<th><p>INT: <strong>-4</strong></p>
<p>WIS: <strong>+0</strong></p>
<p>CHA: <strong>-5</strong></p></th>
<th colspan="2"><p>Senses: <strong>blindsight 60ft (blind beyond)</strong></p>
<p>Speed: <strong>30 ft. Climbing 30ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><p><strong>Damage Immunities:</strong></p>
<p>poison, psychic</p>
<p><strong>Condition Immunities:</strong></p>
<p>Blinded, charmed, deafened, exhaustion, frightened, paralyzed, petrified, poisoned</p></th>
<th colspan="3"><p><strong>Actions</strong></p>
<p><strong>Slam.</strong> <em>Melee Weapon Attack</em>: +5 to hit, reach 5 ft., one target. Hit: 5 bludgeoning damage</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="5"><p><strong>Clay Construct</strong></p>
<p>Medium Construct, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>13 + the level of the spell</strong></p>
<p>Hit Points: <strong>40 + 15 for each spell level above 4th</strong></p></th>
<th><p>STR: <strong>+4</strong></p>
<p>DEX: <strong>+0</strong></p>
<p>CON: <strong>+4</strong></p></th>
<th><p>INT: <strong>+2</strong></p>
<p>WIS: <strong>+0</strong></p>
<p>CHA: <strong>-3</strong></p></th>
<th colspan="2"><p>Senses: <strong>darkvision 60ft</strong></p>
<p>Speed: <strong>30 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><p><strong>Damage Resistances:</strong></p>
<p>poison</p>
<p><strong>Condition Immunities:</strong></p>
<p>Blinded, charmed, deafened, exhaustion, frightened, paralyzed, petrified, poisoned</p></th>
<th colspan="3"><p><strong>Actions</strong></p>
<p><strong>Multiattack:</strong> The construct makes a number of attacks equal to the spells level (round down)</p>
<p><strong>Slam.</strong> <em>Melee Weapon Attack</em>: spell attack modifier to hit, reach 5 ft., one target. Hit: 8 + spell level bludgeoning damage</p>
<p><strong>Reaction</strong></p>
<p><strong>Berserk Lashing:</strong> When the construct takes damage, it makes a slam attack against a random creature within 5 feet of it. If no creature is within reach, the construct moves up to half its speed toward an enemy it can see, without provoking opportunity attacks.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="5"><p><strong>Metal Construct</strong></p>
<p>Medium Construct, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>13 + the level of the spell</strong></p>
<p>Hit Points: <strong>40 + 15 for each spell level above 4th</strong></p></th>
<th><p>STR: <strong>+4</strong></p>
<p>DEX: <strong>+0</strong></p>
<p>CON: <strong>+4</strong></p></th>
<th><p>INT: <strong>+2</strong></p>
<p>WIS: <strong>+0</strong></p>
<p>CHA: <strong>-3</strong></p></th>
<th colspan="2"><p>Senses: <strong>darkvision 60ft</strong></p>
<p>Speed: <strong>30 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><p><strong>Damage Resistances:</strong></p>
<p>poison</p>
<p><strong>Condition Immunities:</strong></p>
<p>Blinded, charmed, deafened, exhaustion, frightened, paralyzed, petrified, poisoned</p></th>
<th colspan="3"><p><strong>Actions</strong></p>
<p><strong>Multiattack:</strong> The construct makes a number of attacks equal to the spells level (round down)</p>
<p><strong>Slam.</strong> <em>Melee Weapon Attack</em>: spell attack modifier to hit, reach 5 ft., one target. Hit: 8 + spell level bludgeoning damage</p>
<p><strong>Special Ability</strong></p>
<p><strong>Heated Body:</strong> A creature that touches the construct or hits it with a melee attack while within 5 feet of it takes 1d10 fire damage.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="5"><p><strong>Stone Construct</strong></p>
<p>Medium Construct, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>13 + the level of the spell</strong></p>
<p>Hit Points: <strong>40 + 15 for each spell level above 4th</strong></p></th>
<th><p>STR: <strong>+4</strong></p>
<p>DEX: <strong>+0</strong></p>
<p>CON: <strong>+4</strong></p></th>
<th><p>INT: <strong>+2</strong></p>
<p>WIS: <strong>+0</strong></p>
<p>CHA: <strong>-3</strong></p></th>
<th colspan="2"><p>Senses: <strong>darkvision 60ft</strong></p>
<p>Speed: <strong>30 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><p><strong>Damage Resistances:</strong></p>
<p>poison</p>
<p><strong>Condition Immunities:</strong></p>
<p>Blinded, charmed, deafened, exhaustion, frightened, paralyzed, petrified, poisoned</p></th>
<th colspan="3"><p><strong>Actions</strong></p>
<p><strong>Multiattack:</strong> The construct makes a number of attacks equal to the spells level (round down)</p>
<p><strong>Slam.</strong> <em>Melee Weapon Attack</em>: spell attack modifier to hit, reach 5 ft., one target. Hit: 8 + spell level bludgeoning damage</p>
<p><strong>Special Ability</strong></p>
<p><strong>Stony Lethargy:</strong> When a creature the construct can see starts its turn within 10 feet of the construct, the construct can force it to make a Wisdom saving throw against your spell save DC. On a failed save, the target can't use reactions and its speed is halved until the start of its next turn.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
