---
title: "Kindle - Kenku"
source: "Game Stuff/D&D/Kindle - Kenku"
modified: 2022-03-29
type: character
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 66
summary: "Short character sheet for Kindle, a kenku wizard (stats, skills, background, cantrips)."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

Wizard

Str 8

Dex 14

Con 10

Int 18

Wis 14

Char 12

deception, stealth

[*History*](https://www.dndbeyond.com/compendium/rules/basic-rules/using-ability-scores#History)

[*Investigation*](https://www.dndbeyond.com/compendium/rules/basic-rules/using-ability-scores#Investigation)

Insight, perception

Language: Common/Auran/Infernal

Proficient with Card Games

Background: Far Traveller.

Feature: All Eyes on you.

Piece of jewelry

Quarterstaff

Arcane focus from the Master - Triangle

Scholars Pack - paper, ink, quill

Observant - Lip reading

+5 passive intelligence(investigation) and wisdom(perception)

Cantrips

Firebolt

Control Flame

Prestiditation

Dancing Lights
