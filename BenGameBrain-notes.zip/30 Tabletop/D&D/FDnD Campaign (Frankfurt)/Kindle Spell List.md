---
title: "Kindle Spell List"
source: "Game Stuff/D&D/Kindle Spell List"
modified: 2023-02-17
type: character
area: dnd
status: "unknown"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 2670
summary: "Nearly empty; only unreadable spell tables for the character Kindle."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="private-sanctum">Private Sanctum</h2></th>
<th><h2 id="summon-construct">Summon Construct</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>10 Minutes</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>24 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M</strong></p>
<p>You make an area within range magically secure. The area is a cube that can be as small as 5 feet to as large as 100 feet on each side. The spell lasts for the duration or until you use an action to dismiss it.</p>
<p>When you cast the spell, you decide what sort of security the spell provides, choosing any or all of the following properties:</p>
<ul>
<li><blockquote>
<p>Sound can't pass through the barrier at the edge of the warded area.</p>
</blockquote></li>
<li><blockquote>
<p>The barrier of the warded area appears dark and foggy, preventing vision (including darkvision) through it.</p>
</blockquote></li>
<li><blockquote>
<p>Sensors created by divination spells can't appear inside the protected area or pass through the barrier at its perimeter.</p>
</blockquote></li>
<li><blockquote>
<p>Creatures in the area can't be targeted by divination spells.</p>
</blockquote></li>
<li><blockquote>
<p>Nothing can teleport into or out of the warded area.</p>
</blockquote></li>
<li><blockquote>
<p>Planar travel is blocked within the warded area.</p>
</blockquote></li>
</ul>
<p>Casting this spell on the same spot every day for a year makes this effect permanent.</p>
<p><strong>At Higher Levels</strong>: When you cast this spell using a spell slot of 5th level or higher, you can increase the size of the cube by 100 feet for each slot level beyond 4th. Thus you could protect a cube that can be up to 200 feet on one side by using a spell slot of 5th level.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (ornate object worth 400gp)</strong></p>
<p>You call forth the spirit of a construct. It manifests in an unoccupied space that you can see within range. This corporeal form uses the Construct Spirit stat block. When you cast the spell, choose a material: Clay, Metal, or Stone. The creature resembles a golem of your choice made of the chosen material, which determines certain traits in its stat block. The creature disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The creature is an ally to you and your companions. In combat, the creature shares your initiative count, but it takes its turn immediately after yours. It obeys your verbal commands (no action required by you). If you don't issue any, it takes the Dodge action and uses its move to avoid danger.</p>
<p><strong>At Higher Levels</strong>: When you cast this spell using a spell slot of 4th level or higher, use the higher level wherever the spell's level appears in the stat block.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4">Level 4</h3></th>
<th><h3 id="level-4-1">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="control-flames">Control Flames</h2></th>
<th><h2 id="mending">Mending</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p>
<p><strong>or 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>You choose a non-magical flame that you can see within range and that fits within a 5-foot cube. You affect it in one of the following ways:</p>
<ul>
<li><blockquote>
<p>You instantaneously expand the flame 5 feet in one direction, provided that wood or other fuel is present in the new location.</p>
</blockquote></li>
<li><blockquote>
<p>You instantaneously extinguish the flames within the cube.</p>
</blockquote></li>
</ul>
<ul>
<li><blockquote>
<p>You double or halve the area of bright light and dim light cast by the flame, change its color, or both. The change lasts for 1 hour.</p>
</blockquote></li>
<li><blockquote>
<p>You cause simple shapes—such as the vague form of a creature, an inanimate object, or a location—to appear within the flames and animate as you like. The shapes last for 1 hour.</p>
</blockquote></li>
</ul>
<p>If you cast this spell multiple times, you can have up to three non-instantaneous effects created by it active at a time, and you can dismiss such an effect as an action.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Minute</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (two lodestones</strong></p>
<p>This spell repairs a single break or tear in an object you touch, such as broken chain link, two halves of a broken key, a torn cloak, or a leaking wineskin. As long as the break or tear is no larger than 1 foot in any dimension, you mend it, leaving no trace of the former damage.</p>
<p>This spell can physically repair a magic item or construct, but the spell can't restore magic to such an object.</p></th>
</tr>
<tr class="header">
<th><h3 id="cantrip">Cantrip</h3></th>
<th><h3 id="cantrip-1">Cantrip</h3></th>
</tr>
<tr class="odd">
<th><h2 id="mind-sliver">Mind Sliver</h2></th>
<th><h2 id="green-flame-blade">Green-Flame Blade</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>1 round</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You drive a disorienting spike of psychic energy into the mind of one creature you can see within range. The target must succeed on an Intelligence saving throw or take 1d6 psychic damage and subtract 1d4 from the next saving throw it makes before the end of your next turn.</p>
<p><strong>At Higher Level:</strong> This spell's damage increases by 1d6 when you reach certain levels: 5th level (2d6), 11th level (3d6), and 17th level (4d6).</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S, M (A weapon)</strong></p>
<p>You brandish the weapon used in the spell's casting and make a melee attack with it against one creature within 5 feet of you. On a hit, the target suffers the weapon attack's normal effects, and you can cause green fire to leap from the target to a different creature of your choice that you can see within 5 feet of it. The second creature takes fire damage equal to your spellcasting ability modifier.</p>
<p><strong>At Higher Level:</strong> Both damage rolls increase by 1d8 at 5th, 11th level and 17th level.</p></th>
</tr>
<tr class="odd">
<th><h3 id="cantrip-2">Cantrip</h3></th>
<th><h3 id="cantrip-3">Cantrip</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="burning-hands">Burning Hands</h2></th>
<th><h2 id="hideous-laughter">Hideous Laughter</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>15 foot cone</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>As you hold your hands with thumbs touching and fingers spread, a thin sheet of flames shoots forth from your outstretched fingertips. Each creature in a 15-foot cone must make a Dexterity saving throw. A creature takes 3d6 fire damage on a failed save, or half as much damage on a successful one.</p>
<p>The fire ignites any flammable objects in the area that aren't being worn or carried.</p>
<p><strong>At Higher Level:</strong> When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (tiny tarts and a feather)</strong></p>
<p>A creature of your choice that you can see within range perceives everything as hilariously funny and falls into fits of laughter if this spell affects it. The target must succeed on a Wisdom saving throw or fall prone, becoming incapacitated and unable to stand up for the duration. A creature with an Intelligence score of 4 or less isn't affected.</p>
<p>At the end of each of its turns, and each time it takes damage, the target can make another Wisdom saving throw. The target has advantage on the saving throw if it's triggered by damage. On a success, the spell ends.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1">Level 1</h3></th>
<th><h3 id="level-1-1">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="absorb-elements">Absorb Elements</h2></th>
<th><h2 id="ray-of-sickness">Ray of Sickness</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>Special</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>1 round</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>As a reaction, when you suffer acid, cold, fire, lightning, or thunder damage.</p>
<p>The spell captures some of the incoming energy, lessening its effect on you and storing it for your next melee attack. You have resistance to the triggering damage type until the start of your next turn. Also, the first time you hit with a melee attack on your next turn, the target takes an extra 1d6 damage of the triggering</p>
<p>type, and the spell ends.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the extra damage increases by 1d6 for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Necromancy</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A ray of sickening greenish energy lashes out toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 poison damage and must make a Constitution saving throw. On a failed save, it is also poisoned until the end of your next turn.</p>
<p><strong>At Higher Level:</strong> When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d8 for each slot level above 1st.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-2">Level 1</h3></th>
<th><h3 id="level-1-3">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="2"><h2 id="enhance-ability">Enhance Ability</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (A handful of oak bark)</strong></p>
<p>You touch a creature and bestow upon it a magical enhancement. Choose one of the following effects; the target gains that effect until the spell ends.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.</p></th>
<th><p><strong>Bear's Endurance:</strong> The target has advantage on Constitution checks. It also gains 2d6 temporary hit points, which are lost when the spell ends.</p>
<p><strong>Bull's Strength</strong>: The target has advantage on Strength checks, and his or her carrying capacity doubles.</p>
<p><strong>Cat's Grace</strong>: The target has advantage on Dexterity checks. It also doesn't take damage from falling 20 feet or less if it isn't incapacitated.</p>
<p><strong>Eagle's Splendor</strong>: The target has advantage on Charisma checks.</p>
<p><strong>Fox's Cunning</strong>: The target has advantage on Intelligence checks.</p>
<p><strong>Owl's Wisdom</strong>: The target has advantage on Wisdom checks.</p></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="level-2">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="sparking-ray-scorching-ray">Sparking Ray (Scorching Ray)</h2></th>
<th><h2 id="mind-whip">Mind Whip</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You create three rays of fire and direct them at targets within range. You can direct them at one target or several.</p>
<p>Make a ranged spell attack for each ray. On a hit, the target takes 2d6 lightning damage.</p>
<p><strong>At Higher Levels:</strong> You create one additional ray for each slot level above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>1 round</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You psychically lash out at one creature you can see within range. The target must make an Intelligence saving throw. On a failed save, the target takes 3d6 psychic damage, and it can't take a reaction until the end of its next turn. Moreover, on its next turn, it must choose whether it gets a move, an action, or a bonus action; it gets only one of the three. On a successful save, the target takes half as much damage and suffers none of the spell's other effects.</p>
<p><strong>At Higher Levels:</strong> You can target one additional creature for each slot level above 2nd. The creatures must be within 30 feet of each other when you target them.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-1">Level 2</h3></th>
<th><h3 id="level-2-2">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="thunder-step">Thunder Step</h2></th>
<th><h2 id="minute-meteors">Minute Meteors</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You teleport yourself to an unoccupied space you can see within range. Immediately after you disappear, a thunderous boom sounds, and each creature within 10 feet of the space you left must make a Constitution saving throw, taking 3d10 thunder damage on a failed save, or half as much damage on a successful one. The thunder can be heard from up to 300 feet away.</p>
<p>You can bring along objects as long as their weight doesn't exceed what you can carry. You can also teleport one willing creature of your size or smaller who is carrying gear up to its carrying capacity. The creature must be within 5 feet of you when you cast this spell, and there must be an unoccupied space within 5 feet of your destination space for the creature to appear in; otherwise, the creature is left behind.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d10 for each slot level above 3rd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (sulfur and tar)</strong></p>
<p>You create six tiny meteors in your space. They float in the air and orbit you for the spell's duration.</p>
<p>When you cast the spell—and as a bonus action on each of your turns thereafter—you can expend one or two of the meteors, sending them streaking toward a point or points you choose within 120 feet of you. Once a meteor reaches its destination or impacts against a solid surface, the meteor explodes. Each creature within 5 feet of the point where the meteor explodes must make a Dexterity saving throw. A creature takes 2d6 fire damage on a failed save, or half as much damage on a successful one.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 4th level or higher, the number of meteors created increases by two for each slot level above 3rd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3">Level 3</h3></th>
<th><h3 id="level-3-1">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="haste">Haste</h2></th>
<th><h2 id="section"></h2></th>
</tr>
<tr class="header">
<th><h3 id="section-1"></h3>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="school-transmutation">School: Transmutation</h3>
<h3 id="casting-time-1-action">Casting time: 1 Action</h3>
<h3 id="section-2"></h3></th>
<th><h3 id="range-30-feet">Range: 30 feet</h3>
<h3 id="duration-concentration-up-to-1-minute">Duration: Concentration, up to 1 minute</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<h3 id="section-3"></h3>
<h3 id="components-v-s-m-a-shaving-of-licorice-root">Components: V, S, M (a shaving of licorice root)</h3>
<h3 id="section-4"></h3>
<h3 id="choose-a-willing-creature-that-you-can-see-within-range.-until-the-spell-ends-the-targets-speed-is-doubled-it-gains-a-2-bonus-to-ac-it-has-advantage-on-dexterity-saving-throws-and-it-gains-an-additional-action-on-each-of-its-turns.-that-action-can-be-used-only-to-take-the-attack-one-weapon-attack-only-dash-disengage-hide-or-use-an-object-action.">Choose a willing creature that you can see within range. Until the spell ends, the target's speed is doubled, it gains a +2 bonus to AC, it has advantage on Dexterity saving throws, and it gains an additional action on each of its turns. That action can be used only to take the Attack (one weapon attack only), Dash, Disengage, Hide, or Use an Object action.</h3>
<h3 id="section-5"></h3>
<h3 id="when-the-spell-ends-the-target-cant-move-or-take-actions-until-after-its-next-turn-as-a-wave-of-lethargy-sweeps-over-it.">When the spell ends, the target can't move or take actions until after its next turn, as a wave of lethargy sweeps over it.</h3></th>
<th><h3 id="section-6"></h3>
<h3 id="section-7"></h3>
<h3 id="section-8"></h3></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-2">Level 3</h3></th>
<th><h3 id="section-9"></h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="kindles-wip">Kindles WIP</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S, M (Kindles amulet)</strong></p>
<p>You fill a 20-foot cube you can see with magic. Roll to determine the magical effect produced, and roll again at the start of each of your turns until the spell ends. You can move the cube up to 10 feet before you roll.</p>
<table>
<colgroup>
<col style="width: 5%" />
<col style="width: 94%" />
</colgroup>
<thead>
<tr class="header">
<th>1</th>
<th>Bubbles form in the cube causing everything they touch to become weightless. Each creature in the cube must pass a <strong>Dexterity saving throw</strong> or have its Walk speed reduced to 0ft, although they gain a Fly speed of 5ft. The effect ends when the cube changes, or a creature leaves the cube. When the effect ends on a creature they gain the Prone condition as they slam into the ground.</th>
</tr>
<tr class="odd">
<th>2</th>
<th>You summon a flock of friendly, animated blindfolds. Each creature in the cube must pass a <strong>Strength saving throw</strong> or gain the <strong>Blinded condition</strong> until the start of your next turn. Blinded creatures move randomly.</th>
</tr>
<tr class="header">
<th>3</th>
<th>The cube fills with a stinky blue gas. Creatures inside the cube must pass a <strong>Constitution saving throw</strong> or be <strong>Poisoned</strong> until the start of your next turn as they vomit violently. Creatures poisoned in this way also lose their Reaction.</th>
</tr>
<tr class="odd">
<th>4</th>
<th>You summon hundreds of bonbons with fairy wings: Creatures inside the cube must pass a <strong>Wisdom saving throw</strong> or become <strong>Charmed</strong> by you until the start of your next turn. Creatures charmed in this way must try to stay inside the cube on their turn.</th>
</tr>
<tr class="header">
<th>5</th>
<th>A sparkling laughing gas fills the cube. Creatures inside the cube must pass a <strong>Charisma saving throw</strong> or be <strong>Incapacitated</strong> until the start of your next turn and move randomly on their next turn.</th>
</tr>
<tr class="odd">
<th>6</th>
<th>Everything in the cube gets covered in a sticky substance. Unless a creature has resistance to fire damage, it gains <strong>vulnerability to fire damage</strong>. The effect wears off if they leave the cube.</th>
</tr>
<tr class="header">
<th>7</th>
<th>Tiny grey clouds cover the top of the cube, raining down on the occupants. Unless a creature has resistance to lightning damage, it gains <strong>vulnerability to lightning damage</strong>. The effect wears off if they leave the cube.</th>
</tr>
<tr class="odd">
<th>8</th>
<th>The ears of every creature in the cube grow to triple size. Unless a creature has resistance to thunder damage, it gains <strong>vulnerability to thunder damage</strong>. They also gain advantage on Perception checks to hear. The effect wears off if they leave the cube.</th>
</tr>
<tr class="header">
<th>9</th>
<th>The cube shrinks 5ft and you choose if you want to roll again. Creatures inside the cube must test again if necessary.</th>
</tr>
<tr class="odd">
<th>10</th>
<th>The cube grows 5ft and the effect stays the same. Creatures inside the cube must test again if necessary.</th>
</tr>
</thead>
<tbody>
</tbody>
</table></th>
</tr>
<tr class="header">
<th><h3 id="level-2-3">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
