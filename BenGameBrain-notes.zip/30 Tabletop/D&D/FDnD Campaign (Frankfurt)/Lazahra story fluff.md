---
title: "Lazahra story fluff"
source: "Game Stuff/Lazahra story fluff"
modified: 2023-01-27
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[D&D One-shots]]", "[[FDnD Campaign (Frankfurt)]]"]
concepts: ["D&D one-shots", "Lazahra Arctic Campaign"]
words: 346
summary: "D&D campaign notes for Lazahra's arctic backstory: druids, raven nomads, wood elves, goliaths, monsters, recap and keep/dragon encounter outline."
tags: ["area/dnd", "project/d-d-one-shots", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

**Northern Arctic druids**

Only a few scattered permanent settlements.

Houses built into the landscape

The biggest ones have ancient caves, now carved into tunnels, running between them

In winter, extra population build igloos

Not many humans, mostly Goliath, elves and dwarves. Humans are mostly half breeds.

Oldest druids stay in settlements

Young ones go out for long patrols

Almost no children, most come as teens to become apprentices.

Druid, snow walker

**Raven nomad tribe**

Lazaras mother was chieftain

100% human

Sun magic except to speak with their ancestors or divination magic

Still deal with the druids for healing when necessary.

Shun non humans whenever possible

Fighter, Cleric, ancestral barbarian

**Arctic wood elves**

Defend the glades around their settlements

Trade with druids

echo monk, trance barbarian, fey warlock

**Goliath tribes**

Much further north

Try not to interact with anyone

Far less warlike than you think as they are busy surviving

Rune knight, sorcerer

**Other inhabitants**

Frost, Stone and Fire Giants

Remoraz

White, Blue and Red Dragons

Crystal worms

Ice owl bear (blue Jay)

What Carolin remembers

Lazara was cursed and apandoned by her mother

She was taken in by druids of the Arctic Circle

The druids raised her and sent her on a mission to kill a young white dragon that fled from the north.

Her companions are Night breeze and Falcon

The orcs have the heart of a dead young green dragon.

The orcs want to take the white dragons heart while it is still alive, to summon a deamon.

**What you each remember: Recap**

The battle against half-orc shamans

The dead green dragons heart

The orc horde is heading for the dragon

**Camp on the mountain**

Lazara tells a story about one of her mother's deeds.

**Approach**

Frozen corpses in clear icebergs.

Challenge: Find the dragon

Keep is frozen over. All doors and entrances are covered with ice

**Keep**

Truths:

- Wagon dropped on the roof. Coins frozen in perfectly clear ice floor.

- Dragon sleeps around the wagon iceberg

- Dragon has the same runic birthmark as lazara.

**Dragon**

Young dragon but can Enlarge.
