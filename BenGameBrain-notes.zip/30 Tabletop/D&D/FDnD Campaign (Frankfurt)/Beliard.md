---
title: "Beliard"
source: "Game Stuff/D&D/FDnD Files/Beliard"
modified: 2020-04-25
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 421
summary: "Town sheet for Beliard in the Dessarin Valley (Princes of the Apocalypse): short descriptions of shops and inn, travel times; mostly empty NPC/location sections."
contains_external_material: "Town and location descriptions copied from the published Princes of the Apocalypse adventure"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Beliard

Town

One of the more pleasant-looking villages in the Dessarin Valley thanks to its many trees, Beliard is a market-moot for local cattle drovers. It surrounds the intersection of the Dessarin Road with the Stone Trail. Beliard is home to many cattle ranchers whose herds roam the hills around it, particularly to the east. The village offers a public well, as well as a pond where

harnessed horses or oxen can be driven through the water to bathe them, drive off flies, and let them drink. It's also home to a tanner, a smith, some horse dealers and trainers who keep extensive stables, and an inn: the venerable, popular, and several-times-expanded Watchful Knight.

**[Beliard](#beliard) 1**

> [Unplaced NPCs](#unplaced-npcs) 1
>
> [Locations](#locations) 1
>
> [Watchful Knight (Inn)](#watchful-knight-inn) 1
>
> [Ornra Butchery and Jail (Business)](#ornra-butchery-and-jail-business) 2
>
> [Luruth’s Tannery (Business)](#luruths-tannery-business) 2
>
> [Tarnlar’s Fine Vestments](#tarnlars-fine-vestments) 2
>
> [Vallivoe’s Sundries (General store)](#vallivoes-sundries-general-store) 2
>
> [Unvisited Locations](#unvisited-locations) 2
>
> [Travel Times](#travel-times) 2

## Unplaced NPCs

None

## Locations

None

### Watchful Knight (Inn)

This patchwork building has obviously been expanded many times over the years.

### Ornra Butchery and Jail (Business)

Four identical single-story stone buildings, running back from the street in a line. The front building has a painted sign of a ham being carved by a cleaver, accompanied by no words.

### Luruth’s Tannery (Business)

The only tannery in a town dedicated to livestock. The building shows how successful this business must be with its well maintained facade and expensive fittings.

### Tarnlar’s Fine Vestments

The square two-story building stands at the center of town. Its signboard is painted with the images of a well-dressed lord and lady, one on each side of the board. Ornate scrollwork iron bars protect the windows.

### Vallivoe’s Sundries (General store)

Aside from the bewildering profusion of doors, barrels,

rotting old furniture, and tools leaning against its

outside walls, this building looks like a private home.

## Unvisited Locations

## Travel Times

| **Destination**                                                                               | **Trail type**     | **Distance**       |
|-----------------------------------------------------------------------------------------------|--------------------|--------------------|
| [*Westbridge*](https://drive.google.com/open?id=1uCMZbNF4boMkIdK-dfg9E6Af9qM5gSW_nBND_-hUHr0) | Rough road         | 36 miles           |
| Red larch                                                                                     | Rough road         | 44 miles           |
| Summit Hall                                                                                   | Rough road         | 28 miles           |
| Womford                                                                                       | Rough road         | 64 miles           |
| Stone Bridge                                                                                  | Rough road         | 8 miles            |
| Yatar                                                                                         | Rough road / River | 8 miles / 68 miles |
| Ironford                                                                                      | Rough road / River | 8 miles / 76 miles |
