---
title: "Westbridge"
source: "Game Stuff/D&D/FDnD Files/Westbridge"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Westbridge"]
words: 327
summary: "Player-facing/visited Westbridge sheet: Harvest Inn, poultry stores, wagonworks and travel times."
contains_external_material: "Descriptions appear from published module"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Westbridge

Village

**[Westbridge](#westbridge) 1**

> [Unplaced NPCs](#unplaced-npcs) 1
>
> [Locations](#locations) 1
>
> [Harvest Inn (Inn)](#harvest-inn-inn) 1
>
> [Mhandyvers Poultry (General Store)](#mhandyvers-poultry-general-store) 2
>
> [Unvisited Locations](#unvisited-locations) 2
>
> [Drouth Fine Poultry](#drouth-fine-poultry) 2
>
> [Waelvur’s Wagonworks](#waelvurs-wagonworks) 2
>
> [Travel Times](#travel-times) 2

## Unplaced NPCs

Chickens (lots)

## Locations

### Harvest Inn (Inn)

A friendly tavern and bunkhouse which stands in the middle of town. A ramshackle carpenters workshop is built adjoining the main structure, but obviously sees less maintenance.

**NPCs**

Stan Thistlehair - Owner / Carpenter

| **Service**                                      | **Cost** |
|--------------------------------------------------|----------|
| Single Bed, Board and Meal (per room, per night) | 5sp      |
| Stabling and Feed (per animal, per night)        | 2sp      |

### Mhandyvers Poultry (General Store)

This wooden building grew haphazardly for many years,

shooting out single-story wings and annexes untidily

in all directions. The interior looks like a barn or attic,

with exposed beams and posts. Pens with live chickens

fill most of the odd corners and halls of the building,

leaving only a narrow aisle down to the back, where the

Mhandyvvers live. Their rooms are separated from the

chicken pens by a workroom with cutting benches and a

central hearth.

**NPCs**

Minthra “Minny” Mhandyver - Owner

## Unvisited Locations

### Drouth Fine Poultry

The one-story building is long, narrow, and

nondescript on the outside, but the name of the business

is painted above the double entry doors (wide enough

for a wagon).

### Waelvur’s Wagonworks

The workshop is a cluttered, untidy

shed surrounded by dozens of wagons shrouded in

worn canvas tarpaulins.

## Travel Times

| **Destination**   | **Trail type** | **Distance** |
|-------------------|----------------|--------------|
| Triboar           | Good road      | 36 miles     |
| Red Larch         | Good road      | 36 miles     |
| Helvenblade House | Crosscountry   | 8 miles      |
| Nettlebee Ranch   | Crosscountry   | 10 miles     |
| Beliard           | Rough trail    | 40 miles     |

[*Undiscovered - Westbridge*](https://drive.google.com/open?id=1Wt_wBQZKl6dUJTQRCy1JItYE91QMHNj7ffu7OKvnG4E)
