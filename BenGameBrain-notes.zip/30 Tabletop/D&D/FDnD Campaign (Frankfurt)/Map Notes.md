---
title: "Map Notes"
source: "Game Stuff/D&D/Map Notes"
modified: 2018-10-11
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 365
summary: "Handout-style notes describing numbered rooms of a ruined, collapsed castle/hall as perceived during a trance, including shrine, statues, tower and hidden openings."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

**Some notes on the map.**

1\) The northern part of the hall seems to be a shrine, with a stone altar in the centre of the room. There are carvings on each face of the altar but all the faces have been chiselled off. There are also two arrow slits looking out to the north, that an archer could fire from.

2\) This room is a long hall with high vaulted ceilings. During your trance, you can make out in high detail that the ceiling has a ledge which is lined with some variety of elven angel statues. Most of their faces have been chiselled off.

3\) This tower has fallen in, but there is still a walkable space big enough for a human to stand (just). You can detect that the north wall has a gap large enough to pass through (although from outside you saw that the hole was camouflaged with cloth and rubble).

4\) The foundation in this area is in the best condition. The small room has a stone bathtub built into the floor.

5\) Here you detect that there is a cramped path through the rubble that comes out on top of this tower. It is a difficult climb and too small for a human.

6\) This room has a very smooth stone floor and a chimney leading up to the roof.

**Extended notes on the map.**

7\) This room as almost completely collapsed. It should be possible for all your party members to squeeze through, however combat here would be disadvantageous.

8\) The foundation has collapsed creating a shallow pit in the floor (10ft deep). The second floor here is still intact but further up it has fallen together. It could collapse at any moment.

9\) This area has already collapsed. The ground is littered with loose rubble. Combat here would be disadvantageous. There is room for even a large creature to stand.

10\) There is a set of stairs leading up to a concealed opening on this side of the castle.

11\) The ceiling in this area has already collapsed but something you cant see is holding it up. Whatever it is, it is not made of stone.
