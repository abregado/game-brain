---
title: "Fdnd character ideas"
source: "Game Stuff/Fdnd character ideas"
modified: 2021-10-09
type: campaign-prep
area: dnd
status: "idea"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 61
summary: "List of character concept ideas for the Frankfurt D&D campaign (carnival, Feywild, Kettlesteam)."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

Fdnd character ideas

A child who can do magic

A warlock with fey patron

Adventurer who has been to the carnival before

Hitchhiker with the carnival

Carnival worker

Adventurer Hunting Kettlesteam

Animal person who was born in the Feywild

Looking for a friend lost in the Feywilds.

Looking for one of the previous heroes

Adventurer with a Fey pact, possibly generational.
