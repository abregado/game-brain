---
title: "FDnD Lazahra Spell List"
source: "Game Stuff/D&D/FDnD Lazahra Spell List"
modified: 2023-03-05
type: character
area: dnd
status: "unknown"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Lazahra"]
words: 13337
summary: "Spell list for the character Lazahra; the conversion kept only 27 empty table placeholders so no text survives."
contains_external_material: "Spell lists likely derived from official 5e spells"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="druidcraft">Druidcraft</h2></th>
<th><h2 id="frostbite">Frostbite</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Whispering to the spirits of nature, you create one of the following effects within range:</p>
<p>You create a tiny, harmless sensory effect that predicts what the weather will be at your location for the next 24 hours. The effect might manifest as a golden orb for clear skies, a cloud for rain, falling snowflakes for snow, and so on. This effect persists for 1 round.</p>
<p>You instantly make a flower blossom, a seed pod open, or a leaf bud bloom.</p>
<p>You create an instantaneous, harmless sensory effect, such as falling leaves, a puff of wind, the sound of a small animal, or the faint odor of skunk. The effect must fit in a 5-foot cube.</p>
<p>You instantly light or snuff out a candle, a torch, or a small Campfire.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You cause numbing frost to form on one creature that you can see within range. The target must make a Constitution saving throw. On a failed save, the target takes 1d6 cold damage, and it has disadvantage on the next weapon attack roll it makes before the end of its next turn.</p>
<p><strong>At higher levels:</strong> The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).</p></th>
</tr>
<tr class="header">
<th><h3 id="cantrip">Cantrip</h3></th>
<th><h3 id="cantrip-1">Cantrip</h3></th>
</tr>
<tr class="odd">
<th><h2 id="poison-spray">Poison Spray</h2></th>
<th><h2 id="shillelagh">Shillelagh</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>10 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You extend your hand toward a creature you can see within range and project a puff of noxious gas from your palm. The creature must succeed on a Constitution saving throw or take 1d12 poison damage.</p>
<p><strong>At higher levels:</strong> This spell’s damage increases by 1d12 when you reach 5th level (2d12), 11th level (3d12), 17th level (4d12).</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (mistletoe, a shamrock leaf, and a club or quarterstaff)</strong></p>
<p>The wood of a club or quarterstaff you are holding is imbued with nature’s power. For the duration, you can use your spellcasting ability instead of Strength for the attack and damage rolls of melee attacks using that weapon, and the weapon’s damage die becomes a d8. The weapon also becomes magical, if it isn’t already. The spell ends if you cast it again or if you let go of the weapon.</p></th>
</tr>
<tr class="odd">
<th><h3 id="cantrip-2">Cantrip</h3></th>
<th><h3 id="cantrip-3">Cantrip</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="beast-bond">Beast Bond</h2></th>
<th><h2 id="charm-person">Charm Person</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a bit of fur wrapped in a cloth)</strong></p>
<p>You establish a telepathic link with one beast you touch that is friendly to you or charmed by you. The spell fails if the beast’s Intelligence is 4 or higher. Until the spell ends, the link is active while you and the beast are within line of sight of each other. Through the link, the beast can understand your telepathic messages to it, and it can telepathically communicate simple emotions and concepts back to you. While the link is active, the beast gains advantage on attack rolls against any creature within 5 feet of you that you can see.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You attempt to charm a humanoid you can see within range. It must make a Wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it.The charmed creature regards you as a friendly acquaintance. When the spell ends, the creature knows it was charmed by you.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st. The creatures must be within 30 feet of each other when you target them.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1">Level 1</h3></th>
<th><h3 id="level-1-1">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="absorb-elements">Absorb Elements</h2></th>
<th><h2 id="animal-friendship">Animal Friendship</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>Special</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>1 round</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>As a reaction, when you suffer acid, cold, fire, lightning, or thunder damage.</p>
<p>The spell captures some of the incoming energy, lessening its effect on you and storing it for your next melee attack. You have resistance to the triggering damage type until the start of your next turn. Also, the first time you hit with a melee attack on your next turn, the target takes an extra 1d6 damage of the triggering</p>
<p>type, and the spell ends.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the extra damage increases by 1d6 for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>24 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a morsel of food)</strong></p>
<p>This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast’s Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell’s duration. If you or one of your companions harms the target, the spell ends.</p>
<p><strong>At higher levels</strong>: When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional beast for each slot level above 1st.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-2">Level 1</h3></th>
<th><h3 id="level-1-3">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="create-or-destroy-water">Create or Destroy Water</h2></th>
<th><h2 id="cure-wounds">Cure Wounds</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a drop of water if creating water or a few grains of sand if destroying it)</strong></p>
<p>You either create or destroy water.</p>
<p><strong>Create Water.</strong> You create up to 10 gallons of clean water within range in an open container. Alternatively, the water falls as rain in a 30-foot cube within range, extinguishing exposed flames in the area.</p>
<p><strong>Destroy Water.</strong> You destroy up to 10 gallons of water in an open container within range. Alternatively, you destroy fog in a 30-foot cube within range.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, you create or destroy 10 additional gallons of water, or the size of the cube increases by 5 feet, for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A creature you touch regains a number of hit points equal to 1d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d8 for each slot level above 1st.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1-4">Level 1</h3></th>
<th><h3 id="level-1-5">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="detect-magic-ritual">Detect Magic (Ritual)</h2></th>
<th><h2 id="detect-poison-and-disease">Detect Poison and Disease</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any.</p>
<p>The spell can penetrate most barriers, but is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a yew leaf)</strong></p>
<p>For the duration, you can sense the presence and location of poisons, poisonous creatures, and diseases within 30 feet of you. You also identify the kind of poison, poisonous creature, or disease in each case.</p>
<p>The spell can penetrate most barriers, but is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-6">Level 1</h3></th>
<th><h3 id="level-1-7">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="earth-tremor">Earth Tremor</h2></th>
<th><h2 id="entangle">Entangle</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You cause a tremor in the ground in a 10-foot radius. Each creature other than you in that area must make a Dexterity saving throw. On a failed save, a creature takes 1d6 bludgeoning damage and is knocked prone. If the ground in that area is loose earth or stone, it becomes difficult terrain until cleared.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the damage</p>
<p>increases by 1d6 for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range:<strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Grasping weeds and vines sprout from the ground in a 20-foot square starting from a point within range. For the duration, these plants turn the ground in the area into difficult terrain.</p>
<p>A creature in the area when you cast the spell must succeed on a Strength saving throw or be restrained by the entangling plants until the spell ends. A creature restrained by the plants can use its action to make a Strength check against your spell save DC. On a success, it frees itself.</p>
<p>When the spell ends, the conjured plants wilt away.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1-8">Level 1</h3></th>
<th><h3 id="level-1-9">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="faerie-fire">Faerie Fire</h2></th>
<th><h2 id="fog-cloud">Fog Cloud</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>Each object in a 20-foot cube within range is outlined in blue, green, or violet light (your choice).</p>
<p>Any creature in the area when the spell is cast is also outlined in light if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed dim light in a 10-foot radius.</p>
<p>Any attack roll against an affected creature or object has</p>
<p>advantage if the attacker can see it, and the affected creature or object can’t benefit from being invisible.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You create a 20-foot-radius sphere of fog centered on a point within range. The sphere spreads around corners, and its area is heavily obscured, It lasts for the duration or until a wind of moderate or greater speed (at least 10 miles per hour) disperses it.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the radius of the fog increases by 20 feet for each slot level above 1st.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-10">Level 1</h3></th>
<th><h3 id="level-1-11">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="goodberry">Goodberry</h2></th>
<th><h2 id="healing-word">Healing Word</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a sprig of mistletoe)</strong></p>
<p>Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for one day. The berries lose their potency if they have not been consumed within 24 hours of the casting of this spell.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>A creature of your choice that you can see within range regains hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d4 for each slot level above 1st.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1-12">Level 1</h3></th>
<th><h3 id="level-1-13">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="ice-knife">Ice Knife</h2></th>
<th><h2 id="jump">Jump</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S, M (a drop of water or piece of ice)</strong></p>
<p>You create a shard of ice and fling it at one creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 piercing damage. Hit or miss, the shard then explodes. The target and each creature within 5 feet of the point where the ice exploded must succeed on a Dexterity saving throw or take 2d6 cold damage.</p>
<p><strong>At Higher Levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the cold damage increases by 1d6 for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a grasshopper’s hind leg)</strong></p>
<p>You touch a creature. The creature’s jump distance is tripled until the spell ends.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-14">Level 1</h3></th>
<th><h3 id="level-1-15">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="longstrider">Longstrider</h2></th>
<th><h2 id="purify-food-and-drink-ritual">Purify Food and Drink (Ritual)</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a pinch of dirt)</strong></p>
<p>You touch a creature. The target’s speed increases by 10 feet until the spell ends.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>10 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>All non-magical food and drink within a 5-foot-radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1-16">Level 1</h3></th>
<th><h3 id="level-1-17">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="snare">Snare</h2></th>
<th><h2 id="speak-with-animals-ritual">Speak with Animals (Ritual)</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Minute</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>8 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S, M (25 feet of rope, which the spell consumes)</strong></p>
<p>As you cast this spell, you use the rope to create a circle with a 5-foot radius on the ground or the floor. When you finish casting, the rope disappears and the circle becomes a magic trap. This trap is nearly invisible, requiring a successful Intelligence (Investigation) check against your spell save DC to be discerned.</p>
<p>The trap triggers when a Small, Medium, or Large creature moves onto the ground or the floor in the spell’s radius. That creature must succeed on a Dexterity saving throw or be magically hoisted into the air, leaving it hanging upside down 3 feet above the ground or the floor. The creature is restrained there until the spell ends.</p>
<p>A restrained creature can make a Dexterity saving throw at the end of each of its turns, ending the effect on itself on a success. Alternatively, the creature or someone else who can reach it can use an action to make an Intelligence (Arcana) check against your spell save DC. On a success, the restrained effect ends. After the trap is triggered, the spell ends when no creature is restrained by it.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You gain the ability to comprehend and verbally communicate with beasts for the duration. The knowledge and awareness of many beasts is limited by their intelligence, but at minimum, beasts can give you information about nearby locations and monsters, including whatever they can perceive or have perceived within the past day. You might be able to persuade a beast to perform a small favor for you, at the DM’s discretion.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-18">Level 1</h3></th>
<th><h3 id="level-1-19">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="animal-messenger-ritual">Animal Messenger (Ritual)</h2></th>
<th><h2 id="barkskin">Barkskin</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>24 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a morsel of food)</strong></p>
<p>By means of this spell, you use an animal to deliver a message. Choose a Tiny beast you can see within range, such as a squirrel, a blue ray, or a bat. You specify a location, which you must have visited, and a recipient who matches a general description. You also speak a message of up to twenty-five words. The target beast travels for the duration of the spell towards the specified location, covering about 50 miles per 24 hours for a flying messenger or 25 miles for other animals.</p>
<p>When the messenger arrives, it delivers your message to the creature that you described, replicating the sound of your voice. The messenger speaks only to a creature matching the description you gave. If the messenger doesn’t reach its destination before the spell ends, the message is lost, and the beast makes it way back to where you cast this spell.</p>
<p><strong>At higher level:</strong> If you cast this spell using a spell slot of 3rd level or higher, the duration of the spell increases by 48 hours for each slot level above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (A handful of oak bark)</strong></p>
<p>You touch a willing creature. Until the spellends, the target’s skin has a rough, bark-like appearance, and the target’s AC can’t be less than 16, regardless of what kind of armor it is wearing.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2">Level 2</h3></th>
<th><h3 id="level-2-1">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="beast-sense-ritual">Beast Sense (Ritual)</h2></th>
<th><h2 id="darkvision">Darkvision</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>You touch a willing beast. For the duration of the spell, you can use your action to see through the beast’s eyes and hear what it hears, and continue to do so until you use your action to return to your normal senses.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>8 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (either a pinch of dried carrot or an agate)</strong></p>
<p>You touch a willing creature to grant it the ability to see in the dark. For the duration, that creature has darkvision out to a range of 60 feet.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-2">Level 2</h3></th>
<th><h3 id="level-2-3">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="dust-devil">Dust Devil</h2></th>
<th><h2 id="earthbind">Earthbind</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a pinch of dust)</strong></p>
<p>Choose an unoccupied 5-foot cube of air that you can see within range. An elemental force that resembles a dust devil appears in the cube and lasts for the spell’s duration. Any creature that ends its turn within 5 feet of the dust devil must make a Strength saving throw. On a failed save, the creature takes 1d8 bludgeoning damage and is pushed 10 feet away. On a successful save, the creature takes half as much damage and</p>
<p>isn’t pushed.</p>
<p>As a bonus action, you can move the dust devil up to 30 feet in any direction. If the dust devil moves over sand, dust, loose dirt, or small gravel, it sucks up the material and forms a 10-foot radius cloud of debris around itself that lasts until the start of your next turn. The cloud heavily obscures its area.</p>
<p><strong>At Higher Levels</strong>: When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>300 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>Choose one creature you can see within range. Yellow strips of magical energy loop around the creature. The target must succeed on a S trength saving throw or its flying speed (if any) is reduced to 0 feet for the spell’s duration. An airborne creature affected by this spell descends at 60 feet per round until it reaches the ground or the spell ends.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2-4">Level 2</h3></th>
<th><h3 id="level-2-5">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="enhance-ability">Enhance Ability</h2></th>
<th><h2 id="find-traps">Find Traps</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (fur or a feather from a beast)</strong></p>
<p>Bestow one of the following enhancements:</p>
<p><strong>Bear’s Endurance.</strong> The target has advantage on Constitution checks. It also gains 2d6 temporary hit points, which are lost when the spell ends.</p>
<p><strong>Bull’s Strength.</strong> The target has advantage on Strength checks, and his or her carrying capacity doubles.</p>
<p><strong>Cat’s Grace.</strong> The target has advantage on Dexterity checks. It also doesn’t take damage from falling 20 feet or less if it isn’t incapacitated.</p>
<p><strong>Eagle’s Splendor.</strong> The target has advantage on Charisma checks.</p>
<p><strong>Fox’s Cunning.</strong> The target has advantage on Intelligence checks.</p>
<p><strong>Owl’s Wisdom.</strong> The target has advantage on Wisdom checks.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You sense the presence of any trap within range that is within line of sight. A trap, for the purpose of this spell, includes anything that would inflict a sudden or unexpected effect you consider harmful or undesirable, which was specifically intended as such by its creator. Thus, the spell would sense an area affected by the alarm spell, a glyph of warding, or a mechanical pit trap, but it would not reveal a natural weakness in the floor, an unstable ceiling, or a hidden sinkhole.</p>
<p>This spell merely reveals that a trap is present. You don’t learn the location of each trap, but you do learn the general nature of the danger posed by a trap you sense.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-6">Level 2</h3></th>
<th><h3 id="level-2-7">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="flame-blade">Flame Blade</h2></th>
<th><h2 id="flaming-sphere">Flaming Sphere</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (leaf of sumac)</strong></p>
<p>You evoke a fiery blade in your free hand. The blade is similar in size and shape to a scimitar, and it lasts for the duration. If you let go of the blade, it disappears, but you can evoke the blade again as a bonus action.</p>
<p>You can use your action to make a melee spell attack with the fiery blade. On a hit, the target takes 3d6 fire damage.</p>
<p>The flaming blade sheds bright light in a 10-foot radius and dim light for an additional 10 feet.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for every two slot levels above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a bit of tallow, a pinch of brimstone, and a dusting of powdered iron)</strong></p>
<p>A 5-foot-diameter sphere of fire appears in an unoccupied space of your choice within range and lasts for the duration. Any creature that ends its turn within 5 feet of the sphere must make a Dexterity saving throw. The creature takes 2d6 fire damage on a failed save, or half as much damage on a successful one.</p>
<p>As a bonus action, you can move the sphere up to 30 feet. If you ram the sphere into a creature, that creature must make the saving throw against the sphere’s damage, and the sphere stops moving this turn.</p>
<p>When you move the sphere, you can direct it over barriers up to 5 feet tall and jump it across pits up to 10 feet wide. The sphere ignites flammable objects not being worn or carried, and it sheds bright light in a 20-foot radius and dim light for an additional 20 feet.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d6 for each slot level above 2nd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2-8">Level 2</h3></th>
<th><h3 id="level-2-9">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="gust-of-wind">Gust of Wind</h2></th>
<th><h2 id="healing-spirit">Healing Spirit</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a legume seed)</strong></p>
<p>A line of strong wind 60 feet long and 10 feet wide blasts from you in a direction you choose for the spell’s duration. Each creature that starts its turn in the line must succeed on a Strength saving throw or be pushed 15 feet away from you in a direction following the line.</p>
<p>Any creature in the line must spend 2 feet of movement for every 1 foot it moves when moving closer to you.</p>
<p>The gust disperses gas or vapor, and it extinguishes candles, torches, and similar unprotected flames in the area. It causes protected flames, such as those of lanterns, to dance wildly and has a 50 percent chance to extinguish them.</p>
<p>As a bonus action on each of your turns before the spell ends, you can change the direction in which the line blasts from you.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You call forth a nature spirit to soothe the wounded. The</p>
<p>intangible spirit appears in a space that is a 5-foot cube you can see within range. The spirit looks like a transparent beast or fey (your choice). Until the spell ends, whenever you or a creature you can see moves into the spirits space for the first time on a turn or starts its turn there, you can cause the spirit to restore ld6 hit points to that creature (no action required). The spirit</p>
<p>can’t heal constructs or undead. As a bonus action on your turn, you can move the Spirit up to 30 feet to a space you can see.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, the healing increases 1d6 for each slot level above 2nd.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-10">Level 2</h3></th>
<th><h3 id="level-2-11">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="heat-metal">Heat Metal</h2></th>
<th><h2 id="hold-person">Hold Person</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a piece of iron and a flame)</strong></p>
<p>Choose a manufactured metal object, such as a metal weapon or a suit of heavy or medium metal armor, that you can see within range. You cause the object to glow red-hot. Any creature in physical contact with the object takes 2d8 fire damage when you cast the spell. Until the spell ends, you can use a bonus action on each of your subsequent turns to cause this damage again.</p>
<p>If a creature is holding or wearing the object and takes the damage from it, the creature must succeed on a Constitution saving throw or drop the object if it can. If it doesn’t drop the object, it has disadvantage on attack rolls and ability checks until the start of your next turn.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a small, straight piece of iron)</strong></p>
<p>Choose a humanoid that you can see within range. The target must succeed on a Wisdom saving throw or be paralyz ed for the duration. At the end of each of its turns, the target can make another Wisdom saving throw. On a success, the spell ends on the target.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 3rd level or higher, you can target one additional humanoid for each slot level above 2nd. The humanoids must be within 30 feet of each other when</p>
<p>you target them.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2-12">Level 2</h3></th>
<th><h3 id="level-2-13">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="lesser-restoration">Lesser Restoration</h2></th>
<th><h2 id="locate-animals-or-plants-ritual">Locate Animals or Plants (Ritual)</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration:<strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You touch a creature and can end either one disease or one condition afflicting it. The condition can be blinded, deafened, paralyzed, or poisoned.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a bit of fur from a bloodhound)</strong></p>
<p>Describe or name a specific kind of beast or plant. Concentrating on the voice of nature in your surroundings, you learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-14">Level 2</h3></th>
<th><h3 id="level-2-15">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="locate-object">Locate Object</h2></th>
<th><h2 id="moonbeam">Moonbeam</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a forked twig)</strong></p>
<p>Describe or name an object that is familiar to you. You sense the direction to the object’s location, as long as that object is within 1,000 feet of you. If the object is in motion, you know the direction of its movement.</p>
<p>The spell can locate a specific object known to you, as long as you have seen it up close – within 30 feet – at least once.</p>
<p>Alternatively, the spell can locate the nearest object of a</p>
<p>particular kind, such as a certain kind of apparel, jewelry, furniture, tool, or weapon.</p>
<p>This spell can’t locate an object if any thickness of lead, even a thin sheet, blocks a direct path between you and the object.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (seeds of a moonseed plant and a piece of opalescent feldspar)</strong></p>
<p>A silvery beam of pale light shines down in a 5-foot radius, 40-foot high cylinder centered on a point within range. Until the spell ends, dim light fills the cylinder.</p>
<p>When a creature enters the spell’s area for the first time on a turn or starts its turn there, it must make a Constitution saving throw, taking 2d10 radiant damage on a failed save, or half as much damage on a successful one.</p>
<p>Shapechangers make their saving throws with disadvantage. While inside the light, they cannot use any shape changing abilities.</p>
<p>On each of your turns after you cast this spell, you can use an action to move the beam 60 feet in any direction.</p>
<p><strong>At higher levels:</strong> Damage increases by 1d10 for each slot level above 2nd.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2-16">Level 2</h3></th>
<th><h3 id="level-2-17">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="pass-without-trace">Pass Without Trace</h2></th>
<th><h2 id="protection-from-poison">Protection from Poison</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (ashes from a burned leaf of mistletoe and a sprig of spruce)</strong></p>
<p>A veil of shadows and silence radiates from you, masking you and your companions from detection.</p>
<p>For the duration, each creature you choose within 30 feet of you (including you) has a +10 bonus to Dexterity (Stealth) checks and can’t be tracked except by magical means. A creature that receives this bonus leaves behind no tracks or other traces of its passage.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You touch a creature. If it is poisoned, you neutralize the poison. If more than one poison afflicts the target, you neutralize one poison that you know is present, or you neutralize one at random.</p>
<p>For the duration, the target has advantage on saving throws against being poisoned, and it has resistance to poison damage.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-18">Level 2</h3></th>
<th><h3 id="level-2-19">Level 2</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="skywrite-ritual">Skywrite (Ritual)</h2></th>
<th><h2 id="spike-growth">Spike Growth</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Sight</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You cause up to ten words to form in a part of the sky you can see. The words appear to be made of cloud and remain in place for the spell’s duration. The words dissipate when the spell ends.</p>
<p>A strong wind can disperse the clouds and end the spell early.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>150 feet</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (seven sharp thorns or seven small twigs, each sharpened to a point)</strong></p>
<p>The ground in a 20-foot radius centered on a point within range twists and sprouts hard spikes and thorns. The area becomes difficult terrain for the duration. When a creature moves into or within the area, it takes 2d4 piercing damage for every 5 feet it travels.</p>
<p>The transformation of the ground is camouflaged to look natural. Any creature that can’t see the area at the time the spell is case must make a Wisdom (Perception) check against your spell save DC to recognize the terrain as hazardous before entering it.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-2-20">Level 2</h3></th>
<th><h3 id="level-2-21">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="warding-wind">Warding Wind</h2></th>
<th><h2 id="thunderwave">Thunderwave</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>A strong wind (20 miles per hour) blows around you in a 10-foot radius and moves with you, remaining centered on you. The wind lasts for the spell’s duration.</p>
<p>The wind has the following effects:</p>
<ul>
<li><blockquote>
<p>It deafens you and other creatures in its area.</p>
</blockquote></li>
<li><blockquote>
<p>It extinguishes unprotected flames in its area that are torch sized or smaller.</p>
</blockquote></li>
<li><blockquote>
<p>The area is difficult terrain for creatures other than you.</p>
</blockquote></li>
<li><blockquote>
<p>The attack rolls of ranged weapon attacks have disadvantage if they pass in or out of the wind.</p>
</blockquote></li>
<li><blockquote>
<p>It hedges out vapor, gas, and fog that can be dispersed by strong wind.</p>
</blockquote></li>
</ul></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A wave of thunderous force sweeps out from you.</p>
<p>Each creature in a 15-foot cube originating from you must make a Constitution saving throw. On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, the creature takes half as much damage and isn’t pushed.</p>
<p>In addition, unsecured objects that are completely within the area of effect are automatically pushed 10 feet away from you by the spell’s effect, and the spell emits a thunderous boom audible out to 300 feet.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d8 for each slot level above 1st.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-2-22">Level 2</h3></th>
<th><h3 id="level-1-20">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="call-lightning">Call Lightning</h2></th>
<th><h2 id="conjure-animals">Conjure Animals</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>A storm cloud appears in the shape of a cylinder that is 10 feet tall with a 60-foot radius, centered on a point you can see 100 feet directly above you. The spell fails if you can’t see a point in the air where the storm cloud could appear (for example, if you are in a room that can’t accommodate the cloud).</p>
<p>When you cast the spell, choose a point you can see within range. A bolt of lightning flashes down from the cloud to that point. Each creature within 5 feet of that point must make a Dexterity saving throw. A creature takes 3d10 lightning damage on a failed save, or half as much damage on a successful one. On each of your</p>
<p>turns until the spell ends, you can use your action to call down lightning in this way again, targeting the same point or a different one.</p>
<p>If you are outdoors in stormy conditions when you cast this spell, the spell gives you control over the existing storm instead of creating a new one. Under such conditions, the spell’s damage increases by 1d10.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 4th or higher level, the damage increases by 1d10 for each slot level above 3rd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You summon 2 CR worth of beasts that appear in unoccupied spaces that you can see within range.</p>
<p>• One beast of challenge rating 2 or lower</p>
<p>• Two beasts of challenge rating 1 or lower</p>
<p>• Four beasts of challenge rating 1/2 or lower</p>
<p>• Eight beasts of challenge rating 1/4 or lower</p>
<p>Each beast is also considered fey, and it disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The summoned creatures are friendly to you and your</p>
<p>companions. Roll initiative for the summoned creatures as a group, which has its own turns. They obey any verbal commands that you issue to them (no action required by you). If you don’t issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.</p>
<p><strong>At higher levels:</strong> If a 5th level slot is used, double the amount of creatures. Triple with a 7th level, and quadruple with a 9th level slot.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3">Level 3</h3></th>
<th><h3 id="level-3-1">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="daylight">Daylight</h2></th>
<th><h2 id="dispel-magic">Dispel Magic</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: V, S</p>
<p>A 60-foot-radius sphere of light spreads out from a point you choose within range. The sphere is bright light and sheds dim light for an additional 60 feet.</p>
<p>If you chose a point on an object you are holding or one that isn’t being worn or carried, the light shines from the object with and moves with it. Completely covering the affected object with an opaque object, such as a bowl or a helm, blocks the light.</p>
<p>If any of this spell’s area overlaps with an area of darkness created by a spell of 3rd level or lower, the spell that created the darkness is dispelled.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: V, S</p>
<p>Choose any creature, object, or magical effect within range. Any spell of 3rd level or lower on the target ends. For each spell of 4th level or higher on the target, make an ability check using your spellcasting ability. The DC equals 10 + the spell’s level. On a successful check, the spell ends.</p>
<p><strong>At higher levels:</strong> When you cast this spell using a spell slot of 4th level or higher, you automatically end the effects of a spell on the target if the spell’s level is equal to or less than the level of the spell slot you used.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-2">Level 3</h3></th>
<th><h3 id="level-3-3">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="erupting-earth">Erupting Earth</h2></th>
<th><h2 id="feign-death-ritual">Feign Death (Ritual)</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a piece of obsidian)</strong></p>
<p>Choose a point you can see on the ground within range. A fountain of churned earth and stone erupts in a 20-foot cube centered on that point. Each creature in that area must make a Dexterity saving throw. A creature takes 3d12 bludgeoning damage on a failed save, or half as much damage on a successful one. Additionally, the ground in that area becomes difficult terrain until cleared away. Each 5-foot-square portion of the area</p>
<p>requires at least 1 minute to clear by hand.</p>
<p><strong>At higher level:</strong> When you cast this spell using a spell slot of 4rd level or higher, the damage increases by 1d12 for each slot level above 3rd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Necromancy</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a pinch of graveyard dirt)</strong></p>
<p>You touch a willing creature and put it into a cataleptic state that is indistinguishable from death.</p>
<p>For the spell’s duration, or until you use an action to touch the target and dismiss the spell, the target appears dead to all outward inspection and to spells used to determine the target’s status. The target is blinded and incapacitated, and its speed drops to 0.</p>
<p>The target has resistance to all damage except psychic damage. If the target is diseased or poisoned when you cast the spell, or becomes diseased or poisoned while under the spell’s effect, the disease and poison have no effect until the spell ends.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-4">Level 3</h3></th>
<th><h3 id="level-3-5">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="flame-arrows">Flame Arrows</h2></th>
<th><h2 id="meld-into-stone-ritual">Meld into Stone (Ritual)</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You touch a quiver containing arrows or bolts. When a target is hit by a ranged weapon attack using a piece of ammunition drawn from the quiver, the target takes an extra 1d6 fire damage. The spell’s magic ends on the piece of ammunition when it hits or misses, and the spell ends when twelve pieces of ammunition have been drawn from the quiver.</p>
<p>At higher levels: When you cast this spell using a spell slot of 4th level or higher, the number of pieces of ammunition you can affect with this spell increases by two for each slot level above 3rd.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>8 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You step into a stone object or surface large enough to fully contain your body, melding yourself and all the equipment you carry with the stone for the duration.</p>
<p>Nothing of your presence remains visible or otherwise detectable by non-magical senses.</p>
<p>You can’t see what occurs outside it, and any Wisdom (Perception) checks you make to hear sounds outside it are made with disadvantage. You remain aware of the passage of time and can cast spells on yourself while merged in the stone. You can use your movement to leave the stone where you entered it, which ends the spell. You otherwise can’t move.</p>
<p>Minor physical damage to the stone doesn’t harm you, but its partial destruction or a change in its shape (to the extent that you no longer fit within it) expels you and deals 6d6 bludgeoning damage to you. The stone’s complete destruction (or transmutation into a different substance) expels you and deals 50 bludgeoning damage to you. If expelled, you fall prone in an unoccupied space closest to where you first entered.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-6">Level 3</h3></th>
<th><h3 id="level-3-7">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="plant-growth">Plant Growth</h2></th>
<th><h2 id="protection-from-energy">Protection from Energy</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>Special</strong></p></th>
<th><p>Range: <strong>150 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>This spell channels vitality into plants within a specific area. There are two possible uses for the spell, granting either immediate or long-term benefits.</p>
<p>If you cast this spell using 1 action, choose a point within range. All normal plants in a 100-foot radius centered on that point become thick and overgrown. A creature moving through the area must spend 4 feet of movement for every 1 foot it moves.</p>
<p>You can exclude one or more areas of any size within the spell’s area from being affected.</p>
<p>If you cast this spell over 8 hours, you enrich the land. All plants in a half-mile radius centered on a point within range become enriched for 1 year. The plants yield twice the normal amount of food when harvested.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: V, S</p>
<p>For the duration, the willing creature you touch has resistance to one damage type of your choice: acid, cold, fire, lightning, or thunder.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-8">Level 3</h3></th>
<th><h3 id="level-3-9">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="sleet-storm">Sleet Storm</h2></th>
<th><h2 id="speak-with-plants">Speak with Plants</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>150 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a pinch of dust and some water)</strong></p>
<p>Until the spell ends, freezing rain and sleet fall in a 20-foot-tall cylinder with a 40-foot radius centered on a point you choose within range. The area is heavily obscured, and exposed flames in the area are doused.</p>
<p>The ground in the area is covered with slick ice, making it difficult terrain. When a creature enters the spell’s area for the first time on a turn or starts its turn there, it must make a Dexterity saving throw. On a failed save, it falls prone.</p>
<p>If a creature is concentrating in the spell’s area, the creature must make a successful Constitution saving throw against your spell save DC or lose concentration.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>10 Minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You imbue plants within 30 feet of you with limited sentience and animation, giving them the ability to communicate with you and follow your simple commands. You can question plants about events in the spell’s area within the past day, gaining information</p>
<p>about creatures that have passed, weather, and other</p>
<p>Circumstances.</p>
<p>You can also turn difficult terrain caused by plant growth into ordinary terrain that lasts for the duration. Or you can turn ordinary terrain where plants are present into difficult terrain that lasts for the duration.</p>
<p>Plants might be able to perform other tasks on your behalf, at the DM’s discretion. The spell doesn’t enable plants to uproot themselves and move about, but they can freely move branches, tendrils, and stalks.</p>
<p>If a plant creature is in the area, you can communicate with it as if you shared a common language, but you gain no magical ability to influence it.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-10">Level 3</h3></th>
<th><h3 id="level-3-11">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="tidal-wave">Tidal Wave</h2></th>
<th><h2 id="wall-of-water">Wall of Water</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a drop of water)</strong></p>
<p>You conjure up a wave of water that crashes down on an area within range. The area can be up to 30 feet long, up to 10 feet wide, and up to 10 feet tall. Each creature in that area must make a Dexterity saving throw. On a failed save, a creature takes 4d8 bludgeoning damage and is knocked prone. On a successful save, a creature takes half as much damage and isn’t knocked prone.</p>
<p>The water then spreads out across the ground in all directions, extinguishing unprotected flames in its area and within 30 feet of it, and then it vanishes.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a drop of water)</strong></p>
<p>You conjure up a wall of water on the ground at a point you can see within range. You can make the wall up to 30 feet long, 10 feet high, and 1 foot thick, or you can make a ringed wall up to 20 feet in diameter, 20 feet high, and 1 foot thick. The wall vanishes when the spell ends. The wall’s space is difficult terrain. Any ranged weapon attack that enters the wall’s space has disadvantage on the attack roll, and fire damage</p>
<p>is halved if the fire effect passes through the wall to reach its target. Spells that deal cold damage that pass through the wall cause the area of the wall they pass through to freeze solid (at least a 5-foot square section is frozen). Each 5-foot-square frozen section has AC 5 and 15 hit points. Reducing a frozen section to 0 hit points destroys it. When a section is destroyed, the wall’s water doesn’t fill it.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-12">Level 3</h3></th>
<th><h3 id="level-3-13">Level 3</h3></th>
</tr>
<tr class="odd">
<th><h2 id="water-breathing-ritual">Water Breathing (Ritual)</h2></th>
<th><h2 id="water-walk-ritual">Water Walk (Ritual)</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>24 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a short reed or piece of straw)</strong></p>
<p>This spell grants up to ten willing creatures you can see within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a piece of cork)</strong></p>
<p>This spell grants the ability to move across any liquid surface – such as water, acid, mud, snow, quicksand, or lava – as if it were harmless solid ground (creatures crossing molten lava can still take damage from the heat).</p>
<p>Up to ten willing creatures you can see within range gain this ability for the duration.</p>
<p>If you target a creature submerged in a liquid, the spell carries the target to the surface of the liquid at a rate of 60 feet per round.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-3-14">Level 3</h3></th>
<th><h3 id="level-3-15">Level 3</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="wind-wall">Wind Wall</h2></th>
<th><h2 id="earthen-grasp">Earthen Grasp</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M (a tiny fan and an exotic feather)</strong></p>
<p>A wall of strong wind rises from the ground at a point you choose within range.</p>
<p>You can make the wall up to 50 feet long, 15 feet high, and 1 foot thick. You can shape the wall in any way you choose so long as it makes one continuous path along the ground. The wall lasts for the duration.</p>
<p>When the wall appears, each creature within its area must make a Strength saving throw. A creature takes 3d8 bludgeoning damage on a failed save, or half as much damage on a successful one.</p>
<p>The strong wind keeps fog, smoke, and other gases at bay. Small or smaller flying creatures or objects can’t pass through the wall. Loose, lightweight materials brought into the wall fly upward. Arrows, bolts, and other ordinary projectiles launched at targets behind the wall are deflected upward and automatically miss. (Boulders hurled by giants or siege engines, and similar projectiles, are unaffected.) Creatures in gaseous form can’t pass through it.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M (a miniature hand sculpted from clay)</strong></p>
<p>You choose a 5-foot-square unoccupied space on the ground that you can see within range. A Medium hand made from compacted soil rises there and reaches</p>
<p>for one creature you can see within 5 feet of it. The target must make a Strength saving throw. On a failed save, the target takes 2d6 bludgeoning damage and is restrained for the spell’s duration.</p>
<p>As an action, you can cause the hand to crush the restrained target, who must make a Strength saving throw. It takes 2d6 bludgeoning damage on a failed save, or half as much damage on a successful one.</p>
<p>To break out, the restrained target can make a Strength check against your spell save DC. On a success, the target escapes and is no longer restrained by the hand.</p>
<p>As an action, you can cause the hand to reach for a different creature or to move to a different unoccupied space within range. The hand releases a restrained target if you do either.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-16">Level 3</h3></th>
<th><h3 id="level-2-23">Level 2</h3></th>
</tr>
<tr class="odd">
<th><h2 id="mold-earth">Mold Earth</h2></th>
<th><h2 id="control-flame">Control Flame</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Instantaneous or 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>You choose a portion of dirt or stone that you can see within range and that fits within a 5-foot cube. You manipulate it in one of the following ways:</p>
<p>If you target an area of loose earth, you can instantaneously excavate it, move it along the ground, and deposit it up to 5 feet away. This movement doesn’t have enough force to cause damage.</p>
<p>You cause shapes, colors, or both to appear on the dirt or stone, spelling out words, creating images, or shaping patterns. The changes last for 1 hour.</p>
<p>If the dirt or stone you target is on the ground, you cause it to become difficult terrain. Alternatively, you can cause the ground to become normal terrain if it is already difficult terrain. This change lasts for 1 hour.</p>
<p>If you cast this spell multiple times, you can have no more than two of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Instantaneous or 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>You affect a non-magical flame 5-foot in a 5 foot cube in one of the following ways:</p>
<p>You instantaneously expand the flame 5 feet in one direction, provided that wood or other fuel is present in the new location.</p>
<p>You instantaneously extinguish the flames within the cube.</p>
<p>You double or halve the area of bright light and dim light cast by the flame, change its color, or both. The change lasts for 1 hour.</p>
<p>You cause simple shapes — such as the vague form of a creature, an inanimate object, or a location — to appear within the flames and animate as you like. The shapes last for 1 hour.</p>
<p>If you cast this spell multiple times, you can have up to three non-instantaneous</p></th>
</tr>
<tr class="odd">
<th><h3 id="cantrip-4">Cantrip</h3></th>
<th><h3 id="cantrip-5">Cantrip</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="4"><h2 id="arctic-fox-alpha">Arctic Fox Alpha</h2>
<p>Medium beast, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>14</strong></p>
<p>Hit Points: <strong>16</strong></p></th>
<th><p>STR: <strong>12 (+1)</strong></p>
<p>DEX: <strong>16 (+3)</strong></p>
<p>CON: <strong>12 (+1)</strong></p></th>
<th colspan="2"><p>Skills: <strong>Perception +3, Stealth +5</strong></p>
<p>Senses: <strong>passive Perception 13</strong></p>
<p>Speed: <strong>40 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="special-rules">Special Rules</h3>
<p><strong>Keen Hearing and Smell.</strong> The fox has advantage on Wisdom (Perception) checks that rely on hearing or smell.</p>
<p><strong>Fox Cunning.</strong> The fox has advantage on an attack roll against a creature if at least one of the fox's allies is within 5 ft. of the creature and the ally isn't incapacitated.</p>
<h3 id="actions">Actions</h3>
<p><strong>Multiattack.</strong> Make one Bite and Pounce attack.</p>
<p><strong>Bite.</strong> <em>Melee Weapon Attack</em>: +5 to hit, reach 5 ft., one target. Hit: (2d6 + 2) piercing damage.</p>
<p><strong>Pounce.</strong> <em>Melee Weapon Attack:</em> +5 to hit, reach 5 ft., one target. <em>Hit:</em> (2d4 + 2) slashing damage. If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.</p>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
</tbody>
</table></th>
<th colspan="2"><p></p>
<p>Available as Wildshape at Druid level 4</p></th>
</tr>
<tr class="odd">
<th colspan="4"><h2 id="otter">Otter</h2>
<p>Small beast, Unaligned</p></th>
</tr>
<tr class="header">
<th><p>Armor Class: <strong>11</strong></p>
<p>Hit Points: <strong>11</strong></p></th>
<th><p>STR: <strong>11 (+1)</strong></p>
<p>DEX: <strong>12 (+1)</strong></p>
<p>CON: <strong>10 (+0)</strong></p></th>
<th colspan="2"><p>Skills: <strong>Stealth +3</strong></p>
<p>Senses: <strong>Tremorsense 30ft, passive Perception 13</strong></p>
<p>Speed: <strong>30 ft. swim 30ft, burrowing 10ft</strong></p></th>
</tr>
<tr class="odd">
<th colspan="2"><h3 id="special-rules-1">Special Rules</h3>
<p><strong>Keen Smell.</strong> The otter has advantage on Wisdom (Perception) checks that rely on smell.</p>
<p><strong>Hold Breath.</strong> The Otter can hold its breath for 8 minutes.</p>
<h3 id="actions-1">Actions</h3>
<p><strong>Bite.</strong> <em>Melee Weapon Attack:</em> +3 to hit, reach 5 ft., one target. Hit: (1d4 + 2) piercing damage.</p></th>
<th colspan="2"><p></p>
<p>Available as Wildshape at Druid level 4</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th colspan="4"><h2 id="arctic-fox">Arctic Fox</h2>
<p>Small beast, Unaligned</p></th>
</tr>
<tr class="odd">
<th><p>Armor Class: <strong>13</strong></p>
<p>Hit Points: <strong>11</strong></p></th>
<th><p>STR: <strong>12 (+1)</strong></p>
<p>DEX: <strong>15 (+2)</strong></p>
<p>CON: <strong>12 (+1)</strong></p></th>
<th colspan="2"><p>Skills: <strong>Perception +3, Stealth +4</strong></p>
<p>Senses: <strong>passive Perception 13</strong></p>
<p>Speed: <strong>45 ft.</strong></p></th>
</tr>
<tr class="header">
<th colspan="2"><h3 id="special-rules-2">Special Rules</h3>
<p><strong>Keen Hearing and Smell.</strong> The fox has advantage on Wisdom (Perception) checks that rely on hearing or smell.</p>
<p><strong>Fox Cunning.</strong> The fox has advantage on an attack roll against a creature if at least one of the fox's allies is within 5 ft. of the creature and the ally isn't incapacitated.</p>
<h3 id="actions-2">Actions</h3>
<p><strong>Pounce.</strong> <em>Melee Weapon Attack:</em> +4 to hit, reach 5 ft., one target. Hit: (2d4 + 2) piercing damage. If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone</p>
<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
</tbody>
</table></th>
<th colspan="2"><p></p>
<p>Available as Wildshape at Druid level 1</p></th>
</tr>
<tr class="odd">
<th colspan="4"><h2 id="lizard">Lizard</h2>
<p>Tiny beast, Unaligned</p></th>
</tr>
<tr class="header">
<th><p>Armor Class: <strong>10</strong></p>
<p>Hit Points: <strong>2</strong></p></th>
<th><p>STR: <strong>2 (-4)</strong></p>
<p>DEX: <strong>11 (+0)</strong></p>
<p>CON: <strong>10 (+0)</strong></p></th>
<th colspan="2"><p>Skills: <strong>None</strong></p>
<p>Senses: <strong>Darkvision 30ft, passive Perception 9</strong></p>
<p>Speed: <strong>20 ft. climb 20ft</strong></p></th>
</tr>
<tr class="odd">
<th colspan="2"><h3 id="special-rules-3">Special Rules</h3>
<p><strong>Unnoticeable.</strong> When standing still, the Lizard has advantage on Dexterity (Stealth) rolls.</p>
<h3 id="actions-3">Actions</h3>
<p><strong>Bite.</strong> <em>Melee Weapon Attack:</em> +0 to hit, reach 5 ft., one target. Hit: 1 piercing damage.</p></th>
<th colspan="2"><p></p>
<p>Available as Wildshape at Druid level 1</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="slow">Slow</h2></th>
<th><h2 id="freedom-of-movement">Freedom of Movement</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M</strong></p>
<p>You alter time around up to six creatures of your choice in a 40-foot cube within range. Each target must succeed on a Wisdom saving throw or be affected by this spell for the duration.</p>
<p>An affected target's speed is halved, it takes a −2 penalty to AC and Dexterity saving throws, and it can't use reactions. On its turn, it can use either an action or a bonus action, not both. Regardless of the creature's abilities or magic items, it can't make more than one melee or ranged attack during its turn.</p>
<p>If the creature attempts to cast a spell with a casting time of 1 action, roll a d20. On an 11 or higher, the spell doesn't take effect until the creature's next turn, and the creature must use its action on that turn to complete the spell. If it can't, the spell is wasted.</p>
<p>A creature affected by this spell makes another Wisdom saving throw at the end of each of its turns. On a successful save, the effect ends for it.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>touch</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You touch a willing creature. For the duration, the target's movement is unaffected by difficult terrain, and spells and other magical effects can neither reduce the target's speed nor cause the target to be paralyzed or restrained.</p>
<p>The target can also spend 5 feet of movement to automatically escape from non magical restraints, such as manacles or a creature that has it grappled. Finally, being underwater imposes no penalties on the target's movement or attacks.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-3-17">Level 3</h3></th>
<th><h3 id="level-4">Level 4</h3></th>
</tr>
<tr class="odd">
<th><h2 id="ice-storm">Ice Storm</h2></th>
<th><h2 id="section"></h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>300 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>A hail of rock-hard ice pounds to the ground in a 20-foot-radius, 40-foot-high cylinder centered on a point within range. Each creature in the cylinder must make a Dexterity saving throw. A creature takes 2d8 bludgeoning damage and 4d6 cold damage on a failed save, or half as much damage on a successful one.</p>
<p>Hailstones turn the storm's area of effect into difficult terrain until the end of your next turn.</p>
<p>At Higher Levels.</p>
<p>When you cast this spell using a spell slot of 5th level or higher, the bludgeoning damage increases by 1d8 for each slot level above 4th.</p></th>
<th></th>
</tr>
<tr class="odd">
<th><h3 id="level-4-1">Level 4</h3></th>
<th><h3 id="section-1"></h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:67%;">
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="watery-sphere">Watery Sphere</h2></th>
<th><h2 id="polymorph">Polymorph</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You conjure up a sphere of water with a 5-foot radius at a point you can see within range. The sphere can hover but no more than 10 feet off the ground. The sphere remains for the spell's duration.</p>
<p>Any creature in the sphere's space must make a Strength saving throw. On a successful save, a creature is ejected from that space to the nearest unoccupied space of the creature's choice outside the sphere. A Huge or larger creature succeeds on the saving throw automatically, and a Large or smaller creature can choose to fail it. On a failed save, a creature is restrained by the sphere and is engulfed by the water. At the end of each of its turns, a restrained target can repeat the saving throw, ending the effect on itself on a success.</p>
<p>The sphere can restrain as many as four Medium or smaller creatures or one Large creature. If the sphere restrains a creature that causes it to exceed this capacity, a random creature that was already restrained by the sphere falls out of it and lands prone in a space within 5 feet of it.</p>
<p>As an action, you can move the sphere up to 30 feet in a straight line. If it moves over a pit, a cliff, or other drop-off, it safely descends until it is hovering 10 feet above the ground. Any creature restrained by the sphere moves with it. You can ram the sphere into creatures, forcing them to make the saving throw.</p>
<p>When the spell ends, the sphere falls to the ground and extinguishes all normal flames within 30 feet of it. Any creature restrained by the sphere is knocked prone in the space where it falls. The water then vanishes.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>This spell transforms a creature that you can see within range into a new form. An unwilling creature must make a Wisdom saving throw to avoid the effect. The spell has no effect on a shapechanger or a creature with 0 hit points.</p>
<p>The transformation lasts for the duration, or until the target drops to 0 hit points or dies. The new form can be any beast whose challenge rating is equal to or less than the target's (or the target's level, if it doesn't have a challenge rating). The target's game statistics, including mental ability scores, are replaced by the statistics of the chosen beast. It retains its alignment and personality.</p>
<p>The target assumes the hit points of its new form. When it reverts to its normal form, the creature returns to the number of hit points it had before it transformed. If it reverts as a result of dropping to 0 hit points, any excess damage carries over to its normal form. As long as the excess damage doesn't reduce the creature's normal form to 0 hit points, it isn't knocked unconscious.</p>
<p>The creature is limited in the actions it can perform by the nature of its new form, and it can't speak, cast spells, or take any other action that requires hands or speech.</p>
<p>The target's gear melds into the new form. The creature can't activate, use, wield, or otherwise benefit from any of its equipment.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-2">Level 4</h3></th>
<th><h3 id="level-4-3">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="wall-of-fire">Wall of Fire</h2></th>
<th><h2 id="summon-elemental">Summon Elemental</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>120 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M</strong></p>
<p>You create a wall of fire on a solid surface within range. You can make the wall up to 60 feet long, 20 feet high, and 1 foot thick, or a ringed wall up to 20 feet in diameter, 20 feet high, and 1 foot thick. The wall is opaque and lasts for the duration.</p>
<p>When the wall appears, each creature within its area must make a Dexterity saving throw. On a failed save, a creature takes 5d8 fire damage, or half as much damage on a successful save.</p>
<p>One side of the wall, selected by you when you cast this spell, deals 5d8 fire damage to each creature that ends its turn within 10 feet of that side or inside the wall. A creature takes the same damage when it enters the wall for the first time on a turn or ends its turn there. The other side of the wall deals no damage.</p>
<p>At Higher Levels: When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d8 for each slot level above 4th.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You call forth an elemental spirit. It manifests in an unoccupied space that you can see within range. This corporeal form uses the Elemental Spirit stat block. When you cast the spell, choose an element: Air, Earth, Fire, or Water. The creature resembles a bipedal form wreathed in the chosen element, which determines certain traits in its stat block. The creature disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The creature is an ally to you and your companions. In combat, the creature shares your initiative count, but it takes its turn immediately after yours. It obeys your verbal commands (no action required by you). If you don't issue any, it takes the Dodge action and uses its move to avoid danger.</p>
<p>At Higher Levels: When you cast this spell using a spell slot of 5th level or higher, use the higher level wherever the spell's level appears in the stat block.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-4">Level 4</h3></th>
<th><h3 id="level-4-5">Level 4</h3></th>
</tr>
<tr class="odd">
<th><h2 id="stoneskin">Stoneskin</h2></th>
<th><h2 id="stone-shape">Stone Shape</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>This spell turns the flesh of a willing creature you touch as hard as stone. Until the spell ends, the target has resistance to nonmagical bludgeoning, piercing, and slashing damage.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Touch</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You touch a stone object of Medium size or smaller or a section of stone no more than 5 feet in any dimension and form it into any shape that suits your purpose. So, for example, you could shape a large rock into a weapon, idol, or coffer, or make a small passage through a wall, as long as the wall is less than 5 feet thick. You could also shape a stone door or its frame to seal the door shut. The object you create can have up to two hinges and a latch, but finer mechanical detail isn't possible.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-4-6">Level 4</h3></th>
<th><h3 id="level-4-7">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="section-2"></h2></th>
<th><h2 id="locate-creature">Locate Creature</h2></th>
</tr>
<tr class="odd">
<th></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>Describe or name a creature that is familiar to you. You sense the direction to the creature's location, as long as that creature is within 1,000 feet of you. If the creature is moving, you know the direction of its movement.</p>
<p>The spell can locate a specific creature known to you, or the nearest creature of a specific kind (such as a human or a unicorn), so long as you have seen such a creature up close—within 30 feet—at least once. If the creature you described or named is in a different form, such as being under the effects of a polymorph spell, this spell doesn't locate the creature.</p>
<p>This spell can't locate a creature if running water at least 10 feet wide blocks a direct path between you and the creature.</p></th>
</tr>
<tr class="header">
<th><h3 id="section-3"></h3></th>
<th><h3 id="level-4-8">Level 4</h3></th>
</tr>
<tr class="odd">
<th><h2 id="hallucinatory-terrain">Hallucinatory Terrain</h2></th>
<th><h2 id="guardian-of-nature">Guardian of Nature</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Illusion</strong></p>
<p>Casting time: <strong>10 minutes</strong></p></th>
<th><p>Range: <strong>300 feet</strong></p>
<p>Duration: <strong>24 hours</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You make natural terrain in a 150-foot cube in range look, sound, and smell like some other sort of natural terrain. Thus, open fields or a road can be made to resemble a swamp, hill, crevasse, or some other difficult or impassable terrain. A pond can be made to seem like a grassy meadow, a precipice like a gentle slope, or a rock-strewn gully like a wide and smooth road. Manufactured structures, equipment, and creatures within the area aren't changed in appearance.</p>
<p>The tactile characteristics of the terrain are unchanged, so creatures entering the area are likely to see through the illusion. If the difference isn't obvious by touch, a creature carefully examining the illusion can attempt an Intelligence (Investigation) check against your spell save DC to disbelieve it. A creature who discerns the illusion for what it is, sees it as a vague image superimposed on the terrain.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>A nature spirit answers your call and transforms you into a powerful guardian. The transformation lasts until the spell ends. You choose one of the following forms to assume: Primal Beast or Great Tree.</p>
<p>Primal Beast: Bestial fur covers your body, your facial features become feral, and you gain the following benefits:</p>
<ul>
<li><blockquote>
<p>Your walking speed increases by 10 feet.</p>
</blockquote></li>
<li><blockquote>
<p>You gain darkvision with a range of 120 feet.</p>
</blockquote></li>
<li><blockquote>
<p>You make Strength-based attack rolls with advantage.</p>
</blockquote></li>
<li><blockquote>
<p>Your melee weapon attacks deal an extra 1d6 force damage on a hit.</p>
</blockquote></li>
</ul>
<p>Great Tree: Your skin appears barky, leaves sprout from your hair, and you gain the following benefits:</p>
<ul>
<li><blockquote>
<p>You gain 10 temporary hit points.</p>
</blockquote></li>
<li><blockquote>
<p>You make Constitution saving throws with advantage.</p>
</blockquote></li>
<li><blockquote>
<p>You make Dexterity- and Wisdom-based attack rolls with advantage.</p>
</blockquote></li>
<li><blockquote>
<p>While you are on the ground, the ground within 15 feet of you is difficult terrain for your enemies.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="odd">
<th><h3 id="level-4-9">Level 4</h3></th>
<th><h3 id="level-4-10">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="grasping-vine">Grasping Vine</h2></th>
<th><h2 id="giant-insect">Giant Insect</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S, M</strong></p>
<p>You conjure a vine that sprouts from the ground in an unoccupied space of your choice that you can see within range. When you cast this spell, you can direct the vine to lash out at a creature within 30 feet of it that you can see. That creature must succeed on a Dexterity saving throw or be pulled 20 feet directly toward the vine.</p>
<p>Until the spell ends, you can direct the vine to lash out at the same creature or another one as a bonus action on each of your turns.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You transform up to ten centipedes, three spiders, five wasps, or one scorpion within range into giant versions of their natural forms for the duration. A centipede becomes a giant centipede, a spider becomes a giant spider, a wasp becomes a giant wasp, and a scorpion becomes a giant scorpion.</p>
<p>Each creature obeys your verbal commands, and in combat, they act on your turn each round. The DM has the statistics for these creatures and resolves their actions and movement.</p>
<p>A creature remains in its giant size for the duration, until it drops to 0 hit points, or until you use an action to dismiss the effect on it.</p>
<p>The DM might allow you to choose different targets. For example, if you transform a bee, its giant version might have the same statistics as a giant wasp.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-11">Level 4</h3></th>
<th><h3 id="level-4-12">Level 4</h3></th>
</tr>
<tr class="odd">
<th><h2 id="fire-shield">Fire Shield</h2></th>
<th><h2 id="elemental-bane">Elemental Bane</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>Thin and wispy flames wreathe your body for the duration, shedding bright light in a 10-foot radius and dim light for an additional 10 feet. You can end the spell early by using an action to dismiss it.</p>
<p>The flames provide you with a warm shield or a chill shield, as you choose. The warm shield grants you resistance to cold damage, and the chill shield grants you resistance to fire damage.</p>
<p>In addition, whenever a creature within 5 feet of you hits you with a melee attack, the shield erupts with flame. The attacker takes 2d8 fire damage from a warm shield, or 2d8 cold damage from a cold shield.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>Choose one creature you can see within range, and choose one of the following damage types: acid, cold, fire, lightning, or thunder. The target must succeed on a Constitution saving throw or be affected by the spell for its duration. The first time each turn the affected target takes damage of the chosen type, the target takes an extra 2d6 damage of that type. Moreover, the target loses any resistance to that damage type until the spell ends.</p>
<p>At Higher Levels.</p>
<p>When you cast this spell using a spell slot of 5th level or higher, you can target one additional creature for each slot level above 4th. The creatures must be within 30 feet of each other when you target them.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-4-13">Level 4</h3></th>
<th><h3 id="level-4-14">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:67%;">
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="dominate-beast">Dominate Beast</h2></th>
<th><h2 id="control-water">Control Water</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You attempt to beguile a beast that you can see within range. It must succeed on a Wisdom saving throw or be charmed by you for the duration. If you or creatures that are friendly to you are fighting it, it has advantage on the saving throw.</p>
<p>While the beast is charmed, you have a telepathic link with it as long as the two of you are on the same plane of existence. You can use this telepathic link to issue commands to the creature while you are conscious (no action required), which it does its best to obey. You can specify a simple and general course of action, such as "Attack that creature," "Run over there," or "Fetch that object." If the creature completes the order and doesn't receive further direction from you, it defends and preserves itself to the best of its ability.</p>
<p>You can use your action to take total and precise control of the target. Until the end of your next turn, the creature takes only the actions you choose, and doesn't do anything that you don't allow it to do. During this time, you can also cause the creature to use a reaction, but this requires you to use your own reaction as well.</p>
<p>Each time the target takes damage, it makes a new Wisdom saving throw against the spell. If the saving throw succeeds, the spell ends.</p>
<p>At Higher Levels: When you cast this spell with a 5th-level spell slot, the duration is concentration, up to 10 minutes. When you use a 6th-level spell slot, the duration is concentration, up to 1 hour. When you use a spell slot of 7th level or higher, the duration is concentration, up to 8 hours.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Until the spell ends, you control any freestanding water inside an area you choose that is a cube up to 100 feet on a side. You can choose from any of the following effects when you cast this spell. As an action on your turn, you can repeat the same effect or choose a different one.</p>
<p>Flood: You cause the water level of all standing water in the area to rise by as much as 20 feet. If the area includes a shore, the flooding water spills over onto dry land.</p>
<p>If you choose an area in a large body of water, you instead create a 20-foot tall wave that travels from one side of the area to the other and then crashes down. Any Huge or smaller vehicles in the wave's path are carried with it to the other side. Any Huge or smaller vehicles struck by the wave have a 25 percent chance of capsizing.</p>
<p>The water level remains elevated until the spell ends or you choose a different effect. If this effect produced a wave, the wave repeats on the start of your next turn while the flood effect lasts.</p>
<p>Part Water: You cause water in the area to move apart and create a trench. The trench extends across the spell's area, and the separated water forms a wall to either side. The trench remains until the spell ends or you choose a different effect. The water then slowly fills in the trench over the course of the next round until the normal water level is restored.</p>
<p>Redirect Flow.</p>
<p>You cause flowing water in the area to move in a direction you choose, even if the water has to flow over obstacles, up walls, or in other unlikely directions. The water in the area moves as you direct it, but once it moves beyond the spell's area, it resumes its flow based on the terrain conditions. The water continues to move in the direction you chose until the spell ends or you choose a different effect.</p>
<p>Whirlpool: This effect requires a body of water at least 50 feet square and 25 feet deep. You cause a whirlpool to form in the center of the area. The whirlpool forms a vortex that is 5 feet wide at the base, up to 50 feet wide at the top, and 25 feet tall. Any creature or object in the water and within 25 feet of the vortex is pulled 10 feet toward it. A creature can swim away from the vortex by making a Strength (Athletics) check against your spell save DC.</p>
<p>When a creature enters the vortex for the first time on a turn or starts its turn there, it must make a Strength saving throw. On a failed save, the creature takes 2d8 bludgeoning damage and is caught in the vortex until the spell ends. On a successful save, the creature takes half damage, and isn't caught in the vortex. A creature caught in the vortex can use its action to try to swim away from the vortex as described above, but has disadvantage on the Strength (Athletics) check to do so.</p>
<p>The first time each turn that an object enters the vortex, the object takes 2d8 bludgeoning damage; this damage occurs each round it remains in the vortex.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-15">Level 4</h3></th>
<th><h3 id="level-4-16">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="charm-monster">Charm Monster</h2></th>
<th><h2 id="divination-ritual">Divination Ritual</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>S</strong></p>
<p>You attempt to charm a creature you can see within range. It must make a Wisdom saving throw, and it does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it. The charmed creature is friendly to you. When the spell ends, the creature knows it was charmed by you.</p>
<p>At Higher Levels: When you cast this spell using a spell slot of 5th level or higher, you can target one additional creature for each slot level above 4th. The creatures must be within 30 feet of each other when you target them.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Divination</strong></p>
<p>Casting time: <strong>10 Minutes</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M(25g worth of materials)</strong></p>
<p>Your magic and an offering put you in contact with a god or a god's servants. You ask a single question concerning a specific goal, event, or activity to occur within 7 days. The DM offers a truthful reply. The reply might be a short phrase, a cryptic rhyme, or an omen.</p>
<p>The spell doesn't take into account any possible circumstances that might change the outcome, such as the casting of additional spells or the loss or gain of a companion.</p>
<p>If you cast the spell two or more times before finishing your next long rest, there is a cumulative 25 percent chance for each casting after the first that you get a random reading. The DM makes this roll in secret.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-17">Level 4</h3></th>
<th><h3 id="level-4-18">Level 4</h3></th>
</tr>
<tr class="odd">
<th><h2 id="blight">Blight</h2></th>
<th><h2 id="conjure-woodland-beings">Conjure Woodland Beings</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Necromancy</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>30 feet</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S</strong></p>
<p>Necromantic energy washes over a creature of your choice that you can see within range, draining moisture and vitality from it. The target must make a Constitution saving throw. The target takes 8d8 necrotic damage on a failed save, or half as much damage on a successful one. This spell has no effect on undead or constructs.</p>
<p>If you target a plant creature or a magical plant, it makes the saving throw with disadvantage, and the spell deals maximum damage to it.</p>
<p>If you target a nonmagical plant that isn't a creature, such as a tree or shrub, it doesn't make a saving throw, it simply withers and dies.</p>
<p>At Higher Levels: When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d8 for each slot level above 4th.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour.</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>You summon fey creatures that appear in unoccupied spaces that you can see within range. Choose one of the following options for what appears:</p>
<ul>
<li><blockquote>
<p>One Darkling Elder or a Sea Hag</p>
</blockquote></li>
<li><blockquote>
<p>Two Dryads or Quicklings</p>
</blockquote></li>
<li><blockquote>
<p>Four Satyr</p>
</blockquote></li>
<li><blockquote>
<p>Eight Sprites or Pixies</p>
</blockquote></li>
</ul>
<p>A summoned creature disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The summoned creatures are friendly to you and your companions. Roll initiative for the summoned creatures as a group, which have their own turns. They obey any verbal commands that you issue to them (no action required by you). If you don't issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.</p>
<p>At Higher Levels: When you cast this spell using certain higher-level spell slots, you choose one of the summoning options above, and more creatures appear: twice as many with a 6th-level slot and three times as many with an 8th-level slot.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-4-19">Level 4</h3></th>
<th><h3 id="level-4-20">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="conjure-minor-elementals">Conjure Minor Elementals</h2></th>
<th><h2 id="confusion">Confusion</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Evocation</strong></p>
<p>Casting time: <strong>1 minute</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You summon elementals that appear in unoccupied spaces that you can see within range. You choose one the following options for what appears:</p>
<ul>
<li><blockquote>
<p>One Gargoyle</p>
</blockquote></li>
<li><blockquote>
<p>Two Frost Serpents (Fire Snake)</p>
</blockquote></li>
<li><blockquote>
<p>Four Ice Mephits</p>
</blockquote></li>
<li><blockquote>
<p>Eight Mist Mephits (Smoke Mephits)</p>
</blockquote></li>
</ul>
<p>An elemental summoned by this spell disappears when it drops to 0 hit points or when the spell ends.</p>
<p>The summoned creatures are friendly to you and your companions. Roll initiative for the summoned creatures as a group, which has its own turns. They obey any verbal commands that you issue to them (no action required by you). If you don't issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.</p>
<p>At Higher Levels:When you cast this spell using certain higher-level spell slots, you choose one of the summoning options above, and more creatures appear: twice as many with a 6th-level slot and three times as many with an 8th-level slot.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V,S,M</strong></p>
<p>This spell assaults and twists creatures' minds, spawning delusions and provoking uncontrolled action. Each creature in a 10-foot-radius sphere centered on a point you choose within range must succeed on a Wisdom saving throw when you cast this spell or be affected by it.</p>
<p>An affected target can't take reactions and must roll a d10 at the start of each of its turns to determine its behavior for that turn.</p>
<table>
<colgroup>
<col style="width: 12%" />
<col style="width: 87%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>d10</strong></th>
<th><strong>Behavior</strong></th>
</tr>
<tr class="odd">
<th>1</th>
<th>The creature uses all its movement to move in a random direction. To determine the direction, roll a d8 and assign a direction to each die face. The creature doesn't take an action this turn.</th>
</tr>
<tr class="header">
<th>2-6</th>
<th>The creature doesn't move or take actions this turn.</th>
</tr>
<tr class="odd">
<th>7-8</th>
<th>The creature uses its action to make a melee attack against a randomly determined creature within its reach. If there is no creature within its reach, the creature does nothing this turn.</th>
</tr>
<tr class="header">
<th>9-10</th>
<th>The creature can act and move normally.</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>At the end of each of its turns, an affected target can make a Wisdom saving throw. If it succeeds, this effect ends for that target.</p>
<p>At Higher Levels: When you cast this spell using a spell slot of 5th level or higher, the radius of the sphere increases by 5 feet for each slot level above 4th.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-4-21">Level 4</h3></th>
<th><h3 id="level-4-22">Level 4</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
