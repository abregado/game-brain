---
title: "New Meetup Formats"
source: "Game Stuff/New Meetup Formats"
modified: 2026-04-09
type: planning
area: other
status: "designed"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["Game Dev Meetup Frankfurt"]
words: 256
summary: "Plan for restructuring Frankfurt in-person and online game dev meetups with presentation types (frontal, table, video loop, Discord feedback)."
tags: ["area/other", "project/fdnd-campaign-frankfurt", "type/planning"]
---

## New Meetup Formats

Damn. We have the “problem” that there are too many cool people at our meetup and people want more time to talk amongst themselves.

### In person meetup Frankfurt

Pizza arrives at 7:00pm

Social mixer until 8pm

News and notes from Ben at 8pm

Calls for help on Discord listed

Frontal Presentations 8-9pm

Each pres 10-15mins (based on amount of list people)

Probably get a stage timer.

Table presentations and social mixer

9pm until 10:00pm

During this time I play videos and trailers from a playlist on a loop. If you want your thing on there then you can send me a video.

The meetup PC is available for table presentations as well during this time

Langsam gehen bis 11pm

Schnell gehen nach 11pm

### Online meetup

Capping topics at 20-30 mins, but apart from that the format is working well.

### Opportunities 

Members should decide which of these presentation types work best for their project.

**Frontal Presentations.** Show your thing or progress in front of everyone, ask for specific feedback.

**Table presentations**. People can come by and look or get stuck in. Better for longer discussions that might only interest a portion of people.

**Video playlist loop**. Good if you just want to show something but don't want feedback.

**Discord feedback**. Post it on the discord and then collect feedback there. I'll go over a list of people who want feedback at the start of the meetup.

**Online meetup**. It's all about presentations so might be a better option for you.
