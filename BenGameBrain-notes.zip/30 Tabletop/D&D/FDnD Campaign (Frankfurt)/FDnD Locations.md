---
title: "FDnD Locations"
source: "Game Stuff/D&D/FDnD Locations"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Dessarin Valley locations"]
words: 503
summary: "Quick-reference cheat-sheet of key NPCs and locations in Red Larch, Triboar, Westbridge, Beliard, Summit Hall, Womford/Ironford."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

Red Larch

- Allfaiths Shrine

  - Idris Relvaunder - Tempus Priest

  - Lydia Alldark - Sune Priestess

- (Inn) The Swinging Sword / Helm at Highsun

  - Larmon Greenboot - new graves outside Red larch

  - Aaron Thelder - Stablemaster - Howling Hatred

  - Gilly - Maid - Crushing Wave

  - Kaylessa Irkell - Owner + Quest

  - Brother Edric - Lathandar Preist - Met with delegation in Beliard

- (Inn) Mother Yalanthas

  - Yalantha Dreen - Owner

  - Workers staying here are cultists of Black Earth

- (Bath) Haeleeyas

  - Haeleeya Hanadroum - Owner

  - Gossip is available here

  - 1gp for full service bath

- (Smith) Ironhead Arms

  - Feng Ironhead - Honest Merchant

- Bethendurs Storage

  - Abraham Bethendar - Owner - Belevier

- 

Triboar

The players need to decide if they go to Beliard or to Red Larch.

Important Locations

- (Inn) Everwyvern House / Pleasing Platter

  - Draven Millovyr - Mage + Owner

  - 15g per night

  - 25g per meal

  - Windharrow performs here

- (Trader) The Lions Share

  - Nathan Tezrin - Owner

- (Wagonshouse) The Cart and Coin

  - Arn Widdens - Owner

- (Mercs) The Triboar Travelers

  - Alan Stockspool - Zhentarin Contact

  - Valken Naspeer - Zhentarim Assassin

  - 4g per day as a guard

  - 600g to guard a caravan down to Waterdeep

- (Townmaster) Tower + Market

  - Darathra Shendrel - Lord Protector

  - 12 Knights (some out on patrol)

- (Inn) Northshield House

  - Ursula Meltimer + 3 Mastiffs - Owner

  - Zomith - Caravan Guard - knows the Delegation arrived in Beliard

  - Silvarren Loomshank - Priest of Helm

  - 1g per night, meal included

- (Smith) Foehammers Forge and Arms

  - Ghelryn Foehammer - Royal Armorer

- (Private Estate) Boars Rest

  - Hayden Kolstaag - Mage and Owner

- (Inn) North and West Campgrounds

  - Free board to travellers

Westbridge

Poultry and swamp rumors

- Harvest Inn

  - Stan Thistlehair - Carpenter - tells that Waelvur is up to something

- Mhandyvers Poultry

  - Minthra “Minny” Mhandyver - Can give a clue that Red Larch officials have a “boys club”

- Waelvurs Wagonworks

  - Umi - Amnian Merchant - gives location of Scarlet Moon Hall and festival

Beliard

Cows and a watchful Sherrif

- (Inn) Watchful Knight

  - Garlen Harkathurl - Owner

  - Justin Daehl - Crushing Wave

- (Market) Town Market

- (Butcher/Sherrif/Jail) Jalessa Ornra

  - Jalessa Ornra - Butcher/Owner

  - Harburk Tuthmarillar - Sherrif/Worker

- (Tanner) Luruths Tannery

  - Ulric Luruth - Beleiver

- (Tailor) Tarnlars

  - Henry Tarnlar - Owner

  - Megan Tarnlar - Owner

- (General store) Vallivoes Sundries

  - Edgar Vallivoe - Book of Bruthendor

Outside Red Larch

- Mellikho Stoneworks

  - Alban Mellikho - Beleiver

- Dornen Finestone

  - Eric Dornen - Beleiver leader

Summit Hall

- Lady Uschien Stormbanner - Knight Veteren

- 

Womford/ironford

- River Crossing

- Bargewight Inn

  - Caleb Muruin - Operator

  - Nadir Thaelond - Innkeeper

  - Long Road and New Management Quests

- Ironford Bridge (tolled)
