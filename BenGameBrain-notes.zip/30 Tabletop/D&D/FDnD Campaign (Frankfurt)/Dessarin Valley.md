---
title: "Dessarin Valley"
source: "Game Stuff/D&D/FDnD Files/Dessarin Valley"
modified: 2020-04-25
type: reference-data
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign"]
words: 22
summary: "Tiny hub page linking to Dessarin Valley map and location documents (Triboar, Westbridge, Beliard, Red Larch, Feathergale Spire etc)."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/reference-data"]
---

# Dessarin Valley

## Maps

[*Dessarin Valley map*](https://drive.google.com/file/d/1nVuWvVDYzvq8-nsAnmyXgJZgxdk1sptD/view)

## Locations

[*Triboar*](https://drive.google.com/open?id=1YtCM-cDJiz4IHOaDJU53u1lDk9Q7oTb9_lTqDu9u-JM)

[*Westbridge*](https://drive.google.com/open?id=1uCMZbNF4boMkIdK-dfg9E6Af9qM5gSW_nBND_-hUHr0)

[*Beliard*](https://drive.google.com/open?id=10-8NZwpSySFDMMsRJbhWoWb7UFCtZi5ISmMGEzvA5Po)

Womford/Ironford

[*Red larch*](https://drive.google.com/open?id=1wcjSAWDDWge1mE8a7sJpAbnohWBWT0u4FA-K-CXgo2c)

Yatar

Goldenfields

Summit Hall

[*Feathergale Spire*](https://drive.google.com/open?id=1Jy45Zdg3mjF0lYeOrT5RIhUInlK8d96xyj9b4ybCsAM)
