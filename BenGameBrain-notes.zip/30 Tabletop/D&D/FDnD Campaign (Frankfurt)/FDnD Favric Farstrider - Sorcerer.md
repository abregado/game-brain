---
title: "FDnD Favric Farstrider - Sorcerer"
source: "Game Stuff/D&D/FDnD Favric Farstrider - Sorcerer"
modified: 2020-02-12
type: character
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign (Frankfurt)", "D&D homebrew items"]
words: 2600
summary: "Full character sheet for Favric Farstrider, a Dragon Soul sorcerer/charlatan: stats, features, spells, items, homebrew magic items and personality."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/character"]
---

## Favric Farstrider

**Dragon Soul Sorcerer - Chaotic Neutral**

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 13      | 15      | 10      | 12      | 18      |
| -1      | +1      | +2      | +0      | +1      | +4      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 14     | 45     | 5D6    | 30ft     | 8ft      | 16ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +1      | +5      | +0      | +1      | +7      |

### Proficiencies:

**Insight (Wisdom) +4**

**Persuasion (Charisma) +7**

**Deception (Charisma) +7**

**Sleight of Hand (Dexterity) +4**

**Disguise Kit (Intelligence) +3**

**Forgery Kit (Intelligence) +3**

**Daggers (Dexterity) +4**

**Darts, Slings, Light Crossbow (Dexterity) +4**

**Quarterstaff (Strength) +2**

### Languages:

**Common, Giant and Draconic**

### Secret Identity - Charlatan

You have created a second identity that includes documentation, established acquaintances, and disguises that allow you to assume that persona. Additionally, you can forge documents including official papers and personal letters, as long as you have seen an example of the kind of document or the handwriting you are trying to copy.

### Healer 

You are an able physician, allowing you to mend wounds quickly and get your allies back in the fight. You gain the following benefits:

**When you use a healer's kit to stabilize a dying creature:** that creature also regains 1 hit point.

**Action:** you can spend one use of a healer's kit to tend to a creature and restore 1d6 + 4 hit points to it, plus additional hit points equal to the creature's maximum number of Hit Dice. The creature can't regain hit points from this feat again until it finishes a short or long rest.

# Dragon Heritage

Favric’s bloodline was tainted long ago by a dragon. He gains several abilities from this lineage.

### Draconic Ancestry

You can speak, read, and write Draconic. Additionally, when making Charisma checks to interact with Dragons, your proficiency bonus is doubled if it would apply to the check.

### Draconic Resilience

Your hit point maximum increases by 1 per level in the sorcerer class. Additionally, parts of you skin are covered by scales. When not wearing armor, your AC is 13 + your Dexterity modifier.

# Elemental Magic

Your magic comes from an internal elemental reserve which you can call out at will.

### Font of Magic

You have 5 sorcery points. You can never have more sorcery points than shown on the table for your level. You regain all points when you finish a long rest.

### Flexible Casting

**Bonus action:** you can expend one spell slot and gain a number of sorcery points equal to the slot’s level.

**Bonus action:** you can expend sorcery points to create a spell slot. These slots vanish when you finish a long rest.

### MetaMagic

You have two Metamagic options. You can only use one Metamagic option on a spell when you cast it, unless otherwise noted.

### Heightened Spell

**When casting a spell that forces a creature to make a saving throw to resist its effect:** spend 3 sorcery points to impose disadvantage on its first saving throw against the spell.

### Twinned Spell

**When casting a spell that can only target one creature and doesn’t have a range of self:** spend a number of sorcery points equal to the spell’s level to target a second creature in range with the same spell (1 Sorcery point if its a cantrip).

# Cantrips

### Prestidigitation

- Casting Time: 1 action

- Range: 10 feet

- Components: V S

- Duration: Up to 1 hour

This spell is a minor magical trick that novice spellcasters use for practice. You create one of the following magical Effects within range.

• You create an Instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.

• You instantaneously light or snuff out a Candle, a torch, or a small campfire.

• You instantaneously clean or soil an object no larger than 1 cubic foot.

• You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.

• You make a color, a small mark, or a Symbol appear on an object or a surface for 1 hour.

• You create a nonmagical trinket or an illusory image that can fit in your hand and that lasts until the end of your next turn.

If you cast this spell multiple times, you can have up to three of its non-instantaneous Effects active at a time, and you can dismiss such an effect as an action.

### Shadow dragon claw

- Casting Time: 1 action

- Range: 30 feet

- Components: V S

- Duration: 1 minute

A spectral claw appears at a point you choose within range. The claw lasts for the Duration or until you dismiss it as an action. The claw vanishes if it is ever more than 30 feet away from you or if you cast this spell again.

You can use your action to control the claw. You can use the claw to manipulate an object, open an unlocked door or container, stow or retrieve an item from an open container, or pour the contents out of a vial. You can move the claw up to 30 feet each time you use it.

The claw can't Attack, activate magical items, or carry more than 10 pounds.

### Crippling spear

- Casting Time: 1 action

- Range: 60 feet

- Components: V S

- Duration: Instantaneous

You clap your hands together and then slide them apart, a short throwing spear of energy appearing between them.

Make a ranged spell Attack against the target. On a hit, it takes 1d8 cold damage, and its speed is reduced by 10 feet until the start of your next turn.

The spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).

### Numbing pulse

- Casting Time: 1 action

- Range: Touch

- Components: V S

- Duration: Instantaneous

You attempt to touch a target but a pulse of elemental energy pushes your hand back away.

Make a melee spell Attack against the target. You have advantage on the Attack roll if the target is wearing armor made of metal. On a hit, the target takes 1d8 lightning damage, and it can't take reactions until the start of its next turn.

The spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).

### Draining barb

- Casting Time: 1 action

- Range: 120 feet

- Components: V S

- Duration: 1 round

Closing and opening your fist, a shard of hard energy appears. You throw it at a target, and when it hits, it sinks in half way.

Make a ranged spell Attack against the target. On a hit, the target takes 1d8 necrotic damage, and it can't regain Hit Points until the start of your next turn. The barb then dissolves.

If you hit an Undead target, it also has disadvantage on Attack rolls against you until the end of your next turn.

This spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).

# Spells - Lvl 1



### Charm Person

- Casting Time: 1 action

- Range: 30 feet

- Components: V S

- Duration: 1 hour

You attempt to charm a humanoid you can see within range. It must make a Wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it. The charmed creature regards you as a friendly acquaintance. When the spell ends, the creature knows it was charmed by you.

At Higher Levels: When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st. The creatures must be within 30 feet of each other when you target them.

### Disguise Self

- Casting Time: 1 action

- Range: Self

- Components: V S

- Duration: 1 hour

You make yourself—including your clothing, armor, weapons, and other belongings on your person—look different until the spell ends or until you use your action to dismiss it. You can seem 1 foot shorter or taller and can appear thin, fat, or in between. You can’t change your body type, so you must adopt a form that has the same basic arrangement of limbs. Otherwise, the extent of the illusion is up to you.

The changes wrought by this spell fail to hold up to physical inspection. For example, if you use this spell to add a hat to your outfit, objects pass through the hat, and anyone who touches it would feel nothing or would feel your head and hair. If you use this spell to appear thinner than you are, the hand of someone who reaches out to touch you would bump into you while it was seemingly still in midair.

To discern that you are disguised, a creature can use its action to inspect your appearance and must succeed on an Intelligence (Investigation) check against your spell save DC.

# Spells - Lvl 2



### Invisibility

- Casting Time: 1 action

- Range: Touch

- Components: V S M

- Duration: Concentration, Up to 1 hour

A creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target’s person. The spell ends for a target that attacks or casts a spell.

At Higher Levels: When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.

### Suggestion

- Casting Time: 1 action

- Range: 30 feet

- Components: V M

- Duration: Concentration, Up to 8 hours

You suggest a course of activity (limited to a sentence or two) and magically influence a creature you can see within range that can hear and understand you. Creatures that can’t be charmed are immune to this effect. The suggestion must be worded in such a manner as to make the course of action sound reasonable. Asking the creature to stab itself, throw itself onto a spear, immolate itself, or do some other obviously harmful act ends the spell.

The target must make a Wisdom saving throw. On a failed save, it pursues the course of action you described to the best of its ability. The suggested course of action can continue for the entire duration. If the suggested activity can be completed in a shorter time, the spell ends when the subject finishes what it was asked to do.

You can also specify conditions that will trigger a special activity during the duration. For example, you might suggest that a knight give her warhorse to the first beggar she meets. If the condition isn’t met before the spell expires, the activity isn’t performed.

If you or any of your companions damage the target, the spell ends.

# Spells - Lvl 3



### Haste

- Casting Time: 1 action

- Range: 30 feet

- Components: V S M

- Duration: Concentration, Up to 1 minute

Choose a willing creature that you can see within range. Until the spell ends, the target’s speed is doubled, it gains a +2 bonus to AC, it has advantage on Dexterity saving throws, and it gains an additional action on each of its turns. That action can be used only to take the Attack (one weapon attack only), Dash, Disengage, Hide, or Use an Object action.

When the spell ends, the target can’t move or take actions until after its next turn, as a wave of lethargy sweeps over it.

### Lighting Bolt

- Casting Time: 1 action

- Range: Self (100-foot line)

- Components: V S M

- Duration: Instantaneous

A stroke of lightning forming a line 100 feet long and 5 feet wide blasts out from you in a direction you choose. Each creature in the line must make a Dexterity saving throw. A creature takes 8d6 lightning damage on a failed save, or half as much damage on a successful one. The lightning ignites flammable objects in the area that aren’t being worn or carried.

At Higher Levels: When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for each slot above 3rd.

Mundane Items

Dagger

Disguise Kit

Forgery Kit

Healer's Kit oooooooooo

False Identity Papers

10 glass vials, with vial belt

Finger of a black dragon wyrmling

Backpack Containing:

Set of Fine clothes

Set of Travelling clothes

Dark robe with hood

Signet Ring of a fine house (false identity)

Large Diamond (500g)

# Magic Items

### Focus of the Five headed Queen

Uncommon small trinket, held

Attunement, Sorcerer

**Bonus Action:** spend a sorcery point and select a damage type (lightning, fire, cold, acid, lightning) For the next minute, all damage you cause by cantrips does this type of damage instead.

### Periapt of Wound Closure

Uncommon small trinket, neck

Attunement, any class

While you wear this pendant, you stabilize whenever you are dying at the start of Your Turn. In addition, whenever you roll a Hit Die to regain Hit Points, double the number of Hit Points it restores.

### Vials of Dragon's Essence

Uncommon potion

**Use Object Action:** you drink a vial and regain D6 sorcery points. If this brings you above your sorcery point maximum, you suffer an amount of psychic damage equal to the roll of the dice.

### Staff of Curative light

Uncommon quarterstaff

Attunement, Cleric, Bard, Wizard or Sorcerer

The staff has 14 Hit Points left. With each usage its Hit Points decrease by 1d4 + the number of charges used. If it has no Hit Points left, the spell does not work, but the staff vanishes in a flash of light, lost forever, and blinds every creature in radius of 50ft for 1d12 + 1 round (or that number times 6 seconds when not in combat).

**Cure Wounds:** 1-4 Charges

Action: A creature you touch regains a number of hit points equal to 1d8 for each charge used + your Wisdom modifier. This spell has no effect on undead or constructs.

**Lesser Restoration:** 2 charges

Action: You touch a creature and can end either one disease or one condition afflicting it. The condition can be blinded, deafened, paralyzed, or poisoned.

**Mass Cure Wounds:** 5 charges

A wave of healing energy washes out from a point of your choice within 60ft. Choose up to six creatures in a 30-foot-radius sphere centered on that point. Each target regains hit points equal to 3d8 + your Wisdom modifier. This spell has no effect on undead or constructs.

Personality

### Traits

I judge people by their actions, not their words.

Despite my blood, I do not place myself above other folk. We are all cursed.

### Ideal

Purity: A person is valued by how strictly they adhere to their born nature, if they know what it is.

### Bond

I can’t be accepting of my actions until I know my nature. I do not yet know what cursed me.

### Flaw

I can become very dogmatic about my beliefs, especially when pressed.
