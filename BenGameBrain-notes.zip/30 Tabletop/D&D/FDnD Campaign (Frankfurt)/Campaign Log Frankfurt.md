---
title: "Campaign Log Frankfurt"
source: "Game Stuff/D&D/FDnD Files/Campaign Log Frankfurt"
modified: 2020-11-30
type: session-log
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign", "D&D homebrew items", "Princes of the Apocalypse Dessarin Valley"]
words: 3301
summary: "Session-by-session campaign log (sessions 10-24, 1st-30th Flamerule) of the Frankfurt group in the Dessarin Valley: delegation hunt, fire/water/earth/air cults, Elizar and Vanifer, flying race at Feathergale Spire; ends with an index of NPCs, places and the Ritual of Balance. Includes two custom items (Potion of Diminution, Orb of Standing Water)."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/session-log"]
---

# Campaign Log

Location: [*Dessarin Valley*](https://drive.google.com/open?id=1_CIgqeAYxrt7KX22Tey950NWOq8AWO9xTTCrNHlGsFA)

[*Index*](#index) of Characters, Locations and Events

### 30th Flamerule - New Festival date

### 27th Flamerule

**Session 24**

Met Marlon, the Prophet of Earth.

Fought and defeated Yasha.

The Ettin Broog-Norb has the Bomb/Devestation orb.

**Session 23 - Early Morning**

Heading down the stairs to the darkness. Long Rested.

### 26th Flamerule

**Session 23 - Evening**

At the Monastery. Hama fought Hellenrae.

**Session 22**

Location: Camped near Scarlet Moon Hall

Breakfast story with Hama

- Book of Elemental Eclipse

- Shar not necessarily evil…

- Genies are from the Elemental Planes

### 25th Flamerule

Location: Camped near Scarlet Moon Hall

Livia was visited by Selune over night

Location: Scarlet Moon Hall

The party interviewed Elizar, and discovered:

- He is an actual druid

- [*Vanifer*](#vanifer) is a prophet and [*Elizar*](#elizar) just plays his part in the prophecy.

- His faith is very strong. He truly believed his actions will restore balance.

- He has spies in the other cults. But he doesn't know anything about the other prophets or other cults.

- The fire cult has an above ground operation and an "inner circle" operation. Only Vanifers chosen are allowed underground.

- There is a dwarven city under the Sumber Hills.

- A month ago a door appeared to block the way.

- Vanifer was given a dagger which opens the door to the dwarven city.

- The coffin and Rhundorth (the Dwarven diplomat) were sent to the Earth cult

- The Dara (elven princess) and Deseyna (Waterdeep diplomat) were sent to the air cult

- The Teresiel (elf diplomat) was sent underground to the fire cult.

- The [*ritual of balance*](#ritual-of-balance) has been brought forward to 30th of Flamerule.

Thokk broke Elizars neck to finish it. Trisha tried to stop him but was too slow. Bad Thokk!

The remaining druids gave some information:

- They were invited by Elizar to participate in a ritual to restore balance.

- They were not ok with the use of elemental plane magic.

- Garina (Pixie lady) and sprites are from Goldenfields.

- Varigo, Mahoon, Iniri and Fariya (druids) from Dessarin hills

- Connall, Murcad, Ragnad, Sauruki (druids) from West wood

- Pavel, Lytin (elven rangers) from High Forest

- The groups don't like each other

- They all work against Elemental Evil, a force that tries to return the Material plane to pure chaos.

- They returned to their circles to report.

Trisha has some charms to be identified.

Thokk was visited by Pavel

Delegation

- Rhundorth - Male Dwarf diplomat from Mirabar.

- Teresiel -Female Elf Diplomat from Silverymoon.

- Deseyna Norvael -Female Human Lord and Diplomat from Waterdeep .

- Brulenthor - Male Dwarf Historian from Mirabar.

- Dara Algwynenn Kalinoth - Female Moon Elf princess from Mhilamniir, joined at Silverymoon.

- The coffin - Stored at Summit Hall - Contents unknown.

\-

A fight broke out when the party arrived in the stolen wagon.

Vanifer caused the Wicker man to be summoned, a huge fire elemental. There was a big explosion.

Thokk and Trisha confronted Vanifer. Hama, Kildrak and Livia stayed to deal with Elizar and the Wicker man.

Vanifer tried to mind control Thokk but he resisted twice. Shehad seen visions of this day, but Thokk was not in her visions. Thokk let her go but Trisha attacked and was struck down. She managed to steal Vanifers purse.

Location: The Beliard-Westbridge road, near the Stone bridge

Ambushed a fire druid wagon. Stole two cloaks and an iron necklace.

There were a group of dancing people who will be sacrificed for the ritual. They seemed to be controlled magically somehow.

Fire druids know you by name, and know you are coming.

Prophet Vanifer is running the show. She has seen a vision that includes the party members in great detail.

Elizar has called fire druids from across Faerun to summon Imix, God of Fire. The fire druids believe that Imix will save the world.

Elizar has a beard and a pipe, and is likely to be the one talking. 20-40 other people at the festival site.

The tower is 1000metres high so you can spot it pretty easy right? You got some basic descriptions of where to go.

The strong alcohol helps with their magic… and human sacrifices.

The fire druids dont think it is possible to interrupt the festival/ritual.

### 24th Flamerule

Location: Womford

Hama and Kildrak got their new armor

The party met Shoalar. Trisha stole a map with some locations on it. The air cult is based somewhere else than the spire. He caught Trisha and she lost her Rapier for a little while.

Trisha made a distraction using an illusion and the rest of the group chimed in at the right time to create a diversion.

Thokks probably a wanted orc when the guard he slogged wakes up. However, he is an amazing fish.

Hama’s name was dropped during the Shoalar meeting. She knows a lot of boring history.

Shoalar was let go with his life, on the deal that he “behaves”.

Livias bird is friendly and wants to tell her something. Livia named it Isabeau.

Kildrak asked Marthammor Duin for guidance and this leads the party to the Fire cult next. They will take the boat to the Stone bridge and then take the horses down towards Red Larch.

### 23nd Flamerule

Location: Bargewright Inn, Outside Ironford

**Session 14**

Firedawgs attack!

Suicide attack! - the leader of the attack said that “you haven’t figured it out yet”.

Innkeeper ++ points from repairing the damaged tavern floor and carpets.

Gunnloda of Eversharp fought against Hellhounds from the Cavern of Ari.

**Session 13**

Location: Ironford

The water priests are doing some good things for the town. The genasi guy is not welcome in the criminal world.

There are orphans at the docks.

Hama and Kildrak will get Splint mail each for 140gp.

Kildrak finally intimidated someone and can pass the bridge for free.

Trisha purchased volume 11 of the History books “The founding of Tzar Besil” for 20gp, and won 10gp in gambling with criminals.

Location: Thokks garden

Thokks garden has grown more powerful. He has pixies now. The golden seeds are growing into golden orb plants.

Location: East bank of Dessarin River, across from Rivergard Keep

Met with Ushien

Ushien sent 5 Knights of Samular to Rivergard keep.

Ushien and the rest of the knights transported the coffin back to Summit Hall. She was most happy and smiled once a bit.

Trisha still wants to find a diamond “for sale”. Thokk gave 100g via Kildrak and Livia also gave 100g.

Livia received a gift from the gods, a silver hawk.

Livia does not like to have fish scale tattoos.

Trisha experienced the wonders of Hamas handiwork… a talking shortbow.

Travelled to Ironford by Boat.

### 22nd Flamerule

**Session 12**

Camping on the East side of the river, waiting ro Ushien to arrive at dawn.

We must find out what is going on with the Golden fish.

Met Captain Holger.

You told him:

- Told him go to Ushien and deliver a letter

He told

- Drosin is the head priest

- Drosin will come back and punish whoever is left at Rivergard.

- Where the Pay Chest is.

- That Jollivers Lieutenant Shoalar, a genasi, is in Womford on business.

The remaining mercenaries:

- Holger.

- 6 mercenaries.

- 1 teenage Crushing Wave sympathizer.

Kildrak was dancing because he found the Coffin of Samular Caradoon. It has necromancy and abjuration magic around it. The chains have locks or shackles.

In the water cave are many bodies drowned and floating in the river, kept down with ropes attached to something. At the end is a sealed entrance on the edge of an underground lake, the entrance has a lock with 5 symbols.

Thokks dragon is becoming greedy and arrogant.

Three servants lead by Anja. Were taken as slaves and want to go back to Womford. Anja doesn't like Trisha very much.

Three servants lead my Bernt. They were hired and want to go back to Beliard. They went will the mercenaries.

Some letters were found in Jollivers room:

*I’ve spotted the troublemakers that you described and delivered the parcel. The half-orc really is massive. The Black Earth have been messing about with the local townsfolk, but your trouble makers went and scared them off.*

*\*the letter is signed J\**

*Jolliver,*

*We need to placate these dimwitted earthers. Here is a description of what they want. I told them that we won’t do all their dirty work for them, so they are sending some bugbears and a priest over. Don’t drop your guard for a second especially with the priest. He knows when and where to get the cargo.*

*\*A rough sketch at the bottom of the page shows the coffin, it is signed Gar\**

Some magic items were also found.

### Potion of Diminution

***Use Object Action:*** The drinkers size is halved in all dimensions, and its weight is reduced to one-eighth of normal. This reduction decreases its size by one category - from Medium to Small, for example. Until the spell ends, the drinker also has disadvantage on Strength Checks and Strength Saving Throws. The target's Weapons also shrink to match its new size. While these Weapons are reduced, they have damage dice that are one level smaller (d1, d4, d6, d8, d10, d12) and don’t add their users Strength ability modifier. The effect lasts for 1 minute.

### Orb of Standing Water

**Use Object Action:** You smash the orb at your feet. A wall of water rushes up from the ground. Select a type of wall from the options below.

Barrier wall: up to 30 feet long, 10 feet high, and 1 foot thick

Ring wall: 20 feet in diameter, 20 feet high, and 1 foot thick.

You must maintain concentration on the wall. The wall dissipates after 10 minutes, or when you lose Concentration. The wall’s space is difficult terrain. Any ranged weapon attack that enters the wall’s space has disadvantage on the attack roll, and fire damage is halved if the fire effect passes through the wall to reach its target. Spells that deal cold damage that pass through the wall cause the area of the wall they pass through to freeze solid (at least a 5-foot square section is frozen). Each 5-foot-square frozen section has AC 5 and 15 hit points. Reducing a frozen section to 0 hit points destroys it. When a section is destroyed, the wall’s water doesn’t fill it.

**Session 11**

The group took the only option they had, and killed most people.

Jolliver Grimjaw made a pact with Olhydra, he became powerful and could change into a boar.

He also got magic boats.

They collected the delegation,

Black earth + Crushing wave fought the delegation

The mercenaries helped ferry the delegation prisoners across the river.

The Black earth attackers took the Elven Princess and some minabarran guards went west toward red larch.

The other delegates were taken to the caves

Coffin was taken somewhere but it was unknown.

Resch is a fish person lvl 2

Drosin is the head priest

The mercenaries will be dropped at summit hall if you ferry them across the river.

**Session 10**

Leaving for the boat, Womford, Ironford

Met with “The Boss”. Turns out he was a boarman, now dead.

Trisha was hit with a burning cigar.

The alge skirt priests are guarding a small building inside the complex.

Livia knows that The Boss was lying about protecting the river.

Hama crafted an item to drive the boat.

### 21st Flamerule - Beliard

The wanderer, the observed, and the one the gods cannot see.

Chased by fire, drowned in stone, the winds will lift them up beyond the realm.

Summit Hall

The Knights are “fun”. Livia is disillusioned with praying.

Hama can fix the boat. She learned some new recipes.

Trisha and Thokk fought a Umber Hulk and saved the dinner. Umber Hulks are intellegnet and dont attack aggressivly.

Dark lady lives at the Manor on the road to Amphail.

Iceshield Orcs at the north

Wood Elves protecting the High forest

Kildrak had a vision of Moradin.

Samular Caradoon is in the coffin. He is the founder of The Knights of Samular.

He had a brother. The brother is dead.

Perhaps there were magic items in Samulars coffin?

Perhaps he is not in the coffin.

Trisha wrote a new ballad about Thokk the Mighty.

Kildrak was to join the Order of the Gauntlet but no time.

Rivergard keep is where the mercenaries are.

Prophecy seems to involve the party.

Apocalypse stands at the door.

Images of the delegation.

Battlefield

- Bugbears and sharkteeth

- Pirates were here

- Cloth pieces in a train, implies that one of the delegation was captured.

- Wagons are destroyed, one crashed over the cliff

- Coffin and attack group got on boats here

- Found a symbol on a long boat

Theory about 4 elements. We already found a fire symbol and a water symbol.

Why did the delegation leave the road and go on the small path?

Water serpents came to defend the two pirates with fish scale tatoos

Pouch with papierkram.

The boats are moved by water magic.

Thokk has a sharktooth sword.

A stone rod weapon was found by Trisha.

Delegation left Beliard on 25th Kythorn

The cattle drover told:

- He saw the delegates convoy 10 miles out of town

- The days afterwards he saw flying creatures with riders

- Following Kildraks description he said there is a trail off the road

Innkeeper told about

- Coffin stored at butchers

- Details about the delegates.

Waitress told

- There was a golden mask man watching the delegates on the last night

- He left, but nobody saw him leave the wall

Butcher Constable Harburk told

- Coffin covered with chains

- Coffin contains a Knight of Samular / Order of the Gauntlet

- Needs to be taken to Summit Hall

- Half orc curfew because of recent Orc attacks

Edith and the Historical Society told

- Edith purchased a dwarvish book in Ironford

- Book 3 of 47

- He bought it from a dock worker… who is a fence for stolen goods.

- You have a description of the seller.

- Afraid of the Constable. He might come and damage their precious artifacts.

- Edith has purchased items from the fence before…

- Edith said bought the book on the 17th Flamerule

Leaving for the Battlefield at lunch

### 20th Flamerule - Left Beliard

Arrived at beliard

The party met a caravan who had a letter for Teresial (the elf delegate) they will give it to Minny at Westbridge.

Hama saw a green place near the river. The knights said the dwarves there are not friendly.

Overnighted at the start of the Stone Bridge

### 19th Flamerule - Flying training

Everyone gains 1 reroll that can be used for an Animal Handling check when not on the ground. These do not expire, so can be stored indefinitely.

Rumors from the knights who are returning.

Hama asks about stone, snakes, dreams.

### 18th Flamerule - Tower Arrival, Race and Feast

Location: [*Feathergale Spire*](https://drive.google.com/open?id=1Jy45Zdg3mjF0lYeOrT5RIhUInlK8d96xyj9b4ybCsAM)

The hunt is about to begin!

Griffon - Hama + Best pilot

Hippogriff - Trisha + Livia

Giant Vulture - Thokk

Hippogriff - Kildrak + Knight

Signet ring with HUUUUGE gem (precious) for prize to winner

Thokk has the ring from Thurl after telling he committed the last strike

Kildrak revivified the Giant Vulture (mid-air!)

Pseudo-Drag got a headache

As did Thokk

Everyone flew on giant birds

After getting back to the tower, Kildrak kissed his egg of luck (in an appropriate manner).

Livia took an additional ride through the air.

Trisha harvested manticore feathers.

Mounted Knights are scouting the area for trouble:

- found evidence of a battle south of Beliard

- Heard tales of pirates attacking ships on the Dessarin river between Yatar and Ironford

- Gnolls live in the canyon, as well as Manticores.

The knights do not report any of their people missing, although Trisha suspects something (downs from Giant Vultures are expensive!).

There are only male knights

Spoke with Thurl Merosska over dinner

- His people will deal with the Stone cloaks at the quarry.

- He has been Lord Commander of the Feathergale Society for 5 years

- Seems there is some mistrust internally

- Seems like a military person

- Was a personal guard to a Waterdeep Lord

Thokk raced his Pseudodragon against a knight's Peryton and won. There was no competition. He won 100gp. The Pseudodragon claims half of it for itself.

### 15th Flamerule - Redlarch Arrival

Location: [*Red larch*](https://drive.google.com/open?id=1wcjSAWDDWge1mE8a7sJpAbnohWBWT0u4FA-K-CXgo2c)

Searched the graves, location provided by Larmon Greenboot. Found a battle site nearby. Graves contained:

- One male human in a feather cloak (giant vulture down)

- One human male in a Stone cloak

- 1 male human, one female dwarf wearing Mirabarran tabards.

The party was paid 8gp each for going to the quarry.

Went to the Quarry at night, encountered some Stone cloaks who were watching the Stone cutters working. The Stone cloaks escaped by Melding into Stone and moving away.

Thokk had a haircut, and Trisha got some gossip about Larmon Greenboot finding graves outside of town. Thokk was asked to go to the quarry at night to watch out for the workers.

Livia discovered that some “Fire Druid merchants” came through town. Their wagons were full of alcohol barrels marked with this symbol:



Kildrak discovered that there are only two Stoneworkers in town, and it has been that way for some time. Both store their stone in a warehouse on the edge of town called Bethendars Storage.

### 10th Flamerule - Westbridge overnight

Location: [*Westbridge*](https://drive.google.com/open?id=1uCMZbNF4boMkIdK-dfg9E6Af9qM5gSW_nBND_-hUHr0)

The Delegation came this way and stayed for a night, then headed for Beliard.

Kildrak bought an egg and hard boiled it

### 5th Flamerule - Triboar

Location: [*Triboar*](https://drive.google.com/open?id=1YtCM-cDJiz4IHOaDJU53u1lDk9Q7oTb9_lTqDu9u-JM)

The Delegation came this way and stayed for a night, then headed for Westbridge

The Lord Protector, Dara, is in charge of security. She has command of 12 knights from Waterdeep to keep the Kings road safe.

The party attended dinner at Everwyvern House where they saw a performance from Windharrow, a famous Bard. They were wearing fancy clothes which Trisha stole from Everwyvern House.

Hama said goodbye to her Stone cloak friends.

### 1st Flamerule - Left Phandalin

25th Kythorn

#  

# Index

## Characters

### Vanifer

Female Tiefling. Seemingly in change of the Fire Cult.

### Elizar

Male Human Druid and Head Priest of the Scarlet Moon Circle. Dead by Thokks hand.

### Shoalar

Male Water Genasi swindler whos boat was last seen parked in Ironford

### Pike

Male halfling swashbuckler. Shoalars sidekick

### Rhundorth 

Male Dwarf diplomat from Mirabar.

### Teresiel

Female Elf Diplomat from Silverymoon.

### Deseyna Norvael -

Female Human Lord and Diplomat from Waterdeep .

### Brulenthor - 

Male Dwarf Historian from Mirabar.

### Dara Algwynenn Kalinoth - 

Female Moon Elf princess from Mhilamniir, joined at Silverymoon.

### The coffin - 

Stored at Summit Hall - Contents unknown.

### Garina 

Female Elf Druid from Goldenfields. Travels with two Sprites.

### Varigo

Male Human Druid from the Dessarin Hills. Last seen at Scarlet Moon Hall travelling with Mahoon, Iniri and Fariya.

### Connall

Male Human Druid from West wood. Last seen at Scarlet Moon Hall travelling with Murcad, Ragnad, Sauruki.

### Pavel

Male Elven ranger from the High Forest. Last seen at Scarlet Moon Hall travelling with Lytin. Also was tracking Thok.

## Places

Tyar Besil

A forgotten dwarven city built under the Sumber Hills.

## Events

### Ritual of Balance

Originally to take place on the 30th of Eglesius, it will now apparently take place on the 30th of Flamerule.
