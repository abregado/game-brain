---
title: "Undiscovered - Westbridge"
source: "Game Stuff/D&D/FDnD Files/Undiscovered - Westbridge"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Westbridge"]
words: 344
summary: "DM-only Westbridge village sheet: inn, poultry shops, wagonworks, NPCs and travel times."
contains_external_material: "Base descriptions from published module"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Westbridge

Village

## Unplaced NPCs

Chickens

## Locations

### Harvest Inn (Inn)

**NPCs**

Stan Thistlehair - Owner / Carpenter

Works at the Wagonworks when necessary. Knows that Waelvur is up to something dodgy in Red larch.

### Mhandyvers Poultry (General Store)

This wooden building grew haphazardly for many years,

shooting out single-story wings and annexes untidily

in all directions. The interior looks like a barn or attic,

with exposed beams and posts. Pens with live chickens

fill most of the odd corners and halls of the building,

leaving only a narrow aisle down to the back, where the

Mhandyvvers live. Their rooms are separated from the

chicken pens by a workroom with cutting benches and a

central hearth.

**NPCs**

Minthra “Minny” Mhandyver - Owner

### Drouth Fine Poultry

The one-story building is long, narrow, and

nondescript on the outside, but the name ofthe business

is painted above the double entry doors (wide enough

for a wagon). Inside, feathers drift in the air. Cages

and casks sit at the street end of the building, followed

by two brick cooking-hearths, long and bloodstained

cutting tables, and a plucking area in the back. The

feathers are heaped in open handcarts that are taken

away for washing and eventual sale as pillow stuffing.

**NPCs**

Nahaeliya “Nat” Drouth - Owner

### Waelvur’s Wagonworks

The workshop is a cluttered, untidy

shed surrounded by dozens of wagons shrouded in

worn canvas tarpaulins. Inside, half a dozen wagons stand in various stages of

assembly, surrounded by stools, ladders, and benches.

Wooden pillars support a loft that is an open latticework

of boards, serving as home to some birds and storage

for scores of wooden wagon wheels.

**NPCs**

Ilmeth Waelvur - Owner - Believer

## Travel Times

| **Destination**   | **Trail type** | **Distance** |
|-------------------|----------------|--------------|
| Triboar           | Good road      | 36 miles     |
| Red Larch         | Good road      | 36 miles     |
| Helvenblade House | Crosscountry   | 8 miles      |
| Nettlebee Ranch   | Crosscountry   | 10 miles     |
| Beliard           | Rough trail    | 40 miles     |
