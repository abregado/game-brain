---
title: "Triboar"
source: "Game Stuff/D&D/FDnD Files/Triboar"
modified: 2020-04-13
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Triboar"]
words: 614
summary: "Location sheet for Triboar: inns, mercenary contractor, tower, campgrounds, with NPCs, prices and travel times."
contains_external_material: "Location descriptions appear copied from the published module"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Triboar

Town

**[Triboar](#triboar) 1**

> [Unplaced NPC’s](#unplaced-npcs) 1
>
> [Locations](#locations) 1
>
> [Everwyvern House (Inn) / Pleasing Platter (Resteraunt)](#everwyvern-house-inn-pleasing-platter-resteraunt) 1
>
> [The Triboar Travelers - (Mercenary contractor)](#the-triboar-travelers---mercenary-contractor) 3
>
> [Tower (Townmaster)](#tower-townmaster) 3
>
> [Northshield House (Inn)](#northshield-house-inn) 4
>
> [North and West Campgrounds (Inn)](#north-and-west-campgrounds-inn) 4
>
> [Gwaerons Slumber (magical forest)](#gwaerons-slumber-magical-forest) 4
>
> [Unvisited Locations](#unvisited-locations) 5
>
> [Boars Rest (Private Estate)](#boars-rest-private-estate) 5
>
> [Foehammers Forge and Arms (Smith)](#foehammers-forge-and-arms-smith) 5
>
> [The Cart and Coin (Wagonshouse)](#the-cart-and-coin-wagonshouse) 5
>
> [The Lions Share (Trader)](#the-lions-share-trader) 5
>
> [Travel Times](#travel-times) 5

## Unplaced NPC’s

none

## Locations

### Everwyvern House (Inn) / Pleasing Platter (Resteraunt)

This expensive inn caters to Waterdhavian nobility and other well-to-do folk who wouldn't be caught dead in a more modest establishment. Two large buildings border a walled area which contains a pleasant and orderly garden. A large fountain stands in front of the manor house. The only entrance is though a gate which is guarded by several well dressed guards.

**NPC’s**

Draven Millovyr - Owner

| **Service**                               | **Cost** |
|-------------------------------------------|----------|
| Suite room with breakfast (per person)    | 15gp     |
| Stabling and Feed (per animal, per night) | 5gp      |
| Meal at the Pleasing Platter (4 courses)  | 25gp     |

###  

### The Triboar Travelers - (Mercenary contractor) 

A simple building with a waiting room and office where travellers can get work.

**NPC’s**

Alan Stockspool - Owner / Businessman

Valken Naspeer - Owner / Public Relations

| **Service**                       | **Cost** |
|-----------------------------------|----------|
| Guard a Caravan down to Waterdeep | 600gp    |
| Guard a Caravan to Mirabar        | 800gp    |

| **Quests**              | **Cost** |
|-------------------------|----------|
| Caravan Guard (per day) | 4gp      |

### Tower (Townmaster)

The center of Triboar, where the Long Road meets the

Evermoor Way, is a huge open space used as a market

by local farmers and visiting peddlers. Dominating

the space is the two-story Tower of the Lord Protector,

a simple stone keep that leans decidedly to the east.

Hanging above the entrance is the dusty banner of the

lord protector, which depicts three black boars running

toward the head of the banner on a blood-red field.

**NPC’s**

Darathra “Dara” Shendrel - Lord Protector

12 Knights (some out on patrol)

###  

### Northshield House (Inn)

**NPC’s**

Ursula Meltimer - Owner

Zomith - Half-orc Caravan Guard

3 Mastiffs

**Guests**

Silvarren Loomshank - Priest of Helm

| **Service**                                      | **Cost** |
|--------------------------------------------------|----------|
| Single Bed, Board and Meal (per room, per night) | 1gp      |
| Stabling and Feed (per animal, per night)        | 1gp      |

### North and West Campgrounds (Inn) 

Two large trampled areas devoid of grass. During wet weather, these are muddy, and on sunny days they are very dusty. Travellers may camp here for free, and caravans may also park for free.

**NPC’s**

Three monks of the Sacred Stone

### Gwaerons Slumber (magical forest)

To avoid angering the god of tracking, the law in Triboar for­bids cutting any wood from these trees or hunting any creature in the woods. Many of the trees in Gwaeron's Slumber are trapped in a perpetual autumnal state, with leaves in dazzling shades of yellow, orange, and red.

## Unvisited Locations

### Boars Rest (Private Estate)

### Foehammers Forge and Arms (Smith)

### The Cart and Coin (Wagonshouse)

### The Lions Share (Trader)

## Travel Times

| **Destination** | **Trail type** | **Distance** |
|-----------------|----------------|--------------|
| Westbridge      | Good road      | 36 miles     |
| Yatar           | Good road      | 34 miles     |
| Conyberry       | Horse trail    | 32 miles     |
| Black Maw Bog   | Good road      | 12 miles     |

[*Undiscovered Triboar*](https://drive.google.com/open?id=1MI0gDCDyQLy6xgzqHWlkZOstEhn7UpifmvgktABjv_8)
