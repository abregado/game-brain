---
title: "FDnD Favric GoodbyeLetter"
source: "Game Stuff/D&D/FDnD Favric GoodbyeLetter"
modified: 2020-02-12
type: session-log
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 498
summary: "In-character farewell letter from Favric Farstrider to the party (Livia, Hama, Thokk, Trisha) explaining his con on a green dragon and leaving the group."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/session-log"]
---

> Livia, Hama, Thokk and Trisha
>
> Things were tense yesterday and I'm sure that I did not explain myself very well. As you can tell, I have left your company. Im putting my thoughts into words so you can be sure that I have not influenced you with magic.
>
> I have spent the larger part of my life being bullied into using my clearly dangerous abilities for the benefit of unsavory people. The sort of people who only trust those who they hold power over, whether it be threats of violence or by ransoming something precious of mine.
>
> Now I work and travel alone trying to be a better person as I search for what cursed me with my powers.
>
> Dragons. Chromatic dragons are evil, selfish, arrogant and generally rich. A perfect target for a con-man who has a magical way with words. Young Green dragons are my preferred mark, since they are the most insidious of evil, delighting in tricking good people into doing evil on their behalf.
>
> I really was not sure if you would be able to slay the creature, and so I had to play both sides to keep my story believable. Even my mind tricks have limits. Proof of my prior deeds you already have, as the large diamond I placed in Venomfangs hoard was actually from another young green I had dealt with.
>
> I judge people by their actions, so, if you are the type of people who have plagued me for my early life, be on your way. You will never see me again and I will make no act against your endeavours.
>
> If you want to accept my request for forgiveness, then leave the things you took from me at the place where we first met. Then, I will seek you out in Neverwinter.
>
> For my part in the misunderstanding, I am sincerely sorry.
>
> Until we chance another meeting,
>
> Favric Farstrider

Torden Arentson - Human light cleric - Northener/Luskan- NG

Illithor Arakas - Elven tempest cleric - NG

Tarneth Silverbane - Dwarven war cleric - LN

Madrak (Mithrilforge) - Dwarven Gloom stalker - CG - Lived most his life in the underdark. His clan is extinct. Good replacement for Trisha, if Carolin wants to play her Dragonborn character.

Cyran Thera - Elf blade singer - LN - Wizard class but with powerful melee abilities. Not a healer.

Dusk - Elven horizon walker - CG - Ranger subclass focusing on Astral projection, planar movement and teleportation.

Novis Vekin - Human Phoenix soul sorceror - NG - Just fire magic, but with a touch of ressurection magic.

Rynders Daerel - Elven werewolf moon druid - NG - use giant elk stats

Amrynn Lorawynn - Elf swashbuckler - NG - Lords Alliance , maybe an old acquaintance of Kildrak from his sailing days.

Ninthalor Tordithas (Nin) - High Elf eldritch knight - LN
