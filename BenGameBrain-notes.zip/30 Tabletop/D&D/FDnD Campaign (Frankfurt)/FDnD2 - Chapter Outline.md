---
title: "FDnD2 - Chapter Outline"
source: "Game Stuff/D&D/FDnD2_ Chapter Outline"
modified: 2021-06-20
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D One-shots]]"]
concepts: ["FDnD campaign (Frankfurt)", "Spelljammer Crash Campaign"]
words: 400
summary: "Outline for the second Frankfurt campaign: Spelljammer crash near Neverwinter, three quests (Thundertree, Phandalin/Spellforge, Dread Ring/Netheril city) and a prologue with a stay-or-go choice."
tags: ["area/dnd", "project/d-d-one-shots", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

### Intro Chapter 1: Ship

Fighting a beast in the Phlogiston, on the deck of the Spelljammer.

After the battle, the beast falls towards a disc of world, and then breaks apart into 4 pieces.

Crash landing of the Spelljammer into the ocean within sight of Neverwinter. Objects that are thrown overboard crash down like comets within a mile wide radius.

### Intro Chapter 2: Neverwinter

###  

### Quest 1 Chapter 1: Thundertree

The Heartless Dragon, a tavern in Thundertree.

A statue of Livia in the Thundertree square.

###  

### Quest 1 Chapter 2a: Sunken Tower Grove

###  

### Quest 1 Chapter 2b: Flaming Crater

###  

### Quest 2 Chapter 1: Phandalin

A magical narrow gauge railway from the Wave Echo cave to Phandalin.

The road to Phandalin is paved with cobblestones and well signposted.

###  

### Quest 2 Chapter 2a: The Sword Mountains

###  

### Quest 2 Chapter 2b: Spellforge

###  

### Quest 3 Chapter 1: Dread Ring

The heroes find the macguffin they need but realise that by taking it, innocent lives will be put at risk.

Who is at risk? They must be important to the heroes.

What is needed before this happens:

- The characters must know of those at risk

###  

### Quest 3 Chapter 2: Lull

A lull in the action, as the heroes know they need to go to the city and just wait for it to appear again.

###  

### Quest 3 Chapter 3: City

The party repair the Spelljamer they arrived in and fly to the Netheril City.

Why can the heroes only land in the one spot?

Thokk in the center of the portal room. He is chained to 4 runic pillars, one for each element. The chains end in shackles around his wrists and forearms. Each chain is made of ethereal energy. During the fight, he explains he must hold the door open for his friends.

What needs to happen before:

- The heroes must travel to the circle

- The heroes need to know where the circle is

- The city must be accessible to the heroes

- The city must contain a goal of the heroes

### Prologue

A series of adventures culminates in the adventurers having a choice to either stay here or go back where they came from. The party discovers that one of the heroes made a choice which forces them to stay.

###
