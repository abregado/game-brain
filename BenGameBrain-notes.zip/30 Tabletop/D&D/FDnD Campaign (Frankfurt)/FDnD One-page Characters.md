---
title: "FDnD One-page Characters"
source: "Game Stuff/D&D/WDnD Files/FDnD One-page Characters"
modified: 2020-02-12
type: character
area: dnd
status: "designed"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D Homebrew]]"]
concepts: ["FDnD campaign (Frankfurt)", "D&D characters"]
words: 7306
summary: "Collection of one-page pregenerated level 3 characters for the FDnD campaign: Eldritch Knight, Guardian of Lore cleric, Open Hand Monk, an elemental caster, Bladesinger, Quasit warlock, and Druid of the Moon, with stats and ability text."
tags: ["area/dnd", "project/d-d-homebrew", "project/fdnd-campaign-frankfurt", "type/character"]
---

## Eldritch Knight

You have mastered the basics of all combat styles. You can swing an axe, fence with a rapier, wield a longsword or a greatsword, use a bow, and even trap foes in a net with some degree of skill. Likewise, you are adept with shields and every form of armor. Now you turn your hand to the arcane, augmenting your skills with combat magic.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 16      | 14      | 13      | 15      | 11      | 9       |
| +3      | +2      | +1      | +2      | +0      | -1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 16     | 25     | 3D10   | 30ft     | 8ft      | 16ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +5      | +2      | +3      | +2      | +0      | -1      |

### Major Skills:

**Athletics (Strength) +5**

Covers difficult situations you encounter while climbing, Jumping, or swimming. Examples include the following activities:

- You attempt to climb a sheer or slippery cliff, avoid hazards while scaling a wall, or cling to a surface while something is trying to knock you off.

- You try to jump an unusually long distance or pull off a stunt midjump.

**Perception (Wisdom) + 2**

Lets you spot, hear, or otherwise detect the presence of something. Is also used to notice traps from a distance. It measures your general awareness of your surroundings and the keenness of your Senses.

**Alert (Perception Talent)**

You gain a +5 bonus to initiative and you can’t be surprised while you are conscious.

**Investigation (Intellegence) +4**

When you look around for clues, deduce the location of a hidden object, check and object for traps or search for a hidden fragment of knowledge.

### Attack with Bonded Longsword

**Main action:** Make an attack roll with +6 to hit. This attack does D8+8 slashing damage.

### Second Wind

**Bonus action:** regain hit points equal to Id10 + 3. You regain the use of this ability after a short or long rest.

### Action surge

**Free action:** take one extra main action this turn. You regain the use of this ability after a short or long rest.



# War Magic

Your magic comes from study and martial practice. You memorize your spells so you don’t need an arcane focus or spellbook. You do need a free hand to cast.



### Green flame blade 

**Action:** Make a melee attack with a weapon against one creature within the spell's range. On a hit, the target suffers the attack's normal effects, and green fire leaps from the target to a different creature that you can see within 5 feet of it. The second creature takes 2 fire damage.

### Blade Ward

**Action:** Tracing an arcane sigil in the air, you grant yourself resistance to bludgeoning, piercing, and slashing damage dealt by weapons until the end of your next turn.



### Absorb Elements (1st level)

**Reaction when you are hit with elemental damage:** You have resistance to the triggering damage type until the start of your next turn. Your next melee attack causes an extra 1d6 damage of the triggering type, and the spell ends.

### Shield (1st level)

**Reaction when you are hit with an attack:** An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile.



## Guardian of Lore 

You are a intermediary between the mortal world and the distant planes of the gods. Chosen by a god of learning, you seek out, protect and share arcane texts hidden in the most dangerous places. These works are collected in a great temple library where you worship.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 15      | 11      | 13      | 14      | 16      | 9       |
| +2      | +0      | +1      | +2      | +3      | -1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 16     | 21     | 3D8    | 30ft     | 7ft      | 15ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +2      | +0      | +1      | +2      | +5      | +1      |

### Major Skills:

**Religion (Intelligence) +6**

**History (Intelligence) +6**

**Arcana (Intelligence) +4**

**Medicine (Wisdom) +5**

Your primary skills help when gaining information about a topic. The DM might call for you to make a given roll to recall lore about historical events, deities, rites and prayers, religious hierarchies, holy symbols, wounds, diseases, spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes.

### Chainmail

You wear a full suit of heavy chainmail complete with steel pauldrons, greaves and a shield. The holy symbol of your god is emblazoned on your shield. Your Stealth (Dexterity) checks are made with disadvantage.

### Attack with Warpick

**Main action:** Make an attack roll with +4 to hit. This attack does D8+5 bludgeoning damage.

### Spiritual weapon attack

**Bonus action:** Move your spectral weapon up to 20ft and make a melee weapon attack with +5 to hit causing 1D8 + 5 force damage.

# Celestial Magic

Your magic comes from channeling the celestial power of your god. It relies on devotion and it can be taken away if you displease your deity.



### Guidance 

**Action:** You touch a willing creature, granting it a 1d4 bonus to one ability check of its choice in the next minute. The spell then ends. The target can roll the die before or after making the check.

### Sacred Flame 

**Action:** Flame-like radiance descends on a creature that you can see within range. A target within 60ft must succeed on a Dexterity saving throw (DC 13) or take 1d8 radiant damage. The target gains no benefit from cover for this saving throw.



### Bane (1st level)

**Action:** Up to three creatures of your choice that you can see within 30ft must make Charisma saving throws (DC 13). For the next minute, whenever an affected target makes an attack roll or a saving throw, the target must roll a d4 and subtract the number rolled. You must maintain concentration.

### Bless (1st level)

**Action:** You bless up to three creatures of your choice within 30ft. Whenever a target makes an attack roll or a saving throw in the next minute, the target can roll a d4 and add the number rolled. You must maintain concentration.



### Lesser Restoration (2nd level)

**Action:** You touch a creature and can end either one disease or one condition afflicting it. The condition can be *blinded, deafened, paralyzed,* or *poisoned*.

### Summon spiritual weapon (2nd level)

**Bonus action:** You create a floating, spectral weapon within range that lasts for the 1 minute. The weapon can take whichever form you choose. After casting, you make a free Spiritual Weapon attack.



### Sigil of Temporal harmony

A small metallic trinket which can be activated by turning a small dial on the cover.

**Use Object:** Cast Slow or Haste. The user requires attunement.

Recharges at the start of each day.

### 

### Haste

**Action:** Choose a willing creature that you can see within 30ft. For 1 minute, the target's speed is doubled, it gains a +2 bonus to AC, it has advantage on Dexterity Saving Throws, and it gains an additional action on each of its turns. That action can be used only to take the Attack, Dash, Disengage, Hide, or Use an Object action. You must maintain concentration otherwise the spell ends.

When the spell ends, the target can't move or take Actions until after its next turn, as a wave of lethargy sweeps over it.

### Slow

**Action:** You alter time around up to six creatures of your choice in a 40-foot cube within 120ft. Each target must succeed on a Wisdom saving throw (DC 13) or be affected by this spell for the Duration.

An affected target's speed is halved, it takes a -2 penalty to AC and Dexterity Saving Throws, and it can't use reactions. On its turn, it can use either an action or a Bonus Action, not both. Regardless of the creature's Abilities or Magic Items, it can't make more than one melee or ranged Attack during its turn.

A creature affected by this spell makes another Wisdom saving throw (DC 13) at the end of its turn. On a successful save, the effect ends for it.

# Open Hand Monk

Your fists a blur as they deflect an incoming hail of arrows. You spring over a barricade and throw yourself into the massed ranks of hobgoblins on the other side. You whirl among them, knocking their blows aside and sending them reeling, until at last you stand alone.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 12      | 16      | 13      | 9       | 14      | 10      |
| +1      | +3      | +1      | -1      | +2      | +0      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 15     | 21     | 3D8    | 40ft     | 6ft      | 12ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +3      | +5      | +1      | -1      | +2      | +0      |

### Major Skills:

**Perception (Wisdom) +4**

Lets you spot, hear, or otherwise detect the presence of something. Is also used to notice traps from a distance. It measures your general awareness of your surroundings and the keenness of your Senses.

**Acrobatics (Dexterity) +5**

Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck. The DM might also call for a Acrobatics check to see if you can perform acrobatic stunts, including dives, rolls, somersaults, and flips.

**Insight (Wisdom) +4**

Decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone's next move. Doing so involves gleaning clues from body language, speech habits, and changes in mannerisms.

**Emotional Insights (Insight talent)**

You are very skilled at pinpointing reasons and motivations behind deception. When you succeed on an Insight check to determine if a creature is lying, you learn a one-word summary of why the creature lied, such as “greed”, “anger”, or “fear.”

###  

### Attack with Tonfa

**Action:** Make an attack roll with +5 to hit. This attack does D6+5 bludgeoning damage.

### Martial Arts

**Bonus action if you used Attack as your main action this turn:** Make one unarmed strike with +5 to hit causing D4+5 bludgeoning damage.

### Open Hand technique

**Bonus action if you used Attack as your main action this turn:** Spend one Ki. Make two unarmed strikes with +5 to hit, each doing D4+5 bludgeoning damage.

Whenever you hit a creature with one of these attacks, you can impose one of the following effects on that target:

- It must succeed on a Dexterity saving throw (DC 12) or be knocked prone.

- It must make a Strength saving throw (DC 12). If it fails, you can push it up to 15 feet away from you.

- lt can't take reactions until the end of your next turn.

### Deflect Missiles

**Reaction when you are hit by a ranged weapon:** The damage you take from the attack is reduced by 1d10 + 6. If you reduce the damage to 0, you can catch the missile if it is small enough for you to hold in one hand and you have at least one hand free. If you catch a missile in this way, you can spend 1 ki point to make a ranged attack with the weapon or piece of ammunition you just caught, as part of the same reaction. This attack is made at +5 to hit and does D6+5 damage.

### Patient Defense 

**Reaction before an opponent rolls to hit:** Spend one ki point. Take the Dodge action.

### Step of the Wind

**Bonus action:** Spend one ki. Take the Disengage or Dash action and your long jump distance is doubled (12/24) for the turn.

## Ki energy

Your magical abilities come from harnessing the inner life force of your body and manifesting it in the world. It is always with you and cannot be taken away.

### Energy reserve

You have 3 Ki points. You regain all spent ki at the end of any rest.



Roguish Explorer

You rely on skill, stealth, cunning, and your foes' vulnerabilities to get the upper hand in any situation. You have a knack for finding the solution to just about any problem, especially if it requires the tip of your blade.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 9       | 16      | 14      | 10      | 12      | 15      |
| -1      | +3      | +2      | +0      | +1      | +2      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 15     | 24     | 3D8    | 30ft     | 4ft      | 9ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +5      | +2      | +2      | +1      | +2      |

### Major Skills:

**Perception (Wisdom) +3**

**Sleight of Hand (Dexterity) +5**

**Deception (Charisma) +4**

This check determines whether you can convincingly hide the truth, either verbally or through your Actions.

**Acrobatics (Dexterity) +5**

Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck.

**Withdraw (Acrobatics Talent)**

When you make an attack against a creature, you don’t provoke opportunity attacks from that creature for the rest of the turn, whether you hit or miss.

**Slippery (Acrobatics Talent)**

You have advantage on saving throws made to avoid or resist traps and you have resistance to the damage dealt by traps.

**Stealth (Dexterity) +7**

Make a check when you attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone without being seen or heard.

###  

### Assassinate

You are at your deadliest when you get the drop on your enemies. You have advantage on attack rolls against any creature that hasn't taken a turn in the combat yet. In addition, any hit you score against a creature that is surprised is a critical hit.

### Attack with Rapier

**Main action:** Make an attack roll with +5 to hit. This attack does D6+5 piercing damage.

### Throw a dagger

**Main action:** Make a ranged attack roll at a target within 20ft. This attack is made at +5 and deals D4+5 piercing damage. You have 4 daggers and recover them after an encounter.

### Cunning Action

**Bonus action:** Your quick thinking and agility allow you to move and act quickly. This action can be used take the Dash, Disengage, or Hide action.

### Sneak Attack

**When you hit a target which is adjacent to a friend, or you have advantage on your attack:** Once per turn, If you don't have disadvantage. you deals an extra 2d6 damage to the target. The attack must use a finesse or a ranged weapon.

### Throw flask of oil

**Use Object action:** Make an attack roll with +5 against a target within 20ft. This hits automatically if the target is within 5ft. For the next minute, the target takes 5 additional fire damage whenever it suffers fire damage.

### Throw flask of acid

**Use Object action:** Make an attack roll with +5 against a target within 20ft. This hits automatically if the target is within 5ft. The target takes 2D6 acid damage.

### Dungeoneer's Pack

A backpack filled with useful tools and equipment. It includes:

- 50ft of rope, hammer and pitons, grappling hook, two torches, tinderbox, 10ft of string, a small bell and a lantern.

### Thieves Tools

This set of tools includes a small file, a set of lock picks, a small mirror mounted on a metal handle, a set of narrow-bladed scissors, and a pair of pliers. When you roll to disarm traps or pick locks, you roll with +7.

Storm Sorcerer

Golden eyes flashing, you stretch out your hand and unleash the energy that storms through your veins. As a whirlwind rages around your foes, you whisper a word. The wind lifts you and sends you flying to a safe location.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 13      | 14      | 15      | 9       | 11      | 16      |
| +1      | +2      | +2      | -1      | +0      | +3      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 12     | 20     | 3D6    | 30ft     | 4ft      | 9ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +2      | +4      | -1      | +0      | +5      |

### Major Skills:

**Persuasion (Charisma) +5**

When you attempt to influence someone or a group of people with tact, social graces, or good Nature, the GM might ask you to make a Charisma (Persuasion) check. Typically, you use Persuasion when acting in good faith, to foster friendships, make cordial requests, or exhibit proper etiquette.

**Survival (Wisdom) +2**

To follow tracks, hunt wild game, guide your group through frozen wastelands, Identify signs that owlbears live nearby, predict the weather, or avoid quicksand and other natural hazards.

**Weathered Tracker (Survival Talent)**

You gain advantage on checks to discern the species of the creature based on its tracks. Additionally, you ignore the adverse effects of harsh weather. This can include not getting exhaustion due to being in very hot or very cold temperatures.

### Speak with the Wind

You can speak, read, write and understand the Primordial language. You can speak to elementals and other beings which tend to inhabit the elemental planes.

### Attack with Quarterstaff

**Main action:** Make an attack roll with +3 to hit. This attack does D6+3 bludgeoning damage.

# Elemental Magic

Your magic comes from an internal elemental reserve which you can call out at will.

### Tempestuous Magic

**Bonus action:** Immediately before or after you cast a spell of 1st level or higher, to fly up to 10 ft without provoking opportunity attacks.



### Subtle Spell

**When you cast a spell:**, spend 1 sorcery point to cast it without any somatic or verbal components.

### Twinned Shock

**When you cast Shocking grasp or Lighting lure:** Spend 1 sorcery point to target a second creature in range with the same spell, without spending an extra action.

### Font of Magic

You can modify your spells using a powerful, but limited reserve of magic. You can recharge a spell slot using sorcery points at a cost of spell level + 1.



### Shocking grasp 

**Action:** Make a melee spell attack against the target with +5 . You have advantage if the target is wearing armor made of metal. On a hit, the target takes 1d8 lightning damage, and it can't take reactions until the start of its next turn.

### Lightning Lure

**Action:** You create a lash of lightning energy that strikes at one creature of your choice that you can see within 15ft. It must succeed on a Strength saving throw (DC 13) or be pulled up to 10 feet in a straight line toward you. If it ends up within 5 feet of you, it takes 1D8 lightning damage.

### Thunderclap

**Action:** You create a burst of thunderous sound that can be heard up to 100 feet away. Each creature within 5ft, other than you, must succeed on a Constitution saving throw (DC 13) or take 1d6 thunder damage.

### Gust

**Action:** You seize the air and compel it at one Medium creature you can see within 30ft. It must succeed on a Strength saving throw (DC13) or be pushed up to 5 feet away from you.



### Shield (1st level)

**Reaction when you are hit with an attack:** Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile.

### Fog Cloud (1st level)

**Action:** You create a 20-foot-radius Sphere of fog centered on a point within 120ft. The Sphere spreads around corners, and its area is heavily obscured. It lasts for 1 hour or until a wind at least 10 miles per hour disperses it.

### Ice Knife (1st level)

You create a shard of ice and fling it at one creature within 60ft. Make a ranged spell attack at +5 against the target. On a hit, the target takes 1d10 piercing damage. Hit or miss, the shard then explodes. The target and each creature within 5 feet of it must succeed on a Dexterity saving throw (DC13) or take 2d6 cold damage.



### Dust Devil (2nd level)

**Action:** An elemental force that resembles a dust devil appears in an unoccupied space within 60ft and lasts for 1 minute. Any creature that ends its turn within 5 feet of the dust devil must make a Strength saving throw (DC 13). On a failed save, the creature takes 1d8 bludgeoning damage and is pushed 10 feet away. On a successful save, the creature takes half as much damage and isn’t pushed. You must maintain concentration or the spell ends. If the dust devil moves over sand, dust, loose dirt, or small gravel it forms a 10-foot-radius cloud of debris around itself that lasts until the start of your next turn.

### Move Dust devil

**Bonus action:** Move the dust devil up to 30 feet in any direction.

### Hurricane (2nd level)

A line of strong wind 60ft long and 10ft wide blasts from you in a direction you choose. Each creature that starts its turn in the line must succeed on a Strength saving throw (DC 13) or be pushed 15 feet away from you in a direction following the line. Any creature in the line counts as being in difficult terrain when moving closer to you.

### Retarget Hurricane 

**Bonus action:** Choose a new direction for the line.

#  

# Bladesinger

Clad in the robes that denote your rare station, you close your eyes to shut out the distractions of the battlefield and begin a quiet chant. Fingers weaving across your blade, it begins to sing along with you. Time slows as you and the blade slip into a harmonious trance.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 13      | 16      | 10      | 16      | 8       | 12      |
| +1      | +3      | +0      | +3      | -1      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 14     | 14     | 3D6    | 30ft     | 6ft      | 13ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +3      | +0      | +5      | +1      | +1      |

### Major Skills:

**Performance (Charisma) +3**

Determines how well you can delight an audience with music, dance, acting, storytelling, or some other form of entertainment.

**Arcana (Intelligence) +5**

**Nature (Intelligence) +5**

Helps when gaining information about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes, terrain, plants and animals, the weather, and natural cycles.

**Investigation (Intelligence) +5**

When you look around for clues, deduce the location of a hidden object, check an item for traps or search for a hidden fragment of knowledge.

**Keen Mind (Investigation Talent)**

You can accurately recall anything you have seen or heard within the past month, you always know which way is north, and you always know the number of hours left before the next sunrise or sunset.

### Arcane Recovery

Whenever you take a short rest, you can recover either two level one spell slots, or a single level two spell slot. Taking a long rest recovers all of your spell slots as per usual.

### Attack with Echoblade

**Main action:** You strike with this magical shortsword. Make an attack roll with +6 to hit. This attack does D6+6 slashing damage. Attacks with this weapon count as magical.

### Bladesong

**Bonus action:** Start a Bladesong, which lasts for 1 minute. It ends early if you’re incapacitated. You can also dismiss it at any time. While it is active:

- You gain +3 AC

- Your walking speed increases by 10 ft

- You have advantage on Acrobatics checks

- You gain +3 to Concentration checks

You regain all expended uses when you finish a short or long rest.



# Academic Magic

Your magic comes from long hours of study. You analyse old texts and reconstruct ancient knowledge, then experiment until you find a spell that works. Everything you learned is contained in a spellbook. Your magic is so complex, if your book is ever lost, you will lose everything.



### Firebolt 

**Action:** You hurl a mote of fire at a creature or object within 120ft. Make a ranged spell attack at +5. On a hit, the target takes 1d10 fire damage. A flammable object hit by this spell ignites if it isn't being worn or carried.

### Ray of Frost

**Action:** A frigid beam of blue-white light streaks toward a creature within 60ft. Make a ranged spell attack at +5. On a hit, it takes 1d8 cold damage, and its speed is reduced by 10 feet until the start of your next turn.

### True Strike

**Action:** You extend your hand and point a finger at a target within 30ft. On your next turn, you gain advantage on your first attack roll against the target, provided that this spell hasn't ended. Requires concentration.



### Magic Missile (1st level)

**Action:** You create three glowing darts of magical force. Each dart hits a creature of your choice that you can see within 120ft. A dart deals 1d4+1 force damage to its target. The darts all strike simultaneously and you can direct them to hit one creature or several.

### Identify (1st level)

You choose one object that you must touch throughout the casting of the spell, which takes 1 minute. If it is a magic item or some other magic-imbued object, you learn its properties.

### Featherfall (1st level)

**Reaction:** When you or a creature within 60 feet of you falls choose up to five falling creatures within 60ft. A falling creature's rate of descent slows to 60 feet per round for up to 1 minute. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature.

### False Life (1st Level)

**Action:** Bolstering yourself with a necromantic facsimile of life, you gain 1d4+4 temporary hit points for 1 hour.



### Blur (2nd level)

**Action:** Your body becomes blurred, shifting and wavering to all who can see you. For the 1 minute, any creature has disadvantage on attack rolls against you. An attacker is immune to this effect if it doesn't rely on sight, as with Blindsight, or can see through illusions, as with Truesight.

### Shatter (2nd level)

**Action:** A sudden loud ringing noise, painfully intense, erupts from a point of your choice within 60ft. Each creature within 10ft of this point must make a Constitution saving throw (DC 13). A creature takes 3d8 thunder damage on a failed save, or half as much damage on a successful one. A creature made of inorganic material such as stone, crystal, or metal has disadvantage on this saving throw.

Non-magical objects that are not being worn or carried also take the damage if it's in the spell's area.



Abyssal Warlock

You are a seeker of a knowledge that lies hidden in the fabric of the multiverse. Through pacts made with your demonic patron, you unlocked magical effects, subtle and spectacular. Darkness shrouds both your intent and visage, and the Abyss granted you a Familiar to do your bidding.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 13      | 15      | 9       | 11      | 14      | 16      |
| +1      | +2      | -1      | +0      | +2      | +3      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 12     | 15     | 3D8    | 30ft     | 6ft      | 13ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +2      | -1      | +0      | +4      | +5      |

### Major Skills:

**Deception (Charisma) +5**

**Insight (Wisdom) +4**

**Sense Enchantment (Insight Talent)**

**Action:** When you observe or interact with a creature to closely examine it by touch and smell, you can determine if its mood or behavior is being influenced by a spell or other magical effect.

### Pact of the Chain

When you perform this 10 minute ritual a Quasit is summoned from the Abyss to act as a familiar. While your familiar is within 100 feet of you, you can communicate with it telepathically. It obeys your commands and acts independently of you.

### Fiendish Bond

**Action:** Until the start of your next turn, you can see through your familiar's eyes and hear what it hears.

### Armor of Shadows

**Action:** You bind demonic energies to your body. Your AC becomes 15 for 1 hour, or until you don any armor.

### Dark One’s Blessing

When you reduce a hostile creature to 0 hit points, you gain 6 temporary hit points.

Pact Magic

Your magic comes from a deal made with an otherworldly fiend. As long as you keep up your end of the deal, you can wield a power that was never meant for mortals.



### Friends

**Action:** For 1 minute, you have advantage on all Charisma checks directed at one creature of your choice that isn’t hostile toward you. When the spell ends, the creature realizes that you used magic to influence its mood and becomes hostile toward you.

### Agonizing blast

**Action:** Make a ranged spell attack against a target within 120ft with +5 to your roll. On a hit, the target takes 1D10+3 force damage.



### Witch bolt (2nd level)

**Action:** Make a ranged spell attack with +5 against a creature you can see. On a hit, the target takes 2d12 lightning damage and the bolt has locked on.

### Locked bolt

**Action:** Deal 2d12 lightning damage to a target you have locked onto as long as it is in range and you still have a hand free. This does not cost a spell slot.

### Hellish Rebuke (2nd Level)

**Reaction when you are damaged:** The creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw (DC 13). It takes 3d10 fire damage on a failed save, or half as much damage on a successful one.

### Ray of Enfeeblement (2nd level)

**Action:** A black beam of enervating energy springs from your finger toward a creature within 60ft. Make a ranged spell attack against the target with +5. On a hit, the target deals only half damage with weapon attacks that use strength for the next minute.

### Invisibility (2nd Level)

**Action:** A creature you touch becomes *Invisible* for 1 hour or until you break concentration. Anything the target is wearing or carrying is *Invisible* as long as it is on the target's person. The spell ends if the target attacks or casts a spell.



# Quasit

Tiny fiend (demon), chaotic evil

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 5       | 17      | 10      | 7       | 10      | 10      |
| -3      | +3      | +0      | -2      | +0      | +0      |

| **AC** | **HP** | **Walk** |
|--------|--------|----------|
| 13     | 7      | 40ft     |

### Skills

**Stealth (Dexterity) +5**

### Demonic

The quasit is resistant to cold, dire, lightning, bludgeoning, piercing, and slashing From non-magical Attacks. It is immune to poison damage and the *Poisoned* condition.

### Darkvision

The quasit has Darkvision out to 120ft, meaning it can see in total darkness as if it was dim light, but can not see color.

### Abyssal Language

The quasit can speak in the Abyssal tongue as well as Common.

### Invisibility

The quasit is magically invisible unless it attacks, uses Scare, until its concentration ends or unless it wants to be seen. Any equipment the quasit wears or carries is invisible with it.

### Magic Resistance 

The quasit has advantage on saving throws against spells and other magical effects. If within 10ft, then this effect is also gained by its master.

### 

###  

### 

### 

### Poison attack

**Action:** Make a melee weapon attack at: +4 to hit causing 1d4+3 piercing damage plus 2d4 poison damage on a hit. The target must succeed on a Constitution saving throw (DC 10) or become poisoned for 1 minute. The target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.

### Scare

**Action:** Once per day, one creature of the quasit's choice within 20 ft must succeed on a DC 10 Wisdom saving throw or be *Frightened* for 1 minute. The target can repeat the saving throw at the end of each of its turns, with disadvantage if the quasit is within line of sight, ending the effect on itself on a success.

### Shapechanger 

**Action:** The quasit can polymorph into a beast form that resembles:

- a bat (speed 10 ft. fly 40 ft.)

- a centipede (40 ft., climb 40 ft.)

- a toad (40 ft., swim 40 ft.)

- its true form.

Its statistics are the same in each form, except for the speed changes noted. Any equipment it is wearing or carrying isn't transformed. It reverts to its true form if it dies.

# Druid of the Moon

Whether calling on the elemental forces of nature or emulating the creatures of the animal world, you are an embodiment of nature's resilience, cunning, and fury. You claim no mastery over nature, but it heeds your behest as an old friend might.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 14      | 14      | 10      | 16      | 12      |
| -1      | +2      | +2      | +0      | +3      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 16     | 24     | 3D8    | 30ft     | 6ft      | 13ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +2      | -1      | +0      | +4      | +5      |

### Major Skills:

**Survival (Wisdom) +5**

To follow tracks, hunt wild game, guide your group through frozen wastelands, Identify signs that creatures live nearby, predict the weather, or avoid quicksand and other natural hazards.

**Animal Handling (Wisdom) +5**

How well you can calm down a animal, keep a mount from getting spooked, or understand an animal’s intentions.

**Critter Friend (Animal Handling Talent)**

If you spend at least 1 minute observing or interacting with a beast, you can communicate simple ideas with the animal and understand its responses.

### Wooden Shield

**Action:** Don or doff this shield to gain +2 AC.

### Attack with Druidic Totem

**Action:** Make a melee attack roll with +5 causing D8+5 magical bludgeoning damage. This totem is also your Druidic focus for casting your spells.

### Druidic language

You know Druidic, the secret language of druids. You can speak the language and use it to leave hidden messages. You and others who know this language automatically spot such a message.

Nature Magic

Your magic comes from nature itself. As long as you continue to pay your respects, this power will be yours to weild.

### Natural Recovery

Whenever you take a short rest, you can recover either two level one spell slots, or a single level two spell slot. Taking a long rest recovers all of your spell slots as per usual.



### Thorn Whip

**Action:** You create a long, vine-like whip covered in thorns that lashes out at your command toward a creature within 30ft. Make a melee spell attack at +5 causing 1d6 piercing damage, and if the creature is Large or smaller, you pull the creature up to 10 feet closer to you.

### Magic stones

**Bonus action:** You touch one to three pebbles and imbue them with magic for one minute. If you cast this spell again, the spell ends early on any pebbles still affected by it.

### Throw Stone

**Action:** You or an ally may take this action to throw one of your magic stones. Make a ranged spell attack at a target within 60ft with a +5 to the roll. On a hit, the target takes D6+5 bludgeoning damage. The spell then ends on that stone.



### Entangle (1st level)

**Action:** Grasping weeds and vines sprout from the ground in a 20-foot square starting from a point within 90ft and lasting 1 minute. These plants turn the ground in the area into difficult terrain.

A creature in the area when you cast the spell must succeed on a Strength saving throw (DC 13) or be *Restrained* by the entangling plants until the spell ends. A creature *Restrained* by the plants can use its action to make a Strength check (DC 13) to free itself.

### Summon Goodberries (1st level)

**Action:** Up to ten berries appear in your hand and are infused with magic for 24 hours. Each berry restores 1 hit point when eaten as a Use Object action.



### Healing Spirit (2nd Level)

**Bonus action:** You call forth a nature spirit to soothe the wounded. The intangible spirit appears in a space that is a 5-foot cube you can see within 60ft. Until the spell ends, whenever you or a creature you can see moves into the spirits space for the first time on a turn or starts its turn there, you can cause the spirit to restore ld6 hit points to that creature (no action required). The spirit can’t heal constructs or undead.

The spirit lasts until you lose concentration or after 1 minute.

### Move Spirit

**Bonus action:** move the Spirit up to 30 feet to a space you can see.

### Animal Friendship (2nd Level)

**Action:** This spell lets you convince beasts that you mean them no harm. Choose up to two beasts that you can see within range. Targets must see and hear you. If a beast’s Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw (DC 13) or be *Charmed* by you for 24hrs. If you or one of your companions harms the target, the spells ends.



### Wildshape

**Bonus Action:** You change into or out of one of the beast shapes you have available. You can stay in a beast shape for one hour, then revert to your normal form unless you expend another use of this feature. You automatically revert if you fall unconscious, drop to 0 hit points, or die.

You may select one combat wildshape, or you may change into any small creature such as a squirrel, cat, bird, insect.

While you are transformed, the following rules apply:

- You gain stats of the beast, as shown.

- You have the beast’s hit points and Hit Dice. When you revert, you return to the hit points you had before. If you revert because you hit 0 hit points, any excess damage carries over to your normal form.

- You can’t cast spells, and your ability to speak or take actions is limited to the capabilities of your beast form.



Giant Toad

### Statistics

| **Str** | **Dex** | **Con** | **AC** | **HP** | **HD** |
|---------|---------|---------|--------|--------|--------|
| 15      | 13      | 13      | 11     | 39     | 6d10   |
| +2      | +1      | +1      |        |        |        |

### Darkvision

The toad has Darkvision out to 30ft, meaning it can see in total darkness as if it was dim light, but can not see color.

### Amphibious

The toad can breathe air and water.

### Movement

The toads long jump is up to 20ft, and does not need a running start. The toads swimming speed is 40ft.

### Bite

**Action:** Make a melee attack roll with +4 causing D10+2 piercing damage plus 1D10 poison damage. The target is *Grappled* (escape DC 13) and is *Restrained* until it escapes or the toad grapples another target.

### Swallow

**Action:** Make the bite action against a Medium or smaller target that is being *Grappled*. If it hits, the target is swallowed and the grapple ends. The swallowed target is *Blinded* and *Restrained*, it has total cover against attacks and other effects outside the toad, and it takes 3d6 acid damage at the start of each of the toad's turns. The toad can have only one target swallowed at a time.

If the toad dies, a swallowed creature is no longer restrained by it and can escape from the corpse using 5 feet of movement, exiting prone.

Tiger

### Statistics

| **Str** | **Dex** | **Con** | **AC** | **HP** | **HD** |
|---------|---------|---------|--------|--------|--------|
| 17      | 15      | 14      | 12     | 37     | 5d10   |
| +3      | +2      | +2      |        |        |        |

### Skills

**Perception (Wisdom): +2**

**Stealth (Dexterity): +4**

### Darkvision

The tiger has Darkvision out to 60ft, meaning it can see in total darkness as if it was dim light, but can not see color.

### Keen Smell

The tiger has advantage on Wisdom (Perception) checks that rely on smell.

### Movement

The tigers walking speed is 40ft

### Pounce

If the tiger moves at least 20 ft. straight toward a creature and then hits it with a claw attack on the same turn, that target must succeed on a Strength saving throw (DC 13) or be knocked prone. If the target is prone, the tiger can make one bite attack against it as a bonus action.

### Bite

**Action:** Make a melee attack roll with +5 causing D10+3 piercing damage.

### Claw

**Action:** Make a melee attack roll with +5 causing D8+3 slashing damage.

Giant Eagle

### Statistics

| **Str** | **Dex** | **Con** | **AC** | **HP** | **HD** |
|---------|---------|---------|--------|--------|--------|
| 16      | 17      | 13      | 13     | 26     | 4d10   |
| +3      | +3      | +1      |        |        |        |

### Skills

**Perception (Wisdom): +2**

### Keen Sight

The eagle has advantage on Wisdom (Perception) checks that rely on sight.

### Movement

The eagle has a flying speed of 80ft, but a walking speed of only 10ft.

### Language

The eagle can understand Common and Auran (Primordial), but cant speak. It can speak Giant Eagle language.

### Multiattack

**Action:** Make one Beak attack and one Talon attack.

### Beak

**Action:** Make a melee attack roll with +5 causing D6+3 piercing damage.

### Talons

**Action:** Make a melee attack roll with +5 causing 2D6+3 slashing damage.
