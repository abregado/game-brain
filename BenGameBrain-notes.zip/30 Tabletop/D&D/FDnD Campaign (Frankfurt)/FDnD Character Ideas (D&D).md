---
title: "FDnD Character Ideas (D&D)"
source: "Game Stuff/D&D/FDnD Character Ideas"
modified: 2020-02-12
type: character
area: dnd
status: "designed"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[D&D One-shots]]"]
concepts: ["FDnD campaign (Frankfurt)", "D&D one-shots"]
words: 1374
summary: "Pre-generated character concepts for a Phandalin start (Half Orc monk labourer, human blacksmith, geologist wizard, prince sorcerer) with personality/ideal/bond/flaw options and a template checklist for character creation."
tags: ["area/dnd", "project/d-d-one-shots", "project/fdnd-campaign-frankfurt", "type/character"]
---

**Half Orc Labourer. Monk/Hermit**

You lived your life so far in seclusion but recently started to visit the Mining Camps near the town of Phandalin to offer your services. You were put to work as a Labourer, using your immense strength to half move heavy mining equipment and to pull wagons of ore. You are not dumb, but also not bright, preferring quiet contemplation. You often get lost in your own contemplations and become oblivious to your surroundings. You are a calm character and not prone to violence but you know this is against your Orcish heritage. Lately you have noticed a group of people in the Mining Camps extorting the already poor and unlucky Miners out of their claims, beating them if they don't give up their finds and generally causing problems. Nobody seems to be doing anything about it.

**Personality**

Violence should always be the last resort, but one I am willing to take

**Ideal**

Civilized and Powerful people are not to be trusted.

**Bonds**

I fear I will lose my humanity if I allow my violent orcish heritage to take hold

**Flaws**

After a battle I must be alone to collect my thoughts

**Personality**

I often become lost in my own quiet contemplations

**Ideal**

My gifts should not be used for my own benefit

**Bonds**

I fear I will lose my humanity if I allow my violent orcish heritage to take hold

**Flaws**

After a battle I must be alone to collect my thoughts

**Personality**

Violence should always be the last resort, but one I am willing to take

**Ideal**

Civilized and Powerful people are not to be trusted.

**Bonds**

I spend time every day contemplating my humanity by being alone

**Flaws**

I am jealous of full blood humans because they have such an easy life

**Human Blacksmith. Fighter/Guild Artisan**

Due to your long career as a Blacksmith you are strong and resiliant. Working in a busy Adventuring village you have picked up a thing of two about fighting and have seen many Magic weapons. The guild master in your village started to become competitive and made your life difficult, so, after receiving a letter from an old friend Thel Dendrar, you journied north to the town of Phandalin to meet him. You cannot abide people who make a living from the misery of others, but have never been brave enough to do something about it yourself. You only just arrived today and the town is in chaos due to some local crime activity. Perhaps today is the day to stand up for others?

**Personality**

I have been chased from my home and am seeking a new one at any cost

**Ideal**

I cannot abide people who make a living from the misery of others

**Bonds**

As long as I can be useful and ply my trade, my life has meaning

**Flaws**

I will run to save myself and find it hard to have the courage to stand up for someone in need

**Human Geologist. Wizard/Charlatan**

You have travelled a long way north looking for work and interesting surroundings to extend your knowledge. Everyone gave you the expectation that the journey would be adventurous but so far nothing of note has happened, and your Rapier has gone unsheathed. Finally you happened upon the town of Phandalin and its many scattered Mining Camps. Here you have spent the last 3 weeks identifying claims and mineral finds. The local Mining Guild leader Halia Thornton has sent men to intimidate you for working without a license. You guess it is only fair, given that you are secretly overcharging and underpaying the Miners… just a little bit.

**Personality**

I have been chased from my home and am seeking a new one at any cost

**Ideal**

I cannot abide people who make a living from the misery of others

**Bonds**

Nowhere will ever be as great as where I came from

**Flaws**

I will run to save myself and find it hard to have the courage to stand up for someone in need

**Personality**

I suffer from homesickness even when I know I cannot return

**Ideal**

Every person must look after themselves in this world

**Bonds**

As long as I can be useful and ply my trade, my life has meaning

**Flaws**

I get angry at people who get in the way of my happiness

**Human Prince. Sorcerer/Noble**

Your family is powerful. One of your ancestors was from an elemental plane and your bloodline is tainted with its power. One family member in each generation is born a sorcerer. Of your brothers and sisters it was fated to be you.

Your parents would have you rule, and have even taken steps to “remove” other newborns who would challenge you. You want nothing of this and have left to see the world. Perhaps far away from home, there will be less pressure on you.

**Secret:**

During your tutelage, you discovered that the elemental ancestor actually aided the great Elemental Evil during the last uprising. If anyone important found this out, your family would be branded enemies of civilization.

**Personality**

**Ideal**

**Bonds**

**Flaws**

Race/Profession

Fights with (2 options)

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><p>Trait (2 options)</p>
<p>Something you can use in roleplay often.</p></th>
<th><p>Ideal (2 options)</p>
<p>What would make the world a better place.</p></th>
<th><p>Bond (2 options)</p>
<p>The most important thing to you.</p></th>
<th><p>Flaw (2 options)</p>
<p>Often gets in the way of your success, something out of your control.</p></th>
</tr>
<tr class="odd">
<th><p>Idolize</p>
<p>Empathic to enemies</p>
<p>Sees omens</p>
<p>Optimistic</p>
<p>Quotes sacred texts</p>
<p>tolerant/intolerant</p>
<p>respectful/disrespectful</p>
<p>Conneseur</p>
<p>Miser</p>
<p>High expectations of people</p>
<p>Easily disapointed</p>
<p>Sarcastic</p>
<p>Liar</p>
<p>Flighty</p>
<p>Always speaking to the gods</p>
<p>Always has a plan</p>
<p>Always calm</p>
<p>Always rushing</p>
<p>Impatient</p>
<p>Scrutinizer</p>
<p>Slow/Fast descision maker</p>
<p>Grumpy</p>
<p>Cranky</p>
<p>Romantic</p>
<p>Gossiper</p>
<p>Storyteller</p>
<p>Limelighter</p>
<p>Perfectionist</p>
<p>Mood changer</p>
<p>Acts on words</p>
<p>Helper</p>
<p>Yes man</p>
<p>Pessimist</p>
<p>Follows through</p>
<p>Leader</p>
<p>Wise</p>
<p>Rarely speaks</p>
<p>Commited</p>
<p>Black and White</p>
<p>Snob</p>
<p>Actor</p>
<p>Thinker</p>
<p>Equitable</p>
<p>Old joke cookie</p>
<p>Prankster</p>
<p>Mannerism</p>
<p>Confident/Inconfident</p>
<p>Oblivious</p>
<p>Easily Distracted</p>
<p>Serene</p>
<p>Kind</p>
<p>Generous</p>
<p>Flatterer</p>
<p>Regal</p>
<p>Disgusted easily</p>
<p>Wanderlust</p>
<p>Teacher</p>
<p>People person</p>
<p>Animal Person</p>
<p>Book worm</p>
<p>Stutterer</p>
<p>Mysterious</p>
<p>Contemplator</p>
<p>Talks down to commoners</p>
<p>Awkward</p>
<p>Combative</p>
<p>Crude Humor</p>
<p>Blunt</p></th>
<th><p>Tradition: Religion</p>
<p>Charity</p>
<p>Change</p>
<p>Power</p>
<p>Asp: Worthiness</p>
<p>Independance</p>
<p>Fairness</p>
<p>Creativity</p>
<p>Friendship</p>
<p>Asp: Skill</p>
<p>Honor</p>
<p>Freedom</p>
<p>Self Interest</p>
<p>Weakness removal</p>
<p>Beauty</p>
<p>Bold action</p>
<p>New ideas</p>
<p>Benifit of the doubt</p>
<p>Tradition: Stories</p>
<p>Happiness</p>
<p>Honesty</p>
<p>Obedience</p>
<p>Might is right</p>
<p>Sincerity</p>
<p>Destiny</p>
<p>Respect</p>
<p>Community</p>
<p>Generosity</p>
<p>Greater Good</p>
<p>Logic</p>
<p>Emotions</p>
<p>Freedom of speech</p>
<p>Freedom of thought</p>
<p>Freedom of action</p>
<p>Power</p>
<p>Genetic bloodline</p>
<p>Purity</p>
<p>Obligation</p>
<p>Self-Respect</p>
<p>Introspection</p>
<p>Mastery</p>
<p>Life not Death</p>
<p>Forgivness</p>
<p>Stoicism</p>
<p>Independance</p></th>
<th><p>Artifact recovery</p>
<p>Revenge target</p>
<p>Owe my life</p>
<p>The common people</p>
<p>Church</p>
<p>Guild</p>
<p>Birthplace</p>
<p>Nation</p>
<p>Temple</p>
<p>A Sacred object</p>
<p>Mentor (good)</p>
<p>Mentor (bad)</p>
<p>Mentor (legacy)</p>
<p>Unknowing child</p>
<p>Noble heritage</p>
<p>Lover/Partner</p>
<p>Atonement</p>
<p>Debtor</p>
<p>Family/Tribe</p>
<p>Role model</p>
<p>Treasured Possession</p>
<p>Rival</p>
<p>Work Colleges</p>
<p>School</p>
<p>Profession</p>
<p>The Land</p>
<p>The environment</p>
<p>A specific place</p>
<p>Race/Species</p>
<p>Cultural group</p>
<p>The downtrodden</p>
<p>The weak</p>
<p>The worthy</p>
<p>Unrequited love</p>
<p>My Order/Association</p>
<p>Personal goal</p>
<p>Isolation</p>
<p>Enlightenment</p>
<p>Wilderness</p>
<p>Homeland</p>
<p>My Children</p>
<p>All Children</p>
<p>The elderly</p>
<p>A Vision</p>
<p>A soul/My soul</p>
<p>My lifes work</p>
<p>Students</p>
<p>Rank Superiors</p>
<p>Rank Juniors</p>
<p>A Question</p>
<p>My ship and/or crew</p>
<p>Profit</p>
<p>My Honor</p>
<p>The honor of another</p>
<p>City/Town</p>
<p>Childhood friend</p>
<p>Redemption</p></th>
<th><p>Judgemental</p>
<p>Overly Trusting</p>
<p>Blind piety</p>
<p>Inflexible thinker</p>
<p>Suspicious</p>
<p>Goal Obsessed</p>
<p>Sucker for a pretty face</p>
<p>Always in debt</p>
<p>Optimism</p>
<p>Convinced of infallability</p>
<p>Greedy</p>
<p>Swindles authority</p>
<p>Hates themselves</p>
<p>Cowardly</p>
<p>Covetous</p>
<p>Always forgets the plan</p>
<p>Bad liar</p>
<p>Guilt ridden</p>
<p>Craves infamy</p>
<p>Vain</p>
<p>Paranoid</p>
<p>Hunted</p>
<p>Unreliable</p>
<p>Loose tongue</p>
<p>Insulting</p>
<p>Addict</p>
<p>Shameful secret</p>
<p>Convinced of own destiny</p>
<p>Believes they should rule</p>
<p>Untrusting of allies</p>
<p>Never satisfied</p>
<p>Jealous</p>
<p>Dark thoughts</p>
<p>Rigid philosophy</p>
<p>Bad Loser</p>
<p>Cheater</p>
<p>Tight lipped</p>
<p>Scandalous secret</p>
<p>Quick to anger</p>
<p>Self centered</p>
<p>Black sheep</p>
<p>Uncautious/Rash</p>
<p>Overly Cautious</p>
<p>Racist/Sexist</p>
<p>Power hungry</p>
<p>Violent</p>
<p>Grudge taker</p>
<p>Mocks the weak</p>
<p>Information hungry</p>
<p>Dangerously inquisitive</p>
<p>Always takes the simple option</p>
<p>Always takes the complex option</p>
<p>Blabbermouth</p>
<p>Always follows orders</p>
<p>Lazy/Work avoider</p>
<p>Never backs down</p>
<p>Prideful</p>
<p>Rule of the Sword</p>
<p>Cant be wrong</p>
<p>Self Doubting</p>
<p>Backstabber</p>
<p>Bigot</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Basic Statistics

Player Chooses: Name, Alignment, Gender, Age

Race/Class/Subclass/Background

Attributes

Saving Throws

Skills shortlist

Armor Class

HP

Hit dice

2x Personality Trait

2x Ideals

2x Bonds

2x Flaws

A description of the character without any of the choices that the player makes.

Passive Abilities all in one list.

Items only if needed for an ability, include in ability description.

Choices for how items look. Use quality neutral adjectives.
