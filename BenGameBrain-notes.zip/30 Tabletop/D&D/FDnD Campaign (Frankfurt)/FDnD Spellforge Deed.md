---
title: "FDnD Spellforge Deed"
source: "Game Stuff/D&D/FDnD Spellforge Deed"
modified: 2020-02-16
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]", "[[WDnD Campaign]]"]
concepts: ["FDnD campaign (Frankfurt)", "Phandelver Mine and Forge"]
words: 256
summary: "In-game deed for the Phandelver Mine and Forge listing shareholder percentages (Gundren, Halia, party members), profit rules and the mine's income. Text is duplicated twice."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "project/wdnd-campaign", "type/campaign-prep"]
---

# Phandelver Mine and Forge

### Deed - Phandalin region

The current names listed on the deed are:

Gundren Rockseeker 25%

Nundro Rockseeker 25%

Halia Thornton 35%

Trisha Merryweather 3%

Hama Rein 3%

Kildrak Frostbeard 3%

Thokk 3%

Livia Iorek 3%

Profits made from sales of materials and constructed items will be split between stakeholders. Stakeholders may also vote for which enchantment contracts will be undertaken.

Shareholder payouts can be collected from the Phandalin Miners Exchange.

All mine takings will be sold through the Phandalin Miners Exchange, run by Halia Thornton. The Exchange will cover the sales tax for all such sales, increasing the profits of the mine (not the forge) by 100%.

The mine is currently earning 200gp per tenday but is expected to increase over time.

# Phandelver Mine and Forge

### Deed - Phandalin region

The current names listed on the deed are:

Gundren Rockseeker 25%

Nundro Rockseeker 25%

Halia Thornton 35%

Trisha Merryweather 3%

Hama Rein 3%

Kildrak Frostbeard 3%

Thokk 3%

Livia Iorek 3%

Profits made from sales of materials and constructed items will be split between stakeholders. Stakeholders may also vote for which enchantment contracts will be undertaken.

Shareholder payouts can be collected from the Phandalin Miners Exchange.

All mine takings will be sold through the Phandalin Miners Exchange, run by Halia Thornton. The Exchange will cover the sales tax for all such sales, increasing the profits of the mine (not the forge) by 100%.

The mine is currently earning 200gp per tenday but is expected to increase over time.
