---
title: "Dungeons and Dragons Characters"
source: "Game Stuff/D&D/Dungeons and Dragons Characters"
modified: 2018-09-12
type: character
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 843
summary: "Spreadsheet of five party characters (Trisha, Kildrak, Livia, Thokk, Hama) with ability mods, saves, skills, HP, AC, speed, languages and proficiencies."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

## Sheet: Sheet1

|  | Trisha | Kildrak | Livia | Thokk | Hama |
|---|---|---|---|---|---|
| Strength | -1.0 | 2.0 | 2.0 | 3 | 1.0 |
| Dexterity | 3 | -1.0 | 3.0 | 0.0 | 1.0 |
| Consitution | 1.0 | 2.0 | 2.0 | 2.0 | 1.0 |
| Intellegence | 1.0 | 0.0 | 0.0 | 0.0 | 3.0 |
| Wisdom | 0.0 | 3.0 | 1.0 | 2.0 | 0.0 |
| Charisma | 3.0 | 1.0 | -1.0 | 0.0 | 0.0 |
| Saving Throws |  |  |  |  |  |
| Strength | -1 | 2 | 4 | 5 | 3 |
| Dexterity | 5 | -1 | 3 | 2 | 1 |
| Consitution | 1 | 2 | 4 | 2 | 3 |
| Intellegence | 3 | 0 | 0 | 0 | 3 |
| Wisdom | 0 | 5 | 1 | 2 | 0 |
| Charisma | 3 | 3 | -1 | 0 | 0 |
| Acrobatics | 5 | -1 | 3 | 0 | 1 |
| Animal Handling | 0 | 3 | 3 | 2 | 0 |
| Arcana | 1 | 0 | 0 | 0 | 5 |
| Athletics | -1 | 4 | 2 | 5 | 1 |
| Deception | 5 | 1 | -1 | 0 | 0 |
| History | 1 | 0 | 2 | 0 | 5 |
| Insight | 0 | 3 | 1 | 4 | 2 |
| Intimidation | 3 | 3 | -1 | 2 | 0 |
| Investigation | 3 | 0 | 0 | 0 | 3 |
| Medicine | 0 | 5 | 1 | 4 | 0 |
| Nature | 1 | 0 | 0 | 0 | 3 |
| Perception | 0 | 3 | 3 | 2 | 2 |
| Performance | 5 | 1 | -1 | 0 | 0 |
| Persuasion | 3 | 1 | -1 | 0 | 2 |
| Religion | 1 | 2 | 0 | 0 | 3 |
| Sleight of Hand | 5 | -1 | 3 | 0 | 1 |
| Stealth | 5 | -1 | 3 | 0 | 1 |
| Survival | 0 | 3 | 3 | 4 | 0 |
| Hit Points | 27.0 | 32.0 | 36.0 | 30.0 | 33.0 |
| Armor Class | 14.0 | 18.0 | 14.0 | 12.0 | 15.0 |
| Initiative | 3.0 | -1.0 | 3 | 0.0 | 1 |
| Speed | 25.0 | 25.0 | 30.0 | 40.0 | 30.0 |
| Passive Perception | 10.0 | 13.0 | 13.0 | 12.0 | 12.0 |
| Alignment | Neutral | Neutral Good | Lawful Good | Neutral Good | Neutral Good |
| Language |  |  |  |  |  |
| Common | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 |
| Halfling | 1.0 |  |  |  |  |
| Elf |  |  | 1.0 |  |  |
| Dwarf |  | 1.0 |  |  | 1.0 |
| Orc |  |  |  | 1.0 |  |
| Goblin |  |  |  |  |  |
| Dragon |  |  |  |  |  |
| Undercommon |  |  |  |  |  |
| Gnomish |  |  |  |  | 1.0 |
| Proficiency Bonus | 2.0 | 2.0 | 2.0 | 2.0 | 2.0 |
| Str Saving |  |  | 1.0 | 1.0 | 1.0 |
| Dex Saving | 1.0 |  |  | 1.0 |  |
| Con Saving |  |  | 1.0 |  | 1.0 |
| Int Saving | 1.0 |  |  |  |  |
| Wis Saving |  | 1.0 |  |  |  |
| Cha Saving |  | 1.0 |  |  |  |
| Acrobatics | 1.0 |  |  |  |  |
| Animal Handling |  |  | 1.0 |  |  |
| Arcana |  |  |  |  | 1.0 |
| Athletics |  | 1.0 |  | 1.0 |  |
| Deception | 1.0 |  |  |  |  |
| History |  |  | 1.0 |  | 1.0 |
| Insight |  |  |  | 1.0 | 1.0 |
| Intimidation |  | 1.0 |  | 1.0 |  |
| Investigation | 1.0 |  |  |  |  |
| Medicine |  | 1.0 |  | 1.0 |  |
| Nature |  |  |  |  |  |
| Perception |  |  | 1.0 |  | 1.0 |
| Performance | 1.0 |  |  |  |  |
| Persuasion |  |  |  |  | 1.0 |
| Religion |  | 1.0 |  |  |  |
| Sleight of Hand | 1.0 |  |  |  |  |
| Stealth | 1.0 |  |  |  |  |
| Survival |  |  | 1.0 | 1.0 |  |
