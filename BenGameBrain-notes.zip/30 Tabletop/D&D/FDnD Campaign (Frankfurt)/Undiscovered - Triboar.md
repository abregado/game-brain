---
title: "Undiscovered - Triboar"
source: "Game Stuff/D&D/FDnD Files/Undiscovered - Triboar"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Triboar"]
words: 530
summary: "DM-only version of Triboar with owners and unvisited shops, prices, travel times."
contains_external_material: "Base descriptions from published module"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Triboar

Town

## Unplaced NPC’s

none

## Locations

### Everwyvern House (Inn) / Pleasing Platter (Resteraunt)

This expensive inn caters to Waterdhavian nobility and other well-to-do folk who wouldn't be caught dead in a more modest establishment. Two large buildings border a walled area which contains a pleasant and orderly garden. A large fountain stands in front of the manor house. The only entrance is though a gate which is guarded by several well dressed guards.

**NPC’s**

Draven Millovyr - Owner + mage

| **Service**                               | **Cost** |
|-------------------------------------------|----------|
| Suite room with breakfast (per person)    | 15gp     |
| Stabling and Feed (per animal, per night) | 5gp      |
| Meal at the Pleasing Platter (4 courses)  | 25gp     |

### The Lions Share (Trader) - Unvisited

This building was recently purchased and refurbished

by the Lionshield Coster, a merchant company based

in the city of Yartar. Above the store's entrance hangs a

polished shield emblazoned with the head of a stylized

golden lion on a blue background.

**NPCs**

Nathan Tezrin - Owner

### The Cart and Coin (Wagonshouse) - Unvisited

**NPC’s**

Arn Widdens - Owner

### The Triboar Travelers - (Mercenary contractor) 

A simple building with a waiting room and office where travellers can get work.

NPC’s

Alan Stockspool - Owner / Businessman

Valken Naspeer - Owner / Public Relations

| **Service**                       | **Cost** |
|-----------------------------------|----------|
| Guard a Caravan down to Waterdeep | 600gp    |
| Guard a Caravan to Mirabar        | 800gp    |

| **Quests**              | **Cost** |
|-------------------------|----------|
| Caravan Guard (per day) | 4gp      |

### Tower (Townmaster)

The center of Triboar, where the Long Road meets the

Evermoor Way, is a huge open space used as a market

by local farmers and visiting peddlers. Dominating

the space is the two-story Tower of the Lord Protector,

a simple stone keep that leans decidedly to the east.

Hanging above the entrance is the dusty banner of the

lord protector, which depicts three black boars running

toward the head of the banner on a blood-red field.

**NPC’s**

Darathra “Dara” Shendrel - Lord Protector

12 Knights (some out on patrol)

### Northshield House (Inn)

NPC’s

Ursula Meltimer - Owner

Zomith - Half-orc Caravan Guard

3 Mastiffs

Guests

Silvarren Loomshank - Priest of Helm

| **Service**                                      | **Cost** |
|--------------------------------------------------|----------|
| Single Bed, Board and Meal (per room, per night) | 1gp      |
| Stabling and Feed (per animal, per night)        | 1gp      |

### Foehammers Forge and Arms (Smith) - Unvisited

NPC’s

Ghelryn Foehammer - Royal Armorer

### Boars Rest (Private Estate) - Unvisited

**NPC’s**

Hayden Kolstaag - Resident

### North and West Campgrounds (Inn) 

Two large trampled areas devoid of grass. During wet weather, these are muddy, and on sunny days they are very dusty. Travellers may camp here for free, and caravans may also park for free.

**NPC’s**

Three monks of the Sacred Stone

## Travel Times

| **Destination** | **Trail type** | **Distance** |
|-----------------|----------------|--------------|
| Westbridge      | Good road      | 36 miles     |
| Yatar           | Good road      | 34 miles     |
| Conyberry       | Horse trail    | 32 miles     |
| Black Maw Bog   | Good road      | 12 miles     |
