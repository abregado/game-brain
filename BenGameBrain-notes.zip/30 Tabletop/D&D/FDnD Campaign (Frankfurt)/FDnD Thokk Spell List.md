---
title: "FDnD Thokk Spell List"
source: "Game Stuff/D&D/FDnD Thokk Spell List"
modified: 2020-02-15
type: character
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 755
summary: "Essentially empty; the conversion shows only two unreadable tables (a spell list for the character Thokk)."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/character"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="thrashing-tendrils">Thrashing Tendrils</h2></th>
<th><h2 id="fearsome-visage">Fearsome Visage</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: Self (<strong>10 feet radius)</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p></p>
<p>You summon the power of the Feywild with a hand gesture and a word. Tendrils of thick wood erupt from tiny portals around you and batter all creatures within 10 feet.</p>
<p>Each creature in that area must make a Strength saving throw (DC 15). On a failed save, a target takes 2d6 bludgeoning damage and can’t take reactions until its next turn. On a successful save, the creature takes half damage, but suffers no other effect.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Necromancy</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>60 Feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p></p>
<p>You speak a word and a creature you can see within range sees you as a fey demon and it is terrifying.</p>
<p>The target must succeed on a Window saving throw (DC 15) or become frightened of you until the spell ends. The frightened target can repeat the saving throw at the end of each of its turns, ending the effect on a success.</p>
<p>Constructs and undead are immune to this effect.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1">Level 1</h3></th>
<th><h3 id="level-1-1">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="ensnaring-strike">Ensnaring Strike</h2></th>
<th><h2 id="fey-cloud">Fey Cloud</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Conjuration</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You speak a word. The next time you hit a creature with a melee attack before this spell ends, a writhing mass of thorny vines appears at the point of impact, and the target must succeed on a Strength saving throw (DC 15) or be restrained by the magical vines until the spell ends.</p>
<p>A Large or larger creature has advantage on this saving throw. If the target succeeds on the save, the vines shrivel away. While restrained by this spell, the target takes 1d6 piercing damage at the start of each of its turns. A creature restrained by the vines or one that can touch the creature can use its action to make a Strength check (DC 15). On a success,the target is freed.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>Reaction</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>When you or a creature you can see within 60 feet of you falls, you shout a command and spend your reaction.</p>
<p>Choose up to five creatures within range. A cloud of tiny fey creatures appear and slow the rate of falling.</p>
<p>A falling creatures rate of descent slows to 60 feet per round until the spell ends. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-2">Level 1</h3></th>
<th><h3 id="level-1-3">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="hex">Hex</h2></th>
<th><h2 id="purify-food-and-drink">Purify Food and Drink</h2></th>
</tr>
<tr class="odd">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Enchantment</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>90 feet</strong></p>
<p>Duration: <strong>Concentration, up to 1 hour</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Pointing at the creature and speaking a word of power, you place a curse on a creature that you can see within range.</p>
<p>Until the spell ends, you deal an extra 1d6 necrotic damage to the target whenever you hit it with an attack. Also, choose one ability when you cast the spell. The target has disadvantage on ability checks made with the chosen ability.</p>
<p>If the target drops to 0 hit points before this spell ends, you can use a bonus action on a subsequent turn of yours to curse a new creature. A remove curse cast on the target ends this spell early.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Instantaneous</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>Passing your hand over an area and uttering a word of power, you cause all non-magical food and drink within a 5 foot radius to become purified of poison and disease.</p></th>
</tr>
<tr class="header">
<th><h3 id="level-1-4">Level 1</h3></th>
<th><h3 id="level-1-5">Level 1</h3></th>
</tr>
<tr class="odd">
<th><h2 id="glamour-of-fate">Glamour of Fate</h2></th>
<th><h2 id="zephyr-strike">Zephyr Strike</h2></th>
</tr>
<tr class="header">
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Abjuration</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>60 feet</strong></p>
<p>Duration: <strong>Concentration, up to 10 minutes</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V, S</strong></p>
<p>You point at a creature within range and shout a magical command word. The targeted creature gains +2 Armor Class for the duration of the spell.</p></th>
<th><table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>School: <strong>Transmutation</strong></p>
<p>Casting time: <strong>1 Bonus Action</strong></p></th>
<th><p>Range: <strong>Self</strong></p>
<p>Duration: <strong>Concentration, up to 1 minute</strong></p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
<p>Components: <strong>V</strong></p>
<p>You shout a word of power and take the aspect of a razor wind.</p>
<p>Until the spell ends, your movement doesn’t provoke opportunity attacks.</p>
<p>Once before the spell ends, you can give yourself advantage on one attack roll on your turn. That attack deals an extra 1d8 force damage if it hits. Whether you hit or miss, your walking speed increased by 30 feet until the end of that turn.</p></th>
</tr>
<tr class="odd">
<th><h3 id="level-1-6">Level 1</h3></th>
<th><h3 id="level-1-7">Level 1</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
