---
title: "Red Larch"
source: "Game Stuff/D&D/FDnD Files/Red Larch"
modified: 2020-04-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign", "Red Larch"]
words: 594
summary: "Location sheet for the town of Red Larch: shops, inns, shrine, NPCs with prices and travel times as visited by the party."
contains_external_material: "Location descriptions appear copied from the published module; Ben added prices, visited notes"
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

# Red larch

Town

**[Red larch](#red-larch) 1**

> Unplaced [NPCs](#unplaced-npcs) 1
>
> [Locations](#locations) 1
>
> [Mellikho Stoneworks](#mellikho-stoneworks) 1
>
> [Gaelkurs Barbershop](#gaelkurs-barbershop) 2
>
> [Allfaiths Shrine](#allfaiths-shrine) 2
>
> [The Swinging Sword Inn](#the-swinging-sword-inn) 2
>
> [Mother Yalanthas Flophouse - unvisited](#mother-yalanthas-flophouse---unvisited) 3
>
> [Haeleeyas bathhouse - unvisted](#haeleeyas-bathhouse---unvisted) 3
>
> [Ironhead Arms](#ironhead-arms) 4
>
> [Bethendurs Storage - Unvisited](#bethendurs-storage---unvisited) 4
>
> [Thelorns Safe Journeys](#thelorns-safe-journeys) 4
>
> [Travel Times](#travel-times) 5

## Unplaced NPCs

Larmon Greenboot - Shepherd

## Locations

### Mellikho Stoneworks

An office for the quarry that is just outside town

**NPC’s**

Albaeri “Ali” Mellikho - Owner

### Gaelkurs Barbershop

This seedy wooden building serves as Red Larch’s

used tools and goods shop, its barber, and an unofficial

second tavern for locals. In addition to providing

Grooming,

**NPC’s**

Marlo Gaelkur - Owner + Barber

| **Service**  | **Cost** |
|--------------|----------|
| Mens haircut | 5cp      |

### Allfaiths Shrine

The Allfaiths Shrine is a wayside shrine used by many

faiths and owned by none. Priests shuttle out from

Waterdeep in pairs for month-long stays. The most

frequent combinations are Sune and Selûne, Tymora

and Lathander, and Tempus and Oghma.

**NPCs**

Idris Relvaunder - Tempus Priest

Sister Garele - Tymora Priestess

Brother Edric - Lathandar Priest

Lydia Alldark - Sune Priestess

### The Swinging Sword Inn

This inn is a three-story stone structure, crowned by a

steep slate roof that bristles with many chimneys. An

inn yard with stables and outbuildings lies behind the

Building. The Swinging Sword is the polite

social hub and neutral meeting ground of Red Larch.

**NPCs**

Kaylessa Irkell - Owner

Aaron Thelder - Stablemaster

Gilly - Maid

| **Service**                                      | **Cost** |
|--------------------------------------------------|----------|
| Single Bed, Board and Meal (per room, per night) | 1gp      |
| Stabling and Feed (per animal, per night)        | 1gp      |

### Mother Yalanthas Flophouse - unvisited

This three-story, dilapidated boarding house has a

cheerful—though generally noisy—atmosphere.

**NPC’s**

Yalantha Dreen - Owner

| **Service**                             | **Cost** |
|-----------------------------------------|----------|
| Single Bed in dorm (per bed, per night) | 3sp      |
| Meals                                   | 2sp      |

### Haeleeyas bathhouse - unvisted

**NPC’s**

Haeleeya Hanadroum - Owner

| **Service**                                                   | **Cost** |
|---------------------------------------------------------------|----------|
| (Half day) Full service bath and laundry (Gossip possibility) | 1gp      |

### Ironhead Arms

**NPC’s**

Feng Ironhead - Honest Merchant

| **Stock**                                    | **Chance** | **Cost** |
|----------------------------------------------|------------|----------|
| Simple melee weapons                         | 100%       | x1       |
| Martial melee weapons                        | 10%        | x0.5     |
| Melee Weapon sharpening (Reroll damage once) | 100%       | 1gp      |

### Bethendurs Storage - Unvisited

A series of large warehouses on the edge of town.

**NPC’s**

Abraham Bethendar - Owner

### 

### Thelorns Safe Journeys

Three huge sheds stand here in a triangle, surrounded

by sturdy wooden wagons at all stages of assembly. The

first is a workshop full of busy woodworkers, the second

is a storage area for parts such as wheels and axles, and

the third houses a dozen finished wagons for sale

**NPC’s**

Thorsk Thelorn - Owner (the short one)

Asdan Thelorn - Owner (the tall one)

## Travel Times

| **Destination**                                                                                      | **Trail type**              | **Distance**      |
|------------------------------------------------------------------------------------------------------|-----------------------------|-------------------|
| [*Westbridge*](https://drive.google.com/open?id=1uCMZbNF4boMkIdK-dfg9E6Af9qM5gSW_nBND_-hUHr0)        | Good road                   | 36 miles          |
| Beliard                                                                                              | Rough road                  | 44 miles          |
| [*Feathergale Spire*](https://drive.google.com/open?id=1Jy45Zdg3mjF0lYeOrT5RIhUInlK8d96xyj9b4ybCsAM) | Rough road / Mountain Trail | 8 miles / 4 miles |
| Ironford                                                                                             | Road                        | 40 miles          |
| Amphail                                                                                              | Good road                   | 52 miles          |
| Mellikho Quarry                                                                                      | Rough road                  | 4 miles           |

[***Red Larch - undiscovered***](https://drive.google.com/open?id=1_trlrcddOiZriYpAMSj-grlLU1YXQo730EJOZ67N8SQ)
