---
title: "What Trisha knows about the Redbrands"
source: "Game Stuff/D&D/What Trisha knows about the Redbrands"
modified: 2018-07-27
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["FDnD campaign (Frankfurt)"]
words: 209
summary: "Short list of what the PC Trisha knows about the Redbrands gang and the Sleeping Giant Taphouse in Phandalin."
tags: ["area/dnd", "project/fdnd-campaign-frankfurt", "type/campaign-prep"]
---

Trisha knows some things about the Redbrands:

- She used to go to the Sleeping Giant Taphouse to get her jobs

- She would enter the Tap House and sit down and wait for a drink to be brought to her

- If she got a meal served to her, there would be a note under it with a task

- The tasks were always very vague

- If she got a drink, that means there are no jobs for her. Drink and go

- When returning, if she finished a job, she would be given a drink with her coin in the beer mug.

About the Sleep Giant Taphouse

- There are generally about 20 people in the taphouse at most times

- Trisha was never sure how many of the people in there actually worked for the Redbrands.

- Sometimes there were people in Dark Red cloaks there, who were obviously Redbrands. Only one or two of them generally are in the SGTH at a time, and they dont hang around outside.

Other things Trisha was told

- She should stay away from the Tresendor Manor, which is on a hill outside town

- Dont steal from houses which have been marked as Protected in Theives Cant
