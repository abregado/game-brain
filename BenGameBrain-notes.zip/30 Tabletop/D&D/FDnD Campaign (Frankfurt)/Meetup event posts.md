---
title: "Meetup event posts"
source: "Game Stuff/Non-Game Ideas/Meetup event posts"
modified: 2022-06-29
type: notes
area: non-game
status: "played/used"
projects: ["[[FDnD Campaign (Frankfurt)]]"]
concepts: ["Game Dev Meetup Frankfurt"]
words: 673
summary: "Draft Discord announcement text and etiquette guidelines for the monthly online Frankfurt game dev meetup, with feedback categories and event links."
tags: ["area/non-game", "project/fdnd-campaign-frankfurt", "type/notes"]
---

Kf

[*https://discord.gg/wNHPzFZV?event=991591484577021962*](https://discord.gg/wNHPzFZV?event=991591484577021962)

Barotrauma

[*https://discord.gg/UvPzYbPB?event=991593706371154013*](https://discord.gg/UvPzYbPB?event=991593706371154013)

https://discord.gg/UvPzYbPB?event=990573801643335770

@everyone

A reminder about tonight's Meetup.

Details

Date: Thursday 23rd

Time: 20:00

Place: ffm-text \#meetup-voice

Language: English

https://discord.gg/wNHPzFZV?event=990570583353880608

This is our regular meetup on the 4th Thursday of each month. Currently the sessions are running online over Discord.

Things that are regularly discussed:

- Personal project updates and demonstrations

- Current happenings in the industry

- Workflow and tool suggestions

- Upcoming game jams and events

- Calls for assistance with projects

- Collaboration ideas

We are a friendly bunch and try to foster an environment where everyone can show their work no matter the state of completion, level of polish, ect.

Meet us on our discord using this link.

https://discord.gg/0i0fL2tJM4qZSplA

Agenda

19:00 arrival, admin announcements and upcoming events

19:15 first presentation

Come and go as you wish

Quick Tips

When entering the voice channel, use the \#ffm-text to say hello.

When you need to leave, and a discussion is ongoing, use \#ffm-text to say goodbye.

If you want to present but can't stay late, just tell the MC and you can go first.

When showing your work:

Be specific about what comments you want to receive, and write it in the text channel in case people arrive during your presentation. Here are the categories I use personally:

Opinion: What you liked or didn't like. Comments on your experience playing. Eg:// I thought it was too red.

Problems: Something you think will cause problems in the future, or caused problems for you. Eg:// Red is a difficult color for many players.

Suggestions: Your idea for solving a problem. Probably state the problem you think needs to be fixed first. Eg:// You should make it more blue.

Or declare a free for all and get whatever you get!

When commenting on someone else's work:

Be civil. Everyone has different tastes and they are most likely different from yours. We are indies afterall!  
Check what kind of feedback the presenter wants, especially if you just dropped in for a minute or two.

Stick to giving requested feedback. We are all designers and love to solve other people's problems, but we are also all designers and like to solve our own problems... sometimes.

We start at 7pm but always wait until 7:15pm before starting. Ill generally check at this point who has projects to show and after going over any admin announcements, we get started with the first presentation. Feel free to come and go over the evening as you wish.

If there is an existing conversation going on, or you are joining while someone is demonstrating, use the text channel so say Hello.

No need to wait until there is a break in the conversation. You can say goodbye in the text chat if you are in a hurry. Nobody will get offended if you just disappear.

When showing your work:

Be specific about what comments you want to receive, and write it in the text channel in case people arrive during your presentation.

Opinion: What you liked or didn't like. Comments on your experience playing. Eg:// I thought it was too red.

Problems: Something you think will cause problems in the future, or caused problems for you. Eg:// Red is a difficult color for many players.

Suggestions: Your idea for solving a problem. Probably state the problem you think needs to be fixed first. Eg:// You should make it more blue.

Don't feel obligated to present something, or to answer a question. You can stop presenting or taking comments at any time. Just say you are done and we will move on.

When commenting on someone elses work:

Be civil. Everyone has different tastes and they are most likely different from yours. We are indies afterall!

Check what kind of feedback the presenter wants, especially if you just dropped in for a second.

Stick to the type of feedback asked for by the presenter. We are all designers and love to solve other peoples problems, but we are also all designers and like to solve our own problems... sometimes.
