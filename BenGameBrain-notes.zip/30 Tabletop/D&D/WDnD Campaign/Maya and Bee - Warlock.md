---
title: "Maya and Bee - Warlock"
source: "Game Stuff/D&D/WDnD Files/Maya and Bee - Warlock"
modified: 2024-10-06
type: character
area: dnd
status: "unknown"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D characters"]
words: 3290
summary: "Character sheet for Maya, a Felchild (forest gnome-like) Chain-pact warlock with her bee familiar, including racial traits, patron features, spellcasting and inventory."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

## Maya (and Bee)

**Felchild (Forest Gnome) Warlock / Fellost (Feylost) - Chaotic Good**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 14      | 12      | 10      | 14      | 17      |
| -1      | +2      | +1      | 0       | +2      | +3      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 13     | 21     | 3d8    | 25       | 4        | 8   |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +2      | +1      | 0       | +4      | +5      |

### Proficiencies (+2 bonus):

**Deception (Charisma) +5**

**Survival (Wisdom) +4**

**Investigation (Intelligence) +2**

**Nature (Intelligence) +2**

**Instrument (Ocarina) +2**

**Light Armor**

**Simple Weapons**

### Languages:

**Common, Sylvan, Elvish**

## Personality

### Traits

I live by my own set of weird and wonderful rules.

### Ideal

Changeability. Change is good, which is why I live by an ever-changing set of rules.

### Bond

Bee accompanies me everywhere. He is my most trusted friend.

### Flaw

I'm forgetful. Sometimes I can't remember even the simplest things.

## Background

### Shadowfell Connection

Your mannerisms and knowledge of fel customs are recognized by natives of the Shadowfell, who see you as one of their own. Because of this, friendly Fel creatures are inclined to come to your aid if you are lost or need help in the Shadowfell.

### Fel Mark

Maya has pale skin and hair but her eyes are very dark. At night her eyes glow bright green.

### Shadowfell Visitor

Whenever you're sound asleep or in a deep trance during a long rest, a spirit of the Shadowfell might pay you a visit, if the DM wishes it. Determine the spirit's form by rolling on the Shadowfell Visitor table. No harm ever comes to you as a result of such visits, which can last for minutes or hours, and you remember each visit when you wake up. Conversations that occur with a visitor can contain any number of things, from messages and insights to nonsense and red herrings, at the DM's discretion. Such conversations are always conducted in a language you can understand, even if the Shadowfell visitor can't speak that language normally.

| **D8** | **Visitor**                                                                          |
|--------|--------------------------------------------------------------------------------------|
| 1      | Awakened creature (a normal beast or plant that has had the Awaken spell cast on it) |
| 2      | Berbalang                                                                            |
| 3      | Deadwood Dryad                                                                       |
| 4      | Gibbering Mouther                                                                    |
| 5      | Giant Frog                                                                           |
| 6      | Abyssal Wretch                                                                       |
| 7      | Displacer Beast Kitten                                                               |
| 8      | Night Hag                                                                            |

## 

##  

## Racial

### Size

Felchildren are between 3 and 4 feet tall and average about 40 pounds. Your size is Small.

### Darkvision

You have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray.

### Shadow Cunning

You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic.

### Natural Illusionist

You know the minor illusion cantrip. Intelligence is your spellcasting ability for it.

### Speak with Small Beasts

Through sounds and gestures, you can communicate simple ideas with Small or smaller beasts. Fel children love animals and often keep squirrels, badgers, rabbits, moles, woodpeckers, and other creatures as beloved pets.

## Patron

### Form of Dread

You manifest an aspect of your patron's dreadful power. As a bonus action, you transform for 1 minute.

You gain the following benefits while transformed:

- You gain temporary hit points equal to 1d10 + your warlock level.

- Once during each of your turns, when you hit a creature with an attack roll, you can force it to make a Wisdom saving throw, and if the saving throw fails, the target is frightened of you until the end of your next turn.

- You are immune to the frightened condition.

You can transform a number of times equal to your proficiency bonus, and you regain all expended uses when you finish a long rest.

The appearance of your Form of Dread reflects some aspect of your patron. For example, your form could be a shroud of shadows forming the crown and robes of your lich patron, or your body might glow with glyphs from ancient funerary rites and be surrounded by desert winds, suggesting your mummy patron.

## Class

### Pact of the Chain

You learn the find familiar spell and can cast it as a ritual. The spell doesn't count against your number of spells known.

The form of your familiar is a bee. Its stat block is of an Imp.

Additionally, when you take the Attack action, you can forgo one of your own attacks to allow your familiar to use its reaction to make one attack of its own.

### Familiar

While the imp is within 10 feet of its master, the master shares the imp's Magic Resistance trait.

### Gift of the Ever-Living Ones

Whenever you regain hit points while your familiar is within 100 feet of you, treat any dice rolled to determine the hit points you regain as having rolled their maximum value for you.

### Investment of the Chain Master

When you cast find familiar, you infuse the summoned familiar with a measure of your eldritch power, granting the creature the following benefits:

- The familiar gains either a flying speed or a swimming speed (your choice) of 40 feet.

- As a bonus action, you can command the familiar to take the Attack action.

- The familiar's weapon attacks are considered magical for the purpose of overcoming immunity and resistance to non magical attacks.

- If the familiar forces a creature to make a saving throw, it uses your spell save DC.

- When the familiar takes damage, you can use your reaction to grant it resistance against that damage.

##  

## Spellcasting

### Magical Cunning

You can perform an esoteric rite for 1 minute. At the end of it, you regain expended Pact Magic spell slots but no more than a number equal to half your maximum (round up). Once you use this feature, you can't do so again until you finish a Long Rest.

| **Spell Attack** | **Spell Save DC** |
|------------------|-------------------|
| +5               | 13                |



### Bane

1st-level enchantment

Casting Time: **1 action**

Range: **30 feet**

Components: **V, S, M** (a drop of blood)

Duration: **Concentration, up to 1 minute**

Up to three creatures of your choice that you can see within range must make Charisma saving throws. Whenever a target that fails this saving throw makes an attack roll or a saving throw before the spell ends, the target must roll a d4 and subtract the number rolled from the attack roll or saving throw.

When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.

### False Life

1st-level necromancy

Casting Time: **1 action**

Range: **Self**

Components: **V, S, M** (a small amount of alcohol or distilled spirits)

Duration: **1 hour**

Bolstering yourself with a necromantic facsimile of life, you gain 1d4 + 4 temporary hit points for the duration.

When you cast this spell using a spell slot of 2nd level or higher, you gain 5 additional temporary hit points for each slot level above 1st.

### 

###  

### Eldritch Blast

Evocation cantrip

Casting Time: **1 action**

Range: **120 feet**

Components: **V, S**

Duration: **Instantaneous**

A beam of crackling energy streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 force damage.

The spell creates more than one beam when you reach higher levels: two beams at 5th level, three beams at 11th level, and four beams at 17th level. You can direct the beams at the same target or at different ones. Make a separate attack roll for each beam.

### Blindness/Deafness

2nd-level necromancy

Casting Time: **1 action**

Range: **30 feet**

Components: **V**

Duration: **1 minute**

You can blind or deafen a foe. Choose one creature that you can see within range to make a Constitution saving throw. If it fails, the target is either blinded or deafened (your choice) for the duration. At the end of each of its turns, the target can make a Constitution saving throw. On a success, the spell ends.

When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.

### Hellish Rebuke

1st-level evocation

Casting Time: **1 reaction**, which you take in response to being damaged by a creature within 60 feet of you that you can see

Range: **60 feet**

Components: **V, S**

Duration: **Instantaneous**

You point your finger, and the creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw. It takes 2d10 fire damage on a failed save, or half as much damage on a successful one.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.

###  

### Mind Spike

2nd-level divination

Casting Time: **1 action**

Range: **60 feet**

Components: **S**

Duration: **Concentration, up to 1 hour**

You reach into the mind of one creature you can see within range. The target must make a Wisdom saving throw, taking 3d8 psychic damage on a failed save, or half as much damage on a successful one. On a failed save, you also always know the target's location until the spell ends, but only while the two of you are on the same plane of existence. While you have this knowledge, the target can't become hidden from you, and if it's invisible, it gains no benefit from that condition against you.

When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd.

### Prestidigitation

Transmutation cantrip

Casting Time: **1 action**

Range: **10 feet**

Components: **V, S**

Duration: **Up to 1 hour**

This spell is a minor magical trick that novice spellcasters use for practice. You create one of the following magical effects within range:

- You create an instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.

- You instantaneously light or snuff out a candle, a torch, or a small campfire.

- You instantaneously clean or soil an object no larger than 1 cubic foot.

- You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.

- You make a color, a small mark, or a symbol appear on an object or a surface for 1 hour.

- You create a non magical trinket or an illusory image that can fit in your hand and that lasts until the end of your next turn.

If you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action.

### 

###  

### Minor Illusion

Illusion cantrip

Casting Time: **1 action**

Range: **30 feet**

Components: **S, M** (a bit of fleece)

Duration: **1 minute**

You create a sound or an image of an object within range that lasts for the duration. The illusion also ends if you dismiss it as an action or cast this spell again.

If you create a sound, its volume can range from a whisper to a scream. It can be your voice, someone else's voice, a lion's roar, a beating of drums, or any other sound you choose. The sound continues unabated throughout the duration, or you can make discrete sounds at different times before the spell ends.

If you create an image of an object—such as a chair, muddy footprints, or a small chest—it must be no larger than a 5-foot cube. The image can't create sound, light, smell, or any other sensory effect. Physical interaction with the image reveals it to be an illusion, because things can pass through it.

If a creature uses its action to examine the sound or image, the creature can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the illusion becomes faint to the creature.

### Arms of Hadar

1st-level conjuration

Casting Time: **1 action**

Range: **Self (10-foot radius)**

Components: **V, S**

Duration: **Instantaneous**

You invoke the power of Hadar, the Dark Hunger. Tendrils of dark energy erupt from you and batter all creatures within 10 feet of you. Each creature in that area must make a Strength saving throw. On a failed save, a target takes 2d6 necrotic damage and can't take reactions until its next turn. On a successful save, the creature takes half damage, but suffers no other effect.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.

### Suggestion

2nd-level enchantment

Casting Time: **1 action**

Range: **30 feet**

Components: **V, M** (a snake's tongue and either a bit of honeycomb or a drop of sweet oil)

Duration: **Concentration, up to 8 hours**

You suggest a course of activity (limited to a sentence or two) and magically influence a creature you can see within range that can hear and understand you. Creatures that can't be charmed are immune to this effect. The suggestion must be worded in such a manner as to make the course of action sound reasonable. Asking the creature to stab itself, throw itself onto a spear, immolate itself, or do some other obviously harmful act ends the spell.

The target must make a Wisdom saving throw. On a failed save, it pursues the course of action you described to the best of its ability. The suggested course of action can continue for the entire duration. If the suggested activity can be completed in a shorter time, the spell ends when the subject finishes what it was asked to do.

You can also specify conditions that will trigger a special activity during the duration. For example, you might suggest that a knight give her warhorse to the first beggar she meets. If the condition isn't met before the spell expires, the activity isn't performed.

If you or any of your companions damage the target, the spell ends.

### Phantasmal Force

2nd-level illusion

Casting Time: **1 action**

Range: **60 feet**

Components: **V, S, M** (a bit of fleece)

Duration: **Concentration, up to 1 minute**

You craft an illusion that takes root in the mind of a creature that you can see within range. The target must make an Intelligence saving throw. On a failed save, you create a phantasmal object, creature, or other visible phenomenon of your choice that is no larger than a 10-foot cube and that is perceivable only to the target for the duration. This spell has no effect on undead or constructs.

The phantasm includes sound, temperature, and other stimuli, also evident only to the creature.

The target can use its action to examine the phantasm with an Intelligence (Investigation) check against your spell save DC. If the check succeeds, the target realizes that the phantasm is an illusion, and the spell ends.

While a target is affected by the spell, the target treats the phantasm as if it were real. The target rationalizes any illogical outcomes from interacting with the phantasm. For example, a target attempting to walk across a phantasmal bridge that spans a chasm falls once it steps onto the bridge. If the target survives the fall, it still believes that the bridge exists and comes up with some other explanation for its fall—it was pushed, it slipped, or a strong wind might have knocked it off.

An affected target is so convinced of the phantasm's reality that it can even take damage from the illusion. A phantasm created to appear as a creature can attack the target. Similarly, a phantasm created to appear as fire, a pool of acid, or lava can burn the target. Each round on your turn, the phantasm can deal 1d6 psychic damage to the target if it is in the phantasm's area or within 5 feet of the phantasm, provided that the illusion is of a creature or hazard that could logically deal damage, such as by attacking. The target perceives the damage as a type appropriate to the illusion.

### Find Familiar

1st-level conjuration (ritual)

Casting Time: **1 hour**

Range: **10 feet**

Components: **V, S, M** (10 gp worth of charcoal, incense, and herbs that must be consumed by fire in a brass brazier)

Duration: **Instantaneous**

You gain the service of a familiar, a spirit that takes an animal form of a bee. Appearing in an unoccupied space within range, the familiar has the statistics of an imp, though it is a celestial, fey, or fiend (your choice) instead of a beast.

Additional animal form choices may be available at the DM's discretion.

Your familiar acts independently of you, but it always obeys your commands. In combat, it rolls its own initiative and acts on its own turn. A familiar can't attack, but it can take other actions as normal.

When the familiar drops to 0 hit points, it disappears, leaving behind no physical form. It reappears after you cast this spell again. As an action, you can temporarily dismiss the familiar to a pocket dimension. Alternatively, you can dismiss it forever. As an action while it is temporarily dismissed, you can cause it to reappear in any unoccupied space within 30 feet of you. Whenever the familiar drops to 0 hit points or disappears into the pocket dimension, it leaves behind in its space anything it was wearing or carrying.

While your familiar is within 100 feet of you, you can communicate with it telepathically. Additionally, as an action, you can see through your familiar's eyes and hear what it hears until the start of your next turn, gaining the benefits of any special senses that the familiar has. During this time, you are deaf and blind with regard to your own senses.

You can't have more than one familiar at a time. If you cast this spell while you already have a familiar, you instead cause it to adopt a new form. Choose one of the forms from the above list. Your familiar transforms into the chosen creature.

Finally, when you cast a spell with a range of touch, your familiar can deliver the spell as if it had cast the spell. Your familiar must be within 100 feet of you, and it must use its reaction to deliver the spell when you cast it. If the spell requires an attack roll, you use your attack modifier for the roll.

## Inventory

### Darts x3

1d4 piercing, finesse, thrown 20/60ft, improvised melee attacks

### Leather armor

AC 11 + Dex mod

### Gold Pouch

7gp

50cp

3sp

Several colorful buttons

### Backpack

Filled with dolls and toys

A pillow and blankie

### Arcane Focus

Cookie cutter that Maya's mum used to use. Kept on a chain around neck.

### Misc

Traveling clothes

Instrument (Ocarina)

Piece of orange parchment folded to look like a knight astride a unicorn

Spool of glistening silver thread

Opalescent conch shell that laughs when you hold it to your ear
