---
title: "WDnD - Tyon the Squire"
source: "Game Stuff/D&D/WDnD - Tyon the Squire"
modified: 2020-02-12
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D characters"]
words: 564
summary: "Pregenerated NPC/PC sheet for Tyon, human squire to Lady Sildar Hallwinter, with stats, personality, plot hooks (ambush, Gundren) and options for how the party meets him."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

# Tyon

**Human Squire - Neutral Good**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 12      | 10      | 10      | 10      | 11      | 12      |
| +1      | +0      | +0      | +0      | +1      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 12/14  | 10     | 1d10   | 30       | 6        | 12  |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +2      | +0      | +0      | +0      | +2      |

### Proficiencies:

**Short Sword, Shield, Light Armor**

**Athletics (Strength) +3**

**Medicine (Wisdom) +3**

**Survival (Wisdom) +3**

### Languages

**Common**

### 

Personality

### Traits

You try too hard to impress when meeting new people.

### Ideal

I will be a knight one day.

### Bond

I owe everything to Sildar Hallwinter my mentor and hope one day to impress her.

### Flaw

You brag about about amazing your mentor, Lady Hallwinter when she is not around. If she caught you doing it, you would be beaten, and you know you would deserve it.

# Equipment

Shortsword: +3 to hit, D6+1 slashing damage.

Shield: +2 to Armor Class when wielded.

#  

# Plot Devices and Intel

### Lady Hallwinter

You are a squire to the knighted Lady Sildar Hallwinter. She is from a proud family of nobles and a member of the Lords Alliance. She did not disclose the purpose of her mission to Phandalin, but it has something to do with a missing friend.

Lady Hallwinter was a veteren in many battles, but now that she is older (70+ yrs), her fighting capabilities are beginning to wane. She prefers diplomatic missions, but is certainly not afraid of a fight.

She is a friendly woman, but knows her station. She is harsh, but never violent with servants or peasants if they make mistakes. She has only beaten you when you made server mistakes. Generally she is an image of a good noble and cares for the common people.

### Gundren Rockseeker

A dwarven prospector, who was friends with Lady Hallwinters parents when they were young. The Lady seems to trust him as a grandparent or maybe great uncle. Often during the 4 day trip from Neverwinter, you were told to ride ahead while they talked in low voices. Gundren has secrets, but you are well trained and never evesdrop or ask questions.

### Current Mission

You were the travelling with your mentor Lady Hallwinter and the dwarven prospector Gundren Rockseeker. At some stage of the journey Sildar asked for an item from the saddlebags and you realised you had dropped it on the road. You back tracked to find it, but when you tried to catch up, you discovered the ambush.

### Ambush Site

Some goblins must have ambushed and captured Lady Hallwinter and Mr Rockseeker. You found their horses dead and followed the goblin trail into the forest.

### The players find you (option 1)

The Heroes will find you lost in the woods looking for the goblin hideout.

### You go looking for help (option 2)

You show up in town to find heroes to help. If they decide to do something else, you offer to help them, in exchange for them helping to find your mentor.
