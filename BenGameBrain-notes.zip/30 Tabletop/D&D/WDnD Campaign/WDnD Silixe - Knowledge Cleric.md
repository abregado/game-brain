---
title: "WDnD Silixe - Knowledge Cleric"
source: "Game Stuff/D&D/WDnD Files/WDnD Silixe - Knowledge Cleric"
modified: 2020-04-14
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 867
summary: "Knowledge Cleric sheet for Silixe with a custom attuned item (Stone of Enervation) and motivation to secure the lost Spellforge."
contains_external_material: "SRD class text"
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

# Silixe

**Human Knowledge Cleric / Cloistered Scholar**

**Lawful Neutral**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 14      | 11      | 13      | 15      | 16      | 9       |
| +2      | +0      | +1      | +2      | +3      | -1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 16     | 9      | 1d8    | 30       | 7        | 14  |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +2      | +0      | +1      | +2      | +5      | +1      |

### Proficiencies (+2 bonus):

**Sleight of Hand, Nature, Arcana\*, History\*, Religion, Insight**

**Light, Medium Armor**

**Shields**

**Simple Weapons**

### Languages

**Common, Gnomish, Elvish, Invernal**

### LIBRARY ACCESS

Though others must often endure extensive interviews and significant fees to gain access to even the most common archives in your library, you have free and easy access to the majority of the library, though it might also have repositories of lore that are too valuable, magical, or secret to permit anyone immediate access. You have a working knowledge of your cloister's personnel and bureaucracy, and you know how to navigate those connections with some ease. Additionally, you are likely to gain preferential treatment at other libraries across the Realms, as professional courtesy shown to a fellow scholar.

### Subtle Interaction

You have advantage on Sleight of Hand checks to move or conceal an object that you are holding that is small enough to fit in the palm of your hand.

Personality

### Traits

Ohgma is the best god

### Ideal

Free Thinking

### Bond

I owe my temple a great debt

### Flaw

Jealous

# Feats and Abilities

### Blessing of Knowledge

At 1st level, you learn two languages, and become proficient in two of the following: Arcana, History, Nature, or Religion. Your proficiency bonus is doubled for any check you make with either skill

# Holy Magic

### Cantrips

At 1st level, you know three cantrips of your choice from the cleric spell list. You learn more cleric cantrips at higher levels, as shown in the Cleric table.

### Preparing And Casting Spells

The Cleric table shows how many spell slots you have of 1st level and higher. Casting spells expends a slot of the spell’s level or higher. You regain all spell slots when you take a long rest.You prepare a list of cleric spells that are available for you to cast, choosing from all cleric spells. When you do, choose a number of cleric spells equal to your Wisdom modifier + your cleric level (min 1). The spells must be of a level for which you have spell slots. Casting the spell doesn’t remove it from your list of prepared spells.You can change your prepared spells when you finish a long rest. Changing spells requires time: at least 1 minute per spell level for each spell on your list

# 

#  

# Inventory

### Holy Symbol

+2 AC when held

Needed for your spells

### Mace

Simple weapon

Melee Attack bonus: Strength + Proficiency

Damage: D6 + Strength (Bludgeoning)

### Scale Mail

Heavy armor, full body

Armor Class: 16

While wearing:

Disadvantage on Stealth checks

Can’t swim

Can’t long rest

# Stone of Enervation

**Small held object - Transmutation magic**

**Attunement required by Silixe**

Starts with zero tokens.

**Action:** Choose an open, non-magical flame within 60 feet. The flame is extinguished but explodes in a bright display before going out. Each creature within 10 feet of the target must pass a DC 15 Constitution saving throw or become blinded until the end of your next turn.

Each time the stone is used, it also heats up. When you use the stone, suffer 1D6 fire damage for each token the stone has, then add a number of tokens as directed by the GM.

**During a long rest:** you may remove one token from the stone, or add one by placing it in a fire.

# 

#  

# Plot Devices and Intel

### History of Phandalin

The town of Phandalin has been rebuilt on the same ground several times over the last 1000 years. Originally it was a support settlement for a series of mines in the Sword mountains nearby. These mines were worked by dwarves, and powerful human wizards and gnomish artificers operated a Spellforge.

### The Lost Spellforge found?

The mines of Phandelver and the Spellforge were lost when orcs raided the entire Sword mountains area 500 years ago. Since then nobody has risked building a settlement so far from a large city. Rumors around the city indicate that someone might have uncovered an entrance.

### Your Holy Appointment

The wealth of knowledge that was stored in the Spellforge library must have been immense. There may also be clues as to why the gnomish civilization collapsed. If, Oghma willing, the Spellforge is still intact, it cannot be allowed to fall into private hands.

Find out what you can. By the Binders Eyes, learn what you can, and do everything in your power, short of killing someone, to stop the Spellforge from falling into the wrong hands.
