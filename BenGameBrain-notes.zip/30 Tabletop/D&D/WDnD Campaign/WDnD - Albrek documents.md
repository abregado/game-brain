---
title: "WDnD - Albrek documents"
source: "Game Stuff/D&D/WDnD_ Albrek documents"
modified: 2020-02-12
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]"]
concepts: ["WDnD campaign", "Lost Mine Plot Letters"]
words: 309
summary: "In-world handout letters between the Black Spider, Iarno Albrek and Sildar, adapted from the Lost Mine of Phandelver module."
contains_external_material: "Letter content closely based on published module text"
tags: ["area/dnd", "project/wdnd-campaign", "type/campaign-prep"]
---

> Lord Albrek,
>
> I have arranged for the items you requested. Consider this ample payment, and do not forget why you are in Phandalin.
>
> These distractions had better not cost me your dedication to our plans. Make sure Phandalin is no place for adventurers.
>
> \[Signed with the symbol of a spider\]
>
> Lord Albrek,
>
> My spies in Neverwinter tell me that strangers are due to arrive in Phandalin. They could be working for the dwarves. Capture them if you can, kill them if you must, but dont allow them to upset our plans. See that any dwarven maps in their possession are delivered to me with haste.
>
> Im counting on you, Iarno. Don’t disappoint me like you did the Lords Alliance.
>
> \[Signed with the symbol of a spider\]
>
> Lord Albrek,
>
> To assist with the trouble you are having controlling your men, I’ve had our associate send you three of his companions. I trust that these brutes will be sufficient to force the Redbrands obedience.
>
> Keep your men in line. They are causing too much trouble in the town.
>
> \[Signed with the symbol of a spider\]
>
> Sildar,
>
> My new assignment is not going so well. I am writing to ask for you... \[letter is not finished\]
>
> Lord Hallwinter,
>
> Your presence is required in the town of Phandalin. Please arrive with expediency.
>
> Your college
>
> Iarno Albrek
>
> Lord Albrek,
>
> The Alliance feels it would be in your best interests to expand your experiences. After your less than perfect performance during your last assignment here in Neverwinter, you are being sent to the frontier town of Phandalin. Take over... \[the letter has been torn into pieces\]
