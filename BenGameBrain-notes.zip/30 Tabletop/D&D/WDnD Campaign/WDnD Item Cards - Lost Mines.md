---
title: "WDnD Item Cards - Lost Mines"
source: "Game Stuff/D&D/WDnD Item Cards - Lost Mines"
modified: 2020-06-01
type: template
area: dnd
status: "unknown"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 808
summary: "Practically empty; the conversion produced only table placeholders, presumably item card layouts for Lost Mines."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/template"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="aspect-of-the-plane">Aspect of the Plane</h2>
<p><strong>Small Belt, requires attunement</strong></p></th>
<th><h2 id="goggles-of-night">Goggles of Night</h2>
<p><strong>Small Item, requires attunement</strong></p></th>
</tr>
<tr class="odd">
<th><p>Usable by Druid, Barbarian or Nature Cleric</p>
<p>1 Charge, recharge 1D4 on a long rest. Abilities only function on the Material plane.</p>
<ul>
<li><p><strong>Action:</strong> cast the Mold Earth cantrip<br />
<strong>Action:</strong> You may also expend one charge to cast Maximilian's Earthen Grasp (DC 18).</p></li>
<li><p><strong>Action:</strong> You may expend one charge to cast Plant Growth.</p></li>
<li><p><strong>Action:</strong> cast the Control Flames cantrip<br />
<strong>Action:</strong> You may expend one charge to cast Heat Metal (lvl 3)</p></li>
<li><p><strong>Action:</strong> You may expend a charge to Wildshape. This shape is determined by the DM at the time of use, based on which plane of existence you are currently on and your current level.</p></li>
<li><p><strong>Passive:</strong> The maximum charges of this item increases to 3.</p></li>
</ul></th>
<th><p>Usable by any class/race - Divination</p>
<p>3 Charges, cannot be recharged.</p>
<p>When you attune to the Goggles of Night, select two of the options below, which become available to you.</p>
<ul>
<li><p><strong>Action:</strong> spend a Charge to gain Darkvision out to 60ft for 1 hour.</p></li>
<li><p><strong>Action:</strong> spend a Charge to gain Blindsight out to 60ft for 5 minutes.</p></li>
<li><p><strong>Action:</strong> spend a Charge to gain Truesight out to 60ft for 1 minute.</p></li>
<li><p><strong>Action:</strong> spend a Charge to cast Detect Magic, which lasts 10 minutes and does not require Concentration.</p></li>
<li><p><strong>Passive:</strong> The duration of this item's effects is doubled.</p></li>
</ul></th>
</tr>
<tr class="header">
<th><h3 id="forgotten-artifact">Forgotten Artifact</h3></th>
<th><h3 id="forgotten-artifact-1">Forgotten Artifact</h3></th>
</tr>
<tr class="odd">
<th><h2 id="gauntlets-of-ogre-power">Gauntlets of Ogre Power</h2>
<p><strong>Medium Gloves, requires attunement</strong></p></th>
<th><h2 id="staff-of-defense">Staff of Defense</h2>
<p><strong>Medium Quarterstaff, requires attunement</strong></p></th>
</tr>
<tr class="header">
<th><p>Usable by Fighter, Barbarian, Monk</p>
<p>1 Charge. Recharges fully during a long rest.</p>
<p><strong>Passive:</strong> Your Strength ability score cannot be reduced by any effect, magical or otherwise.</p>
<p><strong>Passive:</strong> While under any of the effects listed below, your passive perception and Intelligence drops to 8, and you can speak Giant. The effects cannot be ended early.</p>
<p><strong>Action:</strong> Expend a charge. For the next minute your weight increases eight fold, and you gain advantage on Strength checks and Strength saving throws. Your melee attacks cause an additional d4 damage.</p>
<p><strong>Action:</strong> Expend a charge.Gain Darkvision out to 60ft for 1 hour.</p>
<p><strong>Action:</strong> Expend a charge. For the next hour, you are immune to the Frightened condition.</p></th>
<th><p>Usable by any class</p>
<p>Has ten charges. If the last charge is expended, roll a D6. On a 1 the staff crumbles to dust.</p>
<ul>
<li><p><strong>Passive:</strong> You gain +1 to your Armor class when wielding this weapon.</p></li>
<li><p><strong>As a reaction when you are hit:</strong> Expend two charges to cast Shield.</p></li>
<li><p><strong>Action:</strong> Expend one charge to cast Mage Armor.</p></li>
<li><p><strong>Action:</strong> Expend two charges to cast Blur.</p></li>
<li><p><strong>Ritual once per day:</strong> Use 25gp of magical reagents to recharge D6 charges.</p></li>
</ul></th>
</tr>
<tr class="odd">
<th><h3 id="forgotten-artifact-2">Forgotten Artifact</h3></th>
<th><h3 id="forgotten-artifact-3">Forgotten Artifact</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h2 id="orb-of-repose">Orb of Repose</h2>
<p><strong>Small Item</strong></p></th>
<th><h2 id="talonstrike">Talonstrike</h2>
<p><strong>Longsword, requires attunement</strong></p></th>
</tr>
<tr class="odd">
<th><p>Usable by any class.</p>
<p>Three charges.</p>
<p><strong>As a Ritual:</strong> You preserve the body of any creature which died within the last 10 minutes. The ritual involves placing the orb in the mouth of the target and leaving it there. For the purposes of resurrection magic, the target is considered to have died only moments ago. The effect lasts for 10 days.</p>
<p></p></th>
<th><p>Martial weapon: d8 slashing damage, d10 when wielded in two hands.</p>
<p>Attunement by any character of Good Alignment</p>
<ul>
<li><blockquote>
<p><strong>As a free action:</strong> Summon this sword to your hand. You may stow one item to free up a hand to hold it.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Passive:</strong> +1 to attack and damage rolls made with this weapon. Attacks count as magical.</p>
</blockquote></li>
<li><blockquote>
<p><strong>As a reaction when you are hit:</strong> Force the attacker to reroll their attack.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Bonus Action:</strong> The sword gains the Thrown (10/30) and Finesse traits for the next minute.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Passive:</strong> When wielded in two hands, add D6 to your attack rolls (not damage).</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="header">
<th><h3 id="relic-300gp-30gp">Relic (300gp / 30gp)</h3></th>
<th><h3 id="forgotten-artifact-4">Forgotten Artifact</h3></th>
</tr>
<tr class="odd">
<th><h2 id="lightbringer">Lightbringer</h2>
<p><strong>Mace, requires attunement</strong></p></th>
<th><h2 id="staff-of-defense-1">Staff of Defense</h2>
<p><strong>Medium Quarterstaff, requires attunement</strong></p></th>
</tr>
<tr class="header">
<th><p>Simple weapon: d6 Bludgeoning damage</p>
<p>Requires attunement by Cleric, Fighter, Paladin or Ranger</p>
<ul>
<li><blockquote>
<p><strong>Passive:</strong> +1 to attack and damage rolls. The weapon causes Radiant Damage or Bludgeoning damage, at the user's discretion.</p>
</blockquote></li>
<li><blockquote>
<p><strong>As an action:</strong> You may cast the Daylight spell once per day without using a spell slot.</p>
</blockquote></li>
<li><blockquote>
<p><strong>As a bonus action:</strong> You may cast the Sanctuary spell once per day without using a spell slot or spending materials.</p>
</blockquote></li>
<li><blockquote>
<p><strong>When you hit an undead creature:</strong> Undead with Challenge rating lower than half the users level, which are struck with the item, must pass a Wisdom saving throw of DC 10 or be Stunned.</p>
</blockquote></li>
</ul></th>
<th><p>Usable by any class</p>
<p>Has ten charges. If the last charge is expended, roll a D6. On a 1 the staff crumbles to dust.</p>
<ul>
<li><blockquote>
<p><strong>Passive:</strong> You gain +1 to your Armor class when wielding this weapon.</p>
</blockquote></li>
<li><blockquote>
<p><strong>As a reaction when you are hit:</strong> Expend two charges to cast Shield.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Action:</strong> Expend one charge to cast Mage Armor.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Action:</strong> Expend two charges to cast Blur.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Ritual once per day:</strong> Use 25gp of magical reagents to recharge D6 charges.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="odd">
<th><h3 id="forgotten-artifact-5">Forgotten Artifact</h3></th>
<th><h3 id="forgotten-artifact-6">Forgotten Artifact</h3></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
