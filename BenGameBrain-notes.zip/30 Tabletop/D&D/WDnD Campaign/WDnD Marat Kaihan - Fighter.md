---
title: "WDnD Marat Kaihan - Fighter"
source: "Game Stuff/D&D/WDnD Files/WDnD Marat Kaihan - Fighter"
modified: 2024-04-28
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 1920
summary: "Level 9 Psi Warrior fighter sheet for Marat with detailed magic item inventory, including retired, used and destroyed items (cursed Ironfang)."
contains_external_material: "Some item and feature text from 5e sources / item generator"
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

## Marat Kaihan

**Human Fighter / Guild Merchant - Neutral Good**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 16      | 10      | 15      | 16      | 14      | 11      |
| +3      | +0      | +2      | +3      | +2      | +0      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 20     | 69     | 9D10   | 30       | 8        | 16  |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +6      | +0      | +5      | +3      | +2      | +0      |

### Proficiencies (+4 bonus):

**Insight (Wisdom) +6**

**Perception (Wisdom) +6**

**Persuasion (Charisma) +4**

**Intimidation (Charisma) +4**

**History (Intelligence) +7**

**Navigators Tools (Intelligence) +7**

**Land Vehicles (Dexterity) +4**

**All Armor and Shields**

**Simple and Martial Weapons (Strength) +7**

**Finesse weapons (Dexterity) +4**

**All Ranged weapons (Dexterity) +4**

### Languages:

**Common, Undercommon**

## Personality

### Traits

I'm slow to notice etiquette and social expectations of new people.

I've lost too many friends, so I'm anxious to make new ones.

### Ideal

Sincerity. There's no good in pretending to be something you are not.

### Bond

Those who doubted me will hear songs of my achievements and know they were wrong.

### Flaw

I put too much trust in those who wield power.

## Psi Warrior

### Great Weapon Fighting

When you roll a 1 or 2 on a damage die for attacks made with two handed weapons, you can reroll that die, and must use the new roll.

### Second Wind

**Bonus action:** Regain 1d10 + your fighter level hitpoints. You must finish a short or long rest before using this feature again.

### Action Surge

On your turn, you can take one additional action on top of your regular action and a possible bonus action.

You must finish a short or long rest before using this feature again.

### Extra Attack

You can attack twice, instead of once, whenever you take the Attack action on your turn.

### Indomitable

Beginning at 9th level, you can reroll a saving throw that you fail. If you do so, you must use the new roll, and you can't use this feature again until you finish a long rest.

### Telekinetic Shove

Extra psi ability (with Level 7)

**Bonus action**: Expend a Psionic Energy die and choose a friendly creature you can see within 30 feet of you. That creature can move up to half its speed without provoking opportunity attacks.

### Feat: Tower of Iron Will

[*Your mind's defenses are formidable.*](https://5e.tools/feats.html#tower%20of%20iron%20will_ua2020psionicoptionsrevisited) After you or another creature you can see within 30 feet of you fails a saving throw, you can use your **reaction** to expend one Psionic Energy die, roll the die and add the number rolled to the saving throw, potentially causing it to succeed.

##  

## Inventory

### Barb of the Blind (Dagger)

**Dagger - Divination magic**

Simple weapon, Finesse, Light, Thrown (20/60), Piercing (d4)

**Passive:** Weapon counts as magical. Targets wounded by this weapon must make a DC 15 Wisdom saving throw or be affected by the following condition for 1 hour.

**Spiritmarked (Condition).** The locations of the targets suffering from this condition are known to you, they cannot become hidden from you and if invisible, gain no benefit from that condition from you. If you are blinded, you can still see affected targets as if you were not. If you are Deafened, you can still hear affected targets as if you were not.

### Farfetched (Silver Handaxe)

Melee/Ranged Attack bonus: d20 + Strength + Proficiency + 1

Damage: D6 + Strength (Slashing) + d4 radiant or necrotic dmg (you can change it after a long rest)

Range: 20ft/60ft (with disadvantage)

Thrown weapon

**Free action:** The weapon teleports to your free hand if it was located within 100 feet from you. (“recall”)

When I recall the axe, I can instead teleport to the location of the axe. This teleport costs a **bonus action**. (I must be able to see the axe)

### Sol (Hammer) (Worth 10k gold)

[*Sanctuary*](https://www.dnd-spells.com/spell/sanctuary) (once per day, target myself) (missing from image)  
[*Daylight*](https://www.dnd-spells.com/spell/daylight) (once per day)

(Can also recharge hammer in spellforge)

Highest dice of attack roll deals radiant dmg if I choose to deal radiant dmg  
  
Attack roll (normal): d20 + strength(3) + proficiency(4)  
Damage: 2D10 + Strength (3)



### Cloudreign (Thoughtcapture Vial)

Rare vial (Tiny/Abjuration). 2000gp

This dark blue vial allows you to read another's surface thoughts and capture them as thought strands, storing the strands within the vial.

**Action:** Target a creature you can see within 10 feet of you to learn its surface thoughts and pull the thoughts learned out of the creature's head as a tangible glowing string of energy known as a thought strand. The strands can be stored indefinitely in the vial or until the vial reaches capacity, in which case the oldest strands dissipate. A creature affected by the vial knows that its thoughts are being probed.

Thought strands created using the Encode Though cantrip can be stored in the item. Such strands have their duration extended indefinitely.

The vial has 3 charges and can store up to 3 thought strands. It regains all its charges daily at dusk.

If attuned to a character with the Psi Warrior subclass, the stored thoughts can be spent as additional Psi dice (d4). If the thought is a particularly powerful one, the dice may be higher, at the DMs discretion. Psi Warriors attuned in this way also increase their Intelligence ability score modifier by +1 for the purposes of their psionic powers, and also learn the [*Encode Thoughts*](http://dnd5e.wikidot.com/spell:encode-thoughts) cantrip.

Merchants Cart

Land vehicle, horse drawn

Armor Class: 10

Hit points: 40

Capacity bonus: 2x

### Hildegard

Draft Horse, trained

Armor Class: 10

Hitpoints: 19

Max speed: 40ft per round (16 miles per day)

Carry Capacity: 540lbs

Upkeep: 5sp per day feed, 5sp per day stabling.

### Dried Dandelion

From Lazarah

### Ironfang

Great Maul, Martial melee weapon (Heavy, Two Handed)

Damage: 2d8 bludgeoning (magical)

(2d8 + str + 2)

You gain a +2 bonus to attack and damage rolls made with this magic weapon.

You gain the following benefits while you hold Ironfang:

- You can speak Terran fluently.

- You have resistance to acid damage.

Once per long rest, cast [*Shatter*](https://5e.tools/spells.html#shatter_phb) (Spell save DC: 8 + Proficiency + Strength) on a point you strike with the weapon. You are immune to the damage from this casting.

### Polished Plate mail +2 (5000g)

18+2 Armor class  
Resistance to slashing damage. Disadvantage on Stealth

1x Healing Potion - 50gp

Action: 2d4+2 hp restored

### Potion of Vigor (10gp)

1x

Action: Recover 1 hit die and spend it immediately if you like. Will not stabilise (death saving stuff).

### Crystalized \[Earth, Fire, Water, Air\]

**Bonus Action** (or **Reaction if you are holding the crystal**): You crush the crystal in your hand and gain resistance to two damage types for 1 minute.

Earth: Piercing and Acid

Fire: Fire and Poison

Water: Bludgeoning and Cold

Air: Slashing and Lightning

I have 1 Earth, 1 Air

### Silence Scroll (400g)

Can give it back to military guys if we dont need it and get money back.

### Transmuter Stone from Kindle

Currently has Fire Resistance (halved damage)

### 1 Gem for Resurrection

## Retired inventory (in storage)

### Steel Maul

Heavy, Two-Handed Martial weapon

Melee Attack bonus: Strength + Proficiency + 1

Damage: 2D6 + Strength + 1 (Bludgeoning)

### Handaxe x2

Light Thrown Simple weapon

Melee/Ranged Attack bonus: Strength + Proficiency

Damage: D6 + Strength (Slashing)

Range: 20ft/60ft (with disadvantage)

### Backpack with Travel Supplies

Bedroll, Messkit, Tinderbox, Waterskin, Small tent. Pretty bulky, so it gives you disadvantage on Dexterity based checks while wearing it.

### Merchants Guild Membership

As an established although not very well respected member of a guild, you can rely on certain benefits that membership provides.

Your fellow guild members will provide you with lodging and food if necessary, and pay for your funeral if needed. In some cities and towns, a guildhall offers a central place to meet other members of your profession.

Guilds often wield tremendous political power. If you are accused of a crime, your guild will support you if a good case can be made for your innocence or the crime is justifiable.

You must pay dues of 5 gp per month to the guild. If you miss payments, you must make up back dues to remain in the guild's good graces.

## IRONFANG is in satchel of holding 

## Used Inventory

### Pink Potion From Kindle

Restore to full hitpoints and a random effect.

1x Greater Healing Potion - 250gp

Action: 4d4+4 hp restored

### Basic Climbing equipment

50 ft of rope, Pitons and a small hammer. Can be carried on the outside of your backpack.

## Destroyed Inventory

### Helm

Strong Enchantment 1090gp [*id: ACC-1-3321174354*](https://easyroleplay.com/item-generator/)

**Free action**, at the end of your turn: Three times per day, You gain advantage on a check to remove any condition. Needs attunement, +1 attunement slot. Personality: jealous/possessive, can only ever have 1 of this item. Disattument might lead to some conflict.

### Chainmail armor

Heavy armor, full body

Armor Class: 16

While wearing:

Disadvantage on Stealth checks

Can’t swim

Can’t long rest

### Cursed Ironfang

You attune immediately to the weapon on touch. The weapon is cursed so you cannot break attunement willingly.

Great Maul: 1d8 bludgeoning, 2d8 thunder damage

(1d8 + str + 2 bludgeoning and 2d8 thunder)

You gain a +2 bonus to attack and damage rolls made with this magic weapon.

You gain the following benefits while you hold Ironfang:

- You can speak Terran fluently.

- You have resistance to acid damage.

- You have tremorsense out to a range of 60 feet.

- You can sense the presence of precious metals and stones within 60 feet of you, but not their exact location.

- You can **cast** [*dominate monster*](https://5e.tools/spells.html#dominate%20monster_phb) (save DC 17) on an earth elemental. Once you have done so, Ironfang can't be used this way again until the next dusk.

- Does double damage to inanimate objects

Ironfang has 3 charges. You can use your **action** to expend 1 charge and cast the 2nd-level version of [*shatter*](https://5e.tools/spells.html#shatter_phb) (DC 17). Ironfang regains 1d3 expended charges daily at dusk. You can use your **action** to expend 1 charge to cast [*Greater Restoration*](https://5e.tools/spells.html#greater%20restoration_phb).

The Rumbling: While inside an earth node, you can perform a **10 minute ritual** called the Rumbling, using Ironfang to create a devastation orb of earth. Once you perform the ritual, Ironfang can't be used to perform the ritual again until the next dusk.

While inside an earth node, you can perform a **ritual** which takes **3 actions**. This ritual can be used to open or close a portal to the Plane of elemental earth.

Personality Corruption:

Personality flaw: Ironfang heightens its wielder's destructive nature. While attuned to the weapon, you gain the following flaw: "I like to break things and cause ruin." You need to do something to satiate this flaw every day while you remain attuned to the weapon.

There is a secondary Flaw: While attuned to the weapon, you gain the following flaw: "It is my greatest ambition to open the portal and allow Lord Ogremoch to join me here on the material plane." Wisdom saving throw DC 10 every 8 hours to resist gaining the personality trait. Increases to DC 15 when in the earth elemental node.
