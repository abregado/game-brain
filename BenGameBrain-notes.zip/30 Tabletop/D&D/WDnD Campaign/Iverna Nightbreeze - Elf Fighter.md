---
title: "Iverna Nightbreeze - Elf Fighter"
source: "Game Stuff/D&D/WDnD Files/Iverna Nightbreeze - Elf Fighter"
modified: 2020-05-31
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D characters"]
words: 974
summary: "Character sheet for Iverna Nightbreeze, an elf samurai fighter noble, with traits, feats and abilities; she joins the party in the campaign log."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

# Iverna Nightbreeze

**Elf Samurai / Fighter / Noble**

**Neutral Good**

### **Attributes and Modifiers**

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 14      | 17      | 13      | 12      | 12      | 10      |
| +2      | +3      | +1      | +1      | +1      | +0      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 16/18  | 33     | 3d10   | 30       | 14       | 28  |

### **Saving throws**

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +4      | +3      | +3      | +1      | +1      | +0      |

### Proficiencies (+2 bonus):

**Perception, History, Athletics, Survival**

**All weapons and armor,**

**Crescent Cubes set (gaming)**

### Languages

**Common, Elvish, Orcish, Goblin**

### Darkvision

Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can’t discern color in darkness, only shades of gray.

### Fey Ancestry

You have advantage on saving throws against being charmed, and magic can’t put you to sleep.

### Trance

Elves don’t need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep.

### Fighting Style: Protection

When a creature you can see attacks a target other than you who is within 5 ft of you, you can use your reaction to impose disadvantage on the attack. You must be wielding a shield or have a free hand while wearing your Mithril Bracers.

Personality

### Traits

I choose my words very carefully. Sarcasm, I’m told, is my sharpest weapon.

### Ideal

All people deserve to be treated with dignity, regardless of their station. Of course, orcs are not people.

### Bond

Orcs are a blight on the land. For the sake of the natural and civilized world, I kill them on sight.

### Flaw

I can’t admit when I’m wrong.

# Feats and Abilities

### Elf Natural Magic

**Action:** You seize the air and compel it to create one of the following effects at a point you can see within 30ft:

One Medium or smaller creature that you choose must succeed on a Strength saving throw (DC 11) or be pushed up to 5 feet away from you.

You create a small blast of air capable of moving one object that is neither held nor carried and that weighs no more than 5 pounds. The object is pushed up to 10 feet away from you. It isn’t pushed with enough force to cause damage.

### Action Surge

**Free Action:** you can take one additional action on top of your regular action and a possible bonus action.

You must finish a short or long rest before using this feature again.

### Second Wind

**Bonus action:** regain 1d10 + your fighter level. You must finish a short or long rest before using this feature again.

### Fighting Spirit

**Bonus action:** gain advantage on weapon attack rolls until the end of the current turn. When you do so, you also gain 5 temporary hit points. The number of temporary hit points increases when you reach certain levels in this class, increasing to 10 at 10th level and 15 at 15th level.

You can use this feature three times, and you regain all expended uses of it when you finish a long rest.

#  

# Inventory

### Longbow

Longbow. Ranged (150/600). Heavy, Two-Handed. +5 to hit, 1D8+3 piercing damage. 3 arrows remaining.

### Gruumshbane Longsword

Longsword. +4 to hit. D8+2 slashing damage, or D10+2 slashing damage when wielded two handed. Against orcs, gain +1 to hit and to damage.

### Mithril Bracer

Counts as a shield that is automatically equipped if you have your left hand free, and you were not wielding a weapon in it during your last turn. It cannot be used against ranged attacks or area of effect attacks.

### Ivernas Hat

+1 AC while wearing the hat. If you are wounded, pass a Dexterity saving throw (DC 10) or the hat falls off. You pass automatically if you have a free hand at the time when you are hit.

### Leather Armor + Duster

Light Armor. AC 12 + Dexterity modifier

### Adventuring Clothes 

Durable, washable. Unlikely to be destroyed while delving in the depths of a dungeon.

### Fine Clothes

A suitable set of clothes for a fancy party or invitation to a noble’s court. While wearing these you won’t incur any Charisma penalties due to fashion. Not very durable.

### Nobles Signet ring

A fancy ring for when you can reveal your tattoo of pedigree.

### Tattoo of Pedigree

A non-removable tattoo showing your heritage and that you below to an elven noble house.

### Coin Purse

75gp left

#  

# Plot Devices and Intel

### Orcs and parents

Orcs killed Ivernas parents during a raid. They fought bravely but were overwhelmed and cut down fiercely. She saw them die but escaped soon afterwards.

### The veil drawn too soon

The day after witnessing her parents die, Iverna relived the experience in a trance, marking that day as her First Reflection. She was only 7 at the time.

### Haunted and robbed

Nightbreeze regularly relives her parents death during trance, but feels as if their death was the lesser of two things stolen from her. She no longer receives images of primal elves when trancing, and she feels it unfair that these experiences were taken from her so early.
