---
title: "Wave Echo Wrapup"
source: "Game Stuff/Wave Echo Wrapup"
modified: 2022-01-23
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D One-shots]]"]
concepts: ["Wave Echo Campaign Finale", "D&D one-shots"]
words: 1164
summary: "Narrative wrap-up of a D&D (Lost Mine of Phandelver/Wave Echo Cave style) campaign finale: heroes escape a dwarven city as a bomb detonates and epilogues for each character (Kildrak, Thokk, Hama, Livia, Trisha)."
tags: ["area/dnd", "project/d-d-one-shots", "project/wdnd-campaign", "type/campaign-prep"]
---

Kildrak reached up to grab Thokk’s hand, letting him assist with the final metre of the climb. 120ft of almost perfectly straight chimney joining the dwarven city below with the open sky above. Together they lowered the rope down to the others, who were anchored 40ft below in the ashen darkness.

First Hama, then Livia were helped out of the shaft onto the flat rocky area on top of the mountain. A cry from Trisha below signalled that the package was securely fastened to the final rope. With a final strenuous effort, the four heroes hauled up a large bundle containing the groups backpacks and armour. A few moments later Trisha appeared easily from below.

Taking stock of their surroundings, Trisha, Hama and Livia realised they had seen this place before. It is the plateau from their various visions. Here, each vision showed only one of them alive, looking out as the world was washed clean, each time with a different element. Earth, Fire and Water. Clearly something had changed as here they all stood, together and healthy… if not exhausted. Surely a portent that the end of the world will not happen today.

From this vantage point, both the Tower of the Fire druids and the Sacred Stone monastery are visible. As the group's gaze moves over the Tower, the ashen heap of the wicker giant can be seen, and a few humanoid creatures can be seen moving around the site. The monastery seems far more tranquil.

Then the earth around it splits.

Then you feel the rumble as if the entire mountain is anticipating something.

Oh, the bomb…

—---------------------------

A few hours beforehand.

Deep in the Temple district of the dwarven city, while recovering from their short encounter with Marlon, the self proclaimed Prophet of the Black Earth, the heroes found themselves in the company of Broog and Norb, an ettin, a very peculiar stone priest tinker, and a very large, badly damaged, magical artefact of immense power.

Identifying the object as a bomb of some kind, Hama was able to fuel the priests interest in the device enough that he failed to notice the group sneaking out. When the bomb detonated, the group was already safely across into the next district, the Forge district, of the dwarven city.

There was no explosion. Instead half of the Temple district simply vanished in a flash, everything turning to a fine dust. The sound was terrifying as air rushed into the newly formed void. The edges of the affected radius were smooth as if made of liquid stone. But the destructive energies of this device were not yet exhausted. The radius of the crater began to expand, everything it touched seeming to melt. And yet there was no heat. From their viewpoint across the bridge, the party realised it was time to go.

Searching for a way out, it was clear that this district had been occupied by the Fire druids and their more monstrous minions. Now, however, panic had broken out, making the group realise that the cultists knew exactly what was happening with the bomb, and that they too had to evacuate. Several groups of cultists volunteered the information that the Prophetess Vanifer had abandoned them, but several others were mourning openly, crying that their Prophetess had been in the Temple district at the time of the explosion.

Kildraks knowledge of dwarven architecture led them to the high smelters, where he knew there would be an exit path through the chimneys leading to the clear air. The group encountered several fierce monsters and even more dangerous traps along the way, but each was overcome with skill. Finally the long climb up the smooth shafts began.

—------------------------

Back on the mountaintop

Everyone had hoped the bombs radius would grow weaker and stop after it enveloped the Temple district. Now it was clear that it would not be the case. First the monastery was swallowed by the rapidly forming sinkhole. Large areas of mountainside gave way and slid into the expanding crater; their mass melting into the perfectly smooth crater walls.

As the crater approached the Tower and the mountain that the group stood on, it seemed like it would never stop. But finally, and abruptly, as the crater was scooping out the mountain below the tower it halted. A complex series of tunnels which lead from under the tower were exposed in the crater wall, creating a treacherous stairway back down into the depths.

—---------------------------

Heading back toward Phandalin and Neverwinter, Livia remembered the aftermath from the top of the Tower. The group had trekked down from their high mountain perch and made their way to the Tower. From this new viewpoint, she could see that the entire mountain range was originally hollow, concealing the dwarven city. Now the crater, easily over 10 miles in diameter, had opened up the enormous cavern to the sky.



The crater was perfectly smooth, which made it very easy to pick out the single object at the very centre of the bowl. Demanding to go check it out, Hama led the way down the stairs and out onto the crater floor.

There, lightly embedded in the stone floor, was the War Pick which you last saw by the side of Marlon, Prophet of the Black Earth.



—-------------------------

Weeks later, back in the relaxed safety of Phandalin, Trisha is amusing her family with tales of adventure. Her business ventures in the village have been going well, already turning a tidy profit. In her newly established Theatre some performers are practising a written stage play… about Livia.

In the frontier town of Thundertree, Livia leads a band of green adventurers into a newly discovered warren beneath the eflin grape meadows. Brave folk from Neverwinter have started to arrive in the town seeking a fresh start, and there are many dangers that she needs to attend to personally. The gods still bekon to her from time to time.

Thokk returns to the original secret garden outside Phandalin. He finds it filled with wondrous plants with scaled golden bark and a temperamental rip in the planes of existence. With high hopes he takes his first journey into the Feywild, knowing his garden (and dragon) will follow him.

After making a round trip of all the villages near the crater, it becomes clear to Kildrak that the Earth, Fire and Water cultists have all fled. His journey earns him renown with the villagers in every village. He then returns to Usheen Stormbanner at Summit Hall to finalise his initiation into the Order of the Gauntlet.

Steel strikes steel as Hama finishes yet another masterpiece deep in the bowels of the Spellforge. Business is good, although expectations are high given she is working alongside dwarves. The War Pick from the crater lies on a workbench nearby. As she passes, Hama lightly caresses the Pick with a single finger, speaks its name, and wonders when the call to adventure will rise again.

… “Ironfang”
