---
title: "WDnD Lumpik - Rogue"
source: "Game Stuff/D&D/WDnD Files/WDnD Lumpik - Rogue"
modified: 2020-07-27
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 1251
summary: "Rogue/Spy character sheet for Lumpik with items, a custom gem trinket, and faction intrigue (Lords Alliance, Zhentarim, mission to find a traitor)."
contains_external_material: "SRD feature and gear text mixed in"
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

## Lumpik

**Human Rogue / Spy - Lawful Neutral**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 9       | 16      | 11      | 13      | 14      | 15      |
| -1      | +3      | +0      | +1      | +2      | +2      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 15     | 8      | 1D8    | 30       | 4        | 9   |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +5      | +0      | +3      | +2      | +2      |

### Proficiencies (+2 bonus):

**Insight**

**Survival**

**Intimidation**

**Stealth (Dexterity)**

**Deception\* (Charisma)**

**Persuasion (Charisma)**

**Investigation (Intelligence)**

**Perception (Wisdom)**

**Sleight of Hand (Dexterity)**

**Thieves Tools\* (Dexterity)**

**Light armor**

**Simple Weapons**

**Hand Crossbow**

**Longsword, Rapier, Shortsword**

### Languages:

**Common, Dwarvish**

### Spy Network

You have a reliable and trustworthy contact who acts as your liaison to a network of other spies in your faction. You know how to get messages to and from your contact, even over great distances; specifically, you know the local messengers, loyalist caravan masters, and ex-navy sailors who can deliver messages for you. You can request equipment and information, although you may not receive confirmation that you will be supplied them.

### Faction Cypher

You know how to write a secret cypher uniquely understandable by your faction. It takes four times longer to write a message than it does normally. In addition, you understand a set of secret signs and symbols used to convey short, simple messages.

### Sneak Attack

Once per turn you can deal an extra 1d6 damage to one creature you hit with an attack if you have advantage on the attack roll or the target is being threatened by one of your allies. The attack must use a finesse or ranged weapon.

You cannot gain this damage if you have disadvantage on your attack roll. The amount of extra damage increases to 2d6 at 3rd level and 3d6 at 5th level.

Personality

### Traits

### Ideal

### Bond

### Flaw

##  

## Inventory

### Shortsword

Light finesse Martial weapon

Melee Attack bonus: Dexterity + Proficiency

Damage: D6 + Dexterity (Slashing)

### Blackjack

Light Simple weapon

Melee Attack bonus: Strength + Proficiency

Damage: D4 + Strength (Bludgeoning)

Useful if you want to take someone alive.

### Hand Crossbow

Light ranged Martial weapon

Ranged Attack bonus: Dexterity + Proficiency

Damage: 1d6 + Dexterity (Piercing)

Range: 30ft / 120ft (with Disadvantage)

### Leather armor

Light armor, chest and shoulders

Armor Class: 11 + Dexterity modifier

### Thieves Tools

A small pouch with a comprehensive set of delicate tools. Proficiency with these tools lets you add your proficiency bonus to any ability checks you make to disarm, set or modify traps or open non-magical locks.

### Superior set of Dark clothing

While wearing these clothes you gain advantage to your Stealth checks as long as you are in Dim light or Total darkness.

Taking more than 4 damage from a single source will remove this ability until the clothes are repaired (5gp).

### Set of Fine clothing

While wearing these clothes, unarmored and well groomed, you do not suffer disadvantage to your Charisma based checks for interacting with people of higher class.

### Set of Travelling clothes

These are tough clothes suitable for travelling. They infer no bonus, but also won’t get destroyed by damage.

### Crowbar

You gain advantage on Strength checks to force open doors and containers. Opening objects in this way is quite noisy.

### Bag of Caltrops

**Action:** you can spread a single bag of caltrops to cover a 5-foot-square area. Any creature that enters the area must succeed on a Dexterity saving throw (DC15) or stop moving and take 1 piercing damage. Until the creature regains at least 1 hit point, its walking speed is reduced by 10 feet. A creature moving through the area at half speed doesn't need to make the saving throw.

### Bag of Ball Bearings

**Action:** you can spill these tiny metal balls from their pouch to cover a level area 10 feet square. A creature moving across the covered area must succeed on a Dexterity saving throw (DC10) or fall prone. A creature moving through the area at half speed doesn't need to make the saving throw.

### Firestone

Uncommon tiny object

This magical flintstone creates sparks when struck and ignite any campfire automatically. Additionally any message which is burnt will be read by your faction contact, and quite possibly others.

### Haversack

Just a small bag which clings tightly to your body used to store any small items you have. It does not limit your movement at all.

### Backpack

A larger bag you use when travelling. It can hold much more, but you suffer disadvantage to all Dexterity based checks while wearing it.

##  

## Cusp of Uncertainty

**Tiny trinket - Illusion magic**

**Attunement required by Lumpik**

Consumable: Two uses

(Two gems in separate pouches)

**Action:** Touch a willing creature with a gem. The gem dissolves and grants one of the following illusions to that target for 10 minutes.

**Condition (Mask magic).** Magical items the target is carrying no longer emit any magical aura. Magic users no longer show up as magical. Ongoing spell effects are undetectable.

**Condition (New image).** The target’s alignment, creature type or race is changed to another of your choice (that you have seen).

**Passive:** When both stones are stored in the same pouch, the pouch (and everything inside) is invisible to everyone except the attuned user.

**Passive:** During a long rest, the gems reappear in their pouches.

## Plot Devices and Intel

### The Lords Alliance

A collection of Lords and Noble houses from all races. High ranking members of the Alliance sit as rulers of 10 great cities in the north. Their main goal is to bring order, prosperity and civilization to the wild areas of Faerun, for the benefit of the peasantry and their noble bloodline rulers. Each member is given freedom to complete their tasks as they see fit.

### The Zhentarim

A network of both overt and covert agents. The Zhentarim believe that we should be ruled by those who are willing and capable, rather than those whose birthright allows it. Their members trade favors anonymously with one another to further the goals of all members individually.

### Faction Contact

You have never met them face to face, or even know their name, but they have come through for you before. You reference them by a particular symbol of your faction cypher.

### Sildar Hallwinter

57, Human Female warrior. An overt member of the Lords Alliance and blessed knight of Lord Rainburn, who sits at council with Lord Neverember himself. She has been assigned to find her friend Iarno Albrek, who has not reported in after being sent to Phandalin.

### Iarno Albrek

45, Human Male Wizard. An obsessive but skilled overt member of the Lords Alliance. After an incident in his last station, he was sent to Phandalin to take responsibility for the town militia and for bringing order to the new frontier town.

### Gundren Rockseeker

234, Dwarf Male Explorer. A friend of several generations of Hallwinters. Gundren and Sildar have been meeting regularly of late.

### Your Mission

There is a traitor in the Lords Alliance. Travel to Phandalin and discover what has happened to Iarno. Trail Sildar to find out if she is involved.

###
