---
title: "Tarquin Poryclase - Artificer"
source: "Game Stuff/D&D/WDnD Files/Tarquin Poryclase - Artificer"
modified: 2024-08-11
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 2331
summary: "Artificer (Earth Genasi) character sheet for WDnD with stats, racial/class features, infusions, spell cards, inventory. Features and spells are largely copied from 5e rules text."
contains_external_material: "Official 5e class/spell text pasted into sheet"
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

## Tarquin Poryclase



**Earth Genasi Artificer / Rival Intern - True Neutral**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 10      | 8       | 14      | 17      | 12      | 14      |
| 0       | -1      | +2      | +3      | +1      | +2      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 21     | 28     | 3D8    | 30       | 5        | 10  |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 0       | -1      | +4      | +5      | +1      | +2      |

### Proficiencies (+2 bonus):

**Stonework,**

**Mechanics,**

**Diagnosis,**

**Lore (Contraptions)**

**~~Arcana (Intelligence) +5~~**

**~~Investigation (Intelligence) +5~~**

**~~History (Intelligence) +5~~**

**~~Nature (Intelligence) +5~~**

**All armor and shields**

**Thieves, tinker’s, mason’s and smith’s tools**

**Simple weapons and firearms**

### Languages:

**Common, Terran, Sylvan**

## Personality

### Traits

I'm extremely fond of puzzles.

### Ideal

Balance. I strive for it in every choice I make.

### Bond

I owe the people of Phandalin a moral debt

### Flaw

I forget easily that I look different.

## Background

Rival Intern - Black Earth Cult

### Inside Informant

You have connections to your previous employer or other groups you dealt with during your previous employment. You can communicate with your contacts, gaining information at the DM's discretion.

## Racial

### Darkvision

You can see in dim light within 60 feet of you as if it were bright light and in darkness as if it were dim light. You discern colors in that darkness only as shades of gray.

### Earth Walk

You can move across difficult terrain without expending extra movement if you are using your walking speed on the ground or a floor.

### Merge with Stone

You know the **blade ward** cantrip. You can cast it as normal, and you can also cast it as a bonus action a number of times equal to your proficiency bonus, regaining all expended uses when you finish a long rest.

Starting at 5th level, you can cast the **pass without trace** spell with this trait, without requiring a material component. Once you cast that spell with this trait, you can't do so again until you finish a long rest. You can also cast it using any spell slots you have of 2nd level or higher.

Intelligence is your spellcasting ability for these spells when you cast them with this trait (choose when you select this race).

## Class

### Arcane Gauntlet

You can forge for yourself a wondrous weapon of war known as an Arcane Gauntlet. At the end of a long rest, you can use smith's tools to create an Arcane Gauntlet, choosing for it to be a Lightning Cannon or Thunder Gauntlet. It is a simple weapon only usable by you, and you use your Intelligence, in place of Strength or Dexterity, for its attack and damage rolls.

You can only have one Arcane Gauntlet at a time. Creating a second causes the magic of the first to immediately dispel.

Lightning Cannon: Your Arcane Gauntlet gains the ranged (90/300) property. On hit, it deals 1d6 lightning damage, and once per turn, when you hit with a Lightning Cannon attack, you can cause it to deal an additional 1d6 lightning damage.

Thunder Gauntlet: Your Arcane Gauntlet remains a melee weapon. On hit, it deals 1d8 thunder damage, and any target hit by this Gauntlet has disadvantage on attack rolls against targets other than you until the start of your next turn.

### Arcane Armor

You expand the magic of your Arcane Gauntlet to encompass a full suit of armor. At the end of a long rest, you can use your smith's tools to transform a set of armor into Arcane Armor. This armor incorporates your Arcane Gauntlet, is only usable by you, and while wearing it you gain the following benefits:

- If the set of armor normally has a Strength requirement, your Arcane Armor lacks this requirement for you.

- You can use your Arcane Armor as a spellcasting focus.

- Your Arcane Armor attaches to you and can't be removed against your will. It expands to cover your entire body, and functionally replaces any missing limbs or body parts.

- You can don or doff your Arcane Armor as an action, and can retract or deploy the helmet as a bonus action.

- You can use a bonus action to grant yourself temporary hit points equal to your Intelligence modifier (minimum of 1).

### 

###  

### Known Infusions

#### Enhance Defense

+1 AC

#### Enhanced Weapon 

+1 to hit and damage

#### Mind Sharpener

The infused item can send a jolt to the wearer to refocus their mind. The item has 4 charges. When the wearer fails a Constitution saving throw to maintain [*concentration*](https://5e.tools/conditionsdiseases.html#concentration_phb) on a spell, the wearer can use its reaction to expend 1 of the item's charges to succeed instead. The item regains 1d4 expended charges daily at dawn.

#### Armor of magical strength

This armor has 6 charges. The wearer can expend the armor's charges in the following ways:

- When the wearer makes a Strength check or a Strength saving throw, it can expend 1 charge to add a bonus to the roll equal to its Intelligence modifier.

- If the creature would be knocked [*prone*](https://5e.tools/conditionsdiseases.html#prone_phb), it can use its reaction to expend 1 charge to avoid being knocked prone.

The armor regains 1d6 expended charges daily at dawn.

### 

###  

### Infusing an Object

2 active at once

At the end of a long rest, you can use your tinker's tools to imbue an Infusion you know into a non magical object. To do so, you must be able to touch the object with your tools.

If the Infusion requires attunement, you can attune to the object the instant you infuse it, or you can forgo attunement so another creature can attune to it. To attune to the infused item later, you must follow the normal attunement process.

The Infusion remains in an item indefinitely. If you die, the Infusion vanishes after a number of days have passed equal to your Intelligence modifier (minimum of 1 day). Infusions vanish immediately if you give up your knowledge of one to learn another or imbue the Infusion into another object.

You can infuse multiple objects at the end of each long rest, up to one for each Infusion you know. Each Infusion can be in only one object at a time, and no object can bear more than one Infusion. If you transfer an Infusion to a new object, any previous instance of that Infusion immediately ends.

### Magical Tinkering

At 1st level, you learn how to store a cantrip in an object. During a short or long rest, you can touch one item that you can use as a spellcasting focus, and you store a cantrip in it, choosing a cantrip from the artificer spell list that requires 1 action to cast and does not require concentration. You do not need to know the cantrip. If the cantrip has an option for how it manifests, you must choose the manifestation when storing the cantrip.

When you do this, you can change the damage type to one of similar rarity, and/or modify any saving throws to require a different ability score.

While holding the object, a creature can take an action to produce the spell's effect from it, using your spellcasting ability modifier. The enchantment stays in the object until you dismiss it as an action or until you use this feature again to store a cantrip in a different object.

### Right Tool for the Job

You've learned how to produce exactly the tool you need: with thieves' tools or artisan's tools in hand, you can magically create one set of artisan's tools in an unoccupied space within 5 feet of you. This creation requires 1 hour of uninterrupted work, which can coincide with a short or long rest. Though the product of magic, the tools are non magical, and they vanish when you use this feature again.

## Spellcasting

| **Spell Attack** | **Spell Save DC** |
|------------------|-------------------|
| +5               | 13                |



1st Level Spell Slots

### Shocking Grasp

Evocation cantrip

Casting Time: 1 action

Range: Touch

Components: V, S

Duration: Instantaneous

Lightning springs from your hand to deliver a shock to a creature you try to touch. Make a melee spell attack against the target. You have advantage on the attack roll if the target is wearing armor made of metal. On a hit, the target takes 1d8 lightning damage, and it can't take reactions until the start of its next turn.

The spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).

### Guidance

Divination cantrip

Casting Time: 1 action

Range: Touch

Components: V, S

Duration: Concentration, up to 1 minute

You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one ability check of its choice. It can roll the die before or after making the ability check. The spell then ends.

### Shield

1st-level abjuration

Casting Time: 1 reaction, which you take when you are hit by an attack or targeted by the magic missile spell.

Range: Self

Components: V, S

Duration: 1 round

An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile.

### Thunderwave

1st-level evocation

Casting Time: 1 action

Range: Self (15-foot cube)

Components: V, S

Duration: Instantaneous

A wave of thunderous force sweeps out from you. Each creature in a 15-foot cube originating from you must make a Constitution saving throw. On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, the creature takes half as much damage and isn't pushed.

In addition, unsecured objects that are completely within the area of effect are automatically pushed 10 feet away from you by the spell's effect, and the spell emits a thunderous boom audible out to 300 feet.

When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d8 for each slot level above 1st.

### Ensnaring Strike

1st-level conjuration

Casting Time: 1 bonus action

Range: Self

Components: V

Duration: Concentration, up to 1 minute

The next time you hit a creature with a weapon attack before this spell ends, a writhing mass of thorny vines appears at the point of impact, and the target must succeed on a Strength saving throw or be restrained by the magical vines until the spell ends. A Large or larger creature has advantage on this saving throw. If the target succeeds on the save, the vines shrivel away.

While restrained by this spell, the target takes 1d6 piercing damage at the start of each of its turns. A creature restrained by the vines or one that can touch the creature can use its action to make a Strength check against your spell save DC. On a success, the target is freed.

If you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.

### 

###  

### Grease

1st-level conjuration

Casting Time: 1 action

Range: 60 feet

Components: V, S, M (a bit of pork rind or butter)

Duration: 1 minute

Slick grease covers the ground in a 10-foot square centered on a point within range and turns it into difficult terrain for the duration.

When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or fall prone. A creature that enters the area or ends its turn there must also succeed on a Dexterity saving throw or fall prone.

### Absorb Elements

1st-level abjuration

Casting Time: 1 reaction, which you take when you take acid, cold, fire, lightning, or thunder damage

Range: Self

Components: S

Duration: 1 round

The spell captures some of the incoming energy, lessening its effect on you and storing it for your next melee attack. You have resistance to the triggering damage type until the start of your next turn. Also, the first time you hit with a melee attack on your next turn, the target takes an extra 1d6 damage of the triggering type, and the spell ends.

When you cast this spell using a spell slot of 2nd level or higher, the extra damage increases by 1d6 for each slot level above 1st.

### Feather Fall

1st-level transmutation

Casting Time: 1 reaction, which you take when you or a creature within 60 feet of you falls

Range: 60 feet

Components: V, M (a small feather or a piece of down)

Duration: 1 minute

Choose up to five falling creatures within range. A falling creature's rate of descent slows to 60 feet per round until the spell ends. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature.

###  

### Blade Ward

Abjuration cantrip

Casting Time: 1 action

Range: Self

Components: V, S

Duration: 1 round

You extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks.

## Inventory

### 

### Arcane Full Plate Armor

AC 18

Disadvantage on Stealth checks

If I reach 0 hitpoints, the armor ejects its wearer and cannot be used for 10 minutes. The occupant is ejected on 1 hitpoint.

### Shield

+2 AC

Action to don/doff

### Gold Pouch

[*See the Accounting page*](https://docs.google.com/spreadsheets/d/1KPd7hQZPPq03Ev6xlKU2oT0giMvFKHmpyYr34CMNJFI/edit?usp=sharing)

### Tools

Tinkers, Thieves and Smiths Tools

### Misc

Fine Clothes

Adventuring clothes
