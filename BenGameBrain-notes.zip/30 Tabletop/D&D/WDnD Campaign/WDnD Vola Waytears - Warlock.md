---
title: "WDnD Vola Waytears - Warlock"
source: "Game Stuff/D&D/WDnD Files/WDnD Vola Waytears - Warlock"
modified: 2020-05-28
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D homebrew items"]
words: 798
summary: "Tiefling-style Warlock sheet for Vola with patron (Ancient One) and custom item Die of the Void; hunted heroine heading to Phandalin."
contains_external_material: "SRD class text"
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

## Vola Waytears

**Warlock - Neutral Good**

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 10      | 14      | 14      | 15      | 13      | 18      |
| +0      | +2      | +2      | +2      | +1      | +4      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 13     | 40     | 4d8    | 30       | 5        | 10  |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +0      | +2      | +2      | +2      | +3      | +6      |

### Proficiencies:

**Sleight of Hand (Dexterity) +4**

**Stealth (Dexterity) +4**

**Disguise Kit (Intelligence) +4**

**Thieve’s Tools (Dexterity) +4**

**Intimidation (Charisma) +5**

**Deception (Charisma) +5**

**Light Armor**

**Simple Weapons**

### Languages:

**Common, Infernal**

### Secret Identity

You have created a second identity that includes documentation, established acquaintances, and disguises that allow you to assume that persona.

Personality

### Traits

Once a plan has been formed, I put it into action immediately.

### Ideal

Everyone should be free to choose their own destiny.

### Bond

Patron - See below.

### Flaw

I'm either over excited by, or completely disinterested in a thing.

#  

# Infernal Heritage

### Darkvision

Thanks to your infernal heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray.

### Hellish Resilience

You have resistance to fire damage.

### Infernal Legacy

You know the [*thaumaturgy*](https://www.dndbeyond.com/spells/thaumaturgy) cantrip. When you reach 3rd level, you can cast the [*hellish rebuke*](https://www.dndbeyond.com/spells/hellish-rebuke) spell as a 2nd-level spell once with this trait and regain the ability to do so when you finish a long rest. When you reach 5th level, you can cast the [*darkness*](https://www.dndbeyond.com/spells/darkness) spell once with this trait and regain the ability to do so when you finish a long rest. Charisma is your spellcasting ability for these spells.

# Patron Magic

Your magic comes from a calling on your infernal ancestors.

### Warlock Spell Slots

You have 1 spell slot and gain more as you level up. You regain all points when you finish a long rest.

### Warlock spell level

When you cast your warlock spells, they are always of the same level. Your spells are level two.

### Cantrip Choices (3)

Eldritch Blast

Infestation

Mold Earth

### Spell Choices (5)

Tashas Hideous Laughter

Arms of Hadar

Dissonant Whispers

Expeditious Retreat

### Book of Shadows - Pact boon

You have a book with three cantrips in it.

### Awakened Mind - Patron Feature

You have the ability to touch the minds of other creatures. You speak telepathically to any creature you can see within 30 feet of you. You don't need to share a language with the creature for it to understand your telepathic utterances, but the creature must be able to understand at least one language.

###  

## Eldritch Evocations

### Misty Visions

You can cast the **silent image** spell at will, without expending a spell slot or material components.

### Eldritch Sight

You can cast **detect magic** at will, without expending a spell slot or material components.

Inventory

### Arcane Focus

Needed to cast your magic

### Leather Armor

Light armor, chest and shoulders

Armor Class: 11 + Dexterity modifier

### Dagger

Light finesse Martial weapon

Melee Attack bonus: Dexterity + Proficiency

Damage: D4 + Dexterity (Piercing)

### Backpack with Travel Supplies

Bedroll, Messkit, Tinderbox, Waterskin, Small tent. Pretty bulky, so it gives you disadvantage on Dexterity based checks while wearing it.

### Forgery Kit with Writing Supplies

To everyone else, this looks like a normal writing set.

Die of the Void

**Small worn trinket - Necromancy magic**

**Attunement required by Vola Waytears**

**Passive:** Your maximum Warlock spell tokens increased by 1.

**Reaction, when you spend a Warlock spell token:** roll a D6. On a 1, you immediately regain the spell token but suffer D6 psychic damage. On a 6 you also regain the spell token and the spell you cast is considered one level higher than usual.

**Passive:** After suffering psychic damage (from any source), you may not use the reaction ability of this item until you perform a long rest.

## Plot Devices and Intel

### Disguise

You are masquerading as a scribe, since you have some skill in writing and painting.

### Travelling Reasons

You have heard of a place called Goldenfields where you should be safe from your pursuers. Since the Tribor trail is not used very much, You will travel to Phandalin and try to get a ride to Tribor.

## Ideas for Volas Patron

Volas Patron is an Ancient One.
