---
title: "Campaign Log Prague"
source: "Game Stuff/D&D/WDnD Files/Campaign Log Prague"
modified: 2020-06-15
type: session-log
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D characters"]
words: 2173
summary: "Player-side campaign log of the WDnD (Lost Mine of Phandelver) campaign, sessions 1-15 plus a dated timeline: Phandalin, Redbrands, goblins, Thundertree, Wave Echo, Spellforge, Neverwinter, with NPC and lead notes."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/session-log"]
---

# Campaign Log

Region: [*Map*](https://drive.google.com/open?id=1twV0Si9qP1lUKYgZolAG1BlC5n-dyGrp)

**Session 15**

*Letter to ~~Halia~~ “H”*

*Dear ‘H’,*

*We have succeeded on your little errand.*

*Some of us have come back a few parts (and millisouls) less.*

*Silixe: “I totally wanted to open the chest waaay earlier, the other guys just kept holding me back. We ended up having to steal it back after we delivered it, once we found out it had been delivered to some dodgy guys”*

*We are interested in more work.  
  
Hobgoblins might attack the village. We killed their big strong scary leader but we heard them planning. Try to survive LULZ. Tell Radoth we’re totes O(O?)MW.*

*Have a nice day at the village*

*Your favorite group of adventurers :3 \<3 \<3 \<3 :3 ^^ \<:3 )~*

*\*super magic kawaii photo\**

*Kind regards,*

*SVML(I???)  
*

Stole back the chest we delivered for Halia. Went off pretty smoothly, some guards might have seen our faces but probably not. It contained some magic loot, and a letter for us. Turns out she wanted us to open it, and wants to have us work for her and help the town on the down low.

Wrote a magic reply to Halia through the stone we found in the chest. Silixe’s bugbear friend is sad :(

**Session 14**

Vola has been revived, she now has a brand new left copper leg (with a hoof at the end).  
We now have a spare diamond that is suitable for resurrection.

We are planning to go on a heist during the night, to steal the goods that we delivered previously, they somehow ended up at a crime lord's place. We want to go to Phandalin after that.  
Vola has one of Silixe’s interesting gems embedded somewhere in her chest. The other gem cannot be within 5 feet of her and we are investigating its other properties.

**Session 13**

Met bugbear king & drow elf messenger & bunch of goblins in a throne room.

Big fight in a temple where Vola cracked beneath the king’s fat butt. (! ! !)

Killed the king but needed to escape with almost dead Marat and Silixe.

Met druid R in the forest. He agreed to protect us for a while before we head to Neverwinter and ask the forest while meditating what is happening with the drow messenger.

Luvl up!

**Session 12**

9th Flamerule

Rested til morning.

Found back entrance to castle. This led to tunnels 3ft high with fallen in rubble

Currently in West room of castle

Killed 4 normal goblins; 1 magic; 1 Grick

Spider probably here

NorthWest tower has ~3 goblins (Vola heard whilst scurrying in undergrowth)

NorthEast tower has some loud shouting from a non-goblin creature (Lumpik heard)

**Session 11**

Goblins sleep at day?

Arriving at seven towers by night

Reidoth

- He knows where wave echo cave is

- There is a green dragon in Thundertree

- Drow getting the Spellforge is very serious business

- Thundertree is overrun

- Was not impressed with the party

- After hearing the news, agreed to meet us in Phandalin when we return from our trip to the Seven towers

**Session 10**

8th Flamerule

In Thundertree.

In search of the druid Radoth.

Still under attack from the blights and zombs (x2 forced into corners of room; x1 in hot pursuit of Silixe, having smashed through door).

Having whittled the wooden blights down to a scant few (~1 left? In retreat? Mostly smashed to twigsome bits by Marat), there still creeps a vine creature. The bushes are all a-rustle. What other undergrowth has yet to snare us?! Wily vine and wrathsome root...

**Session 9**

### 5th Flamerule - Arrive at Neverwinter 

Marat paid guild fees 5gp for a month

Lumpik daily expenses

Temple has +1 to Bugbear inventory

Vola was busy with some scribing and forge work for the day

Marats cart and horse is in a neverwinter stable

Lumpik made a 10gp luck donation and got all dusty from a skeleton explosion

Green dragon near Thundertree

Chasm in Neverwinter in which Drow dwell

Gundren is with King Grol in the Seven towers castle

Iverna Nightbreeze has joined the party

We took a boat to near Thundertree THEN SUDDENLY ZOMBIES

- Covered in nasty plants

&nbsp;

- Woody blights

En route to Thundertree, a tower was visible in the distance, but we forged on.

### 25th Kythorn 1482

Location: [*Phandalin*](https://docs.google.com/document/d/1rOUU5HkZhwF_FK7hEc2QvQnFOAk-pjrekOCrxXFxJ0M/edit?usp=sharing)

**Session 8**

RedCloaks (30 Total):

12 dead

3 captured

2 escaped

13 unaccounted for

Bugbears captured: 1

Sent 3 bruisers after Tom the Pious, they haven't returned yet.

We found :

x1 fireball scroll on redcloak leader, in Lord Albrek's handwriting.

x1 scroll in magical script (author unidentified)

Unlocked our magic items.

We had a funeral for the friendly + not so friendly dead.

Had town hall meeting with everyone.

After meeting approached by Priestess of luck ([*Sister Garaele*](https://drive.google.com/open?id=1BXp24fTiEL606NO2wfAKyW3O9gCSLiEk)), she told us about the banshee she was supposed to talk to to find a magic item, gave us a present (silver comb) for her so we can bribe her to help us. She’s an informant for a secret org, she only told Silixe who.

Banshee info:

- Are ancient and incredibly vain

- Hate most races, especially elves

- Must appear for you

- Must flatter it until it likes you enough to answer your questions

Silixe tried to steal the glass staff that Sildar brought to the meeting (found under manor), but Tyon the valiant proved his mettle by thwarting him,

We will get lots of gold for finding [*Gundren*](https://drive.google.com/open?id=1CGU32eYUbJnqQK71A6ZFjFpqwQSRZcG9), Sildar prefers him alive, but dead is also ok

3 leads for finding Gundren

- The captured bugbear should know where spider is

- Banshee in Conyberry, we got a silver comb to gift her

- Druid at Thundertree (ruin)

Questions:

1.  Where is GlassStaff/[*Albrek*](https://drive.google.com/open?id=1hg-VJM3oUnYDUQsA7EOS963bSn5vpogi)/GreenCloak?

2.  Why did he run?

3.  Where are the remaining RedCloaks? Will they harass the town again?

4.  Where is Gundrun? (was captured by Spider most likely)

    1.  BugBears should know (see section above for more leads)

    2.  Radoth ([*Carp’s*](https://drive.google.com/open?id=1FqAfK1bE8OXedrV6ANriCkNfZUzftq-4) uncle/family friend of dwarf fam) may have info - working a gig in destroyed town Thundertree (to N of Phandalin)

5.  Wats dat staff du tho??????????????!!!?????????????!!!1????????eleven1?

6.  Where is The Spellforge?

7.  Is Sister Garael acting against us? (Silixe: “naaah”)

**Session 7**

The party reentered the manor via the secret cave entrance. They encountered the Nothic again and managed to drive it off. It let them know that ‘The Glass man” is not home.

They then discovered a workshop filled with magical apparatus, finding several items of interest, as well as a few letters.

Searching one of the adjoining rooms, a goblin escaped from them and ran.

While chasing the goblin, Tom the pious arrives to tell them the village is being attacked by the Redcloaks. We told him to chase the goblin then left.

The party opted to return to Halia Thornton to get some help from her Bruisers. Halia was helpful and gave them 9 men, also letting them know that Sildar had not been seen since the attack started.

A confrontation at the manor took place. The redcloaks were using a captive green cloaked wizard to lob fireballs at the town. The green cloak guy escaped + teleported away during the encounter. The party bested the Redcloaks but several of the Bruisers died in the struggle. Some captives were taken:

- A Bugbear, hurt probably by the Redcloaks (Gorg)

- 2 Redcloaks (1 surrendered) (1 got eldritched twice)

2 of Halia’s bruisers died

**Session 6**

Group returns to village and inn.

The red-cloaked mercenaries have been attacking the village.

The villagers are sheltering in the mining guild.

x3 go to the shrine of luck to ask questions

Vola goes to Yimig in jail

X3 g to mining guild:

- Sister Graele blessing

- Halia absent?

Somewhere group discovers the Manor owner died at home from orcs.

Mummy in middle sarcophagus:

Ancient red dress

Hands folded together across chest

Encrusted signet ring - snaffled by Lumpik

Injure and scare off Nothic. Mixed sympathies within group.

Cross bridges to get to other side of pit. Can see shuttered windows to rooms (or did I just imagine this?)

Rotting ropes.

Further reaches of cave beyond hall-cave:

Long Hall, 2 doors at end.

Left unlocked leads to a dining room of some kind. Food is fresh on the table and candles are lit. The dwellers have just recently fled.

Right locked.

We force or pick the right door revealing a wizards office full of arcane eclectic and magical items.

Wizard’s Office

Read letters.

Lady Sildar said she sent Albrek and he got lost.

From letters appears:

Albrek gets assignments from Spider.

“The Alliance” was sent by Albrek to Phandelin

**Session 5**

At the Manor.

We wander further in, defeat skellies and mercenaries.

Group finds the room with 3 sarcophagi.

We navigate through the room with the spikes.

We are reunited with Marat.

Find & rescue village hostages:

Lisa

Myena

X2 children

Monster in the adjoining grand-hall-cave room.

Hates salt, refused salted meat.

Feeds on flesh. Necrotic in nature.

Telepathic.

**Session 4**

(In Phandaliln; Marat is poisoned and absent while he recovers and the party is down to 3)

Silixe:

Goes to shrine. Meets elf of church of Tannorn. Dwarves present?

Lumpik:

Investigates farm.

Finds old homeless man attacked.

‘Thebes’ - halfling?

Something is said about a druid in Thundertree.

Farmer Anna Hadernoth

Vola:

Rootles around for info on Gundren, Spellforge.

Wife of murdered carpenter was assaulted and taken somewhere.

Attempts to list those associated with murder.

Attempts to list people for militia recruitment.

Spider the elf in Thundertree

The washer-women that Vola met (Lisa and Dorothy) have been missing last 24h.

A siege is planned on the manor.

Some bruisers are recruited.

Navigating to the manor. (Vola had watched redcloaks enter the hideout at some point, discerning a secret entrance in the ruins)

The Siege:

\[I have written a note “13/16 redcloaks left” - with a later estimate of 30 redcloaks this appears an incorrect estimate.\]

1st Room:

Pool of water with fountain - lions head, motif of the family of the manor.

A glowing stone is cast to the bottom, revealing a 1x1 ft lump - not a rock.

The pool is rather deep.

\[some rough maps available\]

**Session 3**

Groll - King Bugbear

Clarg - Bugbear

Yimig - goblin hostage

Spider - Dark Elf

Yimig the goblin pledges allegiance to Ogma, offered to fight for us, we declined. He is kept on a chain at present.

Return to village Phandalin.

Lady Sildar Hallwinter has taken over and deposed the town mayor.

(I wrote a note: owed 25 gold from Lady Hallwinter, unsure if that was paid to us)

**Session 2**

“Groll” - King Bugbear

Have stayed 1 night in Phandalin.

Group finds out about goblin cave through either Tyon/Glib \> we may track the goblins back there.

Group decides to go to goblin cave after rest.

Happen upon Tyon (I think this was sesh 2)

Goblin wave cave:

Marshy on outside.

Near cave mouth, on right side there is a wolf room with wolves on chains. Their chains do not permit them to exit their room.

There is a kerfuffle with a goblin setting off the wave trap. Glib pulls a fast one and slips off in the confusion of fighting. Marat kills Glib.

We find Lady Hallwinter in a room accessible by both the cave bridge and a hidden passage just to the left. (rough map available)

Goblins

Encountered: 15

Killed: 10

Unconcious & captive: 1

Baby: 3

Peasant goblin: 1

**Session 1**

Travellers encounter each other on their path, toward the town of Phandalin.

Neverwinter. Golden Fields. Tribor Trail. Phandalin.

Attacked by a gang of goblins, killed all but one: Glib.

Brought Glib as captive with us on wagon train to Phandalin.

Red Caped mercenaries are linked with the murder of a carpenter.

They have been loose on the town for ~2 wks, and the villagers are fearful of them.

Travellers rest in 2 inns in Phandalin.

3 of group rest in inn near town centre.

Vola stays in slightly more hostile, more expensive: “The Sleeping Giant Taphouse” run by dwarves.

- Encounters Red Cape: “Vodin”

- The Red Capes are regulars here

- Inn keeper under pressure/threat (has 2 black eyes), may have been given protection money

### 24th Kythorn 1482

Party went into the Redbrand hideout through the stairway under the manor.

Marat joined later via the cave entrance with the help of Carp Alderleaf

### 23rd Kythorn 1482

In the evening, the party encountered the Redbrands in the forest.

### 22nd Kythorn

Travelled from the Goblin hideout to Phandalin

### 21st Kythorn

The party cleared out the Goblin hideout with help from Tyon and Glib. Rescued Sildar Hallwinter.

### 20th Kythorn

The party spent the day gathering clues in Phandalin. Vola met Lisa the washwoman.

### 19th Kythorn

The party is ambushed by goblins along the Triboar trail. Glib is taken captive.

### 16th Kythorn

Leaving Neverwinter for Phandalin with a wagon train.
