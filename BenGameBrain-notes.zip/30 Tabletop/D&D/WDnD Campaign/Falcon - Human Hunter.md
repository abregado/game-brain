---
title: "Falcon - Human Hunter"
source: "Game Stuff/D&D/WDnD Files/Falcon - Human Hunter"
modified: 2021-10-24
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]", "[[D&D Homebrew]]"]
concepts: ["WDnD campaign", "D&D characters"]
words: 1205
summary: "Character sheet for Falcon, a human Ranger 3/Rogue 2 folk hero with skills, features and spells."
tags: ["area/dnd", "project/d-d-homebrew", "project/wdnd-campaign", "type/character"]
---

# Falcon

**Human Ranger 3 / Rogue 2 / Folk Hero**

**Neutral Good**

### **Attributes and Modifiers**

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 11      | 16      | 13      | 14      | 15      | 10      |
| +0      | +3      | +1      | +2      | +2      | +0      |

<table style="width:100%;">
<colgroup>
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
<col style="width: 16%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>AC</strong></th>
<th><strong>HP</strong></th>
<th><strong>HD</strong></th>
<th><strong>Walk</strong></th>
<th colspan="2"><strong>Jump</strong></th>
</tr>
<tr class="odd">
<th>15</th>
<th>48</th>
<th><p>3d10</p>
<p>2d8</p></th>
<th>30ft</th>
<th>5ft</th>
<th>11ft</th>
</tr>
</thead>
<tbody>
</tbody>
</table>

### **Saving throws**

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| \+      | \+      |         | \+      |         |         |

### Proficiencies (+2 bonus):

**Perception, Athletics, Insight, Animal Handling, Nature, Medicine, Investigation**

**Light and Medium armor, simple and martial weapons, Shields, Thieves tools, Artisan tools (whitling), Land Vehicles**

### Proficiencies (+4 bonus):

**Stealth, Survival**

### Languages

**Common**

### Sharpshooter

You have mastered ranged weapons and can make shots that others find impossible. You gain the following benefits:

- Attacking at long range doesn't impose disadvantage on your ranged weapon attack rolls.

<!-- -->

- Your ranged weapon attacks ignore half and three-quarters cover, when you are within short range.

### Archery

You gain a +2 bonus to attack rolls you make with ranged weapons.

### Favored Enemy (Beasts)

You have advantage on Wisdom (Survival) checks to track Beasts, as well as on Intelligence checks to recall information about them.

### 

###  

### Natural Explorer

When you make an Intelligence or Wisdom check related to navigating in a forest or to do with the flora or fauna in a forest, your proficiency bonus is doubled if you are using a skill that you’re proficient in.

While traveling for an hour or more in forests, you gain the following benefits:

- Difficult terrain doesn’t slow your group’s travel.

- Your group can’t become lost except by magical means.

- Even when you are engaged in another activity while traveling (such as foraging, navigating, or tracking), you remain alert to danger.

- If you are traveling alone, you can move stealthily at a normal pace.

- When you forage, you find twice as much food as you normally would.

- While tracking other creatures, you also learn their exact number, their sizes, and how long ago they passed through the area.

### Rustic Hospitality. 

You can find a place to hide, rest, or recuperate among other commoners, unless you have shown yourself to be a danger to them.

Personality

### Traits

Casual confidence. I overcome most challenges I meet with little effort.

### Ideal

People should treat each other how they would like to be treated.

### Bond

The forest must remain in balance. This is why I guide nobles on their hunts, and scare away those who do not hunt with me.

### Flaw

I am indifferent to the greater changes in the world.

# 

#  

# Feats and Abilities

### Cunning Action

**As a bonus action:** Take the Dash, Disengage, or Hide action.

### Sneak Attack

You know how to strike subtly and exploit a foe’s distraction. Once per turn, you can deal an extra 1d6 damage to one creature you hit with an attack if you have advantage on the attack roll. The attack must use a finesse or a ranged weapon.

You don’t need advantage on the attack roll if another enemy of the target is within 5 feet of it, that enemy isn’t incapacitated, and you don’t have disadvantage on the attack roll.

### Primeval Awareness

Expend one spell slot. For one minute per level of the slot, you can sense if creatures of one type (aberrations, celestials, dragons, elementals, fey, fiends, and undead) are within a 1 mile of you.

### Colossus Slayer

Once per turn, when you hit a creature with a weapon attack, the creature takes an additional d8 damage if it's already below its maximum HP.

# Inventory

### Elven Longbow (+1)

Longbow. Ranged (150/600). Heavy, Two-Handed. +6 to hit, 1D8+4 piercing damage. 20 arrows remaining. Attacks from this weapon are considered magical.

### Cloak of Elusive Prey

**As a free action:** When you end your turn at least 20 feet away from where you originally began your turn. Attacks made against you until your next turn are made with disadvantage. Dexterity saving throws you make until then are made with advantage. Three uses. Recharages with a long rest.

### Shortshord

Shortsword.

### Leather Armor

Light Armor. AC 12 + Dexterity modifier

### Rope

50ft of rope

### Hunting supplies

2 Snare traps for catching beasts of size Small.

### Adventuring Clothes 

Durable, washable. Unlikely to be destroyed while delving in the depths of a dungeon.

### Artisan Tools (Whittling)

For Whittling wood.

# Plot Devices and Intel

### Hunting Manor

You have a secret manor and grounds in the Neverwinter woods. You and your party can use it as a safe haven. When resting at the manor, Hit die spent to heal count as rolling maximum.

# 

#  

# Spells

3 Spell slots of 1st Level

### Hunters Mark - Lvl 1

**As a Bonus action:** You choose a creature you can see within 90ft and with a word, mystically mark it as your quarry.

For the next hour, you deal an extra 1d6 damage to the target whenever you hit it with a weapon attack, and you have advantage on any Wisdom (Perception) or Wisdom (Survival) check you make to find it. If the target drops to 0 hit points before this spell ends, you can use a bonus action on a subsequent turn of yours to mark a new creature.

### Snare - lvl 1

**As a 1 minute ritual:** As you cast this spell, you use 25ft of rope to create a circle with a 5-foot radius on the ground or the floor. When you finish casting, the rope disappears and the circle becomes a magic trap.

This trap is nearly invisible, requiring a successful Intelligence (Investigation) check against your spell save DC to be discerned.

The trap triggers when a Small, Medium, or Large creature moves onto the ground or the floor in the spell’s radius. That creature must succeed on a Dexterity saving throw or be magically hoisted into the air, leaving it hanging upside down 3 feet above the ground or the floor. The creature is restrained there until the spell ends.

A restrained creature can make a Dexterity saving throw at the end of each of its turns, ending the effect on itself on a success. Alternatively, the creature or someone else who can reach it can use an action to make an Intelligence (Arcana) check against your spell save DC. On a success, the restrained effect ends.

After the trap is triggered, the spell ends when no creature is restrained by it.

### Speak with Animals - lvl 1

**As a 10 minute ritual:** You gain the ability to verbally communicate with and comprehend beasts for the following 10 minutes.

The knowledge and awareness of many beasts is limited by their intelligence, but at minimum, beasts can give you information about nearby locations and monsters, including whatever they can perceive or have perceived within the past day. You might be able to persuade a beast to perform a small favor for you, at the DM’s discretion.
