---
title: "Phandalin"
source: "Game Stuff/D&D/WDnD Files/Phandalin"
modified: 2020-04-14
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]"]
concepts: ["WDnD campaign"]
words: 584
summary: "Town sheet for Phandalin (Lost Mine of Phandelver) with shops, NPCs, services and prices, prisoners and travel times, with Drive links to images."
contains_external_material: "Locations and NPCs taken from published Lost Mine of Phandelver; Ben adds prices and layout"
tags: ["area/dnd", "project/wdnd-campaign", "type/campaign-prep"]
---

# Phandalin

Region - [*Map*](https://drive.google.com/open?id=1twV0Si9qP1lUKYgZolAG1BlC5n-dyGrp)

Town - [*Map*](https://drive.google.com/file/d/1PwgQ8ZdnBPOj1qwazsllwhe9dtmBPTyw/view?usp=sharing)

**[Phandalin](#phandalin) 1**

> [Unplaced NPCs](#unplaced-npcs) 1
>
> [Locations](#locations) 1
>
> [Stonehill Tavern](#stonehill-tavern) 1
>
> [Barthens Provisions](#barthens-provisions) 2
>
> [Edermath Orchard](#edermath-orchard) 2
>
> [Lionshield Coster](#lionshield-coster) 2
>
> [Alderleaf Farm](#alderleaf-farm) 3
>
> [Shine of Luck](#shine-of-luck) 3
>
> [The Sleeping Giant](#the-sleeping-giant-burnt-down) 4
>
> [Townmaster’s Hall](#townmasters-hall) 4
>
> [Travel Times](#travel-times) 4

## Unplaced NPCs

None

## Locations

### Stonehill Tavern

**NPCs**

Toblen Stonehill - Owner/Bartender - [*Image*](https://drive.google.com/open?id=1mAiJYhdYb8-WSV8mbG0zjdQCvDg-362-)

Pip Stonehill - Owners son - Rumor

Trilena Stonehill - Owner/Cook - Rumor

| **Service**                                       | **Cost** |
|---------------------------------------------------|----------|
| Single bed room, board and meals                  | 1gp      |
| Round of drinks on a busy night (rumor mongering) | 3gp      |
| Stabling (per animal per night)                   | 1gp      |

### Barthens Provisions

Barthen’s is the biggest trading post in Phandalin. Its shelves stock most ordinary goods and supplies, including backpacks, bedrolls, rope, and rations. The place is open from sunup to sundown.

**NPCs**

Elmar Barthen - Owner - [*Image*](https://drive.google.com/open?id=1BoqRpgylZgOQeZRar9FkhASv5QJttTfX)

| **Stock**                                                                         | **Cost**   |
|-----------------------------------------------------------------------------------|------------|
| Supplies from the PHB with value less than 25gp (50% change), no weapons or armor | Up to 25gp |

### Edermath Orchard

A tidy little cottage beside an apple orchard.

**NPCs**

Daran Edermath - Owner - [*Image*](https://drive.google.com/open?id=1C2oDj7JeYiNry4ILjxsTo0PrbianiCeT)

### Lionshield Coster

This building is owned by the Lionshields, a merchant company based in the city of Yartar, over a hundred miles to the east. They ship finished goods to Phandalin and other small settlements throughout the region, but this outpost has been hard hit by banditry.

**NPCs**

Linene Greywind - Owner - [*Image*](https://drive.google.com/file/d/1jr_dq5UTPYCzb0DkeA8w5Z-liCjk47Kl/view)

Phandalin Miner’s Exchange

The Miner’s Exchange is a trading post where local miners have their valuable finds weighed, measured, and paid out. In the absence of any local lord or authority, the exchange also serves as an unofficial records office, registering claims to various streams and excavations around the area.

**NPCs**

Halia Thornton - Owner - [*Image*](https://drive.google.com/open?id=1AJnsRtA577e_RdBDvqflvgVmShZOtE7P)

| **Service**                                                               | **Cost** |
|---------------------------------------------------------------------------|----------|
| Buys rare metals and gems                                                 | 70%      |
| Sells rare metals and gems                                                | 110%     |
| Currency conversion to Neverwinter coinage (thumbs, crowns, gears, plats) | 90%      |

### Alderleaf Farm

A large farm on the outskirts of town run by a halfling family

**NPCs**

Quelline Alderleaf - Owner

Carp Alderleaf - Son (5yrs) where is his image?? He so cute

### Shine of Luck

Phandalin’s only temple is a small shrine made of stones taken from the nearby ruins. It is dedicated to Tymora, goddess of luck and good fortune.

**NPCs**

Sister Pyria Garaele - Priestess of Tymora

| **Service**                           | **Cost** |
|---------------------------------------|----------|
| Healing (full hp/level of exhaustion) | 25gp     |
| Curse removal                         | 150gp    |
| Resurrection (Raise dead)             | 1500gp   |

### The Sleeping Giant \[Burnt down\]

A rundown taphouse and flophouse in the middle of town.

### Townmaster’s Hall

A strong building built mostly from stone from the old town walls.

**NPCs**

Sildar Hallwinter - Townmaster and Lords Alliance representative

**Prisoners**

2x Redbrand ruffians

Iarno Albrek - Leader of the Rebrands

Bugbear

## Travel Times

| **Destination** | **Trail type**          | **Distance**        |
|-----------------|-------------------------|---------------------|
| Neverwinter     | Rough trail / Good road | 53 miles / 63 miles |
| Connyberry      | Rough trail             | 87 miles            |
| Leilon          | Rough trail / Good road | 53 miles / 43 miles |
|                 |                         |                     |
|                 |                         |                     |
|                 |                         |                     |

[***Red Larch - undiscovered***](https://drive.google.com/open?id=1_trlrcddOiZriYpAMSj-grlLU1YXQo730EJOZ67N8SQ)
