---
title: "WDnD Lisa - Washwoman"
source: "Game Stuff/D&D/WDnD Lisa - Washwoman"
modified: 2020-02-12
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]"]
concepts: ["WDnD campaign", "Redbrands"]
words: 582
summary: "NPC player sheet for Lisa, an old washwoman kidnapped by the Redbrands and held in the Townmaster's Hall prison, with plot hooks for party rescue."
tags: ["area/dnd", "project/wdnd-campaign", "type/character"]
---

# Lisa \_\_\_\_\_\_\_\_

**Human Washwoman - Neutral Good**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 10      | 8       | 12      | 14      | 12      |
| -1      | +0      | -1      | +1      | +2      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 12     | 12     | 2d6    | 20       | 2        | 4   |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +0      | -1      | +3      | +5      | +2      |

### Proficiencies:

**History (Intelligence) +2**

### Special Rule: Old Woman

You are over 70 years old. If you are asked to take any Strength or Dexterity test, you fail automatically.

Personality

### Traits

I know everyone in the town by their first name, but very few of them know mine.

### Ideal

Hard workers should be respected, especially by young people who don't know what hard work is.

### Bond

I’ve lived my whole life in Phandalin, Im not going to let some bandit scum take it over!

### Flaws

Im always getting involved even though Im old.

Im a terrible gossip.

# Equipment

Rolling Pin. +2 to hit, D4+2 bludgeoning damage. All enemies gain advantage to hit your after your strike.

#  

# Plot Devices and Intel

### The town of Phandalin

A frontier town, Phandalin has been rebuilt a bunch of times after being destroyed. You have been living here whenever possible for your whole life. You cant really remember, but maybe you were even born here.

### That nice young lady

A day or so ago a young lady came to town. Her name was Vola (Fionas Character). A nice young lady who seemed completely normal. You have been alive long enough to know better than that. Although she was definitely hiding something, but you are sure she has a good heart. She spent some time chatting with you.

### Why am I locked up in a cell?

The Ruffians came to your house to threaten you. Apparently they found out that you had been taking to the new adventurers in town and they wanted to shut you up. You got lucky and managed to knock one out with your rolling pin, so they kidnapped you instead.

### Where do the slaves go?

You were blindfolded and taken to this place. It looks like the prison that is under the Townmasters hall. You are locked in a cell with some other prisoners, who are also from the town..

### Secret Door

You have been paying attention when the guards come and go. Some of them mentioned a secret door in the next room which was “acting up” again. None of them like to use the door because there is a creepy “eye monster” which harasses them when they go through there.

### Revenge

One of these bandits has already suffered your wrath. You want to show them not to mess with you and your town. If you get a chance to hit one of them when they are distracted, you are going to do your best.

### The players find you(option 1)

They will enter a prison room, and when they speak to you, just jump in.

### You sneak out (option 2)

If the heroes do not go into the prison, then they will find you a bit later on.
