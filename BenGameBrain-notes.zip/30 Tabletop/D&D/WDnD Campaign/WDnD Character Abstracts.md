---
title: "WDnD Character Abstracts"
source: "Game Stuff/D&D/WDnD Character Abstracts"
modified: 2020-02-12
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[WDnD Campaign]]"]
concepts: ["WDnD campaign"]
words: 648
summary: "Six short character background and personal-goal templates (Mercenary, Noble, Scoundrel, Researcher, Aspiring hero, Hermit) for a frontier-themed campaign."
tags: ["area/dnd", "project/wdnd-campaign", "type/campaign-prep"]
---

## Mercenary

### Background 

You are trained as a solder and healer, and travelled with a mercenary company for several years. Recently you became disillusioned with your fellow soldiers who seem to enjoy their authority at the expense of the people they’re paid to protect. You then disobeyed a direct order and followed your conscience, resulting in your temporary suspension from active duty.

### Personal Goal 

News has it that there are many gangs and bandits taking advantage of commoners out on the fringe. As a person of courage and principle, you feel that stopping such villainy is a worthy goal.

## Noble

### Background

Your family is no stranger to wealth, power and privilege. In the glory days, your parents were a count and countess of a large estate. After a natural disaster 30 years ago, the estate was destroyed. You family moved to their small but comfortable townhouse in the city. As an adult, you stand to inherit a meaningless title and an empty piece of wilderness.

### Personal Goal

You have heard that villages on the fringe are in need of a civilized influence, someone to take the reigns and bring law and order. Someone like you.

## Scoundrel 

### Background

You grew up in a small village with your family. When a small gang of mercenaries started hanging out in your village, instead of being bullied like the rest of the citizens, you offered to help them with small jobs. Doing so bought you and your family protection, and also some decent earnings. Recently, something changed because the mercenaries tried to have you killed.

### Personal goal

The ruffians won't be expecting you to return with help so you hitchhiked to the city to look for people to help you get your revenge.

## Researcher

### Background

You have spent your life dedicated to Oghma, all-seeing elven god of knowledge. There was never much reason to leave the library temple in the city until recently, when ancient magic items, long dormant, began to reawaken. The temple elders have decided it is time for you to journey to the fringes to be a symbol of Oghma for the people.

### Personal goal

Adventurers now report that out in the wilderness, ancient powers have begun to stir. Pursuit and acquisition of knowledge is for the benefit of all, and the only truly worthy goal. You will go into the world, discover lost knowledge, and use that knowledge for the good of all.

## Aspiring hero

### Background

Your family used to live a comfortable life in a frontier town. Then disaster struck and everyone was forced to flee back to the city. You spent the rest of your life working hard as a refugee in a city filled with refugees. In ancient times, this sort of existence was impossible because of the great heroes who protected the realm. You know you are destined to be such a hero one day.

### Personal Goal

On the fringes the people need a symbol and protector, one that looks out for them and drives off dangerous forces. Once you become such a person, you hope to liberate your home village from the dark force which has taken it over.

## Hermit

### Background

You grew up in the wilderness around some small villages on the fringe. You took everything you need to survive from the forest, so you know your way around natural places. When you needed something that the wilderness could not provide, you earnt some coin doing manual labour for farmers and peasants.

### Personal Goal

Recently, a lot of bandits, monsters and thugs have started visiting the villages in your area. Normally you would stay out of any trouble and let history run its course, but some of the innocents who were kind to you were recently attacked. Inaction and solitude is no longer an option.
