---
title: "WDnD Glib - Captured Goblin"
source: "Game Stuff/D&D/WDnD Files/WDnD Glib - Captured Goblin"
modified: 2020-02-12
type: character
area: dnd
status: "played/used"
projects: ["[[WDnD Campaign]]"]
concepts: ["WDnD campaign", "Cragmaw Hideout"]
words: 652
summary: "One-shot-style NPC character sheet for a captured goblin slave that a player controls during the Cragmaw Hideout section, with plot intel and personalities of the party as seen by the goblin."
tags: ["area/dnd", "project/wdnd-campaign", "type/character"]
---

# Glib

**Goblin Raider - Chaotic Evil**

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 14      | 10      | 10      | 8       | 8       |
| -1      | +2      | +0      | +0      | -1      | -1      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |     |
|--------|--------|--------|----------|----------|-----|
| 13     | 7      | 1d6    | 30       | 4        | 8   |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +2      | +0      | +0      | -1      | -1      |

### Proficiencies:

**Simple Weapons, Light Armor, Shortbows**

**Stealth (Dex) +6**

### Languages

**Goblin**

### 

### Nimble Escape

You can take the Disengage or Hide action as a bonus action on each of your turns.

Personality

### Traits

You can’t help but laugh out loud when someone gets injured.

### Ideal

You see everything from the Master-Slave perspective.

### Bond

I must not make my current master angry

### Flaw

You are a perfect goblin in every way. A shining example of how goblins should be!

#  

# Plot Devices and Intel

### Everything is Slavery

You were the slave of your parents until you were old enough to hold a weapon. Then you were the slave of the clan boss until he was killed by the next boss, and the next boss. Masters come and go, and the best a goblin can hope for is to be master of some, and to have a powerful master so they can be more powerful when they kill them.

### Current Boss

The boss is a bugbear named Klarg. He is very big and strong. Klarg is the slave of the King who lives in a magical castle. Klarg took the boss power from Yeemik, who is your master (used to be your boss, now demon lady is boss). Yeemik wants to kill Klarg like a good goblin.

### The Cragmaw Hideout

There are many Goblins living in a cave with you. More than 6 hands (30+). Not all of them are warrior Goblins. They also have some big Wolves.

You know the way to the Hideout. There are many traps to slow people down and make noise so the goblins know you are coming. You are immune to the traps because you know them all.

### The message

Klarg got a message from King some days ago asking to capture Dwarf and send him to King. Black Spider is big boss of King. Dwarf already taken back to Hideout with Old Shiny Human.

### The two captives

They are being held in the Eating Cave. You know where it is and can show the demon lady where it is.

### Your mission So far

You were sent to capture the Dwarf. You did so, but Klarg got angry because your group left evidence by the roadside. You were sent back again to clean up and stop others from following.

### Bighammer (Bilka)

The man who knocked you out and took you as a slave. He is **WEAK** and doesnt want to be your master, but is very proud of defeating you.

### Shiny magic (Tom)

This one made loud talk with Bighammer over who owns you but also does not want to be your master. He can use magic but seems very **STUPID**.

### Sharptooth (Martin)

You didnt see this one until you woke up. He looks sharp even when he does not have his knives out. Very sneaky but he doesnt seem to care about you at all.

### Demon Lady (Fiona)

A **SCARY** lady. She has special magic to talk with your brain. She also used magic to make herself look like a demon. You think it was to scare you into being her slave. She seems like a **STRONG** master and you respect her.
