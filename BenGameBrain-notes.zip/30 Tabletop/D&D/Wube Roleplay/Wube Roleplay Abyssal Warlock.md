---
title: "Wube Roleplay Abyssal Warlock"
source: "Game Stuff/D&D/Wube Roleplay Abyssal Warlock"
modified: 2019-06-13
type: character
area: dnd
status: "designed"
projects: ["[[Wube Roleplay]]", "[[D&D One-shots]]", "[[D&D Homebrew]]"]
concepts: ["Wube Roleplay (D&D at work)", "easyroleplay.com", "D&D homebrew characters"]
words: 1043
summary: "One-page premade level 3 Abyssal Warlock character sheet with abilities, spells and a Quasit familiar stat block, phrased as simple action cards."
contains_external_material: "Rules text is adapted from 5e SRD warlock spells and Quasit statblock, reworded"
tags: ["area/dnd", "project/d-d-homebrew", "project/d-d-one-shots", "project/wube-roleplay", "type/character"]
---

You are a seeker of a knowledge that lies hidden in the fabric of the multiverse. Through pacts made with your demonic patron, you unlocked magical effects, subtle and spectacular. Darkness shrouds both your intent and visage, and the Abyss granted you a Familiar to do your bidding.

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 13      | 15      | 9       | 11      | 14      | 16      |
| +1      | +2      | -1      | +0      | +2      | +3      |

| **AC** | **HP** | **HD** | **Walk** | **Jump** |      |
|--------|--------|--------|----------|----------|------|
| 12     | 15     | 3D8    | 30ft     | 6ft      | 13ft |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +1      | +2      | -1      | +0      | +4      | +5      |

### Major Skills:

**Deception (Charisma) +5**

**Insight (Wisdom) +4**

**Sense Enchantment (Insight Talent)**

**Action:** When you observe or interact with a creature to closely examine it by touch and smell, you can determine if its mood or behavior is being influenced by a spell or other magical effect.

### Pact of the Chain

When you perform this 10 minute ritual a Quasit is summoned from the Abyss to act as a familiar. While your familiar is within 100 feet of you, you can communicate with it telepathically. It obeys your commands and acts independently of you.

### Fiendish Bond

**Action:** Until the start of your next turn, you can see through your familiar's eyes and hear what it hears.

### Armor of Shadows

**Action:** You bind demonic energies to your body. Your AC becomes 15 for 1 hour, or until you don any armor.

### Dark One’s Blessing

When you reduce a hostile creature to 0 hit points, you gain 6 temporary hit points.

Pact Magic

Your magic comes from a deal made with an otherworldly fiend. As long as you keep up your end of the deal, you can wield a power that was never meant for mortals.



### Friends

**Action:** For 1 minute, you have advantage on all Charisma checks directed at one creature of your choice that isn’t hostile toward you. When the spell ends, the creature realizes that you used magic to influence its mood and becomes hostile toward you.

### Agonizing blast

**Action:** Make a ranged spell attack against a target within 120ft with +5 to your roll. On a hit, the target takes 1D10+3 force damage.



### Witch bolt (2nd level)

**Action:** Make a ranged spell attack with +5 against a creature you can see. On a hit, the target takes 2d12 lightning damage and the bolt has locked on.

### Locked bolt

**Action:** Deal 2d12 lightning damage to a target you have locked onto as long as it is in range and you still have a hand free. This does not cost a spell slot.

### Hellish Rebuke (2nd Level)

**Reaction when you are damaged:** The creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw (DC 13). It takes 3d10 fire damage on a failed save, or half as much damage on a successful one.

### Ray of Enfeeblement (2nd level)

**Action:** A black beam of enervating energy springs from your finger toward a creature within 60ft. Make a ranged spell attack against the target with +5. On a hit, the target deals only half damage with weapon attacks that use strength for the next minute.

### Invisibility (2nd Level)

**Action:** A creature you touch becomes *Invisible* for 1 hour or until you break concentration. Anything the target is wearing or carrying is *Invisible* as long as it is on the target's person. The spell ends if the target attacks or casts a spell.



# 

#  

# Quasit

Tiny fiend (demon), chaotic evil

### Statistics

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 5       | 17      | 10      | 7       | 10      | 10      |
| -3      | +3      | +0      | -2      | +0      | +0      |

| **AC** | **HP** | **Walk** |
|--------|--------|----------|
| 13     | 7      | 40ft     |

### Skills

**Stealth (Dexterity) +5**

### Demonic

The quasit is resistant to cold, dire, lightning, bludgeoning, piercing, and slashing From non-magical Attacks. It is immune to poison damage and the *Poisoned* condition.

### Darkvision

The quasit has Darkvision out to 120ft, meaning it can see in total darkness as if it was dim light, but can not see color.

### Abyssal Language

The quasit can speak in the Abyssal tongue as well as Common.

### Invisibility

The quasit is magically invisible unless it attacks, uses Scare, until its concentration ends or unless it wants to be seen. Any equipment the quasit wears or carries is invisible with it.

### Magic Resistance 

The quasit has advantage on saving throws against spells and other magical effects. If within 10ft, then this effect is also gained by its master.

### 

###  

### 

### 

### Poison attack

**Action:** Make a melee weapon attack at: +4 to hit causing 1d4+3 piercing damage plus 2d4 poison damage on a hit. The target must succeed on a Constitution saving throw (DC 10) or become poisoned for 1 minute. The target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.

### Scare

**Action:** Once per day, one creature of the quasit's choice within 20 ft must succeed on a DC 10 Wisdom saving throw or be *Frightened* for 1 minute. The target can repeat the saving throw at the end of each of its turns, with disadvantage if the quasit is within line of sight, ending the effect on itself on a success.

### Shapechanger 

**Action:** The quasit can polymorph into a beast form that resembles:

- a bat (speed 10 ft. fly 40 ft.)

- a centipede (40 ft., climb 40 ft.)

- a toad (40 ft., swim 40 ft.)

- its true form.

Its statistics are the same in each form, except for the speed changes noted. Any equipment it is wearing or carrying isn't transformed. It reverts to its true form if it dies.
