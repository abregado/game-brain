---
title: "Wube Roleplay World Summary"
source: "Game Stuff/D&D/Wube Roleplay World Summary"
modified: 2019-06-07
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[Wube Roleplay]]"]
concepts: ["Wube Roleplay (D&D at work)"]
words: 421
summary: "Setting summary as Six Truths (post-cataclysm world, returning magic, Lords Alliance, pioneer optimism) plus the one-shot premise of an adventuring guild commission to a troubled village."
tags: ["area/dnd", "project/wube-roleplay", "type/campaign-prep"]
---

# The Six Truths

### Gods are real 

We know this because within written history they were forced walked among us. The strongest returned to the celestial planes to rule. The rest were destroyed, or so it is told. Pious citizens are guided by their gods to effect change in the world. Nobody doubts that the gods exist.

### Magic and Society were sundered

100 Years ago there was a cataclysm which stopped magic working. This lasted for 10 years, after which practitioners could slowly start to harness magic once again. Civilized society barely survived as it had become dependant on magic. Only in the largest cities were people safe, but these were besieged by refugees.

### The wilderness is deadly

30 years ago, the local area was hit with another disaster when a volcano erupted. Since then, the wilderness has been even more dangerous than the post cataclysm times. Due to the two disasters, nature and wilderness has retaken most of the world outside major cities. Most small villages fell into ruin and were abandoned during the cataclysm, those that survived were taken out by the volcano.

### Magic is returning

Magic items created before the cataclysm have recently begun to regain their effects, resulting in major shifts of political power. Many factions are recruiting bold adventures to seek our lost items. Academic magics have almost returned to their pre-cataclysm level.

### The benevolent rich are in control

The major cities of the north are controlled by nobles who form the Lords Alliance. The agreements between these lords are shaky at best, but nobody doubts that strong leadership helped the cities recover after the cataclysm.

### Pioneering optimism

Many pioneers and homesteaders are leaving the cities to found villages again. These tend to have substantial financial backing from the Lords Alliance, other factions and private investors. After so long living in squalid cities, many people are naively optimistic about settling on the frontier.

# One shot premise

You are all members of the adventuring guild in a large city.

A wealthy patron has given the adventurers guild a sizable commission to provide help with one of their pioneering interests. A messenger from a small village recently reported an increase in attacks on the townsfolk and this patron would like some adventurers to go and see what the commotion is, stopping it if possible.

Those adventurers are you. Of course you didn’t agree to go until the guild promised a sizable reward, as well as horses and food for your travel...
