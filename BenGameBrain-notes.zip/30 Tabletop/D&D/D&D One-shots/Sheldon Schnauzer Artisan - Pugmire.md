---
title: "Sheldon Schnauzer Artisan - Pugmire"
source: "Game Stuff/D&D/Sheldon Schnauzer Artisan - Pugmire"
modified: 2020-12-16
type: character
area: rpg-other
status: "prototyped"
projects: ["[[D&D One-shots]]"]
concepts: ["Pugmire one-shot", "Pugmire"]
words: 1668
summary: "Pregenerated Pugmire character sheet for Sheldon Schnauzer, a pointer artisan sage dog, with background, stats and skills."
contains_external_material: "Skill descriptions appear copied from Pugmire rules"
tags: ["area/rpg-other", "project/d-d-one-shots", "type/character"]
---

# Sheldon Schnauzer

**Pointer Artisan Sage**

### Background Story

Sheldon is an old dog. Once, he was lost in the wilderness where he found an arcane masterwork.

He can’t remember what happened while he was lost and this worries him more than anything!

### 

### 

### Ideal

I'm a good dog and I'm smart. Therefore smart dogs must be good dogs. So my task is to help dumb dogs get smarter, so they can be gooder.

### Bond

I am inspired to understand the world in great detail.

### Flaw

I am always afraid that I’ve forgotten something.

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 8       | 10      | 13      | 18      | 14      | 12      |
| -1      | +0      | +1      | +4      | +2      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Init** | **Prof** |
|--------|--------|--------|----------|----------|----------|
| 11     | 14     | 2d6    | 30/40    | +0       | +2       |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| -1      | +0      | +1      | +6      | +2      | +3      |

### 

###  

### Skills:

**Know Arcana (Int) +6**

This skill represents your character’s ability to recall information and lore about magic, spells, masterwork relics, and the like, as well as read the language of the Old Ones.

**Know History (Int) +6**

This skill represents your character’s ability to recall information about historical events, legendary people, and some of the more common myths of the lost civilizations of Man.

**Know Culture (Int) +6**

This skill helps your character understand the nuances of dog society (such as the intricacies of the royal court), or to understand a different culture entirely. While all the uplifted species speak the same core language, Know Culture will allow your dog to understand a particular culture’s lexicon, secret codes, or euphemisms.

**Notice (Wis) +4**

This skill covers your character’s awareness of his surroundings, noticing sudden changes in the environment, and his overall keenness of sense. Dogs value sight and smell equally, and sometimes a distinct smell is more useful than what a dog can see.

**Search (Wis) +4**

This skill helps your character as he actively looks or smells for clues or hidden items, as well as deduce where they might be found. It’s different from Notice because the character is actively looking instead of reacting to stimuli.

#  

# Tricks

### Simple Weapon aptitude

Anyone can use a simple weapon, but dogs

with this trick can add their proficiency bonus to

attack rolls when using any simple weapon. This

includes clubs, daggers, darts, handaxes, javelins,

maces, quarterstaves, shortbows, sickles, slings,

small crossbows, spears, and unarmed punches,

kicks, and bites.

### Light armor aptitude

The dog with this trick can wear light armor effectively, giving her a defense of 11 + her Dexterity modifier. Examples of light armor include padded armor, leather armor, and studded leather armor.

### Nearby Expert

Whenever a dog tries to learn or recall a piece

of information and fails, she sometimes knows a

person or a location from which to get the information.

The Guide may decide that the knowledge

is secret or difficult to obtain. If the player

spends fortune, she can declare that a previously

unknown non-player character sage or expert is a

friend or peer on good terms with the dog.

### Voracious Learner

The pointer with this trick gains an advantage

on Intelligence checks involving something

the dog might have read or heard about in the

past. It does not apply to situations that are new

to the pointer’s experience.

### Focus magic - 1 Refinement

The artisan starts with a masterwork focus —

a strange, intricate device from the ages of Man

that doesn’t do anything obvious. By taking this

trick, the dog has become spiritually attuned to

the focus, and can draw and channel arcane energy

through it. In effect, the dog uses the focus

to cast spells.

This focus is powered by the artisan’s life

force and, once attuned, is uniquely tied to the

artisan — another dog cannot use it, and another

artisan with a similar focus might find that it allows

her to create different effects.

All references to “spellcasting ability score” are

references to Intelligence.

### 

###  

### Spell Slots

4x Spell slots

###  

# 

# Rucksack

| **Small Crossbow**         |     | Simple ranged weapon. 80/320ft range, +2 to hit, 1d8 piercing damage. Loading (1 shot per turn max) |
|----------------------------|-----|-----------------------------------------------------------------------------------------------------|
| **Padded Vest**            |     | Light Armor. 11 + Dex modifier for Armor Class.                                                     |
| **Walking stick**          |     | Simple weapon. +1 to hit, 1d6 -1 bludgeoning damage.                                                |
| **Lightning Rod**          |     | Masterwork Focus. Must rub on fur to cast magic.                                                    |
| **Bottle of fizzy liquid** |     | Unknown effect, could create a healing effect.                                                      |
| **Pendant of Man**         |     | A figure of a man in a T-pose. Unknown qualities. More research required.                           |
| **Travelling Robes**       |     | Sturdy clothes. Repaired many times.                                                                |
| **Research Supplies**      |     | Bottle of ink, ink pen, parchment, books, magnifying glass.                                         |
| **Coin pouch**             |     | Very few plastic coins.                                                                             |
| **Bedroll**                |     | For sleeping outside.                                                                               |

# Map Locations

| **Apple Farm** |     | Odeon Doberman, Bertha (Wife), Bob Doberman (Son). Hour north from the swamp. |
|----------------|-----|-------------------------------------------------------------------------------|
| **Ellendonk**  |     | Mining town in the North, Alfred Yorkshire (Priest)                           |
|                |     | Jack and Jock Doberman (Sheriff and Deputy)                                   |
|                |     |                                                                               |
|                |     |                                                                               |
|                |     |                                                                               |
|                |     |                                                                               |
|                |     |                                                                               |
|                |     |                                                                               |
|                |     |                                                                               |

# Spells

### Lightning Ray - Basic

**Casting Time:** 1 action

**Range:** 60 feet

**Duration:** Instantaneous

A beam of blue light streaks toward a character within range. Make a ranged spell attack against the target. On a hit, it takes 1d8 Lightning damage.

### Magic Paw - Basic

**Casting Time:** 1 action

**Range:** 30 feet

**Duration:** 1 minute

You point your focus at an object and can lift

and move the object from a distance with a ghostly

paw. You can use your action to control the

magic paw. You can use the paw to manipulate

an object, open an unlocked door or container,

stow or retrieve an item from an open container,

or pour the contents out of a vial. You can move

the paw up to 30 feet each time you use it.

The paw can’t attack, activate masterwork

artifacts, or carry heavy objects.

### Smell Magic - Basic

**Casting Time:** 1 action

**Range:** Self

**Duration:** Concentration, up to 10 minutes

For the duration, you smell the presence of

magic, the Unseen, and characters under Unseen

influence within 30 feet of you. If you sense magic

in this way, you can use your action to smell a

faint odor around any specific and visible character

or object in the area that bears magic. This

spell cannot be used if the spellcaster is Anosmic.

### Fog Cloud - Level 1

**Casting Time:** 1 action

**Range:** 120 feet

**Duration:** Concentration, up to 1 hour

You create a 20-foot radius sphere of fog centered

on a point within range. The sphere spreads

around corners, and its area is heavily obscured.

It lasts for the duration or until a strong wind

disperses it.

### Grease - Level 1

**Casting Time:** 1 action

**Range:** 60 feet

**Duration:** 1 minute

Slick grease covers the ground in a 10-foot

square, centered on a point within range, and

turns it into difficult terrain for the duration.

When the grease appears, each character standing

in its area must succeed on a Dexterity saving

throw or fall Prone. A character that enters the

area or ends his turn there must also succeed on

a Dexterity saving throw or fall Prone.

### Feather Fall - Level 1

**Casting Time:** 1 reaction

**Range:** 60 feet

**Duration:** 1 minute

Choose up to five falling characters within range. A falling character’s rate of descent slows to 60 feet per round until the spell ends. If the character lands before the spell ends, he takes no falling damage and can land on his feet, and the spell ends for that character.

### Magic Missile - Level 1

**Casting Time:** 1 action

**Range:** 120 feet

**Duration:** Instantaneous

Three missiles of magical energy dart forth

from your focus and strike their target. Each one

deals 1d4 + 1 points of force damage. The missile

strikes unerringly, even if the target is totally obscured by cover or completely concealed. Specific parts of a character can’t be singled out. Inanimate objects are not damaged by the spell.

You can have the missiles strike a single character

or several characters. Each missile can strike

only one character. You must designate targets

before you roll damage.

### Thunderwave - Level 1

**Casting Time:** 1 action

**Range:** Self (15-foot cube)

**Duration:** Instantaneous

A wave of thunderous force sweeps out from

you. Each character in a 15-foot cube originating

from you must make a Constitution saving throw.

On a failed saving throw, a character takes 2d8

thunder damage and is pushed 10 feet away from

you. On a successful saving throw, the character

takes half as much damage and isn’t pushed.

In addition, unsecured objects that are completely

within the area of effect are automatically pushed 10 feet away from you by the spell’s effect, and the spell emits a thunderous boom audible out to 300 feet.

### Shield - Level 1

**Casting Time:** 1 reaction

**Range:** Self

**Duration:** 1 round

An invisible barrier of magical force appears

and protects you moments before you are hit by

a successful attack. Until the start of your next

turn, you have a +5 bonus to defense, including

against the triggering attack, and you take no

damage from Magic Missile.

Order of Dave - Relics

Order of Jim - Good doggness

Order of Karen - Dogma
