---
title: "AbstractDnD - Pendar Lafayette"
source: "Game Stuff/AbstractDnD - Pendar Lafayette"
modified: 2021-10-15
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 458
summary: "Near-empty character sheet stub for Pendar Lafayette (Human Illusionist); only a title and an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---



Pendar/Pendae Lafayette

## Human Illusionist

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-wisdom">Attribute: Wisdom</h3>
<p>Regardless of your age, you are wise. You intuitively make good choices and are well schooled in practical knowledge. Play this card when you narrate an action that draws on your deep wisdom and experience.</p></th>
<th><h3 id="attribute-intelligence">Attribute: Intelligence</h3>
<p>Regardless of your age, you are smart. You find it easy to absorb new information and are well schooled in academic knowledge. Play this card when you narrate an action that draws on your keen mind.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-sneak">Skill: Sneak</h3>
<p>You are incredibly sneaky. Even heroes get spooked when you approach them from behind. Play this card when you narrate an action involving moving silently, or without being seen.</p></th>
<th><h3 id="skill-insight">Skill: Insight</h3>
<p>You have a keen eye for when someone is lying, and can read people's emotions. Play this card when you narrate an action that involves uncovering a deception, or when interacting socially with someone who might be lying.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-perception">Skill: Perception</h3>
<p>You are trained to notice small things, and are almost never ambushed. Play this card when you narrate an action that involves perceiving something that is difficult to perceive.</p></th>
<th><h3 id="spell-blur">Spell: Blur</h3>
<p>You speak a magic word and your body becomes blurred, shifting and wavering to all who can see you. The effect lasts for the rest of the scene or until you lose Concentration.</p></th>
</tr>
<tr class="odd">
<th><h3 id="spell-mirror-image">Spell: Mirror Image</h3>
<p>Speaking a few magic words and drawing a symbol in the air, three perfect duplicates of yourself appear next to you. Until the end of the scene, the duplicates move with you, copying your actions in ways that make it impossible to tell which is which.</p></th>
<th><h3 id="spell-disguise-self">Spell: Disguise Self</h3>
<p>With a flourish, you make yourself – including your clothing, armor, weapons, and other belongings on your person – look different. The effect lasts until the end of the scene or you decide to remove the effect. The changes wrought by this spell fail to hold up to physical inspection. Example, if someone touches an illusionary hat, their hand will go through.</p></th>
</tr>
<tr class="header">
<th><h3 id="spell-invisibility">Spell: Invisibility</h3>
<p>You speak a word and smear some ash over your third eye, and become invisible. The effect remains until the end of the scene or your Concentration breaks. You can apply the ash to a willing creature to cause them to become invisible instead.</p></th>
<th><h3 id="spell-nystuls-magic-aura">Spell: Nystul’s Magic Aura</h3>
<p>You say a magic word and complete a magic trick involving a cloth of silk. One creature or object you touch with the silk cloth is changed for the next 24 hours so that divination magic does not work properly on it. Choose one effect:</p>
<p>Mask: The object is masked from divination magic from one creature or spell source that you know about.</p>
<p>Misinformation: The object is detectable, but you change its signature so it looks different.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
