---
title: "AbstractDnD - Ali Spigot"
source: "Game Stuff/AbstractDnD - Ali Spigot"
modified: 2021-10-15
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 431
summary: "Near-empty character sheet stub for Ali Spigot (Elf Child Artificer); only a title and an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---



Ali Spigot

## Elf Child Artificer

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-intelligence">Attribute: Intelligence</h3>
<p>Regardless of your age, you are smart. You find it easy to absorb new information and are well schooled in academic knowledge. Play this card when you narrate an action that draws on your keen mind.</p></th>
<th><h3 id="attribute-dexterity">Attribute: Dexterity</h3>
<p>You are nimble and quick, even for a Hero. Play this card when you narrate an action that utilizes your incredible agility.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-acrobatics">Skill: Acrobatics</h3>
<p>Sure footed and perfectly balanced, your body functions incredibly well at high speed and in the air. Play this card when you narrate an action where you need to land correctly, or make a risky gymnastic-like move.</p></th>
<th><h3 id="skill-arcana-knowledge">Skill: Arcana Knowledge</h3>
<p>You have studied ancient infernal texts or had experiences with magic beyond that which normal people can wield. Play this card when you recall knowledge about spells, eldritch symbols, traditions, magical creatures and items.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-sneak">Skill: Sneak</h3>
<p>You are incredibly sneaky. Even heroes get spooked when you approach them from behind. Play this card when you narrate an action involving moving silently, or without being seen.</p></th>
<th><h3 id="spell-ice-spike">Spell: Ice Spike</h3>
<p>You create a flat shard of ice and fling it at a point within 60ft. It resists melting for a short time. After a second of it starting to melt, you can command it to explode, showering a 5ft area in sharp ice shards.</p></th>
</tr>
<tr class="odd">
<th><h3 id="spell-grease-bomb">Spell: Grease Bomb</h3>
<p>Slick grease covers the ground in a 10-foot square centered on a point within 60ft and turns it into difficult terrain for the duration. Creatures standing in, or passing through the area will find it hard not to slip over. The grease puddle lasts until the end of the scene or your Concentration breaks.</p></th>
<th><h3 id="spell-heat-metal">Spell: Heat Metal</h3>
<p>Choose a manufactured metal object, such as a metal weapon or a suit of heavy or medium metal armor, that you can see within 60ft. You cause the object to glow red-hot. The effect lasts for 1 minute or until your Concentration ends.</p></th>
</tr>
<tr class="header">
<th><h3 id="spell-web">Spell: Web</h3>
<p>You conjure a mass of thick, sticky webbing at a point of your choice within 60ft which lasts until your Concentration breaks, or the end of the scene.</p>
<p>The webs fill a 20-foot cube from that point for the duration. The strands run between all objects inside the cubes area (such as trees or columns) The webs are difficult terrain and lightly obscure their area, and creatures in the area are restrained.</p></th>
<th><h3 id="spell-scorcher">Spell: Scorcher</h3>
<p>You speak a magic word and point with your finger. A line of roaring flame 30 feet long and 5 feet wide emanates from you in the direction you chose.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
