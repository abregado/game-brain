---
title: "AbstractDnD - Filip"
source: "Game Stuff/AbstractDnD - Filip"
modified: 2021-10-15
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 477
summary: "Near-empty character sheet stub for Filip (Kuo-toa Druid of the Swarm); only a title and an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---



Filip

## Kuo-toa Druid of the Swarm

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-wisdom">Attribute: Wisdom</h3>
<p>Regardless of your age, you are wise. You intuitively make good choices and are well schooled in practical knowledge. Play this card when you narrate an action that draws on your deep wisdom and experience.</p></th>
<th><h3 id="attribute-constitution">Attribute: Constitution</h3>
<p>You are incredibly tough, healthy, vigourous. You also find it easy to hold your concentration. Play this card when you narrate an action involving doing something that requires incredible stamina, endurance or vigor.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-nature-knowledge">Skill: Nature Knowledge</h3>
<p>Not only are you schooled in knowledge of nature, you seem to have a link to creatures and plants. Play this card when you narrate an action that involves recalling knowledge of nature, or dealing with plants and animals.</p></th>
<th><h3 id="skill-animal-handling">Skill: Animal Handling</h3>
<p>Your natural demeanor around animals causes them to be more calm around you. You also have extensive knowledge and training in handling animals. Play this card when you narrate an action that involves animals regardless of their emotional state.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-survival">Skill: Survival</h3>
<p>You have been trained to survive in harsh environments, find food and track prey. Play this card when narrating an action utilizing this specialised training or knowledge.</p></th>
<th><h3 id="ability-wildshape">Ability: Wildshape</h3>
<p>You turn into either a Swarm of Flying Beetles or a School of fish. The effect wears off at the end of the scene or when you decide to change back.</p></th>
</tr>
<tr class="odd">
<th><h3 id="spell-speak-with-animals-and-insects">Spell: Speak with Animals and Insects</h3>
<p>You speak a few magic words and draw a symbol in the air with your finger. Until the end of the scene, you can comprehend animal and insect noises as if they were speaking your native language. Your words are understood by all animals that can hear you.</p></th>
<th><h3 id="spell-moonflies">Spell: Moonflies</h3>
<p>Speaking a few magic words and crushing a piece of opal stone in your hand, A cloud of silvery fireflies appears and creates pale light in a 5-foot radius, 40-foot-high cylinder centered on a point within 120ft. Enemies in the beam suffer radiant damage, and any shapechangers hit with the beam revert to their original form. You can order the fireflies to follow a target when you summon them and they continue to do so until your Concentration breaks.</p></th>
</tr>
<tr class="header">
<th><h3 id="spell-healing-spirits">Spell: Healing Spirits</h3>
<p>With a quiet plea and a touch, you place small swarms of spirit slugs on a targets. They can heal mild injuries and assist with medical procedures. The spirits stay and can be moved between targets until your Concentration breaks, or the end of the scene.</p></th>
<th><h3 id="spell-warding-swarm">Spell: Warding Swarm</h3>
<p>With a shout you summon a cloud of stinging glowbeetles to emerge from your cloak and form a violent tornado around you. Until your concentration breaks the beetles continue swirling. The following effects happen within 10 feet of you.</p>
<ul>
<li><blockquote>
<p>Deafened by the sound of buzzing</p>
</blockquote></li>
<li><blockquote>
<p>All creatures have a hard time moving through the swarm</p>
</blockquote></li>
<li><blockquote>
<p>Gasses and smoke are swept away</p>
</blockquote></li>
<li><blockquote>
<p>Attacks are more risky.</p>
</blockquote></li>
</ul></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
