---
title: "Phandalin Shops"
source: "Game Stuff/Phandalin Shops"
modified: 2023-09-25
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]", "[[D&D Homebrew]]"]
concepts: ["D&D one-shots", "D&D homebrew items"]
words: 1274
summary: "Shop and service tables with randomised prices and stock for Phandalin shops, taverns and shrines."
tags: ["area/dnd", "project/d-d-homebrew", "project/d-d-one-shots", "type/campaign-prep"]
---

# Shrine of Tymora

Proprietor: Sister Gaerele

| **Item**              | **Price** | **Item**                | **Price**   |
|-----------------------|-----------|-------------------------|-------------|
| Blanket               | d6+2 sp   | Acid (vial)             | 3d6+18 gp   |
| Candle x3             | 1d4 cp    | Poison (vial)           | 6d6+75 gp   |
| Antitoxin (vial)      | 4d6+35 gp | Potion of Vigor (vial)  | d6+15 gp    |
| Chalk x2              | 1d4 cp    | Herbalism Kit           | d6+3 gp     |
| Flask (500ml)         | d4+2 cp   | Poisoner’s Kit          | 4d6+35 gp   |
| Healer’s Kit          | 3d4+2 gp  | Brewing Kit             | 2d6+15 gp   |
| Healer’s Kit (refill) | d6+5 sp   | Spell scroll components | (per level) |
| Incense               | 1d4 cp    | Jug (1l)                | d4+2 cp     |
| Sturdy Vial           | d6+4 sp   | Pouch                   | d6+2 sp     |

| **Possible Item**              | **Price** | **Chance** | **Quantity** |
|--------------------------------|-----------|------------|--------------|
| Healing potion (2d4+2)         | 50gp      | 80%        | d4+1         |
| Greater Healing Potion (4d4+4) | 250gp     | 50%        | 1            |
| Potion of Resistance           | 200gp     | 50%        | 1            |

| **Services**                    | **Price** | **Per day / Lead time** |
|---------------------------------|-----------|-------------------------|
| Cast Cure Wounds (lvl 1)        | 15 gp     | 6 per day               |
| Cast Gentle Repose (lvl 2)      | 75 gp     | 2 per day               |
| Cast Lesser Restoration (lvl 2) | 75 gp     | 2 per day               |
| Cast Remove Curse               | 150 gp    | 3 days lead             |
| Cast Revivify                   | 450 gp    | 2 days lead             |
| Cast Raise Dead                 | 1250 gp   | 1 week lead             |

# Barthens Provisions

Proprietor: Elmar Barthen

| **Item**            | **Price** | **Item**             | **Price** |
|---------------------|-----------|----------------------|-----------|
| Barrel              | d4 gp     | Ladder               | d4 sp     |
| Blanket             | D6+1 sp   | Bucket               | 2d6 cp    |
| Glass bottles (x2)  | 2d4 gp    | Rope (50 ft)         | 5d6 sp    |
| Candle x5           | d4 cp     | Shovel               | d4 gp     |
| Clothes, Common     | d6+2 sp   | Leatherworker Tools  | d6+2 gp   |
| Clothes, Travelling | d4+1 gp   | Carpenter’s Tools    | 8+3d6 gp  |
| Sack                | 1 sp      | Smith’s Tools        | 10+3d6 gp |
| Backpack            | d4 gp     | Mason’s Tools        | 10+2d6 gp |
| Camping Kit         | 6+d6 gp   | 1 day travel Rations | 4 sp      |

| **Possible Item** | **Price** | **Chance** | **Quantity** |
|-------------------|-----------|------------|--------------|
| Cart              | 25gp      | 80%        | 1            |
| Draft Horse       | 50gp      | 50%        | 1            |
| Riding Horse      | 75gp      | 25%        | 1            |

| **Services**                          | **Price** | **Per day / Lead time** |
|---------------------------------------|-----------|-------------------------|
| Stable and Feed (1 night)             | 1 gp      | 6 horses                |
| Mail service to Neverwinter (7 days)  | 1 sp      | 2 days lead             |
| Express mail to Neverwinter (3 days)  | 3 gp      | 1 days lead             |
| Wagon passage to Neverwinter (4 days) | 4 gp      | 5 days lead             |
| As above but to Waterdeep             | x3        | x5                      |

# Lionshield Coster

Proprietor: Linene Greywind

| **Item**            | **Price** | **Item**             | **Price** |
|---------------------|-----------|----------------------|-----------|
| War tent (6 person) | 2d6+2 gp  | Lantern (hooded)     | 2d6+1 gp  |
| Quiver              | d4 gp     | Lantern oil (1 hour) | d4 sp     |
| Waterskin           | 2d4 sp    | 1 day travel Rations | 5 sp      |
| Piton               | 2d4 cp    | Torch (5)            | 2d4 sp    |
| Backpack            | d4+1 gp   |                      |           |
| Hunting Trap        | 2d6 gp    |                      |           |
| Crowbar             | d4 gp     |                      |           |
| Arrows/Bolts (20)   | 2d4+1 gp  |                      |           |
| Chest (lockable)    | 3d6+2 gp  |                      |           |

| **Possible Item**              | **Price** | **Chance** | **Quantity** |
|--------------------------------|-----------|------------|--------------|
| Simple weapon (buyers choice)  | list      | 50%        | Any          |
| Martial weapon (buyers choice) | +50%      | 25%        | Any          |
| Light/Medium Armor             | +50%      | 30%        | 3            |

| **Services**                     | **Price**     | **Per day / Lead time** |
|----------------------------------|---------------|-------------------------|
| Loot appraisal                   | 1 gp          | Any                     |
| Equipment order from Neverwinter | List + 3d6 gp | 6 days                  |
| Item pawning                     | negotiable    | Any                     |

# Miners Exchange

Proprietor: Halia Thornton

| **Item**          | **Price** | **Item** | **Price** |
|-------------------|-----------|----------|-----------|
| Mining Explosives |           |          |           |
|                   |           |          |           |

| **Possible Item**         | **Price** | **Chance** | **Quantity** |
|---------------------------|-----------|------------|--------------|
| Jewellery (buyers choice) | various   | 25%        | Any          |
| Pure Gem worth 100gp      | 100       | 90%        | Any          |
| Pure Gem worth 500gp      | 500+5d10  | 50%        | d4           |
| Pure Gem worth 1000gp     | 1000+5d20 | 25%        | 1            |

| **Services**                    | **Price**   | **Per day / Lead time** |
|---------------------------------|-------------|-------------------------|
| Credit by Collateral            | 25% per day | 1 day                   |
| Gold to Gems (or vice versa)    | 2%          | Immediate               |
| Gold to Neverwinter trade bonds | 10%         | 2 days                  |
| Wealth storage and protection   | 1% interest | 1 day                   |
| Cast Identify                   | 15 gp       | 6 per day               |
| Cast Knock                      | 75 gp       | 2 per day               |

#  

# Stonehill Tavern

Proprietor: Toblin Stonehill

| **Services**                               | **Price** | **Per day / Lead time** |
|--------------------------------------------|-----------|-------------------------|
| Bed and board (1 person, 1 night, 2 meals) | 1 gp      | 12 rooms                |
| Suite (2 people, 1 night, 4 meals)         | 4 gp      | 1 room                  |
| Hot meal                                   | 1 sp      | Served 3 times a day    |
| Boozy session                              | 2d6 sp    |                         |
| Top shelf boozy session                    | 3d6 gp    |                         |
| Best bottle in the house                   | 10 gp     | d6 bottles, 4 days lead |

# The Echo / Sleeping Giant Taphouse

Proprietor: Trisha Merryweather

Performers: Spirit and Sky

| **Services**                   | **Price** | **Per day / Lead time** |
|--------------------------------|-----------|-------------------------|
| Dorm bed (1 person, 1 night)   | 1 sp      | 48 beds                 |
| “Suite” (1 person, 1 night)    | 5 sp      | 3 rooms                 |
| Hot meal                       | 5 cp      | Available all day       |
| Boozy session                  | 5d6 cp    |                         |
| Top shelf boozy session        | 6d6 sp    |                         |
| Best bottle in the house       | 1 gp      |                         |
| Entry on show night (locals)   | 1 sp      | 60 seats                |
| Entry on show night (visitors) | 1 gp      | 60 seats                |

#  

# Shrine of Oghma

Proprietor: Seeker X, Namer X

| **Item**               | **Price** | **Item** | **Price** |
|------------------------|-----------|----------|-----------|
| Spell scroll materials | variable  |          |           |
|                        |           |          |           |
|                        |           |          |           |

| **Services**                       | **Price**    | **Per day / Lead time** |
|------------------------------------|--------------|-------------------------|
| Pen a letter by dictation          | 1 sp         | 12 per day              |
| Collect information about a topic  | 2 gp per day | 1-6 days                |
| Cast Identify                      | 35gp         | 3 per day               |
| Psionic telegram to another Temple | 10+2d6 gp    | 2 per day               |
|                                    |              |                         |

#  

# Alderleaf Farm

Proprietor: Qelline Alderleaf

| **Services**                  | **Price** | **Per day / Lead time** |
|-------------------------------|-----------|-------------------------|
| Barn loft (1 person, 1 night) | 1 cp      | 10 beds                 |
| “B&B” (1 person, 1 night)     | 1 gp      | 2 rooms                 |
| Hot meal                      | 5 cp      | Available 3 times a day |
