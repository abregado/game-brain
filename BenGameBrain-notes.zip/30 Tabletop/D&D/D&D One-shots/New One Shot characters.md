---
title: "New One Shot characters"
source: "Game Stuff/New One Shot characters"
modified: 2025-03-16
type: character
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots", "D&D 2024 Pregens"]
words: 2076
summary: "Spreadsheet of 24 pre-built D&D 2024 one-shot characters (class, subclass, stat array, background, origin feat, skills) with a spells sheet."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---

## Sheet: Classes

| Character | Class | Subclass | Stat Main | Sat Secod | Str | Dex | Con | Int | Wis | Cha | Stat Sum | Background | Origin Feat | Skills | Expertise | Skill Special | Extra Languages | Cantrips | Spells |  |  | Range | Fighting Style | Mastery | Weapon Choices | Shield? | Druid Forms |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Duelist | Fighter | Battlemaster | Str | Dex | 3.0 | 2.0 | 1.0 | -1.0 | 0.0 | 2.0 | 7 | Noble | Skilled | 7.0 |  |  | 2.0 |  |  |  |  | Melee | Duelist | Yes | Morningstar, Rapier, Battleaxe, Flail, Longsword (Pick 3) |  |  |
| Wormtouched | Fighter | Psi Warrior | Str | Dex | 3.0 | 2.0 | 1.0 | -1.0 | 2.0 | 0.0 | 7 | Guard | Alert | 4.0 |  |  | 2.0 |  |  |  |  | Melee | Blindfighting | Yes | Morningstar, Rapier, Battleaxe, Flail, Longsword (Pick 3) | Shield |  |
| Oakwarden | Barbarian | World Tree | Str | Con | 3.0 | 1.0 | 3.0 | -1.0 | 1.0 | 0.0 | 7 | Farmer | Tough | 4.0 |  |  | 2.0 |  |  |  |  | Melee |  | Yes | Morningstar, Rapier, Battleaxe, Flail, Longsword (Pick 2) | Shield |  |
| Beastheart | Barbarian | Wild Heart | Str | Con | 3.0 | 3.0 | 1.0 | 0.0 | 1.0 | -1.0 | 7 | Guard | Alert | 4.0 |  |  | 2.0 |  |  |  |  | Melee |  | Yes | Greatax, Maul or Greatsword (Pick 2) |  |  |
| Nubanite | Bard | Dance | Cha | Dex | 1.0 | 3.0 | 1.0 | -1.0 | 0.0 | 3.0 | 7 | Entertainer | Musician | 5.0 | 2.0 | Advantage on Performance | 2.0 | 2.0 | 6.0 |  |  | Melee |  | No |  |  |  |
| Jongleur | Bard | Glamour | Cha | Dex | -1.0 | 3.0 | 0.0 | 1.0 | 1.0 | 3.0 | 7 | Charlatan | Skilled | 8.0 | 2.0 |  | 2.0 | 2.0 | 6.0 |  |  | Melee |  | No | Daggers |  |  |
| Sun priest | Cleric | Light | Wis | Dex | -1.0 | 1.0 | 3.0 | 1.0 | 3.0 | 0.0 | 7 | Acolyte | Magic Initiatite | 4.0 |  | Wisdom to Religion | 2.0 | 3.0 | 6.0 |  |  | Ranged | Divine Order: Thaumaturge | No | Quarterstaff |  |  |
| Holy Commander | Cleric | War | Wis | Str | 3.0 | 2.0 | 1.0 | -1.0 | 2.0 | 0.0 | 7 | Soldier | Savage Attack | 4.0 |  |  | 2.0 | 3.0 | 6.0 |  |  | Melee | Divine Order: Protector | No | Morningstar | Shield |  |
| Dunewatcher | Druid | Arid Land | Wis | Str | -1.0 | 3.0 | 1.0 | 0.0 | 3.0 | 1.0 | 7 | Guide | Magic Initiatite | 4.0 |  |  | 2.0 | 2.0 | 6.0 |  |  | Melee | Primal Order Warden | No | Warhammer | Shield | Panther Form |
| Tidekeeper | Druid | Ocean | Wis | Dex | -1.0 | 1.0 | 3.0 | 1.0 | 3.0 | 0.0 | 7 | Hermit | Healer | 4.0 |  | Wisdom to Nature | 2.0 | 2.0 | 6.0 |  |  | Melee | Primal Order Magician | No | Staff |  | Giant Venom Snake Form |
| Aesetic | Monk | Open Palm | Dex | Wis | 1.0 | 3.0 | 0.0 | -1.0 | 3.0 | 1.0 | 7 | Merchant | Lucky | 4.0 |  |  | 2.0 |  |  |  |  | Melee |  | No |  |  |  |
| Twilight Walker | Monk | Shadow | Dex | Wis | 1.0 | 3.0 | 0.0 | 1.0 | 3.0 | -1.0 | 7 | Solider | Savage Attack | 4.0 |  |  | 2.0 |  | 2.0 |  |  | Melee |  | No |  |  |  |
| Sworn Protector | Paladin | Oath of Devotion | Cha | Str | 2.0 | 2.0 | 1.0 | -1.0 | 0.0 | 3.0 | 7 | Acolyte | Magic Initiatite | 4.0 |  |  | 2.0 |  | 4.0 |  |  | Ranged | Protection | Yes | Morningstar, Rapier, Battleaxe, Flail, Longsword (Pick 2) | Shield |  |
| Red Knight | Paladin | Oath of Vengeance | Str | Cha | 3.0 | -1.0 | 2.0 | 0.0 | 1.0 | 2.0 | 7 | Soldier | Savage Attack | 4.0 |  |  | 2.0 |  | 4.0 |  |  | Melee | Great Weapon Fighting | Yes | Greatax, Maul or Greatsword (Pick 2) |  |  |
| Bounty Hunter | Ranger | Hunter | Dex | Wis | 1.0 | 3.0 | 2.0 | 0.0 | 2.0 | -1.0 | 7 | Guard | Alert | 5.0 | 1.0 |  | 4.0 |  | 4.0 |  |  | Ranged | Archery | Yes | Rapier, Shortsword, Whip, Scimitar (Pick 1), Longbow or Heavy Crossbow (Pick 1) |  |  |
| Planar Warden | Ranger | Fey Wanderer | Dex | Wis | 0.0 | 3.0 | 1.0 | -1.0 | 2.0 | 2.0 | 7 | Wayfarer | Lucky, Lockpicking | 5.0 | 1.0 | Wisdom to Charisma | 4.0 | 2.0 | 4.0 |  |  | Both | Druidic Warrior | Yes | Twin Scimitar or Twin Shortsword (Pick 1), Longbow |  |  |
| Pactbound | Warlock | Great Old One | Cha | Con | 0.0 | 3.0 | 1.0 | 1.0 | -1.0 | 3.0 | 7 | Wayfarer | Lucky, Lockpicking | 4.0 |  |  | 2.0 | 2.0 | 4.0 |  |  | Melee | Pact of the Blade, Fiendish Vigor, Mask of Many Faces | No | Longsword | Shield |  |
| Demonologist | Warlock | Fiend | Cha | Int | -1.0 | 1.0 | 1.0 | 3.0 | 0.0 | 3.0 | 7 | Scribe | Skilled | 4.0 |  |  | 2.0 | 2.0 | 4.0 |  |  | Ranged | Agonizing Blast, Pact of the Chain, Repelling Blast | No | Dagger |  |  |
| Abjurer | Wizard | Abjuration | Int | Wis | -1.0 | 0.0 | 2.0 | 3.0 | 2.0 | 1.0 | 7 | Sage | Magic Initiatite | 4.0 | 1.0 |  | 2.0 | 4.0 | 6.0 |  |  | Ranged |  | No | Staff |  |  |
| Illusionist | Wizard | Illusion | Int | Cha | -1.0 | 0.0 | 2.0 | 3.0 | 1.0 | 2.0 | 7 | Entertainer | Musician | 4.0 | 1.0 |  | 2.0 | 3.0 | 6.0 |  |  | Ranged |  | No | Staff |  |  |
| Scoundrel | Rogue | Thief | Dex | Cha | -1.0 | 3.0 | 0.0 | 1.0 | 2.0 | 2.0 | 7 | Charlatan | Skilled | 9.0 | 2.0 |  | 2.0 |  |  |  |  | Both |  | Yes | Rapier, Shortsword, Whip, Dagger, Hand Crossbow, Shortbow (Pick 2) |  |  |
| Assassin | Rogue | Assassin | Dex | Con | 0.0 | 3.0 | 3.0 | 1.0 | 1.0 | -1.0 | 7 | Criminal | Alert | 6.0 | 2.0 |  | 2.0 |  |  |  |  | Both |  | Yes | Rapier, Shortsword, Whip, Dagger, Hand Crossbow, Shortbow (Pick 2) |  |  |
| Dragonblood | Sorceror | Draconic | Cha | Dex | 1.0 | 3.0 | 1.0 | 0.0 | -1.0 | 3.0 | 7 | Merchant | Tough | 4.0 |  |  | 2.0 | 4.0 | 6.0 |  |  | Both | Safe Spell, Heightened Spell | No | Spear |  |  |
| Ordinator | Sorceror | Order | Cha | Dex | 1.0 | 3.0 | 0.0 | 1.0 | -1.0 | 3.0 | 7 | Wayfarer | Lucky, Lockpicking | 4.0 |  |  | 2.0 | 4.0 | 6.0 |  |  | Both | Subtle Spell, Twinned Spell | No | Mace |  |  |
|  |  |  |  |  | 15.0 | 14.0 | 13.0 | 12.0 | 10.0 | 8.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | 2.0 | 2.0 | 1.0 | 1.0 | 0.0 | -1.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | 3.0 | 3.0 | 1.0 | 1.0 | 0.0 | -1.0 |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | 3.0 | 2.0 | 2.0 | 1.0 | 0.0 | -1.0 |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

## Sheet: Spells

|  |  |  |  |  |  |  | Lvl 1 Damage | Lvl 1 Enhancement | Lvl 1 Situational | Lvl 1 | Lvl 2 | Lvl 2 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Nubanite | 2.0 | Thunderclap | Message |  |  | 6.0 | Dissonant Whispers | Faerie Fire | Feather fall |  | Knock | Silence |
| Jongleur | 2.0 | Vicsious Mockery | Message |  |  | 6.0 | Thunderwave | Heroism | Charm person |  | Calm Emotions | Cloud of Daggers |
| Sun priest | 3.0 | Word of Radiance | Sacred flame | Light |  | 6.0 | Guiding Bolt | Bless | Sanctuary |  | Scorching Ray | Cure Wounds |
| Holy Commander | 3.0 | Resistance | Guidance |  |  | 6.0 | Sanctuary | Protection from | Healing Word |  | Zone of Truth | Prayer of Healing |
| Dunewatcher | 2.0 | Starry Wisp | Guidance |  |  | 6.0 | Faire Fire | Animal Friendship |  |  | Heat Metal | Animal Messenger |
| Tidekeeper | 2.0 | Thorn whip | Guidance |  |  | 6.0 | Create or Destroy Water | Fog Cloud |  |  | Barkskin | Spike Growth |
| Twilight Walker |  |  |  |  |  | 2.0 | Minor Illusion |  |  |  | Darkness |  |
| Sworn Protector |  |  |  |  |  | 4.0 | Divine Favor | Bless | Shield of Faith | Heroism |  |  |
| Red Knight |  |  |  |  |  | 4.0 | Divine Smite | Bane | Command | Thunderous Smite |  |  |
| Bounty Hunter |  |  |  |  |  | 4.0 | Hunters Mark | Ensnaring Strike | Animal Friendship | Cure Wounds |  |  |
| Planar Warden | 2.0 | Message | Guidance |  |  | 4.0 | Hunters Mark | Goodberry | Hail of Thorns | Entangle |  |  |
| Pactbound | 2.0 | Eldritch Blast | True Strike |  |  | 4.0 | Armor of Agatys | Hex | Hellish Rebuke | Mirror Image |  |  |
| Demonologist | 2.0 | Eldritch Blast | Blade Ward |  |  | 4.0 | Arms of Hadar | Invisibility | Comprehend Language | Misty Step |  |  |
| Abjurer | 4.0 | Firebolt | Blade Ward | Mage Hand |  | 6.0 | Acid Arrow | Shield | Protection from | Feather fall | Arcane Lock | Web |
| Illusionist | 3.0 | Ray of Frost | Minor Illusion | Mage Hand |  | 6.0 | Chromatic Orb | Fog Cloud | Disguise Self | Silent Image | Blur | Invisibility |
| Dragonblood | 4.0 | Sorcerous Burst | Light |  |  | 6.0 | Witch Bolt | False Life | Featherfall | Fog Cloud | Dragons Breath | Spider Climb |
| Ordinator | 4.0 | Sorcerous Burst | Mending |  |  | 6.0 | Magic Missile | Protection from | Shield | Grease | Knock | Shatter |
