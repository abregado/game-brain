---
title: "5RD Vampire Baths"
source: "Game Stuff/Game Ideas/5RD Vampire Baths"
modified: 2024-01-04
type: design-doc
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["Vampire Baths dungeon", "D&D one-shots"]
words: 571
summary: "Template/guideline for writing a Five Room Dungeon style module set in vampire baths: dungeon key, connectors, dead ends, room keys, room writing guidelines."
tags: ["area/dnd", "project/d-d-one-shots", "type/design-doc"]
---

# Dungeon Key

One per dungeon.

## Things that need to be found

Evidence of a party coming soon.

Evidence that there are vampires here.

Blind servant NPC

Statue of the vampire curator of the baths.

Statue of the vampires that are second in charge. Some are well known as bad guys.

Statue of the king of the land

Thing 1. Description. How it works. One example of how it can be resolved. Good choices for where to find.

Thing 5. An npc. Include primary emotion, micro-feature when talking/listening. How much patience do they have? What do they want? What are they doing here? Add a printable image of the NPC at the end of the module.

Thing 6. The Final thing. Resolving this means the players are finished with the adventure.

## Combat groups

Bat swarms and Cloaker

Vampire thralls

Low tier vampire (curator)

## Connector descriptions

Carved corridor.

Liquid tanks.

New expansion, uncarved

Red carpet

Many rooms

Sarcophagus storage

Connector 1. Description. Difficulties encountered when passing. Effects on arrival. Equipment required to access.

## Dead end descriptions

Unused storage room, safe

Construction work

Geothermal vent

## Global environmental effects

Heavy fog on ground

Temperature drop

Organ Music

Blind servants carrying stuff and putting up decorations

Effect. Description. How does it hinder the characters? How does it assist the denizens? What signs are there that this effect is active (sound, sight, smell, ect).

# Room Keys

Entrance chasm

- Pit

- Doors

- Crates

- Lever

Bath house

- Tubs

- Changing room

- Channel

- Engraved relief

- Large Faucets and Drain

Large Spa party room

- Small Statue

- Medium Statue

- Large tub

- Lounge area

- Painting

Sacrifice Pen

- Future sacrifices

- Collapsed corridor

- Caged entrance

Meditation Temple

- Statue of King

- Altar vessel

- Banquet table

## Room name/numbering

Leave it blank and let the players fill it in. They can use this to mark where exists are connected.

## Map/Visual Aid

A sketch of the map. This should include numbers showing the things listed below. It should be suitable for the players to see.

## Room Description

A narrative and cinematic description of the room. Include as many senses as possible. Include mention of each of the 5 things listed below.

## Numbered list of noteworthy things here

Always best to add 5 of these to every room. They should require a mix of abilities and have a range of difficulties. Use these to hide the Things from the Dungeon map. If a character succeeds then they get the thing, otherwise they only get the lore outcome listed. Each room should have something to discover that is not relevant to the dungeon key.

Noteworthy thing 1. Description for players. Ability needed. Difficulty. Lore only outcome. Things from the dungeon map that would fit here.

Note: If there are secret objects or doors, then draw them here and not on the map itself. Once they become visible, then have the players add them to the map.

## Exits

Always number the exits. Remember that the exits do not go anywhere specific until the players go down them. Then you decide what is at the end, and which connector or dead end to use. Remember, that two rooms might be connected with multiple paths.

# Appendix

Include images, stat blocks and maps here. Item cards with their rules can be printed as well.
