---
title: "AbstractDnD - Robin Dappercog"
source: "Game Stuff/AbstractDnD - Robin Dappercog"
modified: 2021-10-15
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 343
summary: "Near-empty character sheet stub for Robin Dappercog (Warforged Duelist); only a title and an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---

## Warforged Duelist

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-strength">Attribute: Strength</h3>
<p>You are strong, even for a hero. Regardless of your size, you always found it easy to move large objects. Play this card when you narrate an action that utilizes your mighty strength.</p></th>
<th><h3 id="attribute-dexterity">Attribute: Dexterity</h3>
<p>You are nimble and quick, even for a Hero. Play this card when you narrate an action that utilizes your incredible agility.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-acrobatics">Skill: Acrobatics</h3>
<p>Sure footed and perfectly balanced, your body functions incredibly well at high speed and in the air. Play this card when you narrate an action where you need to land correctly, or make a risky gymnastic-like move.</p></th>
<th><h3 id="skill-intimidation">Skill: Intimidation</h3>
<p>Whether using body language or well placed insults, you know to intimidate people into doing what you say. Play this card when you narrate an action that involves convincing someone to do something you asked them to do.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-investigation">Skill: Investigation</h3>
<p>You are trained in searching for clues and making deductions based on them. Following information trails is especially easy for you. Play this card when you try to search an area for clues or research a topic of interest.</p></th>
<th><h3 id="ability-constructed-resilience.">Ability: Constructed Resilience. </h3>
<p>You were created to have remarkable fortitude, represented by the following benefits:</p>
<ul>
<li><blockquote>
<p>It is very hard to poison you.</p>
</blockquote></li>
<li><blockquote>
<p>You don’t need to eat, drink, or breathe.</p>
</blockquote></li>
<li><blockquote>
<p>You are immune to disease.</p>
</blockquote></li>
<li><blockquote>
<p>You don't need to sleep, and magic can't put you to sleep.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="odd">
<th><h3 id="spell-enhance-ability">Spell: Enhance Ability</h3>
<p>Use this card as if it were any Attribute card, or use one of your attribute cards to narrate a Super Risky action with guaranteed success.</p></th>
<th><h3 id="ability-second-wind">Ability: Second Wind</h3>
<p>If you discard this card as a result of something bad happening to you, you may immediately recover any one of your other spent cards.</p></th>
</tr>
<tr class="header">
<th><h3 id="ability-duelist-style">Ability: Duelist Style</h3>
<p>You have trained in fighting with one handed weapons. Nothing gets past you while your sword is drawn. Play this card when you need to make an impressive display of fast sword work.</p></th>
<th><h3 id="ability-disarm">Ability: Disarm</h3>
<p>Play this card when narrating an action which includes forcing an opponent to drop and object they are holding.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
