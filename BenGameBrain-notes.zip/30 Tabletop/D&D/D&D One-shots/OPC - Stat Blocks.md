---
title: "OPC - Stat Blocks"
source: "Game Stuff/D&D/Oneshot Kit/OPC - Stat Blocks"
modified: 2020-05-24
type: homebrew-rules
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]", "[[D&D Homebrew]]"]
concepts: ["D&D one-shots", "Simplified 5e Character Cards", "Beginner-Friendly Adventure Module"]
words: 4851
summary: "Simplified combat cards for one-shot pregens (Duelist, Tribal Warrior, Performer, Sun Priest, Druidic Warden, Soulwind Monk, Crusader, Hunter, Explorer, Shaman, Arcanist, Ritualist, Inventor, Witch Hunter) with stats, skills and actions using tactic tokens."
tags: ["area/dnd", "project/d-d-homebrew", "project/d-d-one-shots", "type/homebrew-rules"]
---

## Duelist

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 16            | **+3**   | +5           |
| **Dexterity**    | 15            | **+2**   | +2           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 13            | **+1**   | +1           |
| **Wisdom**       | 11            | **+0**   | +0           |
| **Charisma**     | 9             | **-1**   | -1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
| 25            |         |           |

| Base Armor Class | 16  | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Athletics**                                                                   | +5  |
|---------------------------------------------------------------------------------|-----|
| Covers difficult situations you encounter while climbing, jumping, or swimming. |     |

| **Perception**                                                                                                                                                                                             | +2  |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you spot, hear, or otherwise detect the presence of something. Is also used to notice traps from a distance. It measures your general awareness of your surroundings and the keenness of your Senses. |     |

| **Insight**                                                                                                                              | +2  |
|------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone’s next move. |     |

### Action Surge

**Free Action:** You may take a second Action this turn. This feature can only be used once.

### Second Wind

**Bonus Action:** Heal yourself for 1d10+3 hit points. This feature can only be used once.

### Combat Tactics

**Passive:** You have 4 Tactic tokens. These are used up by your features as listed below.

### Strike with Longsword

**Action:** *Melee weapon attack.* Make an attack roll with +7 against a target within 5ft. On a hit, the target takes d8+3 slashing damage.

### Equip Shield

**Action:** You fasten your shield to your arm. You gain +2 to your Armor class, but cannot use one of your hands for anything else.

### Riposte

**Reaction when a creature missed you with a melee attack:** Spend a Tactic token. You may strike the target with your longsword (see above), and add an additional d6 damage if you hit.

### Evasive Footwork

**Free Action:** Spend a Tactic token and roll a d6, adding this value to your Armor class. At the end of each of your turns, if you did not move, the bonus wears off.

### Hammer Smash

**Action:** *Melee weapon attack.* Make an attack roll with +5 against a target within 5ft. On a hit, the target takes 2d6+3 bludgeoning damage.

When you cause damage with Hammer Smash, you may spend a Tactic token to add d6 bludgeoning damage. If you do, the next attack against the target is made with advantage.

### Block

**Reaction when you are damaged by a melee attack:** Spend a Tactic token and reduce the damage by d6 + 2.

## Tribal Warrior

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 16            | **+3**   | +5           |
| **Dexterity**    | 14            | **+2**   | +2           |
| **Constitution** | 13            | **+1**   | +3           |
| **Intelligence** | 15            | **+2**   | +2           |
| **Wisdom**       | 11            | **+0**   | +0           |
| **Charisma**     | 9             | **-1**   | -1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
| 25            |         |           |

| Base Armor Class | 16  | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Athletics**                                                                   | +5  |
|---------------------------------------------------------------------------------|-----|
| Covers difficult situations you encounter while climbing, jumping, or swimming. |     |

| **Survival**                                                                                                              | +4  |
|---------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you follow tracks, hunt wild game, guide your group through frozen wastelands, live nearby, and predict the weather. |     |

| **Intimidation**                                                                                          | +5  |
|-----------------------------------------------------------------------------------------------------------|-----|
| Used when you attempt to influence someone through overt threats, hostile actions, and physical violence. |     |

### Attack with Greataxe

**Action:** *Melee weapon attack.* Make an attack roll with +5 against a target within 5ft. On a hit, the target takes d12+3 slashing damage.

### Reckless Attack

**Action:** *Melee weapon attack.* Make an attack roll with +5 against a target within 5ft. This attack is made with advantage. On a hit, the target takes d12+3 slashing damage.

Until your next turn, attacks against you are made with advantage.

### Rage

**Bonus Action:** You enter a furious rage and gain the following benefits:

- Advantage on Strength checks and saving throws.

- +2 damage whenever you hit with a melee weapon attack.

- Resistance to bludgeoning, slacking and piercing damage.

- You fail Concentration checks automatically.

The rage lasts for 1 minute, but ends early if you end a turn without taking damage or attacking a hostile creature.

You may use this feature twice.

###  

### Channel Spirit Animal

**Bonus Action:** You enter a Rage (as above), and gain one extra benefit until the end of the rage:

***Bear spirit*.** You have resistance to all damage types.

***Wolf spirit*.** Your allies have advantage on melee attack rolls against any hostile creature within 5ft of you.

### Throw Handaxe

**Action:** *Ranged weapon attack.* Make an attack roll with +5 against a target within 30ft. On a hit, the target takes d6+3 slashing damage.

You have 2 handaxes, and can collect them after a battle.

### Speak with Animals

**Ritual:** You gain the ability to comprehend and verbally communicate with beasts for 10 minutes. The knowledge and awareness of many beasts is limited by their intelligence, but at minimum, beasts can give you information about nearby locations and monsters, including whatever they can perceive or have perceived within the past day.

### Frenzy

**Bonus Action:** You enter a Rage (as above) but also gained the *Frenzied* condition. Once this rage ends, you gain the *Exhausted* condition.

### Frenzied Attack

**Bonus Action:** *Melee weapon attack.* Make an attack roll with +5 against a target within 5ft. On a hit, the target takes d12+3 slashing damage.

### Throw Javelin

**Action:** *Ranged weapon attack.* Make an attack roll with +5 against a target within 30ft. On a hit, the target takes d6+3 piercing damage.

You have 2 javelins, and can collect them after a battle.

### Beast Sense

**Ritual:** You touch a willing beast. For the next hour, you can use your action to see through the beast’s eyes and hear what it hears, and continue to do so until you use your action to return to your normal senses. The ritual ends if you lose Concentration.

##  

## Performer

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 15            | **+2**   | +4           |
| **Constitution** | 11            | **+0**   | +0           |
| **Intelligence** | 13            | **+1**   | +1           |
| **Wisdom**       | 14            | **+2**   | +2           |
| **Charisma**     | 16            | **+3**   | +5           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Performance**                                                                                                               | +5  |
|-------------------------------------------------------------------------------------------------------------------------------|-----|
| Determines how well you can delight an audience with music, dance, acting, storytelling, or some other form of entertainment. |     |

| **Persuasion**                                                                                                                                                | +5  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you attempt to influence someone or a group of people with tact, social graces, or good nature. Typically, you use persuasion when acting in good faith. |     |

| **History**                                                                                                                                           | +3  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about historical events, legendary people, ancient kingdoms, past disputes, recent wars, and lost civilizations. |     |

### Bardic Magic

Passive: You have 3 Inspiration tokens, 4 Spell tokens and 2 Strong Spell tokens.

### Musical Inspiration

**Bonus Action:** Spend an Inspiration token. Select a creature within 60ft that can hear your song. Hand the player who controls that character a d6. The dice can be rolled and the result added to one ability check, attack roll or saving throw.

A target may only have one of these dice at a time.

### Distracting Music

**Reaction when a target within 60ft that can hear you makes an attack roll, ability check or damage roll:** Spend one Inspiration token and roll a d6. Subtract the result of your roll from the targets roll.

### Magical Choker

**Item:** You wear a necklace or choker, which is the spellcasting focus for your magic.

### Fire Shortbow

**Action:** *Ranged weapon attack.* Make an attack roll with +4 against a target within 80ft. On a hit, the target takes d6+2 piercing damage.

You have 20 arrows. After the battle, roll a d6 for each arrow. On a 4 or higher, it can be recovered.

### Vicious Mockery

**Action:** Speak a string of insults laced with subtle enchantments at a creature you can see within 60ft. If the target can hear you (though it need not understand you), it must succeed on a Wisdom saving throw (DC 13) or take 1d4 psychic damage and have disadvantage on the next attack roll it makes before the end of its next turn.

### Hideous Laughter

**Action:** Spend a Spell token. You touch your spellcasting focus and speak a few words. A creature of your choice that you can see within 30ft perceives everything as hilariously funny and falls into fits of laughter if this spell affects it. The target must succeed on a Wisdom saving throw (DC 13) or gaining the *Incapacitated* and *Prone* conditions for 1 minute. A creature with an Intelligence score of 4 or less isn’t affected.

At the end of each of its turns, and each time it takes damage, the target can make another Wisdom saving throw. The target has advantage on the saving throw if it’s triggered by damage. On a success, the spell ends.

If you take damage while the effect is active, you must pass a Constitution saving throw (DC 10 or the amount of damage taken, whichever is higher) or lose concentration on the spell, ending its effect early.

### Healing Song

**Bonus Action:** Spend a Spell token. You sing a song and a creature of your choice within 60ft regains 1d4 + 3 hit points. This has no effect on undead or constructs.

### Powerful Healing Song

**Bonus Action:** Spend a Strong Spell token. You sing a song and a creature of your choice within 60ft regains 2d4 + 3 hit points. This has no effect on undead or constructs.

### Magical Lute

**Item:** You carry a lute, which is the spellcasting focus for your magic.

### Attack with Rapier

**Bonus Action:** *Melee weapon attack.* Make an attack roll with +4 against a target within 5ft. On a hit, the target takes d6+2 piercing damage.

### Thunder Chord

**Action:** You strum a powerful chord on your lute, which can be heard 100 feet away. Each creature other than you within 5ft must pass a Constitution saving throw (DC 13) or suffer 1d6 thunder damage.

### Wave of Sound

**Action:** Spend a Spell token or a Strong Spell token. You cry out and strum a chord on your lute, which can be heard 300ft away. Each creature in a 15-foot cube originating from you must make a Constitution saving throw (DC 13). On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, the creature takes half as much damage and isn’t pushed.

If you spent a Strong Spell token, the damage increases to 3d8.

### Crippling Rhythm

**Action:** Spend a Spell token or a Strong Spell token. You speak and strum a quiet baseline on your lute. Up to three creatures of your choice that you can see within 30ft must make Charisma saving throws (DC 13) or be affected. Whenever an affected target makes an attack roll or a saving throw within the next minute, the affected target must roll a d4 and subtract the number rolled from the attack roll or saving throw.

If you used a Strong Spell token, you may target 4 creatures instead.

If you take damage while the effect is active, you must pass a Constitution saving throw (DC 10 or the amount of damage taken, whichever is higher) or lose concentration on the spell, ending its effect early.

##  

## Sun Priest

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 15            | **+2**   | +2           |
| **Dexterity**    | 13            | **+1**   | +1           |
| **Constitution** | 11            | **+0**   | +0           |
| **Intelligence** | 14            | **+2**   | +2           |
| **Wisdom**       | 16            | **+3**   | +5           |
| **Charisma**     | 9             | **-1**   | +1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Religion**                                                                                                                                   | +4  |
|------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about deities, rites and prayers, religious hierarchies, holy symbols, and the practices of secret cults. |     |

| **Medicine**                                                                                        | +5  |
|-----------------------------------------------------------------------------------------------------|-----|
| Lets you try to stabilize a dying companion or diagnose an illness, and determine a cause of death. |     |

| **Insight**                                                                                                                              | +5  |
|------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone’s next move. |     |

## Druidic Warden

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 11            | **+0**   | +0           |
| **Dexterity**    | 15            | **+2**   | +2           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 13            | **+1**   | +3           |
| **Wisdom**       | 16            | **+3**   | +5           |
| **Charisma**     | 9             | **-1**   | -1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Animal Handling**                                                                                                   | +5  |
|-----------------------------------------------------------------------------------------------------------------------|-----|
| Whether you can calm down a domesticated animal, keep a mount from getting spooked, or intuit an animal’s intentions. |     |

| **Nature**                                                                                               | +3  |
|----------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about terrain, plants and animals, the weather, and natural cycles. |     |

| **Survival**                                                                                                              | +5  |
|---------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you follow tracks, hunt wild game, guide your group through frozen wastelands, live nearby, and predict the weather. |     |

##  

## Soulwind Monk

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | +1           |
| **Dexterity**    | 16            | **+3**   | +5           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 11            | **+0**   | +0           |
| **Wisdom**       | 15            | **+2**   | +2           |
| **Charisma**     | 13            | **+1**   | +1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Acrobatics**                                                                                                                                                                             | +5  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck. |     |

| **Stealth**                                                                                                                                               | +5  |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| You may attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone without being seen or heard. |     |

| **Insight**                                                                                                                              | +4  |
|------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone’s next move. |     |

##  

## Crusader

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 15            | **+2**   | +2           |
| **Dexterity**    | 13            | **+1**   | +1           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 9             | **-1**   | -1           |
| **Wisdom**       | 11            | **+0**   | +2           |
| **Charisma**     | 16            | **+3**   | +5           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Athletics**                                                                   | +4  |
|---------------------------------------------------------------------------------|-----|
| Covers difficult situations you encounter while climbing, jumping, or swimming. |     |

| **Persuasion**                                                                                                                                                | +5  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you attempt to influence someone or a group of people with tact, social graces, or good nature. Typically, you use persuasion when acting in good faith. |     |

| **Insight**                                                                                                                              | +2  |
|------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone’s next move. |     |

##  

## Hunter

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | +1           |
| **Dexterity**    | 16            | **+3**   | -5           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 13            | **+1**   | +1           |
| **Wisdom**       | 15            | **+2**   | +2           |
| **Charisma**     | 11            | **+0**   | +0           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Nature**                                                                                               | +3  |
|----------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about terrain, plants and animals, the weather, and natural cycles. |     |

| **Stealth**                                                                                                                                               | +5  |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| You may attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone without being seen or heard. |     |

| **Survival**                                                                                                              | +4  |
|---------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you follow tracks, hunt wild game, guide your group through frozen wastelands, live nearby, and predict the weather. |     |

## Explorer

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 16            | **+3**   | +5           |
| **Constitution** | 11            | **+0**   | +0           |
| **Intelligence** | 13            | **+1**   | +3           |
| **Wisdom**       | 14            | **+2**   | +2           |
| **Charisma**     | 15            | **+2**   | +2           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Acrobatics**                                                                                                                                                                             | +5  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck. |     |

| **Stealth**                                                                                                                                               | +7  |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| You may attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone without being seen or heard. |     |

| **Sleight of Hand**                                                                                                                     | +5  |
|-----------------------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you attempt manual trickery, such as planting something on someone else, concealing an object on your person, or picking a pocket. |     |

##  

## Shaman

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 14            | **+2**   | +2           |
| **Constitution** | 15            | **+2**   | +4           |
| **Intelligence** | 13            | **+1**   | +1           |
| **Wisdom**       | 11            | **+0**   | +0           |
| **Charisma**     | 16            | **+3**   | +5           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Arcana**                                                                                                                                                          | +3  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes. |     |

| **Religion**                                                                                                                                   | +3  |
|------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about deities, rites and prayers, religious hierarchies, holy symbols, and the practices of secret cults. |     |

| **Persuasion**                                                                                                                                                | +5  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you attempt to influence someone or a group of people with tact, social graces, or good nature. Typically, you use persuasion when acting in good faith. |     |

##  

## Arcanist

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 15            | **+2**   | +2           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 13            | **+1**   | +1           |
| **Wisdom**       | 11            | **+0**   | +2           |
| **Charisma**     | 16            | **+3**   | +5           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Arcana**                                                                                                                                                          | +3  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes. |     |

| **History**                                                                                                                                           | +3  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about historical events, legendary people, ancient kingdoms, past disputes, recent wars, and lost civilizations. |     |

| **Deception**                                                                                                                                                                                               | +5  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Determines whether you can convincingly hide the truth, either verbally or through your actions. This deception can encompass everything from misleading others through ambiguity to telling outright lies. |     |

##  

## Ritualist

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 14            | **+2**   | +2           |
| **Constitution** | 11            | **+0**   | +0           |
| **Intelligence** | 16            | **+3**   | +5           |
| **Wisdom**       | 15            | **+2**   | +4           |
| **Charisma**     | 13            | **+1**   | +1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Arcana**                                                                                                                                                          | +5  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes. |     |

| **History**                                                                                                                                           | +5  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about historical events, legendary people, ancient kingdoms, past disputes, recent wars, and lost civilizations. |     |

| **Investigation**                                                                                                                                  | +5  |
|----------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you look around for clues, deduce the location of a hidden object or determine the weakest point in a tunnel that could cause it to collapse. |     |

##  

## Inventor

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 9             | **-1**   | -1           |
| **Dexterity**    | 14            | **+2**   | +2           |
| **Constitution** | 13            | **+1**   | +3           |
| **Intelligence** | 16            | **+3**   | +5           |
| **Wisdom**       | 15            | **+2**   | +2           |
| **Charisma**     | 11            | **+0**   | +0           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Arcana**                                                                                                                                                          | +5  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes. |     |

| **Investigation**                                                                                                                                  | +5  |
|----------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you look around for clues, deduce the location of a hidden object or determine the weakest point in a tunnel that could cause it to collapse. |     |

| **Sleight of Hand**                                                                                                                     | +4  |
|-----------------------------------------------------------------------------------------------------------------------------------------|-----|
| Lets you attempt manual trickery, such as planting something on someone else, concealing an object on your person, or picking a pocket. |     |

##  

## Witch Hunter

### Statistics

|                  | Ability Score | Modifier | Saving Throw |
|------------------|---------------|----------|--------------|
| **Strength**     | 11            | **+0**   | +0           |
| **Dexterity**    | 16            | **+3**   | +5           |
| **Constitution** | 14            | **+2**   | +2           |
| **Intelligence** | 15            | **+2**   | +4           |
| **Wisdom**       | 13            | **+1**   | +1           |
| **Charisma**     | 9             | **-1**   | -1           |

| Hit Point Max | Current | Temporary |
|---------------|---------|-----------|
|               |         |           |

| Base Armor Class |     | Walk Speed | 30ft |
|------------------|-----|------------|------|

### 

### Skills

| **Athletics**                                                                   | +2  |
|---------------------------------------------------------------------------------|-----|
| Covers difficult situations you encounter while climbing, jumping, or swimming. |     |

| **Acrobatics**                                                                                                                                                                             | +5  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck. |     |

| **Investigation**                                                                                                                                  | +4  |
|----------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| When you look around for clues, deduce the location of a hidden object or determine the weakest point in a tunnel that could cause it to collapse. |     |

Cleric sames

Action: Light cantrip

Reaction: Warding Flare

Action: Radiance of the Dawn

Action: Turn Undead

Action: Bless

Cleric o1

Passive: Divine magic with arcane focus (quarterstaff)

Action: Sacred Flame

Action: Strike with Quarterstaff

Bonus Action: Healing Word

Action: Scorching Ray

Cleric o2

Passive: Divine magic with arcane focus (shield)

Action: Strike with mace

Action: Equip shield

Action: Burning Hands

Ritual: Prayer of Healing

Druid sames

Spellcasting with Arcane focus (totem)

Wildshape tokens

Action: Ice Knife

Druid o1

Action: Attack with Quarterstaff

Action: Attack with Enhanced quarterstaff

Bonus Action: Shillelagh

Action: Earth Tremor

Action: Pass without Trace

Bonus Action: Summon Familiar

Druid o2

Action: Attack with blades

Action: Thornwhip

Action: Entangle

Action: Hold person

Bonus Action: Wildshape (Alpha Wolf)

Monk Sames

Passive: Ki magic

Reaction: Deflect Missiles

Action: Martial Arts

Bonus Action: More martial arts

Bonus Action: Step of the Wind

Bonus Action: Patient Defense

Monk o1

Bonus Action: open palm strikes

Action: Drink blur potion

Monk o2

Free Action: Fangs of the Fire snake

Action: Drink dragonskin potion

Paladin sames

Action: Lay on Hands

Reaction: Protection fighting style

Divine magic (shield)

Action: Divine Strike

Action: equip shield

Paladin o1

Bonus Action: Sanctuary

Bonus Action: Shield of Faith

Action: Sacred Weapon

Action: Turn the Unholy

Paladin o2

Action: Bane

Bonus Action: Hunters Mark

Action: Abjure Enemy

Bonus Action: Vow of Enmity

Ranger sames

Ranger magic slots

Bonus Action: Hunters mark

Bonus Action: Ensnaring strike

Ranger o1

Action: Longsword attack

Bonus Action: Shortsword attack

Reaction: Absorb Elements

Free Action: Command Hunting companion

Bonus Action: Companion attack

Ranger o2

Action: Hordebreaker Longbow attack

Bonus Action: Hail of Thorns

Free Action: Poison Arrow

Free Action: Radiant Arrow

Rogue Sames

Bonus Action: Cunning Dash

Bonus Action: Cunning Disengage

Bonus Action: Cunning Hide

Passive: Sneak Attack

Once per turn, roll an additional 2d6 damage for an attack that was either made with advantage or was made against a target within 5ft of a friendly creature and. not with disadvantage.

Rogue o1

Action: Attack with rapier

Bonus Action: Attack with short sword

Action: Blade venom

Action: Flash bomb

Passive: Assassinate

Rogue o2

Action: Attack with Shortbow

Action: use Poison arrow

Action: use Fire arrow

Action: Throw oil flask

Bonus Action: Cunning Tactic

Sorc sames

Passive: Spellcasting with Metamagic

Action: Elemental strike (cantrip)

Free Action: Empower spell

Free Action: Twinned spell

Sorc 1

Action: False Life

Action: Ray of Sickness

Action: Disguise Self

Action: Detect Magic

Sorc 2

Reaction: Shield

Action: Burning Hands

Action: Charm Person

Action: Misty Step

Warlock sames

Passive: Patron magic

Action: Arms of Hadar

Action: Armor of Agathys

Warlock 1

Action: Agonizing Eldritch blast

Action: Fiendish Vigor

Action: Spare the Dying

Passive: Among the Dead

Action: Attack with Hexblade

Warlock 2

Action: Repelling Eldritch blast

Action: Thief of Five fates

Passive: Dark Ones blessing

Action: Attack with Quarterstaff

Action: Find Familiar

Wizard sames

Passive: Spellbook and Component magic

Action: Mage hand

Passive: Ritual spells in book

Action: Mage Armor

Wiz 1

Action: Firebolt

Passive: Abjuration Ward

Action: Mage Armor

Reaction: Shield

Action: Melf’s Acid Arrow

Wiz 2

Passive: Grim Harvest

Action: Chill Touch

Action: Ray of Sickness

Action: Ray of Enfeeblement

Blood Hunter sames

Action: Attack with silver longsword (+2 damage)

Action: Attack with heavy crossbow (+2 damage)

Passive: Hemocraft magic

Bonus Action: Rite of the Dawn

Action: Drink Healing potion

Hunter 1

Bonus Action: Rite of the Storm

Bonus Action: Blood Curse of Binding x2

Action: Drink Potion of Growth

Hunter 2

Bonus Action: Rite of the Frozen

Bonus Action: Blood Curse of the Marked x2

Action: Drink Potion of Heroism

Artificer sames

Passive: Artisan magic (tools)

Action: Spare the Dying

Action: Equip Shield (+1)

Action: Grease

Action: Featherfall

Reaction: Shield

Artificer o1

Passive: Your AC is 19

Action: Thunder Gauntlets

Bonus Action: Defensive Shield

Action: Magic Missile

Acty o2

Action: Attack with Hammer (int+1)

Action: Attack with Firebolt

Action: Heroism

Passive: Steel Defender companion

Bonus Action: Companion Attack

Bonus Action: Companion Repair
