---
title: "AbstractDnD - Marat"
source: "Game Stuff/AbstractDnD - Marat"
modified: 2021-10-16
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 375
summary: "Empty character sheet for Marat; contains only an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-strength">Attribute: Strength</h3>
<p>You are strong, even for a hero. Regardless of your size, you always found it easy to move large objects. Play this card when you narrate an action that utilizes your mighty strength.</p></th>
<th><h3 id="attribute-constitution">Attribute: Constitution</h3>
<p>You are incredibly tough, healthy, vigourous. You also find it easy to hold your concentration. Play this card when you narrate an action involving doing something that requires incredible stamina, endurance or vigor.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-insight">Skill: Insight</h3>
<p>You have a keen eye for when someone is lying, and can read people's emotions. Play this card when you narrate an action that involves uncovering a deception, or when interacting socially with someone who might be lying.</p></th>
<th><h3 id="skill-deception">Skill: Deception</h3>
<p>Whether through vocal trickery or clever logic, your lies are incredibly hard to detect. Play this card when you narrate an action where you try to convince someone of something that is false.</p></th>
</tr>
<tr class="header">
<th><h3 id="ability-second-wind">Ability: Second Wind</h3>
<p>If you discard this card as a result of something bad happening to you, you may immediately recover any one of your other spent cards.</p></th>
<th><h3 id="skill-persuasion">Skill: Persuasion</h3>
<p>Whether through fancy speech or body language, you are able to convince people to do what you ask when your intentions are honest. Play this card when you narrate an action where you try to convince someone of something that is true.</p></th>
</tr>
<tr class="odd">
<th><h3 id="handaxe">Handaxe</h3>
<p>Just a normal handaxe. Useful for attacking, and a wide range of other actions. Narrate an action in which you use it, and play this card to guarantee success. You can throw it accurately at a range of 30ft.</p></th>
<th><h3 id="ability-sol-hammer-daylight">Ability: Sol Hammer Daylight</h3>
<p>Holding this hammer above your head and calling its name, it begins to glow as bright as a sun. For the rest of the scene bright light is shed within 60ft of the weapon, and dim light for another 60ft. Magical darkness within 60ft is dispelled.</p></th>
</tr>
<tr class="header">
<th><h3 id="ability-sweeping-blow">Ability: Sweeping Blow</h3>
<p>Play this card when you narrate an action which includes your weapon. Up to three targets which are standing next to each other can be affected simultaneously by this action.</p></th>
<th><h3 id="magical-greatweapon-sol">Magical Greatweapon “Sol”</h3>
<p>A big hammer with a round head. Useful for attacking, and a wide range of other actions. Narrate an action in which you use it, and play this card to guarantee success.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
