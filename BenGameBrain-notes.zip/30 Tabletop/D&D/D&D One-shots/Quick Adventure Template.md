---
title: "Quick Adventure Template"
source: "Game Stuff/Quick Adventure Template"
modified: 2021-10-26
type: template
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots"]
words: 80
summary: "Bare outline template for a quick D&D adventure: blurb, scenes, clue challenges, obstacles, final scene and earned advantages."
tags: ["area/dnd", "project/d-d-one-shots", "type/template"]
---

Adventure Blurb (for the players)

Adventure explanation (for the DM)

Introduction

Scene 1

Quick Combat (single round)

Clue finding Challenge 1

Clue finding Challenge 2

Clue finding Challenge 3

Information to be discovered

Scene 2.1

Obstacle or Conflict

Roleplay content

Advantage to be earned

Information to be discovered

Scene 2.2

Obstacle or Conflict

Advantage to be earned

Information to be discovered

Optional Scene 3

Final Scene

Buildup

Turning point 1

Turning point 2

Finale (win)

Finale (lose)

Possible earned Advantages
