---
title: "One shot character ability scores"
source: "Game Stuff/D&D/One shot character ability scores"
modified: 2020-07-30
type: reference-data
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots"]
words: 257
summary: "Table of recommended standard-array ability modifiers for 14 classes for one-shot pregens (incl. Monster Hunter and Artificer)."
tags: ["area/dnd", "project/d-d-one-shots", "type/reference-data"]
---

## Sheet: Sheet1

|  | Str | Dex | Con | Int | Wis | Cha |
|---|---|---|---|---|---|---|
| Fighter | 3 | 2 | 1 | 0 | 2 | -1 |
| Barbarian | 3 | 2 | 2 | -1 | 1 | 0 |
| Bard | 0 | 2 | 1 | 2 | -1 | 3 |
| Cleric | 2 | 2 | 1 | -1 | 3 | 0 |
| Druid | 2 | 1 | 2 | 0 | 3 | -1 |
| Monk | 0 | 2 | 2 | -1 | 3 | 1 |
| Paladin | 3 | 0 | 2 | 1 | -1 | 2 |
| Ranger | -1 | 3 | 2 | 0 | 2 | 1 |
| Rogue | -1 | 3 | 0 | 1 | 2 | 2 |
| Sorcerer | 0 | 2 | 1 | -1 | 2 | 3 |
| Warlock | 2 | 1 | 0 | 2 | -1 | 3 |
| Wizard | -1 | 1 | 2 | 3 | 0 | 2 |
| Monster Hunter | 1 | 2 | 2 | 3 | 0 | -1 |
| Artificer | 2 | 2 | -1 | 3 | 1 | 0 |
|  | 16 | 15 | 14 | 13 | 11 | 9 |
|  | 3 | 2 | 2 | 1 | 0 | -1 |
