---
title: "FATE one shot"
source: "Game Stuff/FATE one shot"
modified: 2024-08-18
type: campaign-prep
area: rpg-other
status: "idea"
projects: ["[[D&D One-shots]]"]
concepts: ["FATE one-shots"]
words: 135
summary: "Opening scene for a FATE one-shot: a train heist on a lightning rail with aspects and setup questions."
tags: ["area/rpg-other", "project/d-d-one-shots", "type/campaign-prep"]
---

FATE one shot

You are sitting in a car, watching the lightning rail track. The train should be along any second. Your plan is to board the train, break into the armored cargo carriage, and steal the item your patron requires.

Each name one modification the car has at your request. Add these aspects to the car zone.

Each tell us your pseudonym for this job.

You are famous in the organisation you work for. What does everyone say about your skills?

The train shoots past. It has to slow down quite a lot on this stretch of track, but it is still moving very fast.

Aspects:

- Frequent pylons

- Arcing energy

How do the crew board the train?

Introduce Overcome and Create advantage

As characters board the train, ask them for their trouble.
