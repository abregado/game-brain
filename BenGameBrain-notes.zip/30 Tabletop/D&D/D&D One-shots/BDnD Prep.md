---
title: "BDnD Prep"
source: "Game Stuff/D&D/BDnD Prep"
modified: 2024-02-17
type: campaign-prep
area: dnd
status: "played/used"
projects: ["[[D&D One-shots]]", "[[D&D Homebrew]]"]
concepts: ["BDnD campaign", "D&D homebrew items", "D&D house rules"]
words: 1031
summary: "Session prep notes for an Eberron campaign (BDnD): sessions 0-4 including NPC beats, Trolanport city/party notes, price lists, poisons, items, homebrew artificer subclass/feat and character notes."
tags: ["area/dnd", "project/d-d-homebrew", "project/d-d-one-shots", "type/campaign-prep"]
---

# Session 4 - Cliffhanger resolution

Lucian and Gisela

- Lucian wants:

  - to find out who sent them “What do you really want?”

  - Warns against starting a fight

  - Mentions that the authorities are looking for murderers.

  - Tell the PCs to stop following

Neya and Shadow

- Neya:

  - Digs for more information

  - Wants to know who sent them

  - Why they are chasing Lucian

Meena wants to capture Lucian

Lord Stenham has Thuranni assassins (the band) who will try to assassinate Meena and Neya

# Session 3 - Trolanport arrival

**Venice like city**

10 story, 30m spire in the center with an airship docked

Mostly gnomes although this is a trading center, so larger races are well accommodated.

**Pre Party**

Make a list of everything that the players want to bring/do and find out what happens

Give everyone a flashback

Everyone should describe the outfits they want to buy/wear and the mask they want.

Glimmersilk or spidersilk?

Gloves a must

700g shadow

- Shiv feather

700g Gisella

- Adrian style

1200g ester

- Full glimmer

250g Gottfried

- Six symbology

- Two silver bolts

**Tips for dealing with Aundarians**

“Don’t mention Thaliost”

Boorish and crass behaviour is not tolerated

Wit and speechcraft are valued more than might or riches

An ungloved hand offered is considered rude in upper echelons of Aundair

**Party**

Audarian magic detectors on the guards?

Building made of mage worked white marble

Minimal interior walls but soundproof magic fields for quiet places.

Humiliation of the young diplomat from Thrane

Debate contest group

# Session 2

### Backpack

Allows you to carry many small items easily. Pretty bulky, so it gives you disadvantage on Dexterity based checks while wearing it. Critical hits against you have a chance to damage the bag

### Travelling supplies

Bedroll, Messkit, Tinderbox, Waterskin, Small tent.

### Mage bred Horse

50 miles per day

75ft per round

25 hp, AC 10

Advantage on Animal handling checks the rider makes to control the horse

### Knockout poison (injury)

A creature subjected to this poison must make a DC 10 Constitution saving throw. On a success, the creature is poisoned for 1 hour. On a failure the creature also gains the unconscious condition. The creature wakes up if it takes damage or if another creature takes an action to shake it awake.

### Paralysis poison (injury)

A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or be paralyzed for 10 minutes. The creature may retest at the end of each of its turns.

### Weakening poison (injury)

A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or be poisoned for 1 hour.

### Bracers of Retribution

Transmutation magic. Gauntlets. Rare item. Requires attunement by a devotee of the Dark Six.

While a target suffering from your Mark of Enmity is visible to you, your Strength is increased by 4 (+2).

Handcuffs: 2gp

Rope 50ft: 1gp

Bolts 3+ recovery: 1gp

Light crossbow: 25gp

Lodestones: 10gp each

Phospherant Moss: 8sp

Jar of 20 fireflies: 25gp

Dagger: 2gp

Handaxe: 5gp

Healing potion: 50gp

Sleep poison: 200gp

Paralysis poison: 100gp

Weakening Poison: 50gp

Silver mirror: 1000gp

Holy Water: 1gp for vial, 1gp donation at the church for the water

Mage bred horse: 150g (but free in this case)

# Session 0 v2

Inventory management? None, Simple or Detailed?

Debts and Regrets

Patron Reputation

Languages

Viorr Maelak

Emotion: Confident

When meeting: handshake without hesitation

When speaking: steepled fingers

When listening: sit up straight

Kings Dark Lanterns

These coins have many friends who would like to meet you. Come

to the northeast stairs of Myriad Tower, upper city, at noon. Bring

travel gear and those you trust. Also bring your sense of urgency and

knack for discretion. Give this parchment to the guard near the stairs,

and he will let you ascend.”

The note is signed with a cryptic “V” beside the black silhouette of a

stylized lantern.

4 healing potions

Dire Ape

55hp AC 13, 2 extra if in tree

Str 22, Dex 15, Con 14, Int 2, Wis 12, Cha 7

7 slashing damage

Con save if grappled. 16 bludgeoning or half on pass

# Items

## Dhakaani Symbiont Shortblade

Rare item, requires attunement.

Magical Shortsword, simple weapon. Light, Finesse, d6 piercing or slashing.

Grants +2 to attack rolls and damage.

After rolling Initiative you may spend a hit die, roll it, and add the result to your Initiative.

## Shield of Light

Common item, requires attunement by a cleric of the Life or Light domain.

Magical shield. +2 Armor class when donned.

When donned the shield emits bright light 5ft, and dim light another 10ft while donned. It can also be used as a spell casting focus.

Shields cannot be donned, doffed or dropped using free actions.

Action: Don or doff the shield to a free hand.

# Characters

## Ester van Vahlen

[*https://docs.google.com/document/d/1i_st6EdidRHpKmEwXR9m2WxST4n1VgU1gvReDx3ssRc/edit?usp=sharing*](https://docs.google.com/document/d/1i_st6EdidRHpKmEwXR9m2WxST4n1VgU1gvReDx3ssRc/edit?usp=sharing)

New Artificer subclass

## Downtime action: Remove symbiont 

Each time you take this action, spend D6x5 gold worth of magical components and make a DC15 tools check. Mark down if it is a success. After your second success, The Dhakanni Symbiont Shortblade has its bonus reduced to +1, and your Surgeons tools become Surgeons tools +2.

## Gisela

Wields the shield of light

## Shadow

## Feat: Aberrant Poisoncrafting

You can craft simple poisons by mixing common ingredients with your own blood.

During a short rest, you may fill a single spare vial with poison by spending 2d6 gold worth of reagents and discarding a hit die. During a long rest or downtime action you can do this without discarding hit dice. In either case you must have access to a poisoner’s kit.

## Item: Simple poison

Common poison (injury)

The target suffers d4 poison damage.

## Feature: Apply poison

**Bonus action:** Injury poison can be applied to weapons, ammunition, trap components, and other objects that deal piercing or slashing damage and remains potent until delivered through a wound or washed off. A creature that takes piercing or slashing damage from an object coated with the poison is exposed to its effects.

Human Ingenuity

1x Reroll per long rest
