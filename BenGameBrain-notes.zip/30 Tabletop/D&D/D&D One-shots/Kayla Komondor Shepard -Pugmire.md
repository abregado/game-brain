---
title: "Kayla Komondor Shepard -Pugmire"
source: "Game Stuff/D&D/Kayla Komondor Shepard -Pugmire"
modified: 2020-12-16
type: character
area: rpg-other
status: "prototyped"
projects: ["[[D&D One-shots]]"]
concepts: ["Pugmire one-shot", "Pugmire"]
words: 1775
summary: "Pregenerated character sheet for Kayla Komondor, a herder shepherd cleric dog for the Pugmire RPG, with spells, tricks and gear. Contains substantial Pugmire rules text."
contains_external_material: "Trick and spell text appears copied from Pugmire rules"
tags: ["area/rpg-other", "project/d-d-one-shots", "type/character"]
---

# Kayla Komondor

**Herder Shepherd Free dog**



### Background Story

Kayla grew up in a monastery. Its monks specialized in healing, the study of nature and of the Tenets. Although she liked the monks and nuns, the strict routine of monastic life was just boring.

One day a wandering priest, Remend Bloodhound, came to the monastery, staying a few days. Kayla listened excitedly to his tales and stories, but what she found really fascinating was the priest’s interpretation of the Tenets. The priest emphasized that because their bond was so strong, Man wanted all dogs to be free. The first tenet is still the highest, but he argued that being a free dog is more important than obeying the master.

When the priest was readying to leave, Kayla begged him to be allowed to go along. To her surprise, he refused. At first she was disappointed and angry. She made up her mind and ran away that very night, meeting him on the road the next morning.

Upon seeing her, the old dog smiled and simply said "Come along free one".

Today Kayla is travelling alone, spreading the true word of Man to every dog she can find.

### Ideal

I believe that every dog has the potential to be a good dog, but sometimes they need a good slap with a rolled newspaper to realise that potential.

### Bond

I owe a great debt to my mentor, who took me in when I ran away from my monastery.

### Flaw

If a dog is not free, it can't know what's best for it. I do.

### Attributes and Modifiers

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| 14      | 12      | 10      | 8       | 18      | 13      |
| +2      | +1      | +0      | -1      | +4      | +1      |

| **AC** | **HP** | **HD** | **Walk** | **Initiative** |     |
|--------|--------|--------|----------|----------------|-----|
| 12/14  | 15/16  | 1/2d8  | 30/40    | +1             |     |

### Saving throws

| **Str** | **Dex** | **Con** | **Int** | **Wis** | **Cha** |
|---------|---------|---------|---------|---------|---------|
| +2      | +1      | +0      | +1      | +6      | +1      |

### 

### Proficiencies:

**Sense Motive (Wisdom) +6**

This skill helps your character determine someone’s true intentions. Whether uncovering a lie or predicting her actions, the dog observes his target’s body language, speech patterns, and mannerisms to learn the truth.

**Persuade (Charisma) +3**

This skill represents your character’s ability to influence someone through tact, social grace, diplomacy, or a generally positive nature.

**Know Nature (Intelligence) +1**

This skill represents your character’s ability to recall information about terrain, plants, animals, the weather, and natural cycles.

**Search (Wisdom) +6**

This skill helps your character as she actively looks or smells for clues or hidden items, as well as deduce where they might be found. It’s different from Notice because the character is actively looking instead of reacting to stimuli.

**Survive (Wisdom) +6**

This skill represents your character’s ability to follow tracks, hunt game, identify signs that enemies live nearby, predict the weather, or avoid natural hazards.

# Tricks

### Simple Weapon aptitude

Anyone can use a simple weapon, but dogs

with this trick can add their proficiency bonus to

attack rolls when using any simple weapon. This

includes clubs, daggers, darts, handaxes, javelins,

maces, quarterstaves, shortbows, sickles, slings,

small crossbows, spears, and unarmed punches,

kicks, and bites.

### Light armor aptitude

The dog with this trick can wear light armor effectively, giving her a defense of 11 + her Dexterity modifier. Examples of light armor include padded armor, leather armor, and studded leather armor.

### Medium armor aptitude

The dog with this trick can wear medium armor

effectively, giving her a defense of 13 + her

Dexterity modifier. Further, the dog’s Dexterity

checks (not attack rolls) are at a disadvantage.

Examples of medium armor include hide armor, a

chain shirt, scale mail, and half plate mail.

Characters must have the Light Armor Aptitude

trick before they can take Medium Armor

Aptitude.

### Shield aptitude

The dog with this trick can use a shield effectively,

giving her +2 to her defense. However, she only has one free paw and cannot use weapons or objects with the “two-pawed” quality. Further, the shield offers no benefit against attacks that the user cannot actively defend against (such as attacks from behind or spell effects that go around corners).

### Prayers to Man

Shepherds pray to Man, giving them access

to incredible feats of magic. These prayers are

powered by the shepherd’s life force. New prayers are learned either from extensive study within the Church of Man, or through intense Meditation and communion with Man.

### Keen Observer

The herder with this trick gains an advantage

on all Wisdom checks involving hearing, sight or smell.

### 

###  

### Respected by Strays

The dog is well known by strays and other

free dogs. If she meets them in her travels, they

generally treat her with respect and offer her

(and her companions) a night of hospitality, if

they don’t bring anything dangerous to the camp. If the player spends fortune, she can declare that a previously unknown non-player character stray or free dog is an old friend.

#  

# Spells

### Sacred Flame - Basic

**Casting Time:** 1 action

**Range:** 60 feet

**Duration:** Instantaneous

Radiance erupts from a character or object

that you can see within range. Characters must

succeed on a Constitution saving throw or take

1d8 radiant damage.

In addition, objects hit by the spell shed bright light in a 20-foot radius, which will stay illuminated if the caster concentrates (up to one minute). If you target an object held or worn by a hostile character, that character must succeed on a Dexterity saving throw to avoid the spell.

### Bless/Bane - Basic

**Casting Time:** 1 action

**Range:** 30 feet

**Duration:** Concentration, up to 1 minute

Choose up to three characters you can see

within range and one effect: Bless or bane. All

targets are affected by the same effect. On the

target’s next attack, ability, or saving throw roll

before the spell ends, the target can roll a d4 and add (Bless) or subtract (Bane) the number rolled to the roll.

### Spare the Dying - Basic

**Casting Time:** 1 action

**Range:** Touch

**Duration:** Instantaneous

You can touch a living character that has 0

stamina points. The character becomes stable

and has 1 stamina point. The target can choose

to spend stamina dice to recover stamina point, if she chooses.

### Cure Wounds - Level 1

**Casting Time:** 1 action

**Range:** Touch

**Duration:** Instantaneous

When laying your paw upon a living character,

you channel positive energy that restores 1d8 stamina points + your spellcasting ability modifier. An additional 1d8 is rolled for every additional spell slot used when casting Cure Wounds. No stamina dice are expended.

### Shield of Faith - Level 1

**Casting Time:** 1 bonus action

**Range:** 60 feet

**Duration:** Concentration, up to 10 minutes

This spell creates a shimmering, magical

field around the target that averts attacks. The

spell grants the subject a +2 bonus to defense.

### Command - Level 1

**Casting Time:** 1 action

**Range:** 60 feet

**Duration:** 1 round

You give the subject a single one- or two-word

command — many shepherds prefer to use the ancient commands of Man, but any command will do.

The target must succeed on a Wisdom saving throw, or must obey the command to the best of its ability at her earliest opportunity. If the target is unable to follow your command, the spell ends. The spell has no effect if the target is immune to being Charmed, or if your command is directly harmful to her.

Some typical commands and their effects follow. You might issue a command other than one described here. If you do so, the Guide determines how the target behaves.

**Come!** On her turn, the subject moves

toward you as quickly and directly as possible.

The character may do nothing but

move during her turn.

**Drop It!** On her turn, the subject drops

whatever she is holding and ends her

turn. She can’t pick up any dropped item

until her next turn.

**Heel!** The subject stands in place. She

may not take any move actions.

**Lay Down!** On her turn, the subject falls

to the ground and remains Prone until

the spellcaster’s next turn.

**Run!** On her turn, the subject moves

away from you as quickly as possible until

the spellcaster’s next turn. She may do

nothing but move during her turn, and

she provokes attacks of opportunity for

this movement as normal.

### Guiding Bolt - Level 1

**Casting Time:** 1 action

**Range:** 120 feet

**Duration:** 1 round

A flash of light streaks toward a character of

your choice within range. Make a ranged spell attack against the target. On a hit, the target takes 3d6 radiant damage, and the next attack roll made against this target before the end of your next turn has advantage, thanks to the mystical dim light glittering on the target until then.

### 

###  

### Inflict Wounds - Level 1

**Casting Time:** 1 action

**Range:** Touch

**Duration:** Instantaneous

Make a melee spell attack against a character.

When successfully laying your paw on a target,

you channel negative energy that deals 2d10 necrotic damage.

### Protection from Evil - Level 1

**Casting Time:** 1 action

**Range:** Touch

**Duration:** Concentration, 10 minutes

Until the spell ends, one willing character you

touch is protected from the undead, the Unseen, and creatures under the influence of the Unseen. The protection grants several benefits. First, characters of those types have disadvantage on attack rolls against the target. The target also can’t be Charmed, Scared, or Possessed by them. If the target is already Charmed, Scared, or Possessed by such a character, the target has an advantage on any new saving throw against the relevant effect.

### Spell Slots

4x Spell slots

###  

# 

# Rucksack

| **Spear**        |     | Thrown 20/60. +2 to hit, 1d8 + 2 piercing damage. |
|------------------|-----|---------------------------------------------------|
| **Old Leathers** |     | AC 11 + Dex.                                      |
| **Shiny Armor**  |     | AC 13 + Dex.                                      |
| **Shield**       |     | +2 AC when held.                                  |
| **Jar of Pesto** |     | Wakes up unconscious dogs.                        |
| **Belt Pouch**   |     | Some plastic coins.                               |
| **Candles**      |     | Makes light.                                      |
| **Vestments**    |     | For holy ceremonies.                              |
| **Patched Robe** |     | Rugged, but worn from lots of use.                |
| **Bedroll**      |     | For sleeping outside.                             |
| **Horse**        |     | Clydesdale horse named Steadfast.                 |

### 

###
