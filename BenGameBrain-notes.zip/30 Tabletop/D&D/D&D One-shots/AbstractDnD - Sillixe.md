---
title: "AbstractDnD - Sillixe"
source: "Game Stuff/AbstractDnD - Sillixe"
modified: 2021-10-16
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 403
summary: "Empty character sheet for Sillixe; contains only an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-intelligence">Attribute: Intelligence</h3>
<p>Regardless of your age, you are smart. You find it easy to absorb new information and are well schooled in academic knowledge. Play this card when you narrate an action that draws on your keen mind.</p></th>
<th><h3 id="attribute-wisdom">Attribute: Wisdom</h3>
<p>Regardless of your age, you are wise. You intuitively make good choices and are well schooled in practical knowledge. Play this card when you narrate an action that draws on your deep wisdom and experience.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-sleight-of-hand">Skill: Sleight of Hand</h3>
<p>You have nimble, and sticky, fingers. Rolling a dozen coins along your knuckles is not an issue for you. Play this card when you narrate an action that involves stealing, concealing or discretely moving an object; or when concealing the intent of your physical movements.</p></th>
<th><h3 id="skill-arcana-knowledge">Skill: Arcana Knowledge</h3>
<p>You have studied ancient infernal texts or had experiences with magic beyond that which normal people can wield. Play this card when you recall knowledge about spells, eldritch symbols, traditions, magical creatures and items.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-history-knowledge">Skill: History Knowledge</h3>
<p>Either schooled or known from some arcane source, you have a good grasp of historical happenings. Folk lore, myth and political knowledge are included. Play this card when you recall knowledge about any of these things.</p></th>
<th><h3 id="spell-protection-from-evil">Spell: Protection from Evil</h3>
<p>You sprinkle a mixture of silver and holy water over a willing or helpless creature.</p>
<p>The creature is protected from evil aberrations, celestials, elementals, fey, fields and undead until the end of the scene. If the creature was already affected by evil, it may attempt to resist the effects again.</p></th>
</tr>
<tr class="odd">
<th><h3 id="spell-prayer-of-healing">Spell: Prayer of Healing</h3>
<p>You speak a long prayer to your god and six creatures within range are healed of their physical wounds. Non-magical healing is also made more effective with this prayer. Disease and poisons are not affected.</p></th>
<th><h3 id="ability-knowledge-of-the-ages">Ability: Knowledge of the Ages</h3>
<p>You are touched by your god's presence, gaining some of its vast knowledge. You can use this card as a skill card of your choice.</p></th>
</tr>
<tr class="header">
<th><h3 id="spell-toll-the-dead">Spell: Toll the Dead</h3>
<p>You point at a creature and the sound of a loud bell can be heard. The creature's skin starts to be eaten away as it suffers a moderate amount of necrotic damage. The effect is very painful.</p></th>
<th><h3 id="spell-bless">Spell: Bless</h3>
<p>You speak a short prayer and sprinkle holy water on up to 3 creatures. For the rest of the scene, when spending a card, they can narrate a Super Risky action and still have a guaranteed outcome.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
