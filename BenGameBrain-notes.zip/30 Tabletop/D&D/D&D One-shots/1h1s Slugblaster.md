---
title: "1h1s Slugblaster"
source: "Game Stuff/Game Ideas/1h1s Slugblaster"
modified: 2025-05-30
type: campaign-prep
area: rpg-other
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["Slugblaster one-shot"]
words: 326
summary: "One-hour one-shot structure for the Slugblaster RPG: opening scene script, escape narration, challenge montage and notes."
tags: ["area/rpg-other", "project/d-d-one-shots", "type/campaign-prep"]
---

Setup

Always have a Counter for extra tricks in the run. Segments equal to number of players plus 1. You dont need to say check it to do this. If maxed before end of run, everyone gets a style.

Always allow a trick action at the end of the run to spend the last Attitude and Turbo

A group of teens are crowded around a phone. The likes are coming in thick and fast.

**Describe the teens**

The camera zooms out, and phases through the 4th wall of a television into some trashy trailer somewhere in the most boring dimension of them all, Null, your home dimension.

On the television is a live shot advertisement for Hardekker Mining Megacorp. The advert shows one of their mining sites in Prismata, a dimension of energy, which you just covered in tags of your crew.

**Describe your tags, which parts are incorporated into the crew tag? Are there any personal tags?**

The man watching the telly turns and shouts into the trailer “Marge, come ava look at this”

The view comes back to the teens, who lookup as an Alarm starts

There are several chutes that are used to transport the mined energy crystals that Hardekker gathers from this place. Thick blast doors start closing. Those were your planned method to the thin-zone.

From some of the nearby mining equipment, there is a clunking sound as chunks fall off to the ground. The shapes unfold into security bots. Lasers start firing.

Each player narrates their escape

Record progress

Fax printing out in some office somewhere. The face of one of the teens. That teen describes themselves.

Disaster roll

Downtime

No dice rolls!

Arcs and Beats

Spending trouble and style

Healing Slams

Tang-xiety from Panic Energy in hidden megamall in Vastish

Plastic desert

Billboard forest

5-6 point track

Old Guard filming sponsored videos in the entrance

Challenge Montage

Storyteller makes first challenge

Player 1 solves it then makes next challenge
