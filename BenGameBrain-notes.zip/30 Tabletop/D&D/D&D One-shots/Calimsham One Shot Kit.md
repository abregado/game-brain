---
title: "Calimsham One Shot Kit"
source: "Game Stuff/D&D/Calimsham One Shot Kit"
modified: 2020-11-14
type: template
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["Calimsham", "D&D one-shots"]
words: 3108
summary: "Document consisting only of unconverted tables (likely cards/character sheets for the Calimsham one-shot); no readable text."
tags: ["area/dnd", "project/d-d-one-shots", "type/template"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Vizier’s Advisor</strong></p>
<p>You are a civil servant working for the vizier who runs this part of Calimshan. Your pay is good and the comforts of your family spring directly from your loyal and hard work for the vizier. You also have seen what happens to those who cross your employer. Remember that your actions will affect the vizier's reputation.</p>
<p>Bonus:</p>
<p>Respect of local business owners.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Private Archaeologist</strong></p>
<p>So much history, so much treasure! You heard from one of the other adventurers that they were heading out this way and asked if you could join them. You have heard tales of some interesting ruins and you would love to explore them, once you figure out where they are. You already have some of the destination area mapped out.</p>
<p>Bonus:</p>
<p>Partial map of the area you already made.</p>
<p>Choose one of the other characters to be your friend.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Temple Orderly</strong></p>
<p>Whether or not you are religious, you work in one of the Temples in Calimport. The Temple pays little more than a stipend but they treat you fairly. A wealthy patron made a donation to the temple in exchange for your services.</p>
<p>You are to go along on this quest, and provide all the assistance you can. Remember, you are representing your temple, make them proud.</p>
<p>Bonus:</p>
<p>Your clothes let everyone know you are a holy person.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Record Keeper</strong></p>
<p>The Department of Record keeping, which is subordinate to Syl-Vizier, has sent you to transcribe the mission, to increase both accountability and transparency of the quest givers motives. It is common that guilds, business and departments get audited, and even more common that discoveries are made of shady deals.</p>
<p>Keep your eyes open. You also know that your report will be scrutinized closely, so be sure to behave.</p>
<p>Bonus:</p>
<p>People trust your word and respect your statistics.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Guild Operative</strong></p>
<p>You were given this job in person by the Pasha of your guild. This is a great opportunity for advancement in an otherwise slow moving and politically heavy work environment. You will be reporting to the Pasha personally when you are done. Your expenses for this mission are covered.</p>
<p>Bonus:</p>
<p>Guild seal and pouch of guild funds.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Common Acquaintance</strong></p>
<p>You were employed as a laborer, guard or other menial task in Calimport but when you heard about your friends mission you asked if you could come along. Since they said yes, you immediately quit your job to begin getting ready for your trip. This mission is a big deal for your friend, so you want to make sure you don’t screw up.</p>
<p>Bonus:</p>
<p>People of the lower class respect you.</p>
<p>Choose one of the other characters to be your friend.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Vigilante Hero</strong></p>
<p>You travel the desert sands looking out for evil, dangerous folk, and a bit of coin. This group was camping along one of your regular routes so you stopped and became acquainted with them. For a bit of coin, they convinced you to come along as protection. You are still not sure if they are the type of people to be protected, or to be protected from. Either way, you can do the most good for people by being involved.</p>
<p>Bonus:</p>
<p>Local legend</p>
</blockquote></th>
<th><blockquote>
<p><strong>Oath of Reverence</strong></p>
<p>You have sworn an oath which has the following tenets:</p>
</blockquote>
<ul>
<li><blockquote>
<p><strong>Honesty</strong>. Your word is your promise.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Duty</strong>. Be responsible for your actions and their consequences.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Compassion</strong>. Be merciful to your foes, and protect the weak.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Oath of Vengeance</strong></p>
<p>You have sworn an oath which has the following tenets:</p>
</blockquote>
<ul>
<li><blockquote>
<p><strong>No Mercy for the Wicked</strong>. They shall meet their judgement in the afterlife.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Countenance</strong>. If evil runs wild in the world, it is because I failed to do my duty.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Restitution</strong>. I must help the victims of evil reclaim their lives.</p>
</blockquote></li>
</ul></th>
<th><blockquote>
<p><strong>Oath of the Light</strong></p>
<p>You have sworn an oath which has the following tenets:</p>
</blockquote>
<ul>
<li><blockquote>
<p><strong>Hope</strong>. Kindle the light of hope, forgiveness and mercy to beat back despair in the world.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Beauty</strong>. Delight in song, laughter and art. The world cannot become dark if you hold the light in your heart.</p>
</blockquote></li>
<li><blockquote>
<p><strong>Beacon</strong>. Be a glorious beacon for all in the world.</p>
</blockquote></li>
</ul></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Outlander</strong></p>
<p>You are just travelling between the smaller outposts and towns looking for work. You were hired to help one of the other characters. You know quite a few people who pass through this area, but your geographical knowledge is limited to the main roads. You have found the best way through life is to build a good reputation in populated areas, and keep your enemies out in the desert sands. Preferably 6 feet under those sands.</p>
<p>Bonus:</p>
<p>Caravan contact in area</p>
<p>Choose one of the other characters to be your client.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Family Involved</strong></p>
<p>You are an uncle or cousin of the quest giver. You have been sent both to make sure that things go smoothly, and to provide assistance. You can keep this a secret from the other party members, or use it to your advantage. Your title and appearance do not link you to the quest giver at all, which means you can work from the shadows. It also means that if you screw up, nobody will associate your disappearance with the quest giver.</p>
<p>Bonus:</p>
<p>Underworld contact in area</p>
<p>Choose one of the other characters to be your family member.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 49%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Athletics</strong></p>
<p>Covers difficult situations you encounter while climbing, Jumping, or swimming. Other examples include avoiding hazards while scaling a wall or trying to jump an unusually long distance or pull off a stunt midjump.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Perception</strong></p>
<p>Lets you spot, hear, or otherwise detect the presence of something. Is also used to notice traps from a distance. It measures your general awareness of your surroundings and the keenness of your Senses.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Acrobatics</strong></p>
<p>Covers your attempt to stay on your feet in a tricky situation, such as when you're trying to run across a sheet of ice, balance on a tightrope, or stay upright on a rocking ship's deck.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Insight</strong></p>
<p>Grants a bonus when determining the true intentions of a creature, such as when searching out a lie, predicting someone's next move or determining a target's emotional state.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Deception</strong></p>
<p>This check determines whether you can convincingly hide the truth, either verbally or through your Actions.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Persuasion</strong></p>
<p>When you attempt to influence someone or a group of people, typically when acting in good faith, to foster friendships, make cordial requests, or exhibit proper etiquette.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Performance</strong></p>
<p>Determines how well you can delight an audience with music, dance, acting, storytelling, or some other form of entertainment as well as impersonating others.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Animal Handling</strong></p>
<p>How well you can calm down an animal, keep a mount from getting spooked, or understand an animal’s intentions. You can also try to command a trained animal.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Medicine</strong></p>
<p>Measures your ability to diagnose illness, or recognise the signs of medical procedures. Also can be used to determine cause of death or causes of wounds.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Sleight of Hand</strong></p>
<p>How well you can attempt an act of legerdemain, try to lift a coin purse off another person or slip something out of another person's pocket.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Investigation</strong></p>
<p>When you look around for clues, deduce the location of a hidden object, check an object for traps or search for a hidden fragment of knowledge.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Arcana</strong></p>
<p>Measures your ability to recall lore about spells, magic items, eldritch symbols, magical traditions, the planes of existence, and the inhabitants of those planes.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Stealth</strong></p>
<p>Make a check when you attempt to conceal yourself from enemies, slink past guards, slip away without being noticed, or sneak up on someone without being seen or heard.</p>
</blockquote></th>
<th><blockquote>
<p><strong>History</strong></p>
<p>Measures your ability to recall lore about historical events, legendary people, ancient kingdoms, past disputes, recent wars, and lost civilizations.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Survival</strong></p>
<p>To follow tracks, hunt wild game, guide your group through frozen wastelands, Identify signs that owlbears live nearby, predict the weather, or avoid quicksand and other natural hazards.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Intimidation</strong></p>
<p>Measures your ability to influence someone through overt threats, hostile actions, and physical violence, as well as getting proving your superiority in an intellectual battle.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Nature</strong></p>
<p>Measures your ability to recall lore about terrain, plants and animals, the weather, and natural cycles.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Religion</strong></p>
<p>Measures your ability to recall lore about deities, rites and prayers, religious hierarchies, holy symbols, and the practices of secret cults.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Greatsword or Greataxe</strong></p>
<p>Martial Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft. Causes 2d6 + Strength slashing damage.</p>
<p><strong>Heavy:</strong> You have disadvantage on this attack if you are Tiny or Small.</p>
<p><strong>Two Handed:</strong> To attack with this weapon, your offhand must be free.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Longsword or Battleaxe</strong></p>
<p>Martial Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p><strong>Versatile:</strong> Causes d8 + modifier slashing damage, or d10 + modifier if your off hand is free.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Heavy Crossbow</strong></p>
<p>Martial Weapon</p>
<p><em>Cock and Fire -</em> <strong>Action:</strong> Ranged attack roll (Dexterity) against a target within 100ft. Causes 1d10 + Dexterity piercing damage.</p>
<p>May only be fired once per turn.</p>
<p>You have disadvantage on this attack if you are Tiny or Small.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Dagger</strong></p>
<p>Simple Weapon</p>
<p><em>Stab -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d4 + modifier piercing damage.</p>
<p><em>Offhand stab -</em> <strong>Bonus Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d4 piercing damage.</p>
<p><em>Throw -</em> <strong>Action:</strong> Ranged attack roll (Dexterity or Strength) against a target within 20ft. Causes 1d4 + modifier piercing damage.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Throwing Axe</strong></p>
<p>Simple Weapon</p>
<p><em>Cleave -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft. Causes d6 + Strength slashing damage.</p>
<p><em>Throw -</em> <strong>Action:</strong> Ranged attack roll (Strength) against a target within 20ft. Causes d6 + Strength slashing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Shield</strong></p>
<p>Large Item</p>
<p>+2 Armor Class when wielding the shield. Counts as using the hand while wielded.</p>
<p><em>Don or Doff -</em> <strong>Action:</strong> equip or unequip the shield.</p>
<p>This item cannot be dropped if equipped.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Glaive</strong></p>
<p>Martial Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 10ft. Causes 1d10 + Strength slashing damage.</p>
<p><strong>Heavy:</strong> You have disadvantage on this attack if you are Tiny or Small.</p>
<p><strong>Two Handed:</strong> To attack with this weapon, your offhand must be free.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Greatmaul</strong></p>
<p>Martial Weapon</p>
<p><em>Smash -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft. Causes 2d6 + Strength bludgeoning damage.</p>
<p><strong>Heavy:</strong> You have disadvantage on this attack if you are Tiny or Small.</p>
<p><strong>Two Handed:</strong> To attack with this weapon, your offhand must be free.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Potion of Healing</strong></p>
<p>Small Item</p>
<p><em>Drink -</em> <strong>Action:</strong> Regain 2d4+2 hit points.</p>
<p><em>Administer -</em> <strong>Action:</strong> A target you can touch regains 2d4+2 hit points. If the target is <em>Unconscious</em> it immediately loses that condition and gains the <em>Prone</em> condition.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Mace or Hammer</strong></p>
<p>Simple Weapon</p>
<p><em>Crack -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft. Causes d6 + Strength bludgeoning damage.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Hand Crossbow</strong></p>
<p>Martial Weapon</p>
<p><em>Cock and Fire -</em> <strong>Action:</strong> Ranged attack roll (Dexterity) against a target within 30ft. Causes 1d6 + Dexterity piercing damage.</p>
<p><em>Offhand fire -</em> <strong>Bonus Action:</strong> Ranged attack roll (Dexterity) against a target within 30ft. Causes 1d6 piercing damage.</p>
<p><strong>Loading:</strong> May only be fired once per turn.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Rapier</strong></p>
<p>Martial Weapon</p>
<p><em>Lunge -</em> <strong>Action:</strong> Melee attack roll (Strength or Dexterity) against a target within 5ft. Causes d6 + modifier piercing damage.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Oud</strong></p>
<p>Held Item</p>
<p>Held in two hands. Is required for a Bard to spend Magic tokens.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Scimitar</strong></p>
<p>Martial Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 + modifier slashing damage.</p>
<p><em>Offhand slash -</em> <strong>Bonus Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 slashing damage.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Soul Contract</strong></p>
<p>Held Item</p>
<p>Wielded in one hand. Is required for a Warlock to spend Magic tokens.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Holy Symbol Shield</strong></p>
<p>Large Item</p>
<p>+2 Armor Class when wielding the shield. Counts as using the hand while wielded.</p>
<p><em>Don or Doff -</em> <strong>Action:</strong> equip or unequip the shield.</p>
<p>Must be donned for a Cleric or Paladin to spend Magic tokens.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Holy Symbol Quarterstaff</strong></p>
<p>Simple Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p><strong>Versatile:</strong> Causes d6 + modifier slashing damage, or d8 + modifier if your off hand is free.</p>
<p>Is required for a Cleric to spend Magic tokens.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Soul Focus</strong></p>
<p>Held Item</p>
<p>Wielded in one hand. Is required for a Sorcerer to spend Magic tokens.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Spellbook</strong></p>
<p>Held Item</p>
<p>Wielded in one hand. Is required for a Wizard to cast magic.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Thieves Tools</strong></p>
<p>Small Item</p>
<p>Adds +2 to a check to disarm traps or pick locks when used by a Rogue.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Druidic Totem</strong></p>
<p>Held Item</p>
<p>Wielded in one hand. Is required for a Druid to cast magic.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Wooden Shield</strong></p>
<p>Large Item</p>
<p>+2 Armor Class when wielding the shield. Counts as using the hand while wielded.</p>
<p><em>Don or Doff -</em> <strong>Action:</strong> equip or unequip the shield.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Sickle</strong></p>
<p>Simple Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p>Causes d4 + modifier slashing damage.</p>
<p><em>Offhand Slash -</em> <strong>Bonus Action:</strong> Melee attack roll (Strength) against a target within 5ft. Causes d4 slashing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Longbow</strong></p>
<p>Martial Weapon</p>
<p><em>Draw and Fire -</em> <strong>Action:</strong> Ranged attack roll (Dexterity) against a target within 150ft. Causes 1d8 + Dexterity piercing damage.</p>
<p>You have disadvantage on this attack if you are Tiny or Small.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Shortbow</strong></p>
<p>Martial Weapon</p>
<p><em>Draw and Fire -</em> <strong>Action:</strong> Ranged attack roll (Dexterity) against a target within 80ft. Causes 1d6 + Dexterity piercing damage.</p>
</blockquote></th>
<th></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Flick Knife</strong></p>
<p>Exotic Weapon</p>
<p><em>Stab -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 + modifier slashing damage.</p>
<p><em>Offhand stab -</em> <strong>Bonus Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 slashing damage.</p>
<p><em>Switch -</em> <strong>Free Action:</strong> Swap your currently wielded weapon with the Punch Dagger.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Pike</strong></p>
<p>Martial Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 10ft. Causes 1d10 + Strength piercing damage.</p>
<p><strong>Heavy:</strong> You have disadvantage on this attack if you are Tiny or Small.</p>
<p><strong>Two Handed:</strong> To attack with this weapon, your offhand must be free.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Silver Dagger</strong></p>
<p>Exotic Weapon</p>
<p><em>Stab -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d4 + modifier piercing damage.</p>
<p><em>Offhand stab -</em> <strong>Bonus Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d4 piercing damage.</p>
<p><em>Throw -</em> <strong>Action:</strong> Ranged attack roll (Dexterity or Strength) against a target within 20ft. Causes 1d4 + modifier piercing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Hellsword</strong></p>
<p>Exotic Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength or Dexterity) against a target within 5ft. Causes d8 + modifier +1 slashing damage, or d10 + modifier +1 if made with two hands.</p>
<p>Attacks count as magical.</p>
<p>Allows a Warlock to spend Magic tokens.</p>
<p>Summon - <strong>Bonus Action:</strong> The sword returns to your hand.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Qiang</strong></p>
<p>Monk Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength or Dexterity) against a target within 5ft. Causes d6 + modifier piercing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Jian</strong></p>
<p>Monk Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength or Dexterity) against a target within 5ft. Causes d6 + modifier slashing damage.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Tonfa</strong></p>
<p>Monk Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength or Dexterity) against a target within 5ft.</p>
<p>Causes d6 + modifier bludgeoning damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Shadow Reaper</strong></p>
<p>Exotic Weapon</p>
<p><em>Attack -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 2d8 psychic damage.</p>
<p><em>Throw -</em> <strong>Action:</strong> Ranged attack roll (Dexterity or Strength) against a target within 20ft. Causes 2d8 psychic damage. It returns to your hand after the attack.</p>
<p>If the target is in dim light or darkness, you gain advantage on your attack.</p>
<p>Attacks made with this weapon are magical.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Warhammer</strong></p>
<p>Martial Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p><strong>Versatile:</strong> Causes d8 + modifier bludgeoning damage, or d10 + modifier if your off hand is free.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Magical Choker</strong></p>
<p>Small Item</p>
<p>Worn around the neck. Allows a Bard to spend Magic tokens, as long as it can speak.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table style="width:50%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Shortsword</strong></p>
<p>Martial Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 + modifier slashing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Silver Shortsword</strong></p>
<p>Exotic Weapon</p>
<p><em>Slash -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 5ft. Causes 1d6 + modifier slashing damage.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Whip</strong></p>
<p>Martial Weapon</p>
<p><em>Lash -</em> <strong>Action:</strong> Melee attack roll (Dexterity or Strength) against a target within 10ft. Causes 1d4 + modifier slashing damage.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Quarterstaff</strong></p>
<p>Simple Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p><strong>Versatile:</strong> Causes d6 + modifier slashing damage, or d8 + modifier if your off hand is free.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Mace or Hammer</strong></p>
<p>Simple Weapon</p>
<p><em>Strike -</em> <strong>Action:</strong> Melee attack roll (Strength) against a target within 5ft.</p>
<p>Causes d6 + Strength bludgeoning damage</p>
</blockquote></th>
<th><blockquote>
<p><strong>Tinkers Kit</strong></p>
<p>Small Item</p>
<p>Adds +2 to a check to disarm traps or pick locks when used by an Artificer.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 49%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Personality</strong></p>
<p>I am always an optimist, even when things are going very wrong.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Bond</strong></p>
<p>I owe a guild a great debt for lifting me out of poverty. I will always act in their best interests.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Personality</strong></p>
<p>I am solemn and see omens in every event.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Bond</strong></p>
<p>The next time I meet my mentor I must be truthful when I say I have always acted in a worthy manner.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Personality</strong></p>
<p>I am always calm and never raise my voice or let my emotions control me.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Bond</strong></p>
<p>I’m being blackmailed by someone in power whom I owe a debt. I need to earn some extra coin soon.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Personality</strong></p>
<p>I love a good insult, especially one directed at me. A good laugh can smooth any bad mood.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Bond</strong></p>
<p>When I die, I will stand before my god and be judged by this action.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Personality</strong></p>
<p>I don’t like to get my hands dirty. There are plenty of people to do those thankless tasks for me.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Bond</strong></p>
<p>My country or state is the most important thing to me.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 49%" />
</colgroup>
<thead>
<tr class="header">
<th><blockquote>
<p><strong>Ideal</strong></p>
<p>Justice and Good at all costs. A few innocent lives should not get in the way of the greater good.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Flaw</strong></p>
<p>There is no room for caution in my life and I enjoy living on the edge.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Ideal</strong></p>
<p>Traditional ways are best. Change is the weakling's reaction to hardship.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Flaw</strong></p>
<p>I put too much trust in what people tell me, even when it sounds implausible.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Ideal</strong></p>
<p>Fairness is for everyone and works both ways. Nobles, kings and the super rich need to be shown this.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Flaw</strong></p>
<p>I have trouble trusting my allies at crucial moments.</p>
</blockquote></th>
</tr>
<tr class="odd">
<th><blockquote>
<p><strong>Ideal</strong></p>
<p>Honesty without question. In this, I must be a shining example to which people aspire.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Flaw</strong></p>
<p>I believe that everyone is beneath me, and make sure they know it.</p>
</blockquote></th>
</tr>
<tr class="header">
<th><blockquote>
<p><strong>Ideal</strong></p>
<p>Respect for Authority. The strong should protect the weak, but the weak should do everything in their power to make it easier.</p>
</blockquote></th>
<th><blockquote>
<p><strong>Flaw</strong></p>
<p>My need to win every argument is more important than any quest.</p>
</blockquote></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
