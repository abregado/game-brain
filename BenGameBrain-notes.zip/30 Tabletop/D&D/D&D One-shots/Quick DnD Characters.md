---
title: "Quick DnD Characters"
source: "Game Stuff/D&D/Quick DnD Characters"
modified: 2019-05-07
type: character
area: dnd
status: "prototyped"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots"]
words: 913
summary: "Spreadsheet of five level-2 pregenerated D&D characters (bard, bard, barbarian, fighter, cleric) with stats, proficiencies, HP and personality traits."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---

## Sheet: Sheet1

| Level | 2.0 | 2.0 | 2.0 | 2.0 | 2.0 |
|---|---|---|---|---|---|
| Race | Tiefling | Half Elf | Shield Dwarf | Stout Halfling | Human |
| Class | Bard | Bard | Barbarian | Fighter | Cleric |
| Subclass | College of Valor | College of Lore |  |  | Knowledge |
| Background | Urchin/Abandoned | Entertainer/Singer | Soldier/Infantry | Guild Artisan / Smith | Acolyte |
| Str | 8.0 | 10.0 | 14.0 | 11.0 | 13.0 |
| Dex | 15.0 | 14.0 | 13.0 | 17.0 | 9.0 |
| Con | 12.0 | 14.0 | 17.0 | 16.0 | 14.0 |
| Int | 14.0 | 10.0 | 8.0 | 10.0 | 15.0 |
| Wis | 8.0 | 12.0 | 13.0 | 10.0 | 16.0 |
| Cha | 17.0 | 17.0 | 10.0 | 10.0 | 11.0 |
| Proficiencies | Deception, Investigation, Persuasion, Sleight of Hand, Stealth, Shortbow, Rapier, Lute | Acrobatics, Deception, Insight,Intimidation, Medicine, Performance, Sleight of Hand, Shortsword, Crossbow, Harmonica | Athletics, Intimidation, Perception, Survival, light armor, medium armor,shields, simple weapon, martial weapons | Acrobatics, Athletics, Insight, Persuasion, Smiths Tools, All Armor, Shields, Simple weapons, Martial Weapons | Arcana, History, Insight, Medicine, nature, Religion |
| Saving Throws | Dexterity, Charisma | Dexterity, Charisma | Strength, Constitution | Strength, Constitusion |  |
| Armor Class | 14.0 | 13.0 | 14.0 | 14.0 |  |
| Size | Medium | Medium | Medium | Small |  |
| Walking/Running | 30/60 | 30/60 | 25/50 | 25/50 |  |
| Long Jump |  |  |  |  |  |
| High Jump |  |  |  |  |  |
| Hit Points Max | 18.0 | 18.0 | 32.0 | 26.0 |  |
| Hit Dice/Type | 2d8 | 2d8 | 2d12 | 2d10 |  |
| Personality Trait 1 | I sleep with my back to a wall or tree, with everything I own wrapped in a bundle in my arms. | I love a good insult, even one directed at me. | Im haunted by memories of war. I cant get images of violence out of my head | I like to talk at length about my profession |  |
| Personality Trait 2 |  | I settle for nothing less than perfection. | I enjoy being strong and like breaking things | I am well known for my work and want to make sure everyone appreciates it. |  |
| Ideal 1 | Im going to prove that Im worthy of a better life | When I perform, I make the world better than it was. | Those who fight beside me are worth dying for. | I work hard to be the best there is at my craft |  |
| Ideal 2 | No one else should have to endure the hardships Ive been through |  |  |  |  |
| Bond 1 | I owe a crime lord a very big favor |  | Nation. My people are all that matter | I owe the guild a great debt for making me the person i am today |  |
| Bond 2 | Creatures acting on their instict are never evil |  |  |  |  |
| Flaw 1 | I will never fully trust anyone other than myself | I will do anything to win fame and renoun | My hatred of my enemies is blind and unreasoning | Im horribly jealopus of anyone who can outshine my work. |  |
| Flaw 2 | I doubt every descision I make |  |  | I see rivals in everyone |  |
| Passive Abilities | Ritual Casting | Fey Ancestry | Unarmored Defence | Fighting Style: Two Weapon |  |
|  | Song of Rest | Darkvision | Danger Sense | Action Surge |  |
|  | Darkvision |  | Military rank | Brave |  |
|  | Jack of all Trades |  | Stone cunning | Lucky |  |
|  |  |  | Darkvision | Nimbleness |  |
|  |  |  | Dwarven Toughness | Stout Resilience |  |
|  |  |  | Dwarven Resilience |  |  |
| Weapon Choice 1 | Shortbow | Shortsword |  | Longsword + Shortsword |  |
| Weapon Choice 2 | Rapier | Hand crossbow |  | Rapier + Shortsword |  |
| Actions | Attack with Shortbow | Attack with weapon | Attack with weapon | Attack with weapon |  |
|  | Vicious Mockery | Vicious Mockery | Reckless Attack |  |  |
| Bonus Actions | Bardic Inspiration | Bardic Inspiration | Rage | Second Wind |  |
|  |  |  |  | Attack with offhand weapon |  |
| Reactions |  |  |  |  |  |
| Cantrips | Thaumaturgy | Light |  |  |  |
|  | Vicious Mockery | Vicious Mockery |  |  |  |
|  | Minor Illusion |  |  |  |  |
| Spells | Hellish Rebuke | Cure Wounds |  |  |  |
|  | Cure Wounds | Healing Word |  |  |  |
|  | Healing Word | Sleep |  |  |  |
|  | Sleep | Thunderwave |  |  |  |
|  | Darkness |  |  |  |  |
| Rituals | Detect magic | Detect Magic |  |  |  |
|  | Idenify |  |  |  |  |
|  | Song of Rest |  |  |  |  |
