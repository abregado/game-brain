---
title: "Phandalin Replacements"
source: "Game Stuff/Phandalin Replacements"
modified: 2022-11-06
type: campaign-prep
area: dnd
status: "idea"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots"]
words: 104
summary: "List of replacement NPC names with moods for Phandalin in a D&D Lost Mine of Phandelver game."
tags: ["area/dnd", "project/d-d-one-shots", "type/campaign-prep"]
---

- Mister witch

  - Somberness

- Mister light

  - Moody

- Kettle steam

  - Temperamental

- Nikolas midnight (goblin ticketmaster)

  - Suspicion

- Treaclewise (rhyming goblin)

  - Elation

- Ernest the monkey

  - Obsessive

- Diana cloppington

  - Sadness/self pity

- Northwind

  - Amazement

- Ellywick tumblestrum

  - Joyous

- Feathereen (gondola swan)

  - Erudite/hauty

- Rubin Sugarwood

  - Embarrassed

- Ween sundapple

  - Shame

- Candle foot

  - Indecisive

- Palasha (mermaid)

  - Impatience

- Dirlagraun (displacer beast)

  - Nurturing

- Zephixo (dwarf mage)

  - Inspired

- Jeremy Plum (pixie)

  - Playful

- Burly (bugbear)

  - Gratitude, educated

- Thaco (clown)

  - Bitter
