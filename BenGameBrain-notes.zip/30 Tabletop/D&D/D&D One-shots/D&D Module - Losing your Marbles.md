---
title: "D&D Module - Losing your Marbles"
source: "Game Stuff/D&D/D&D Module_ Losing your Marbles"
modified: 2020-05-27
type: campaign-prep
area: dnd
status: "designed"
projects: ["[[D&D One-shots]]"]
concepts: ["D&D one-shots"]
words: 701
summary: "Outline and rough notes for a D&D one-shot module about a demonologist and a cursed item that creates evil clones; scene structure, hooks, combat and endings."
tags: ["area/dnd", "project/d-d-one-shots", "type/campaign-prep"]
---

- Adventure Background / The invitation

- Adventure Synopsis

- The invitation

- Scene 1

  - NPC details (the half stranger)

  - Setting (a tavern)

  - Combat (minor demons)

  - Skill challenge or Clues

- Scene 2, Option 1

  - NPC details (The demonologist)

  - Setting (arcane workshop)

  - Combat or Skill option

- Scene 2, Option 2

  - NPC details (The friend of a friend)

  - Setting (the temple grounds)

  - Combat or Skill option

- Scene 2, Option 3

  - Setting (ruined apartment)

  - Investigation (skill challenge)

- Scene 3

  - NPC Details (paladin)

  - Setting (dark alley)

  - Skill option

- Scene 4

  - Cutscene

  - Combat

  - Resolution and final clues

- Glossary and Index

Intro sequence

Hook the demonologist in in some way

- A fence has lined up a job to steal something from him

- A church wants him captured, quietly

- A vigilante heroic order wants him killed

PCs are given an item and then the giver dies in combat or is dragged off by a powerful demon.

- Record if the barkeep sees the PCs take the item

Dretch combat.

- Characters have one weapon attack and a single special rule duet to use.

PCs go to someone to ask for help and information 2-3 choices:

- Skill challenge, players make up ideas for each of their skill proficiencies

- Some PCs have pregenerated background stories and hooks

Option 1.0: Go straight to a temple

Option 1.1: Ask the demonologist

- The demonologist lives in a poor area, there is an enchantment on this house to make it inconspicuous

- There is a gargoyle that watches the alley approach

- The demonologist is fascinated by the item, and gives the party two more options:

  - He has been preparing to summon a powerful demon for weeks, they can speed that along and ask for the fiendish advice

  - He can keep the item, or one of their weapons and perform some divination magic. The heroes can return in 24 hours for some answers.

Option 1.2: Track where the dead person came from (goes back to his apartment)

- The tracks lead to a hotel

- The place is ransacked but humans

- No demonic residue

- The neighbours complain of screaming and crying in the night

Option 1.3: Ask a mutual acquaintance (a cleric who had some contact with them)

- A cleric from the war who likes to keep in touch with everyone from the old unit

- Saw the guy a few weeks back, and knows something was up

- The guy was feeling guilty and conficted that there was something he had to do but it was wrong

- He is staying with a friend/mistress in another part of the city.

After either of these The party encounters some elite City Watchmen, led by a Paladin of Tyr. he asks the party to come back to the temple for cleansing, and to give up their weapons for a divination ritual, as there is still unholy energy on them. If the party will not come with them, then they request all of their weapons. If the party refuses, then they are placed under arrest.

Make sure it is obvious that these are not evil people, and that the party cannot win.

- If the party is stalling, have the main guide show up behind them, see the group and then run, and half the watchmen go after him. This should allow the players to either run, fight or convince them something is up.

The final scene

The PCs need to discover:

- What the item is doing

- 

The scary ending

- There is now an evil clone of you that gets stronger the longer you live, while you become weaker. It wants to keep you alive as long as possible.

- Other demons are losing power and respect to these new fiendish copies on the material realm, they also want to stop them, but will do so by killing or kidnapping the PCs.

Funny ending

- The item is a fiendish chain letter, the people who touched it need to pass it on to be free of the curse
