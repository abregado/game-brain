---
title: "AbstractDnD - Sedge Bluestone"
source: "Game Stuff/AbstractDnD - Sedge Bluestone"
modified: 2021-10-15
type: character
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]"]
concepts: ["AbstractDnD"]
words: 494
summary: "Near-empty character sheet stub for Sedge Bluestone (Earth Genasi Sorcerer); only a title and an unconverted table."
tags: ["area/dnd", "project/d-d-one-shots", "type/character"]
---



Sedge Bluestone

## Earth Genasi Sorcerer

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><h3 id="attribute-constitution">Attribute: Constitution</h3>
<p>You are incredibly tough, healthy, vigourous. You also find it easy to hold your concentration. Play this card when you narrate an action involving doing something that requires incredible stamina, endurance or vigor.</p></th>
<th><h3 id="attribute-charisma">Attribute: Charisma</h3>
<p>Your personality is incredibly powerful. Regardless of what you ask, people seem more likely to do what you ask (or tell) them to do. You make friends easily, and diffuse tense situations almost passively. Play this card when you narrate an action involving social interaction.</p></th>
</tr>
<tr class="odd">
<th><h3 id="skill-athletics">Skill: Athletics</h3>
<p>You are trained in using your body to traverse terrain. Swimming, Climbing and Jumping come as easily to you as walking to others. You also know what kinds of movements will make your opponent tired. Play this card when you narrate an action that involves a great feat of endurance or physical skill.</p></th>
<th><h3 id="skill-acrobatics">Skill: Acrobatics</h3>
<p>Sure footed and perfectly balanced, your body functions incredibly well at high speed and in the air. Play this card when you narrate an action where you need to land correctly, or make a risky gymnastic like move.</p></th>
</tr>
<tr class="header">
<th><h3 id="skill-persuasion">Skill: Persuasion</h3>
<p>Whether through fancy speech or body language, you are able to convince people to do what you ask when your intentions are honest. Play this card when you narrate an action where you try to convince someone of something that is true.</p></th>
<th><h3 id="ability-earth-aegis-teleport">Ability: Earth Aegis Teleport</h3>
<p>You point at a friendly target you can see and an aura of glittering dust surrounds it. Until the end of the scene, the target only loses a card when having something bad happens to it 50% of the time. You can also teleport at any time to be adjacent to the target as long as you are both the same stone surface.</p></th>
</tr>
<tr class="odd">
<th><h3 id="spell-earthen-grasp">Spell: Earthen Grasp</h3>
<p>With a shout you raise and clench your fist. A large hand made of the same material as the floor rises up to envelop a target of your choice you can see within 30ft. The target is gripped by the hand, but you can also command the hand to try and crush the target. The hand stays in existence and can be commanded in later narrations as long as you maintain Concentration.</p></th>
<th><h3 id="spell-shatter">Spell: Shatter</h3>
<p>A sudden loud ringing noise erupts from a point of your choice within 60ft. Every creature within 10ft of this point suffers thunder damage. Inanimate objects within the range suffer severe damage as well.</p></th>
</tr>
<tr class="header">
<th><h3 id="spell-enlargereduce">Spell: Enlarge/Reduce</h3>
<p>You swallow a small ball of iron and say a magic command. One effect of your choice occurs until the end of the scene, or until your Concentration breaks:</p>
<p>Your size doubles in all dimensions, and your weight increases by 8.</p>
<p>Your size halves in all dimensions and your weight is reduced to one eighth its normal.</p></th>
<th><h3 id="spell-absorb-elements">Spell: Absorb Elements</h3>
<p>In the round after being struck by an elemental damage or effect, you may play this card to narrate an effect using that type of elemental energy.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>
