---
title: "WDnD One-shot Classes"
source: "Game Stuff/D&D/WDnD One-shot Classes"
modified: 2020-02-12
type: reference-data
area: dnd
status: "unknown"
projects: ["[[D&D One-shots]]", "[[WDnD Campaign]]"]
concepts: ["D&D one-shots", "WDnD campaign"]
words: 416
summary: "Only a heading 'Classes' and a table that did not convert; effectively empty."
tags: ["area/dnd", "project/d-d-one-shots", "project/wdnd-campaign", "type/reference-data"]
---

## Classes

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>Eldritch Knight</p>
<p>You have mastered the basics of all combat styles. You can swing an axe, fence with a rapier, wield a longsword or a greatsword, use a bow, and even trap foes in a net with some degree of skill. Likewise, you are adept with shields and every form of armor. Now you turn your hand to the arcane, augmenting your skills with combat magic.</p></th>
<th><p>Storm Sorcerer</p>
<p>Golden eyes flashing, you stretch out your hand and unleash the energy that storms through your veins. As a whirlwind rages around your foes, you whisper a word. The wind lifts you and sends you flying to a safe location.</p></th>
</tr>
<tr class="odd">
<th><p>Guardian of Lore</p>
<p>You are an intermediary between the mortal world and the distant planes of the gods. Chosen by a god of learning, you seek out, protect and share the arcane texts of the material plane. These works are collected in a great temple library where you worship.</p></th>
<th><p>Bladesinger</p>
<p>Clad in the robes that denote your station, you close your eyes to shut out the distractions of the battlefield and begin a quiet chant. Fingers weaving across your blade, it begins to sing along with you. Time slows as you and the blade slip into a harmonious trance.</p></th>
</tr>
<tr class="header">
<th><p>Open Hand Monk</p>
<p>Your fists a blur as they deflect an incoming hail of arrows, you spring over a barricade and throw yourself into the massed ranks of hobgoblins on the other side. You whirl among them, knocking their blows aside and sending them reeling, until at last you stand alone.</p></th>
<th><p>Abyssal Warlock</p>
<p>You are a seeker of a knowledge that lies hidden in the fabric of the multiverse. Through pacts made with your demonic patron, you unlocked magical effects, subtle and spectacular. Darkness shrouds both your intent and visage, and the Abyss granted you a Familiar to do your bidding.</p></th>
</tr>
<tr class="odd">
<th><p>Roguish Explorer</p>
<p>You rely on skill, stealth, cunning, and your foes' vulnerabilities to get the upper hand in any situation. You have a knack for finding the solution to just about any problem, especially if it requires the tip of your blade.</p></th>
<th><p>Druid of the Moon</p>
<p>Whether calling on the elemental forces of nature or emulating the creatures of the animal world, you are an embodiment of nature's resilience, cunning, and fury. You claim no mastery over nature, but it heeds your behest as an old friend might. You can change into a number of animal forms, and have an option for most situations.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

## 

##
