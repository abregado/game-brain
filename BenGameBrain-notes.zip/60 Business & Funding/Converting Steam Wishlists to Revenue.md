---
title: "Converting Steam Wishlists to Revenue"
source: "Game Stuff/Converting Steam Wishlists to Revenue"
modified: 2020-06-08
type: business
area: non-game
status: "unknown"
projects: ["[[Game Business & Funding]]"]
concepts: ["Game business & funding"]
words: 216
summary: "Calculator turning Steam wishlist count into sales and revenue after Steam cut and tax, based on a blog article."
contains_external_material: "Based on figures from a Vasinov Games blog article"
tags: ["area/non-game", "project/game-business-funding", "type/business"]
---

## Sheet: Sheet1

| Wishlists at Launch | Sales/Wishlist (1st Week) | 1st Month/1st Week | 1st Year/1st Week | Launch Price |
|---|---|---|---|---|
| 3000.0 | 0.4 | 2.5 | 5.0 | 10.0 |
| Sales 1st Week | Sales 1st Month | Sales 1st Year |  |  |
| 1200 | 3000 | 6000 |  |  |
| Average Price Drop | Steam Cut | Sales Tax |  |  |
| 0.0 | 0.3 | 0.19 |  |  |
| 1st Week Revenue |  |  |  |  |
| Total Revenue | 12000 |  |  |  |
| Revenue After Steam | 8400 |  |  |  |
| Revenue After Steam & Taxes | 6804 |  |  |  |
| 1st Month Revenue |  |  |  |  |
| Total Revenue | 30000 |  |  |  |
| Revenue After Steam | 21000 |  |  |  |
| Revenue After Steam & Taxes | 17010 |  |  |  |
| 1st Year Revenue |  |  |  |  |
| Total Revenue | 60000 |  |  |  |
| Revenue After Steam | 42000 |  |  |  |
| Revenue After Steam & Taxes | 34020 |  |  |  |
| Original Article |  |  |  |  |
| https://www.vasinovgames.com/blog/how-many-steam-wishlists-convert-to-100k/ |  |  |  |  |
