---
title: "BS - Manti(Core) monetization systems"
source: "Game Stuff/Game Ideas/BS - Manti(Core) monetization systems"
modified: 2021-11-07
type: notes
area: other
status: "idea"
projects: ["[[Game Business & Funding]]", "[[Shooters & FPS]]"]
concepts: ["Game business & funding", "Manticore"]
words: 63
summary: "Brief list of reward-point and Manticoin monetization ideas for a game."
tags: ["area/other", "project/game-business-funding", "project/shooters-fps", "type/notes"]
---

**Player expectations**

Two motivations to play a game

- Actually fun game

- RP bonuses

**Reward points**

Daily quests that give RP

Login bonus

Short game with restarts. Get RP per restart completed on Login.

**Manticoins bonuses**

“Donate” to the author

Double resources for X time

“Free items”

Batches of resources

Increase resource rate for all players with you

More daily actions

Lootboxes
