---
title: "Games Fund notes"
source: "Game Stuff/Games Fund notes"
modified: 2023-03-27
type: notes
area: other
status: "unknown"
projects: ["[[Game Business & Funding]]", "[[Emerge]]"]
concepts: ["Game business & funding", "Emerge"]
words: 119
summary: "Questions and notes about games funding eligibility (freelancers, platform market share, co-development, Kickstarter) with notes for Emerge."
tags: ["area/other", "project/emerge", "project/game-business-funding", "type/notes"]
---

Can Freie Berufe (Artists) receive the funding?

Do you have the platform breakdown but for market share, rather than player count?

How is it accessed if a company can support the project budget? How much cash does a company need to have on hand to begin with?

Does crowd-funding count as a co-development? For example, the game is ready for early access, and you want to take it to kickstarter, and would like to also get funding to push the game to release?

**Notes for Emerge**

Co-developments can be funded. Addons, expansions, ports.

Kickstarter is fine as long as you say:

- “We want to get the funding”

- “We wont do the project unless we get the funding”
