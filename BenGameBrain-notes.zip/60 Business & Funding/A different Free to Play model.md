---
title: "A different Free to Play model"
source: "Game Stuff/Game Ideas/A different Free to Play model"
modified: 2014-03-24
type: idea
area: game-idea
status: "idea"
projects: ["[[Game Business & Funding]]"]
concepts: ["Queue Donation F2P Model", "Game business & funding"]
words: 56
summary: "Idea for an online game whose queue position is based on lifetime donations, with limited server slots."
tags: ["area/game-idea", "project/game-business-funding", "type/idea"]
---

Online only multiplayer game

Limited server spaces

a joining queue

Your place in the queue is based on your total lifetime real money donations.

Server spaces can get released at the devs discretion

Start small, the early players might donate more wen their are limited slots.

Free trial for any player, client is available for free
