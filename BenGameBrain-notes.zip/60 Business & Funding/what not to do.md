---
title: "what not to do"
source: "Game Stuff/what not to do"
modified: 2026-03-17
type: notes
area: non-game
status: "unknown"
projects: ["[[Game Business & Funding]]"]
concepts: ["Game business & funding"]
words: 139
summary: "Bullet list of advice for starting a game studio: pick cofounders carefully, contracts, financial plan and funding options, market research, show early, build community, Steam wishlists."
tags: ["area/non-game", "project/game-business-funding", "type/notes"]
---

Be picky about who you start a studio with

Clear Division

Vibes well

Complmentarz skills

Long Term Goals

Don't Save money on contracts

Vesting clause?

Agree on expectations

Do the contracts when you still like each other

Don't found a game, found a company

Have a financial plan

How does each founder fund themselves

Side gigs

Public funding

Publisher

Crowd funding

Have a plan B

Plan and manage your cash flow

Cash flow table…

Look at it every week

Don't make the wrong game

Do market research

Know your competitors

Build on your own strengths

Don't forgot project planning

Don't hide in your cave until the game is done

Show early and often

Be willing to make hard decisions

Build community early

Don't put the game on steam and hope it sells

Wishlist and languages

Understand what steam values
