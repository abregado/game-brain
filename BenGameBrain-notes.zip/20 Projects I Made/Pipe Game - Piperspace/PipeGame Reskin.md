---
title: "PipeGame Reskin"
source: "Game Stuff/PipeGame Reskin"
modified: 2025-02-20
type: notes
area: game-idea
status: "idea"
projects: ["[[Pipe Game - Piperspace|Pipe Game / Piperspace]]"]
concepts: ["Pipe Game / Piperspace"]
words: 133
summary: "List of resource names (Spark, Flux, Matter, Sludge, Nanites, etc.) for reskinning the Pipe Game."
tags: ["area/game-idea", "project/pipe-game-/-piperspace", "type/notes"]
---

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p>Pizza Oven</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Sauce</p>
</blockquote></li>
<li><blockquote>
<p>Cheese</p>
</blockquote></li>
<li><blockquote>
<p>Bread</p>
</blockquote></li>
<li><blockquote>
<p>Heat</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Pizza</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Cryonic Support System</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Gel</p>
</blockquote></li>
<li><blockquote>
<p>Nanites</p>
</blockquote></li>
<li><blockquote>
<p>Filament</p>
</blockquote></li>
<li><blockquote>
<p>Endo</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="odd">
<th><p>Grinder</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Wheat</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Flour</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Congealer - Render x1</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Sludge</p>
</blockquote></li>
<li><blockquote>
<p>Endo</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Chunks</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="header">
<th><p>Kneeder</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Flour</p>
</blockquote></li>
<li><blockquote>
<p>Water</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Bread</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Loom - Protein Folder x1</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Chunks</p>
</blockquote></li>
<li><blockquote>
<p>Flux</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Filament</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="odd">
<th><p>Grower</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Carbon</p>
</blockquote></li>
<li><blockquote>
<p>Hydrogen</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Wheat or Tomato</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Biovat x2</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Matter</p>
</blockquote></li>
<li><blockquote>
<p>Spark</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Sludge</p>
</blockquote></li>
<li><blockquote>
<p>Spark</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="header">
<th><p>Water Maker</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Hydrogen</p>
</blockquote></li>
<li><blockquote>
<p>Oxygen</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Water</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Cauldron</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Spark</p>
</blockquote></li>
<li><blockquote>
<p>Flux</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Exo</p>
</blockquote></li>
<li><blockquote>
<p>Endo</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="odd">
<th><p>Sauce Maker</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Tomato</p>
</blockquote></li>
<li><blockquote>
<p>Water</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Sauce</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Reducer x1</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Sludge</p>
</blockquote></li>
<li><blockquote>
<p>Exo</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Gel</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="header">
<th><p>Cheese Maker</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Hydrogen</p>
</blockquote></li>
<li><blockquote>
<p>Carbon</p>
</blockquote></li>
<li><blockquote>
<p>Water</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Cheese</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><p>Nanite Press x1</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Matter</p>
</blockquote></li>
<li><blockquote>
<p>Spark</p>
</blockquote></li>
<li><blockquote>
<p>Exo</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Nanites</p>
</blockquote></li>
<li><blockquote>
<p>Spark</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="odd">
<th><p>Heat Maker</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Hydrogen</p>
</blockquote></li>
<li><blockquote>
<p>Oxygen</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Heat</p>
</blockquote></li>
</ul></li>
</ul></th>
<th><ul>
<li></li>
</ul></th>
</tr>
<tr class="header">
<th></th>
<th><p>Destabilizer</p>
<ul>
<li><blockquote>
<p>In</p>
</blockquote>
<ul>
<li><blockquote>
<p>Flux</p>
</blockquote></li>
<li><blockquote>
<p>Matter</p>
</blockquote></li>
</ul></li>
<li><blockquote>
<p>Out</p>
</blockquote>
<ul>
<li><blockquote>
<p>Pseudomatter</p>
</blockquote></li>
</ul></li>
</ul></th>
</tr>
<tr class="odd">
<th></th>
<th></th>
</tr>
<tr class="header">
<th></th>
<th></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Spark

Flux

Matter

Pseudomatter

Sludge

Chunks

Gel

Filament

Nanites

Endo

Exo
