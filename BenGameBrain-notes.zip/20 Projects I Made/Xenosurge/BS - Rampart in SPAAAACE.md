---
title: "BS - Rampart in SPAAAACE"
source: "Game Stuff/Game Ideas/BS - Rampart in SPAAAACE"
modified: 2020-12-11
type: design-doc
area: past-project
status: "built/shipped"
projects: ["[[Xenosurge]]"]
concepts: ["Xenosurge"]
words: 296
summary: "Design/spec for a Rampart-style space game; says it is already made as Xenosurge. Covers rules, phases, units, tech and graphic requirements, themes."
tags: ["area/past-project", "project/xenosurge", "type/design-doc"]
---

Already made this

http://binarygambit.itch.io/xenosurge

Rules

Survive a number of rounds

die if you cant encaspulate a castle

score based on territory and kills

two campaigns; beginner and veteren

4 maps in each

two player option on same screen

Phases

Selecting starting castle

Place Cannons

Fight phase

Shoot cannons

Building Phase

Place Walls

Place cannons

goto Fight Phase

Tetris building

random blocks

area encapsulation

dags shaved off

cannons

“one bullet at a time” fire rate

can shoot own walls “cleaning”

ballons

takes over one ship

single use

costs 3 cannons

megacannon

fires fireshot

makes craters

kills ships all in one shot

costs 4 cannons

enemies

normal ship

troop ship

troops/cannons

move towards castles

block building

tear down castles

3 shots to kill

fire ship

fire craters - from own super cannons

cannot build on craters

> fast
>
> 4 shots to kill

Technology requirements

map generator/storage (arrays)

enemy spawner

random piece generator

enemy behavior (very simplistic, randomly move one tile)

GUI Requirements

mouse cursor

shows when a cannon is available

peice shape overlay

cannons left to place overlay

OPTION: kind of shot to be fired next

Menu

Campaign/mission select

Victory and Defeat screens/indicators

Splash screen/intro

Tutorial popups

building overlay/holographic placement guide thingo

Graphical requirements

3 ship types

8 facings

death animations

damage animations

3 normal cannon types

8 facings

1 megacannon

8 facings

1 baloon

single sprite

1 normal castle

1 claimed castle

1 hut

wall tilemap

“facings”

damaged variants

terrain

land/water

fire craters

flags for player ownership

mouse cursor

3 states

troop/cannon

4 facings

cannonball animation

water strike

Thematic Options

Space ships/aliens

Missiles for cannons

defend a space station

with missile turrets

Asteroid base

firecontrols for castles

Ground Based sci-fi

Islands in the sky

steamships come to attack

Things we feel are nessesary

Countdown timer
