---
title: "KenneyJam 2021"
source: "Game Stuff/Game Ideas/KenneyJam 2021"
modified: 2021-08-28
type: planning
area: jam
status: "idea"
projects: ["[[Game Jams]]", "[[Playdate & Small Games]]"]
concepts: ["KenneyJam 2021", "Rotation Puzzle Ideas"]
words: 114
summary: "Jam notes for KenneyJam 2021 (theme Rotation): ideas, an FPS walking sim technical plan and Kenney asset pack choices."
tags: ["area/jam", "project/game-jams", "project/playdate-small-games", "type/planning"]
---

KenneyJam 2021

Theme: Rotation

- Dominos City

- Polar coordinates 2048

- 2048 but the game rotates after every temporary wall placement

- Change Gravity direction

FPS Walking Sim

Phase 1:

FPS Controller

Raycast click to interact on the thing you are looking at

IInteractable interface

ITrigger Interface

ITriggerable Interface

Indicator

Phase 2:

Tween animations

Highlighting for interactive things

Phase 3: Nice to haves

Lighting setup/day night cycle

| 3d Environment    | 2d Actors        |
|-------------------|------------------|
| castle-kit        | Toon characters  |
| Pirate pack       | Pirate pack      |
| Space pack 3d     |                  |
|                   | Cartography pack |
| City kit suburban |                  |
|                   | Simple space     |

Monochrome rpg

https://kenney.nl/assets/monochrome-rpg
