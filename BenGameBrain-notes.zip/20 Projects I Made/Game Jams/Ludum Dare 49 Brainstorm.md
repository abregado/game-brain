---
title: "Ludum Dare 49 Brainstorm"
source: "Game Stuff/Game Ideas/Ludum Dare 49 Brainstorm"
modified: 2021-10-02
type: brainstorm
area: jam
status: "idea"
projects: ["[[Game Jams]]"]
concepts: ["Ludum Dare"]
words: 621
summary: "Round 1 theme-interpretation brainstorm for Ludum Dare 49 (Unstable), a large categorised list of angles."
tags: ["area/jam", "project/game-jams", "type/brainstorm"]
---

Ludum Dare 49 Brainstorm

Theme: Unstable

Round 1 - Theme interpretations

- Logistics

  - Forklift driving

  - Stacking boxes

- Chemical

  - Atoms

  - Atomic decay

  - Molecules in unstable configurations

- Mentally unstable

  - Manipulate things in a scene to drive a character crazy/angry/mad (Murphys Law games)

- How to use instability to make something constructive?

  - Using unstable objects that fall into a useful pattern

- Aeroplanes (WW1)

  - Biplane/Triplanes

  - Fixing a plane while it is gliding to the ground

- Do we try to stabilize a situation?

- Do we try to destabilize a situation?

  - Creating an omelette by breaking eggs

- Both stabilize and destabilize two objects to win

  - Stabilizing on one side makes the other side unstable.

- Political unstable

  - You control a rebel group. Keep the morale high while destabilizing the moral of the government.

  - Moving agents to accomplish the task.

- Liquid Flow

  - Erosion causing instability

- Bomb defusal

- Bomb construction

- System simulation, with downward spiral. Spinning plates game.

  - Do you make it stable or unstable?

  - Remove components to keep the plates spinning.

  - All tools the player has have side effects.

  - Turn based.

- Liquid puzzle flow

- Balance table game. Arctic Shipwreck.

- Reverse Climate Change lolgame

- System creates a stable loop but it is broken. Coax it back into equilibrium.

  - Or try to make a stable loop become unstable.

- Medically unstable (or un-stab-le)

  - Fix up patients before time is up/they bleed out/etc?

- Unstable architecture:

  - Unstable jump platforms, both break down and/or loose?

  - Stabilize Architecture with structure beams

- Character

  - Violent

  - Indecisive

  - Falling apart

  - Delusional

  - Body unstable (like Akira or Zombie)

  - Weight

  - Beliefs

  - Mentally

- Environment

  - Ground disappearing

  - Ground appearing

  - Earthquakes

  - Flooding/Tides

  - Unstable biosphere

  - Thin ice

  - Volcanos

  - Storms

- Enemies

  - Ambush

  - Morale

  - Supply lines

  - Zombies

  - Ethereal

  - Elemental

  - Exploding

  - Emotional

  - Suicidal

  - Reaching equilibrium

- Balance/Weight

  - Scale

  - Jelly

  - Tightrope

  - Water buckets

  - Vectored Thrust

  - Uneven thrust

  - Lever

  - Slinky

  - Aerodynamic

  - Vortex

  - Seesaw

- Chemically

  - Exploding

  - Catalyst

  - Oscillation

  - Spontaneous

  - Equilibrium

  - Decompose

  - Accrete

  - Radioactive decay

  - Flux

  - Volatile

  - Chain reaction

  - Bens Stomach

  - Indigestion

- Feedback loops

  - Sinewave

  - Noise

  - Resonance

  - Asymptote

  - Amplification

  - Runaway greenhouse

  - Gravitational collapse

  - Grey goo

  - Von Neumann Machine

  - Overpopulation

- Horses are unstabled

  - Horses are in the stable

  - Horses are not in the stable

  - Horses are in a quantum state/superposition

  - Sabine Horsenfelder

  - Ernest Pferderford

  - Werner Horsenberg

  - Richard Neighman

- Vacuum Decay

  - Escape from it

  - Cause it

  - Smooth it out

  - Fence it in

  - Reverse it

- Unstable Children

  - Tantrum

  - Bad at balancing

  - Falling off the merry go round

  - Dizzy

- Ships at sea

  - Sliding on the deck

  - Seasick

  - Navigation

  - Ballast

  - Collisions

  - Shipwreck

  - Ship sinking

- Architecture

  - Tower of Pisa

  - Tower of Babel

  - Foundations

  - Scaffolding

  - Bridges

  - Dams

  - Columns

  - House fire

- Politics

  - Revolution

  - Mutually assured destruction

  - Brinkmanship

  - Destabilization

  - Bismarckian diplomacy

  - Mutually exclusive views

- Evolution

  - Mutation

  - Dead End

  - Feast and Famine

  - Competing Pressure

  - Coevolution

  - Unexpected Trait

- Unstable Trajectory

  - 3 body problem

  - Decaying Orbit

  - Aerobraking

  - Station keeping

  - Career trajectory

  - Civilization trajectory

- Medically unstable

  - Bleeding

  - Shock

  - Arrhythmia

  - Circadian
