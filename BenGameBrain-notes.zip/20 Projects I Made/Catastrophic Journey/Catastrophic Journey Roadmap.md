---
title: "Catastrophic Journey Roadmap"
source: "Game Stuff/Game Ideas/Catastrophic Journey Roadmap"
modified: 2021-10-07
type: planning
area: game-idea
status: "prototyped"
projects: ["[[Catastrophic Journey]]"]
concepts: ["Catastrophic Journey"]
words: 259
summary: "Roadmap for the Catastrophic Journey tile game: warning tiles, food bar, car/fuel mode, farm and road tiles, visual effects, feedback and UI."
tags: ["area/game-idea", "project/catastrophic-journey", "type/planning"]
---

A new set of “intermediate” tiles. Each one shows that next turn a tile will change. These go “on top of” regular tiles.

- A Meteor approaching tile (A Meteor will land here next turn)

- A Crater dirt wave tile (Crater dirt will expand here next turn)

- An almost erupting Volcano (Lava will appear next turn)

- A Lava fountain (Volcano will appear here next turn)

- Earthquake (The tile will fall away next turn)

- Small swarm (A locust swarm will appear here next turn)

Food bar

- 10-15 Apples in a bar

- Each move one drops off

- If you reach zero then your health drops and the apples fill up

- Reaching a town fills health AND apples

Car/Fuel

- A fuel gauge with 1-3 fuel tanks (Starts at zero)

- A car tile. Landing on it fills your fuel gauge and swaps you to car mode

- Each move consumes fuel (and food)

- Your movement speed increases

- Tiles have isDrivable. Water and Hills are no longer crossable

- A button for “get out of car”

New Tiles

- Farm Tile (fill your food but not your health)

- Road (costs 0.5 tiles)

Visual Effects

- Tweening the character between walk positions

- Camera follows smoothly (Cinemachine)

Better indication

- Damage sound

- Ambient noise when low on food

- Ambient noise when low on health

- Flashing UI when low on health

- Distance to Escape counter

- Hover information for tiles

UI

- Press key to start splash screen
