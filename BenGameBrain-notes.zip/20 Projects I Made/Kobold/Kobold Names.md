---
title: "Kobold Names"
source: "Game Stuff/Kobold Names"
modified: 2024-07-01
type: reference-data
area: game-idea
status: "idea"
projects: ["[[Kobold]]"]
concepts: ["Kobold"]
words: 304
summary: "Lists of candidate names for Kobold characters (snail dude, cold dude, miner, mechanic, trios of miners)."
tags: ["area/game-idea", "project/kobold", "type/reference-data"]
---

## Sheet: Sheet1

| Snail Dude | Cold Dude | Miner | Mechanic | 3 Miners |
|---|---|---|---|---|
| Snarkles | Rosa | Archibald | Smelty | Klink, Klenk, Klank |
| Snek | Evelyn | Minter | Rusto | Noik, Oik, Koiq |
| Pippi | Snu | Oswald | Jax | Dingus, Bingus, Fred |
| Rowan | Snox | Miney | Wox | Ned, Schmitt, Jochen |
| Lornn | Lenny | Ned | Troyn | Bob, Rob, Noaquim |
| Greta | Vik | Bob | Tex | Rink, Tink, Dink |
| Burgle Backpack | Snowy | Ralf | Adam | Lenny, Kenny, benny |
| Strubby | Cozy | Eduardo | Reginald | Die Karls |
| Snorly | Perry | Dink | Smith | Pick, Tick and Jewel |
| Sweet | Nyx | Ory | Steve | Tick, tikk, Tack |
| Markus | Koolby | Axel | Beryl |  |
| Slink | Evelyn | Quelm | Axel |  |
| Snail | Suzan | Deryl | Seamy |  |
| Slugger | Snow | Olli | Doug |  |
| Nox | Hornet | Dusty | Blue |  |
| Snuggles | Ponki | Poppy | Darx |  |
| Strawy | Peanut | Teemt | Cashew |  |
| Wick | Conrad | Bernd | Kel |  |
| Rick | Brigite | Scrimblo | Jaron |  |
| Weed | Pederle | Mina | Schraube |  |
| Bubi | Frosta | Schmutz | Irony |  |
| Bobb | Frosty | Gigi | Carl |  |
| Steward Snail | Ski | Almond | Peter |  |
| Yas | Sky | Elmo | Torsten |  |
|  |  | Dingelhoper |  |  |
|  |  | Karli |  |  |
