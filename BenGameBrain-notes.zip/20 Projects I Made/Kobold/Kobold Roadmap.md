---
title: "Kobold Roadmap"
source: "Game Stuff/Kobold Roadmap"
modified: 2024-10-24
type: planning
area: past-project
status: "designed"
projects: ["[[Kobold]]", "[[Game Business & Funding]]"]
concepts: ["Kobold", "Kobold Carry Quest System", "Kobold Collectables", "Game business & funding"]
words: 715
summary: "Month-by-month Kobold post-demo roadmap (months 1-10) with budgets in PT/TD, plus design notes for the Kobold Carry Quest system, firefly catching, collectables, bubble and magnet biomes."
tags: ["area/past-project", "project/game-business-funding", "project/kobold", "type/planning"]
---

### Month 1

Work on cleaning up the UX for Switch, adding localization and building the environment workflow for future content.

### Month 2

Add in Mouse support. Automate the build process, so BHI can have weekly builds. Experiments for visual upgrades yield results.

### Month 3 - STEAM DEMO! (EA if we want)

Save/Load progress for the Demo. Environment art for the existing biomes. Animated Kobolds workflow design. Process completed for a single kobold. Demo available on Steam and Itch.

### Month 4 - New Mechanic

Kobolds can be carried and they give you quests when they are in your ship. First new biome is blocked out and playable in the dev branch. Kobolds can also talk (text dialog) to the player to give them information about what to do.

### Month 5 - New Mechanic

First new Biome gets its environment art. All quests from the demo are swapped to the Kobold Karry system. New animated kobolds for all quest givers. New mechanic: Watering can/ Ember shard.

### Month 6 - New Biome 1

Collectable system begun.The systems that allow players to uncover collectable items in each biome using each mechanic are set in place. New kobold buildings in the hub area that mimic existing game mechanics (wind, explosions, ect). Finally the game gets harder as the player progresses. Another new biome is blocked out and playable in the dev branch.

### Month 7 - New Biome 2, New Mechanics x2

The second new biome has environmental art. Actual collectable content for each biome is put in the game. New mechanics: Relic holders and Physics puzzles.

### Month 8 - New Mechanics x2

Third new biome is blocked out and playable. New mechanics: Eyebug teleporter and Bubbles.

### Month 9 - New Biome 3

Final mechanics: Fireflies and Magnets. Final big environmental element. Collectables get their art.

### Month 10

Biome 3 Environment art completed. Polish across all biomes.

**Runway - 20 PT**

Steam achievements

Bug fixes

**Cleanup (Design and Code) - 20 PT**

Controller based Editor controls

Mouse based Editor controls

Mouse flight

**Graphics update - 64 TD**

Textures like Tatjanas drawings “not quite flat color”. Shader?

Animated Kobolds

Speech bubbles

Environment art workflow - 5 TD

Everything is brighter and more colorful

**New Art - 96 TD**

4x Content Unit Production art - 12 TD

4x Biome unique object - 12 TD

4x Biome concepts - 12 TD

**Design + Code - 40PT**

4 Content units - 10 PT each

Design

Code

Placeholder graphics

Biomes, each with an obstacle/part combination.

Bubble Biome.

Stay in the bubbles as they move around, otherwise you get teleported to the start area.

Magnet Biome - 2PT 4PT

Same as the Windy Biome but the “wind” can attract or repel, and the magnets cycle between on and off. Only metal objects are affected.

Content/Mission Units

Kobold Carry Qwest system

This lets the player pick up a Kobold character. The Kobold will use his hand to point towards where he wants you to go. The Carry takes up a button slot, which is used to continue and skip during dialog.

The Kobold could also be used to show how many items you have collected during a collection mission. The Kobold could carry a bag instead of pointing.

Resetting ship position will return the kobold to his “home” location.

Holding the Carry button will drop the kobold with a parachute, and it will teleport home if left for 30 seconds or more.

Firefly Catching.

Vacuum and canister parts. Suck up Fireflies when you fly over them. When you bump the canister, then they escape again.

Fireflies move away from fast moving objects.

Lure part. Attracts fireflies more strongly.

Collectables

Each mechanic used in a quest should also be usable to unlock collectables from spots across the map.

Drill spots.

Bring a drill, drop it on the spot, then come back later for your reward. Bring the Miner Kobold to crack the unearthed geode.

Plant bulbs.

Using the Watering can object, bring water multiple times. Once ripe, bring the Farmer Kobold for your reward.

Firefly Caves

Bring enough Fireflies in a canister, then bring the Farmer kobold for your reward.

Relic holders

Bring one of the larger unique objects here, then bring the Mechanic kobold here for your reward.
