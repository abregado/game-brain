---
title: "Kobold Kickstarter"
source: "Game Stuff/Kobold Kickstarter"
modified: 2024-03-04
type: planning
area: game-idea
status: "idea"
projects: ["[[Kobold]]", "[[Game Business & Funding]]"]
concepts: ["Kobold", "Kobold Kickstarter", "Game business & funding"]
words: 201
summary: "Kickstarter planning for Kobold: 50k goal, 100 dollar pledge tiers, stretch goals up to 300k (localization, touch, network multiplayer) and detailed asset/feature lists."
tags: ["area/game-idea", "project/game-business-funding", "project/kobold", "type/planning"]
---

KS Goal: 50k

Pledges

- 100\$: Choose a body type from 15 (limit to 3-5 spaces)

- 100\$: Give a 2 word description of a Kobold that will appear in the game (limit to 3-5 spaces)

- 100\$: Choose a human object that the kobolds will find in the underground (limit to 3-5 spaces)

Content at project cost

50k

55k

Localization German/French before release

60k

65k

Touch controls / Tablet, Android, iOS support

100k

Features

- 5 mechanics for parts

- 2 new engine styles

- +5 hull pieces

Assets required

- +10 functional parts or obstacles

- 10 unlock missions for those parts

- 20 challenge missions (2 per part/obstacle)

- 10 multipart challenge missions

- 5 biomes (3 we have, +2)

- 5 biome unique objects

- 10 environment decoration objects (2 per Biome)

- 5 objects that can be found in every biome

- 5 unique quest givers

- 5 unique structures for quest givers, including progression prefab

- 10 new kobold structures that expand into the cave

- 4 generic construction meshes for those structures

UI/UX

- 3 profile save system and UI

- Collectables sticker book Screen

200k

300k

Network Multiplayer, Demo can join hosted games
