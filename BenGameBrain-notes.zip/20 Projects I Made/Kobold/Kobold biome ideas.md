---
title: "Kobold biome ideas"
source: "Game Stuff/Kobold biome ideas"
modified: 2026-08-12
type: brainstorm
area: past-project
status: "idea"
projects: ["[[Kobold]]"]
concepts: ["Kobold", "Kobold Biomes and Mechanics"]
words: 112
summary: "Short notes on Kobold biomes: each area has a kobold giving a new part after local quests, plus a drainage pipe area with valves and blockages."
tags: ["area/past-project", "project/kobold", "type/brainstorm"]
---

Kobold biome ideas

Each area has a kobold who will provide a new part after completing their local quests.

Local quests might require items from outside the biome.

The special biome specific parts are only available from the biome originally.

Landing at a local with a part makes it build able at the landing pad.

Player spread new parts as they fly around and land at new places .

Generally, the new biome part allows access to a new biome.

Drainage Pipe area.

- One way valves

- Broken Pipes leading to shortcuts

- Blockages by roots. Bring object near to open.

- Place objects on buttons to change water levels

Obstacles
