---
title: "Emerge last jam"
source: "Game Stuff/Emerge last jam"
modified: 2023-06-10
type: planning
area: jam
status: "prototyped"
projects: ["[[Emerge]]"]
concepts: ["Emerge"]
words: 27
summary: "Short to-do list for the Emerge jam submission: start screen, bug report button, quit button."
tags: ["area/jam", "project/emerge", "type/planning"]
---

Ending submission

Start screen

- Remove multiplayer pips, its just a single player game for now.

Bug report button

Quick menu

- Quit button just quits application
