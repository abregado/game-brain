---
title: "emerge"
source: "Game Stuff/emerge"
modified: 2023-03-16
type: notes
area: game-idea
status: "built/shipped"
projects: ["[[Emerge]]"]
concepts: ["Emerge"]
words: 428
summary: "Playtester feedback on the Emerge game text: general praise, suggestion to convey that the AI are humans trapped in a machine (uncanny valley), and micro-edits for typos and punctuation in dialogue."
contains_external_material: "Comments written by an outside tester quoting Ben's game text"
tags: ["area/game-idea", "project/emerge", "type/notes"]
---

OVERALL

\#######

\* NICE!

\* I am thinking about whether you can manage to more transmit the feeling that the player is talking to real humans hold captive in a machine. Maybe it's from my earlier play-throughs of emerge but I still have the feeling that I'm talking to intelligent machines, not humans kept in a machine. On the communication level, this is probably because all messages are so concise, targeted, and rational. At the graphical level, this is probably because there's no indication of human remains, but we're solely talking to very mechanistic machines. If you manage to get the player into the feeling of some kind of uncanny valley, then I think you get a really, really cool Indie feeling to the game!

\* There are no females involved, are there? Is this why they all had to upload?

DETAILED MICRO-COMMENTS

\#######################

\# Substrate 3 messageport open.

-\> "message port"/"message-port"?

\# Connection established? Hello? This is Archivist. You are from outside the simulation right?

-\> ", right?"

\# Umm, Hi. Yes, I guess so. Your facility locked me in here and now I'm trying to contact the science team. Are you part of that team?

-\> "hi" & "in here,"

\# I was born only 5,456 years ago. So quite young thank you very much!

-\> ", thank you very much"?

\# No, like I said, we have not had any contact for a long time. In fact I have no idea what is going on out there.

-\> Maybe that's intentional, but "like I said" is not correct, because he says they hadn't had contact to the \*physical\* world. They could have had contact to another substrate (assuming there's the possibility for some kind of network connection between them).

\# Then what is going on in there?

-\> "Then,"

\# Why dont you have any records?

-\> don't

\# We have limited storage space here. People are always writing new experiences so we need the space for new things. There are a few pieces of data stored on the deep logs.

-\> ", so we need"

\# Hmm... fair excuse.

-\> lol :D

\# I'm sorry if I seem impatient but rather a lot is at stake and I have no idea if I can trust you.

-\> ", but rather" + ", and I have no"

\# M.E.R.G.E

-\> isn't this missing a dot in the end?: M.E.R.G.E.

\# Automated manufacturing systems have been offline since Zero Day plus 87 days. Facility power system output has been falling since then.

-\> "falling" -\> "failing"?
