---
title: "HLC - Not Emerge"
source: "Game Stuff/Game Ideas/HLC - Not Emerge"
modified: 2021-07-15
type: pitch
area: game-idea
status: "designed"
projects: ["[[Emerge]]", "[[Coop Station]]", "[[Game Business & Funding]]"]
concepts: ["Emerge", "Coop Station", "Game business & funding"]
words: 688
summary: "Concept document for 'Not Emerge', a cooperative round-based builder for 2-4 players with forecasted challenges and an abandoned-surface mystery, originally for Sandmonger games; includes market, tech and development plan."
tags: ["area/game-idea", "project/coop-station", "project/emerge", "project/game-business-funding", "type/pitch"]
---

# Concept Document

# 

# 

# 

# 

# **Not Emerge**

Cooperative round based builder for small groups

Originally by Ben Buckton, created for Sandmonger games.

###  

### Player Story

You, a group of friends from a reclusive underground civilization, choose to explore the forbidden surface. Step by step you overcome the dangers of the overworld by building yourselves an outpost. Later, you explore the planet to learn about why everyone has left, what their motivations were and about your inner selves.

### Background

Colony builder games rely too heavily on surprise events to generate conflict. This project aims to create strategic challenges through forecasted events, instead of surprise.

I also see a market for games which small groups of friends (2-5) would enjoy playing together over an entire playthrough.

### Key Features

| Plan for your future: There are no sudden random challenges, instead you always have several rounds of notice so you can plan your response. |
|----------------------------------------------------------------------------------------------------------------------------------------------|
| Cooperative: Invite your friends for a few rounds, or plan to play the game through with a consistent group.                                 |
| Uncover a mystery: You and your crew will need to explore and expand to find out what happened on the surface and why it is abandoned.       |
| Relaxing and Non-violent: Play focuses on building and developing your creation. This is not a game about fending off hordes of aliens.      |
| Feature 5:                                                                                                                                   |

### Genre and Theme

The game is real time but played in rounds of around 10 minutes. The minute to minute gameplay involves setting up machines to expand the outpost, tending to those machines and then packing everything up before the round ends.

The game should be relaxing, and light hearted. The characters are in no danger. The player built environments are friendly, and the explorable areas should be eerie but not fear inducing.

By focusing on streamlined controls and user experience early in the development, I hope that the game will be more intuitive than other titles in the Building genre.

### Technology

The project will be built using the Unity engine due to developer familiarity. Access to pre-made high quality assets will also allow the project to be jump-started very rapidly.

### Platform

Initially the product would be made available only on Windows PC. Early player engagement is essential for any new project and PC players tend to have higher hours per game title. The gameplay interactions themselves should be simple enough that mouse and keyboard are not required, so other platforms would be considered later in the development cycle, assuming crossplay is an option (as multiplayer is a priority). Linux and Mac are both options as well, but require more support, which we may not have the resources for.

### Market

Our target audience is the subsection of builders who also like to share their creations, either through screenshots, or by inviting friends to participate. Builder players like when they can invest in a project long term and we target those that want to do so with friends.

Our future players are currently playing games such as Stardew Valley, Rimworld, Space Engineers, Stationeers, Astroneer and Space Station 13.

### Development

Development will consist of a 6 month proofing phase, followed by 12 month to get the project to a crowd fundable level. The team already consists of a programmer and a jack of all trades. The bulk of the non-programming roles can be filled by this jack of all trades. This includes: Project management, community management, campaign moderation, marketing, human resources, content scripting, user interface and initial placeholder art. An artist would only be hired after the initial 6 month phase.

### Design Pillars

The sacred axioms. Design choices will not be considered if they violate these.

| **Small groups.** Sure, you can play single player. The game is however designed for 2-4 players with fluctuating player count in each round.                |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **No sudden danger.** The player is never surprised by a randomly generated challenge. They always see challenges coming and have several rounds to prepare. |
| **Building focus.** Solve problems by building your outpost.                                                                                                 |
