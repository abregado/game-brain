---
title: "Laser Projects"
source: "Game Stuff/Non-Game Ideas/Laser Projects"
modified: 2020-12-12
type: idea
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]", "[[Kill Team & 40k Homebrew]]", "[[D&D Homebrew]]"]
concepts: ["Laser Cutter Projects", "Kill Team homebrew", "D&D house rules"]
words: 53
summary: "Short list of laser-cutter project ideas for tabletop games: Kill Team objective bases, D&D tokens, props, class sets, cards, and a six-player Sorry board."
tags: ["area/non-game", "project/d-d-homebrew", "project/kill-team-40k-homebrew", "project/non-game-projects", "type/idea"]
---

Kill team objective bases that fit the number token underneath.

DnD spell slot tokens

Hitpoint counters

Inspiration tokens

DnD props for magic items

- Ring

- Sword

- Shield

- Armor

Attunement token

Class sets with all subclasses and options

Tarot decks

Spell cards

Abilities

Magic items

Magic item history

6player sorry board
