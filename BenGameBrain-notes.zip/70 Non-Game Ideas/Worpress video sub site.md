---
title: "Worpress video sub site"
source: "Game Stuff/Worpress video sub site"
modified: 2022-07-13
type: notes
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["WordPress Video Site"]
words: 17
summary: "Tiny checklist for a WordPress video site: hosting with plugins and cron, WP Automatic plugin, YouTube API key."
tags: ["area/non-game", "project/non-game-projects", "type/notes"]
---

Wordpress running and hosted

Host with plugins and cron job

Allinclusive.com for hosting

[*https://wpautomatic.com/*](https://wpautomatic.com/)

Youtube API key
