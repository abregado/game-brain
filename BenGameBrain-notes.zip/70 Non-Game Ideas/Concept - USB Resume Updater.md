---
title: "Concept - USB Resume Updater"
source: "Game Stuff/Non-Game Ideas/Concept - USB Resume Updater"
modified: 2013-06-12
type: pitch
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["USB Resume Updater"]
words: 409
summary: "Concept paper for a tiny USB-stick app that shows a locally stored resume or downloads the latest version from the internet."
tags: ["area/non-game", "project/non-game-projects", "type/pitch"]
---

Concept

Resume and Folio USB-Key Updater

Drafted by Ben Buckton

**Table of Contents**

Description 2

Goals of the Concept 2

Cost to User 2

Marketing 2

Storage Requirements 2

Uses for the program 3

Release Features 3

Planned Features 3

Potential Problems 3

# Description

A small application run from a usb thumb drive. It simply prompts the user to select from two options. To view a locally stored resume or download a more recent copy from the internet. When the option to download is selected, it updates the file that is stored locally.

For when information in digital format needs to be given physically and stay up to date. Original concept was to be used for updatable resume and folio to hand to employers and to be stored on a fancy thumb drive (See: <http://www.dynamicgift.com.au/> )

# Goals of the Concept

The application should:

- be no larger than 32 meg as to fit on mass produced cheap thumb drives

- allow multiple different file formats to be used

- offer a simple interface

- support file downloads larger than the usb size, stored locally

- single executable

# Cost to User

The software should be released as open-source and as such, is completely free to the user.

# Marketing

Opportunities for cross platorm marketting exist. By making the product compatible with popular file sharing webstes (Rapidshare, Wetransfer, ect) we could market our product (however free) to many people.

# Storage Requirements

The coders of the software are not responsible for where the users files are stored however at release the following transfer protocols should be supported

- Direct link (HTTP)

- FTP

# Uses for the program

- Resume updater

- Users who want to give out a physical object by digital media

- Updatable Photo/Video Momento

- Audition tape (audio/video)

# Release Features

- GUI to edit the menu options and download loaction

- Interface to set up FTP account (encrypted)

- Ability to set the software into read only (moving ability to edit options)

- Single executable file

- Software should run in “Offline mode” unless the user selects to update

- Multiple links available on menu

- Each file can be updated to the usb key or downloaded to the local computer

- Menu can include lcoally stored media (photo for background)

# Planned Features

- Menu can be made updatable

- Menu can support embedded objects (Flash, Unity Player, ect)

# Potential Problems
