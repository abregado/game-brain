---
title: "Favorite German Words"
source: "Game Stuff/Non-Game Ideas/Favorite German Words"
modified: 2024-08-14
type: notes
area: non-game
status: "unknown"
projects: ["[[Non-Game Projects]]"]
concepts: ["German Learning Notes"]
words: 186
summary: "Short list of favourite German words plus notes on noun gender and plural rules."
tags: ["area/non-game", "project/non-game-projects", "type/notes"]
---

## Ben’s favorite german words

Sofort

Flauschig

Eselsbrücke

Schmutz

Smölln

Also on Trello

#### Nouns with -ion, -taet and -ie are latin and always feminine

Nouns that end -ument are always neuter

Seasons, Times of Day(except die Nacht), Weekdays, Directions, Months, Alcoholic Drinks (except das Bier) are always masculine

Flowers and Plants are mostly Feminine

Nouns with -ung, -heit, -erei, -tur are always feminine

Nouns with -ismus and -ling are always masculine

Diminutive Forms, Nouns with -chen or -lein are always neuter

Compund Nouns always take the gender of the last part

Sometimes s or n is inserted between the parts

Pluralization

Most feminine nouns add -n, -en, -nen

many Nouns ending in -er or -en have no ending added

many nouns change the vowels a, o, u to ae, oe, ue

many one syllable words add -e or -er and add an umlaut

weak nouns that dont end in a sharp ending take -en or -n

Foriegn words and those ending in a, i, o just add s

Latin or Greek words ignore this rule and often have special cases ( das Motto, die Motti)
