---
title: "Is Capitalism anti-Species"
source: "Game Stuff/Non-Game Ideas/Is Capitalism anti-Species"
modified: 2021-06-26
type: notes
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["Capitalism and Society Discussions"]
words: 23
summary: "Three-line stub of theories about capitalism and species-wide progress."
tags: ["area/non-game", "project/non-game-projects", "type/notes"]
---

Is Capitalism anti-Species?

Theories

Capitalism promotes us staying in Survival mode

Capitalism does not promote species wide progress

Capitalism promotes scarcity not abundance
