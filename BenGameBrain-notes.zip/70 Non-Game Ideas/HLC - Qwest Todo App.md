---
title: "HLC - Qwest Todo App"
source: "Game Stuff/HLC_ Qwest Todo App"
modified: 2024-08-22
type: pitch
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["Qwest Todo App"]
words: 259
summary: "Concept for a gamified to-do app where streaks earn coins spent on art items for a custom world; monetisation via artist revenue cut, weekly free blueprints and premium currency."
tags: ["area/non-game", "project/non-game-projects", "type/pitch"]
---

**Concept**: A sorted list of to-dos. Sorted by urgency. Detailed options for making todos repeatable, and when exactly they can be checked off. Completing streaks unlocks coins, which are spent on artwork items for a custom environment filled with characters. Each instance of an item saves its streak data, and can be displayed in a trophy case in the user's world.

Users are offered weekly free items if they associate it with a task, and get to keep the “blueprint” if they build a small streak.

**Monetization**: We get a cut of art sold to users. Artists choose the cut they send to us. The higher the cut, the more we promote their work.

**Community object sales:** Artists create sets of items. One item from each set is put into the free pool (artists choice). One of these free items is available to users to add to their blueprint collection each week. These blueprints are temporary, unless the user creates a task with them.

Items can also have streak states, which change the appearance of an item instance after the user completes a streak with the item instance. These can either be a mystery or shown in the store. The artist decides on how long each streak needs to be to unlock the next state.

Art sets need to be reviewed by our team before going live.

Users can use the app for free, getting new blueprints via the weekly free pool. They can also purchase permanent blueprints, and new slots to place task items in for premium currency.
