---
title: "steam dating"
source: "Game Stuff/Non-Game Ideas/steam dating"
modified: 2014-10-11
type: idea
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["Steam Dating Site"]
words: 6
summary: "One-line idea: a dating website based on Steam profiles."
tags: ["area/non-game", "project/non-game-projects", "type/idea"]
---

Dating website based on steam profile
