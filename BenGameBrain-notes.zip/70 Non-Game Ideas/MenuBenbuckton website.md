---
title: "MenuBenbuckton website"
source: "Game Stuff/MenuBenbuckton website"
modified: 2024-06-06
type: brainstorm
area: non-game
status: "idea"
projects: ["[[Non-Game Projects]]"]
concepts: ["Menu Website"]
words: 93
summary: "Brainstorm of a personal menu website listing vegan breakfast, dinner and dessert recipes plus a support page."
tags: ["area/non-game", "project/non-game-projects", "type/brainstorm"]
---

Menu.BenBuckton.com

Brainstorming

## Menu page

### Breakfast

Pancakes

Puffs

Overnight Oats

Fruit Medley and Peanut Butter Bread

### Dinner

Spicy Ramen

Peanut Coconut ramen

Ramen options

- Egg/No Egg

JashMash

- Spinach

- Vegan Schnitzel

Rosemary Roast potatoes and Zucchini

Vegan Senfrahm with Mushrooms

- Pasta

- Potatoes

Green Curry Vegetable Rice

Wirsing Walnut Pasta

Loaded Nachos

Chinakohl Noodle Slaw

Cold Cucumber Soup

Apple Parsnip Soup

Bohnenkraut Beans and Potato

Red wine Goulash

Sambal Olek Quickrice

Hotpot rice with Tofu

### Desserts

Apple Cake

Blueberry Muffins

Brownie

## Support pages

Supermarket Vegan explanation
