---
title: "Indie Portfoilio Website"
source: "Game Stuff/Non-Game Ideas/Indie Portfoilio Website"
modified: 2015-12-17
type: design-doc
area: non-game
status: "designed"
projects: ["[[Non-Game Projects]]", "[[FDnD Campaign (Frankfurt)]]"]
concepts: ["Indie Portfolio Website", "Game Dev Meetup Frankfurt"]
words: 379
summary: "Requirements and views for an indie developer link-aggregator site organised by city subdomain, with data fields and a long list of candidate domain names."
tags: ["area/non-game", "project/fdnd-campaign-frankfurt", "project/non-game-projects", "type/design-doc"]
---

Requirements:

- Devs can add and modify their game entries

- shows in-progress commercial projects

- users can list themselves as jammers and link to games

- People are separate, each can have games associated

- Games track who has been working on them

- This is a link aggregator, not a distribution or blogging platform

- subdomains to point to geographical data sets

- links to Meetup and communication for each location

- users can have multiple locations

Questions

- sort order based on last time user logged in or random?

- games associated with person or team? Teams of 1? confusing?

- requirement for refresh? Upload a new picture? just login?

- Timeout? remove from display if idle too long?

- how to deal with gamejams?

Screens/Views

- Location based view

  - Community Information (if any)

  - Finished Games (playable)

  - Chronological order of in progress and finished games (color coded?)

  - Local Developers portraits shown next to each project for linking

  - At bottom of timeline show larger portraits of active locals (activity is already apparent from portraits)

- Developer View

  - “Bio” view showing all personal links

  - List of projects in chronological order

Personal Information

- Name, Nickname

- Link to bio/information

- Skillset/Title created from tags

- Locations (can have multiple)

- Personal links (namable from tag list: Ludum Dare, Linked In, ect)

- Display links to teams and games in chronological order

- direct email, social media

- last logged in

Game Information

- Name

- Description (#tags for games or compos)

- Location overide (otherwise it is from the contributors)

- Owner (single person) These are indie games afterall

- Founded

- Link list (for website, press,videos, devblogs)

- images upload and display in gallery

- History of participants and accreditation (title)

- last update

Location Information

- link to Meetup organisation

- list of organisers/primary contacts

- link to communications

- 

Domain Ideas (must work with city name subdomains)

- indie.link

- indie.work

- indie-share.team

- localdev.guide

- entrylevel.guide

- entrylevel.link

- devfinder.link

- devfinder.guide

- devhub

- devmeet

- indiemeet

- indiedev.link

- indiedev.guide

- gamedev.guide

- devatlas.link

- indiedex.guide\*\*\* (also available as .com/.net)

- devsociety

- indiesociety

- indiehorde

- indiecrowd

- gameflock

- devquest

- indiequest

-
