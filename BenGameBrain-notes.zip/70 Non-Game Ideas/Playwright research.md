---
title: "Playwright research"
source: "Game Stuff/Playwright research"
modified: 2023-03-14
type: notes
area: other
status: "unknown"
projects: ["[[Non-Game Projects]]"]
concepts: ["Playwright Testing Research"]
words: 22
summary: "Brief notes on Playwright benefits for testing."
tags: ["area/other", "project/non-game-projects", "type/notes"]
---

**Benefits**

Cross Origin

But we don’t need it unless we can have data resets after every test run

Testing on mobile devices
